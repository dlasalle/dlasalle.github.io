/**
 * @file dlthread_pool.h
 * @brief A custom thread pool.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2015-01-17
 */




#ifndef DLTHREAD_POOL_H
#define DLTHREAD_POOL_H




#include "domlib.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


void dlthread_pool_init(
    size_t nthreads);


void dlthread_pool_finalize(void);


size_t dlthread_pool_add(
    void (* func)(void*ptr),
    void * ptr);


void dlthread_pool_wait(
    size_t task);




#endif
