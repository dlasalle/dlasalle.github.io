/**
 * @file dlthread.c
 * @brief Functions for thread communicators.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-12-05
 */




#ifndef DLTHREAD_C
#define DLTHREAD_C




#include "dlthread.h"
#include <omp.h>
#include <pthread.h>




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef struct comm_t {
  int in_use;
  size_t nthreads;
  size_t bufsize;
  void * buffer;
  pthread_mutex_t loc;
  pthread_barrier_t bar;
} comm_t;




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static size_t const __DEFAULT_BYTES_PER_THREAD = 128;
#define __MAX_NCOMMS 1024




/******************************************************************************
* VARIABLES *******************************************************************
******************************************************************************/


static pthread_mutex_t * ncomms_lock = NULL;
static dlthread_comm_t ncomm = 0;
static comm_t my_comms[__MAX_NCOMMS];
static __thread size_t my_ids[__MAX_NCOMMS];




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static void __config_comm(
    comm_t * const comm,
    size_t const nthreads)
{
  size_t maxthreads;

  comm->nthreads = nthreads;
  comm->in_use = 1;

  /* handle data types up to size 16 and round up to a power of two */
  maxthreads = size_uppow2(nthreads);
  comm->bufsize = size_uppow2((__DEFAULT_BYTES_PER_THREAD*maxthreads) + 4096);
  comm->buffer = malloc(comm->bufsize);

  pthread_mutex_init(&comm->loc,NULL);
  pthread_barrier_init(&comm->bar,NULL,nthreads);
}




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


dlthread_comm_t dlthread_comm_init(void)
{
  size_t nthreads;
  dlthread_comm_t cid;
  comm_t * comm;

  #pragma omp master
  {
    /* this first time this function is called, it should not be
     * simoultaeneously across thread teams */
    if (ncomms_lock == NULL) {
      ncomms_lock = malloc(sizeof(pthread_mutex_t));
      pthread_mutex_init(ncomms_lock,NULL);
    }
  }

  nthreads = omp_get_num_threads();

  #pragma omp master
  {
    pthread_mutex_lock(ncomms_lock);
  }
  #pragma omp barrier

  cid = ncomm;

  #pragma omp barrier
  #pragma omp master
  {
    comm = my_comms+ncomm;
    ++ncomm;
    __config_comm(comm,nthreads); 

    pthread_mutex_unlock(ncomms_lock);
  }
  #pragma omp barrier

  /* set my thread id for this communicator */
  my_ids[cid] = omp_get_thread_num();

  return cid;
}


dlthread_comm_t dlthread_comm_split(
    size_t group,
    size_t ngroups,
    dlthread_comm_t const comm_idx)
{
  size_t i, lid, cidx;
  size_t * tid;
  comm_t * lcomm;
  dlthread_comm_t * gcom;
  dlthread_comm_t cid;

  size_t const myid = dlthread_get_id(comm_idx);
  size_t const nthreads = dlthread_get_nthreads(comm_idx);

  DL_ASSERT(group < ngroups,"Invalid group %zu/%zu for thread %zu/%zu\n", \
      group,ngroups,myid,nthreads);

  gcom = dlthread_get_buffer((sizeof(dlthread_comm_t)*ngroups) + \
      (sizeof(size_t)*nthreads),comm_idx);
  tid = (size_t*)(gcom+ngroups);

  if (myid == 0) {
    /* number the new communicators */
    for (i=0;i<ngroups;++i) {
      pthread_mutex_lock(ncomms_lock);
      gcom[i] = ncomm++;
      pthread_mutex_unlock(ncomms_lock);

      my_comms[gcom[i]].nthreads = 0;
    }
  }

  /* I use an alarming number of barriers here -- someday reduce this */

  dlthread_barrier(comm_idx);

  cid = gcom[group];
  lcomm = my_comms+cid;
  tid[myid] = group;

  dlthread_barrier(comm_idx);

  if (myid == 0) {
    /* number the threads per communicator */
    for (i=0;i<nthreads;++i) {
      cidx = gcom[tid[i]];
      tid[i] = my_comms[cidx].nthreads++;
    }
  }

  dlthread_barrier(comm_idx);

  lid = tid[myid];

  if (lid == 0) {
    /* root for each comm */
    __config_comm(lcomm,lcomm->nthreads);
  }

  my_ids[cid] = lid;

  dlthread_barrier(comm_idx);

  dprintf("[%zu:%zu] new communicator %zu with %zu threads\n",myid,lid, \
      (size_t)cid,lcomm->nthreads);

  return cid;
}


void dlthread_comm_finalize(
    dlthread_comm_t const comm_idx)
{
  comm_t * comm;

  size_t const myid = dlthread_get_id(comm_idx);

  dlthread_barrier(comm_idx);

  comm = my_comms+comm_idx;

  if (myid == 0) {
    dl_free(comm->buffer);
    pthread_barrier_destroy(&(comm->bar));
    pthread_mutex_destroy(&(comm->loc));

    comm->in_use = 0;

    pthread_mutex_lock(ncomms_lock);
    if (comm_idx == ncomm-1) {
      --ncomm;
    }
    pthread_mutex_unlock(ncomms_lock);
  }
}


size_t dlthread_get_id(
    dlthread_comm_t const comm)
{
  return my_ids[comm]; 
}


size_t dlthread_get_nthreads(
    dlthread_comm_t const comm)
{
  return my_comms[comm].nthreads;
}


void * dlthread_get_shmem(
    size_t nbytes,
    dlthread_comm_t const comm_idx)
{
  void * ptr;
  comm_t * comm;

  size_t const myid = dlthread_get_id(comm_idx);

  comm = my_comms+comm_idx;

  DL_ASSERT(comm->buffer != NULL,"Null buffer on communicator %zu\n", \
      (size_t)comm_idx);

  if (myid == 0) {
    ptr = malloc(nbytes); 

    ((void**)comm->buffer)[0] = ptr;
  }

  dlthread_barrier(comm_idx);

  ptr = ((void**)comm->buffer)[0];

  dlthread_barrier(comm_idx);

  return ptr;
}


void dlthread_free_shmem(
    void * ptr,
    dlthread_comm_t const comm_idx)
{
  size_t const myid = dlthread_get_id(comm_idx);

  dlthread_barrier(comm_idx);

  if (myid == 0) {
    dl_free(ptr);
  }
}


void dlthread_barrier(
    dlthread_comm_t const comm)
{
  pthread_barrier_wait(&(my_comms[comm].bar));
}


void * dlthread_get_buffer(
    size_t const n,
    dlthread_comm_t const comm_idx)
{
  comm_t * comm;

  size_t const myid = dlthread_get_id(comm_idx);

  comm = my_comms+comm_idx;

  if (comm->bufsize < n) {
    dlthread_barrier(comm_idx);
    if (myid == 0) {
      dl_free(comm->buffer);
      comm->buffer = malloc(n);
      comm->bufsize = n;
    }
    dlthread_barrier(comm_idx);
  }

  return comm->buffer;
}





#endif
