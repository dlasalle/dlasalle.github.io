/**
 * @file bowstring.c
 * @brief Top level driver functions
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-07-24
 */




#ifndef BOWSTRING_C
#define BOWSTRING_C




#include "base.h"
#include "tree.h"
#include "graph.h"
#include "sparsen.h"
#include "io/io.h"




/******************************************************************************
* PRIVATE CONSTANTS ***********************************************************
******************************************************************************/


static const char * FORMAT_SUFFIXES[] = {
  [BOWSTRING_FORMAT_METIS] = ".graph",
  [BOWSTRING_FORMAT_SNAP] = ".snap",
  [BOWSTRING_FORMAT_DIMACS] = ".dimacs",
  [BOWSTRING_FORMAT_CSR] = ".csr",
  [BOWSTRING_FORMAT_PEGASUS] = ".pegasus",
  [BOWSTRING_FORMAT_CLOUD9] = ".cloud9",
  [BOWSTRING_FORMAT_STP] = ".stp",
  [BOWSTRING_FORMAT_NERSTRAND] = ".graph",
  [BOWSTRING_FORMAT_NBG] = ".nbg"
};
static const size_t NSUFFIXES = sizeof(FORMAT_SUFFIXES)/sizeof(char*);




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int bowstring_read_graph(
    const char * const filename, 
    int graphtype, 
    vtx_t * const r_nvtxs, 
    adj_t ** const r_xadj, 
    vtx_t ** const r_adjncy, 
    wgt_t ** const r_vwgt, 
    wgt_t ** const r_adjwgt)
{
  size_t i;

  if (graphtype == BOWSTRING_FORMAT_AUTO) {
    for (i=0;i<NSUFFIXES;++i) {
      if (dl_string_endswith(filename,FORMAT_SUFFIXES[i])) {
        graphtype = (bowstring_graph_type_t)i; 
        break;
      }
    }
    if (i==NSUFFIXES) {
      eprintf("Unable to determine filetype: '%s'\n",filename);
      return BOWSTRING_ERROR_INVALIDINPUT;
    }
  }

  return io_read_graph(filename,graphtype,r_nvtxs,r_xadj,r_adjncy,r_vwgt,
      r_adjwgt);
}


int bowstring_write_graph(
    const char * const filename, 
    int graphtype, 
    const vtx_t const nvtxs, 
    const adj_t * const xadj, 
    const vtx_t * const adjncy, 
    const wgt_t * const vwgt, 
    const wgt_t * const adjwgt)
{
  size_t i;

  if (graphtype == BOWSTRING_FORMAT_AUTO) {
    for (i=0;i<NSUFFIXES;++i) {
      if (dl_string_endswith(filename,FORMAT_SUFFIXES[i])) {
        graphtype = (bowstring_graph_type_t)i; 
        break;
      }
    }
    if (i==NSUFFIXES) {
      eprintf("Unable to determine filetype: '%s'\n",filename);
      return BOWSTRING_ERROR_INVALIDINPUT;
    }
  }

  return io_write_graph(filename,graphtype,nvtxs,xadj,adjncy,vwgt,adjwgt);
}


int build_tree(
    const int treetype, 
    const vtx_t nvtxs, 
    const adj_t * const xadj, 
    const vtx_t * const adjncy, 
    const wgt_t * const adjwgt,
    adj_t ** const r_xadj, 
    vtx_t ** const r_adjncy, 
    wgt_t ** const r_adjwgt)
{
  int err = BOWSTRING_SUCCESS;
  int * adjmask;

  adjmask = int_alloc(xadj[nvtxs]);

  switch (treetype) {
    case BOWSTRING_TREE_MST:
      build_mst_tree(nvtxs,xadj,adjncy,adjwgt,NULL);
      break;
    case BOWSTRING_TREE_RST:
      build_rst_tree(nvtxs,xadj,adjncy,NULL);
      break;
    case BOWSTRING_TREE_DFS:
      build_dfs_tree(nvtxs,xadj,adjncy,vtx_rand(0,nvtxs),NULL,NULL,NULL,
          adjmask);
    case BOWSTRING_TREE_BFS:
      build_bfs_tree(nvtxs,xadj,adjncy,vtx_rand(0,nvtxs),NULL,NULL,NULL,
          adjmask);
    default:
      eprintf("Unknown tree type '%d'\n",treetype);
      err = BOWSTRING_ERROR_INVALIDINPUT;
      goto END;
  }

  err = apply_edge_mask(nvtxs,xadj,adjncy,adjwgt,adjmask,r_xadj,r_adjncy,
      r_adjwgt);

  END:

  dl_free(adjmask);

  return err;
}


int remove_edges(
    const vtx_t nvtxs, 
    const adj_t * const xadj, 
    const vtx_t * const adjncy, 
    const wgt_t * const adjwgt, 
    const int type,
    const double frac, 
    adj_t ** const r_xadj,
    vtx_t ** const r_adjncy, 
    wgt_t ** const r_adjwgt)
{
  elbl_t maxrank;
  elbl_t * ranks;

  ranks = elbl_calloc(xadj[nvtxs]);

  maxrank = 0;
  switch (type) {
    case BOWSTRING_EDGERANK_NI:
      maxrank = build_nirank(nvtxs,xadj,adjncy,adjwgt,ranks);
      break;
    case BOWSTRING_EDGERANK_MST:
      maxrank = build_mstrank(nvtxs,xadj,adjncy,adjwgt,ranks);
      break;
    case BOWSTRING_EDGERANK_AST:
      maxrank = build_astrank(nvtxs,xadj,adjncy,adjwgt,ranks);
      break;
    case BOWSTRING_EDGERANK_LST:
      maxrank = build_lstrank(nvtxs,xadj,adjncy,adjwgt,ranks);
      break;
    default:
      eprintf("Unknown edge ranking %d\n",type);
      return BOWSTRING_ERROR_UNIMPLEMENTED;
  }

  prune_ranked_edges(nvtxs,xadj,adjncy,adjwgt,ranks,maxrank,frac,r_xadj,
      r_adjncy,r_adjwgt,BOWSTRING_REWEIGHT_NONE);

  dl_free(ranks);

  return BOWSTRING_SUCCESS;
}




#endif
