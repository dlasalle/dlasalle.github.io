/**
 * @file bowstring.h
 * @brief Library external header file
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-04-09
 */




#ifndef BOWSTRING_H
#define BOWSTRING_H




#include <stdint.h>
#include <stdlib.h>
#include <inttypes.h>




/******************************************************************************
* MACROS **********************************************************************
******************************************************************************/


#define BOWSTRING_VER_MAJOR 0
#define BOWSTRING_VER_MINOR 1
#define BOWSTRING_VER_SUBMINOR 1




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


/**
 * @brief Return values for status
 */
typedef enum bowstring_error_t {
  /* success messages are 0x0* */
  BOWSTRING_SUCCESS=0x01,
  /* file errors are 0x1* */
  BOWSTRING_ERROR_FILENOTFOUND=0x10,
  BOWSTRING_ERROR_FILEREAD=0x11,
  BOWSTRING_ERROR_FILEWRITE=0x12,
  BOWSTRING_ERROR_FILECLOSE=0x13,
  BOWSTRING_ERROR_FILEPERMISSIONDENIED=0x14,
  /* input errors are 0x2* */
  BOWSTRING_ERROR_INVALIDINPUT=0x20,
  BOWSTRING_ERROR_INVALIDVALUE=0x21,
  /* resource errors */
  BOWSTRING_ERROR_NOTENOUGHMEMORY=0x30,
  /* network errors are 0xA* */
  BOWSTRING_ERROR_MPICALL=0xA0,
  /* special errors are 0xF* */
  BOWSTRING_ERROR_UNKNOWN=0xF0,
  BOWSTRING_ERROR_UNIMPLEMENTED=0xFF
} bowstring_error_t;


typedef enum bowstring_format_t {
  BOWSTRING_FORMAT_AUTO,
  BOWSTRING_FORMAT_METIS,
  BOWSTRING_FORMAT_CSR,
  BOWSTRING_FORMAT_CLOUD9,
  BOWSTRING_FORMAT_SNAP,
  BOWSTRING_FORMAT_DIMACS,
  BOWSTRING_FORMAT_PEGASUS,
  BOWSTRING_FORMAT_MATRIXMARKET,
  BOWSTRING_FORMAT_EDGELIST,
  BOWSTRING_FORMAT_STP,
  BOWSTRING_FORMAT_NERSTRAND,
  BOWSTRING_FORMAT_NBG
} bowstring_graph_type_t;


typedef enum bowstring_tree_t {
  BOWSTRING_TREE_MST,
  BOWSTRING_TREE_RST,
  BOWSTRING_TREE_DFS,
  BOWSTRING_TREE_BFS
} bowstring_tree_type_t;


typedef enum bowstring_order_t {
  BOWSTRING_ORDER_BFS,
  BOWSTRING_ORDER_RANDOM,
  BOWSTRING_ORDER_INCDEGREE,
  BOWSTRING_ORDER_DECDEGREE,
  BOWSTRING_ORDER_CM,
  BOWSTRING_ORDER_RCM
} bowstring_order_type_t;


typedef enum bowstring_edgerank_t {
  BOWSTRING_EDGERANK_NI,
  BOWSTRING_EDGERANK_MST,
  BOWSTRING_EDGERANK_AST,
  BOWSTRING_EDGERANK_LST
} bowstring_edgerank_t;


typedef enum bowstring_reweight_t {
  BOWSTRING_REWEIGHT_NONE,
  BOWSTRING_REWEIGHT_EXACT,
  BOWSTRING_REWEIGHT_APPROX
} bowstring_reweight_t;


typedef enum bowtring_compression_t {
  BOWSTRING_COMPRESSION_NONE=0x0000,
  BOWSTRING_COMPRESSION_GZIP1=0x0011,
  BOWSTRING_COMPRESSION_GZIP2=0x0012,
  BOWSTRING_COMPRESSION_GZIP3=0x0013,
  BOWSTRING_COMPRESSION_GZIP4=0x0014,
  BOWSTRING_COMPRESSION_GZIP5=0x0015,
  BOWSTRING_COMPRESSION_GZIP6=0x0016,
  BOWSTRING_COMPRESSION_GZIP7=0x0017,
  BOWSTRING_COMPRESSION_GZIP8=0x0018,
  BOWSTRING_COMPRESSION_GZIP9=0x0019
} bowstring_compression_t;


#ifndef BOWSTRING_TYPES_DEFINED
#ifdef BOWSTRING_SIGNED_TYPES
typedef int64_t bowstring_int64_t;
#define PF_BSINT64_T "%"PRIi64
typedef int32_t bowstring_int32_t;
#define PF_BSINT32_T "%"PRIi32
#else
typedef uint64_t bowstring_int64_t;
#define PF_BSINT64_T "%"PRIu64
typedef uint32_t bowstring_int32_t;
#define PF_BSINT32_T "%"PRIu32
#endif /* BOWSTRING_SIGNED_TYPES */
#ifdef BOWSTRING_64BIT_VERTICES
typedef bowstring_int64_t vtx_t;
#define PF_VTX_T PF_BSINT64_T
#else
typedef bowstring_int32_t vtx_t;
#define PF_VTX_T PF_BSINT32_T
#endif /* BOWSTRING_64BIT_VERTICES */
#ifdef BOWSTRING_64BIT_EDGES
typedef bowstring_int64_t adj_t;
#define PF_ADJ_T PF_BSINT64_T
#else
typedef bowstring_int32_t adj_t;
#define PF_ADJ_T PF_BSINT32_T
#endif /* BOWSTRING_64BIT_EDGES */
#ifdef BOWSTRING_DOUBLE_WEIGHTS
#ifdef BOWSTRING_INT_WEIGHTS
typedef bowstring_int64_t wgt_t;
#define PF_WGT_T PF_BSINT64_T
#else
typedef double wgt_t;
#define PF_WGT_T "%lf"
#endif /* BOWSTRING_INT_WEIGHTS */
#else
#ifdef BOWSTRING_INT_WEIGHTS
typedef bowstring_int32_t wgt_t;
#define PF_WGT_T PF_BSINT32_T
#else
typedef float wgt_t;
#define PF_WGT_T "%f"
#endif /* BOWSTRING_INT WEIGHTS */
#endif /* BOWSTRING_DOUBLE_WEIGHTS */
#endif /* BOWSTRING_TYPES_DEFINED */


#ifndef BOWSTRING_LABELS_DEFINED
#ifdef BOWSTRING_64BIT_VLABELS
typedef int64_t vlbl_t;
#define PF_VLBL_T "%"PRIi64
#else
typedef int32_t vlbl_t;
#define PF_VLBL_T "%"PRIi32
#endif /* BOWSTRING_64BIT_VLABELS */
#ifdef BOWSTRING_64BIT_ELABELS
typedef int64_t elbl_t;
#define PF_ELBL_T "%"PRIi64
#else
typedef int32_t elbl_t;
#define PF_ELBL_T "%"PRIi32
#endif /* BOWSTRING_64BIT_ELABELS */
#endif /* BOWSTRING_LABELS_DEFINED */


#ifndef BOWSTRING_COORD_DEFINED
#ifdef BOWSTRING_COORD_DOUBLE
typedef double coord_t;
#define PF_COORD_T "%lf"
#else
typedef float coord_t;
#define PF_COORD_T "%f"
#endif /* BOWSTRING_COORD_DOUBLE */
#endif /* BOWSTRING_COORD_DEFINED */




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


int bowstring_read_graph(
    char const * filename, 
    int graphtype, 
    vtx_t * nvtxs, 
    adj_t ** xadj, 
    vtx_t ** adjncy, 
    wgt_t ** vwgt, 
    wgt_t ** adjwgt);


int bowstring_write_graph(
    char const * filename, 
    int graphtype, 
    vtx_t nvtxs, 
    adj_t const * xadj, 
    vtx_t const * adjncy, 
    wgt_t const * vwgt, 
    wgt_t const * adjwgt);


int bowstring_build_tree(
    int treetype, 
    vtx_t nvtxs, 
    adj_t const * gxadj, 
    vtx_t const * gadjncy, 
    wgt_t const * const gadjwgt, 
    adj_t ** xadj, 
    vtx_t ** adjncy, 
    wgt_t ** adjwgt);


/**
 * @brief Build a reverse adjacency index, such that:
 *
 * radj[radj[j]] = j
 *
 * and:
 *
 * for (j=xadj[i];j<xadj[i+1];++j) {
 *   adjncy[radj[j]] == i
 * }
 *
 * @param nvtxs Number of vertices in the graph
 * @param xadj The array pointing to the start of each vertices adjacency list
 * @param adjncy The adjacency list of each vertex
 * @param radj The reverse adjacency list -- output array of length 
 *   xadj[nvtxs].
 */
void bowstring_build_adjncy_index(
    vtx_t nvtxs, 
    adj_t const * xadj,
    vtx_t const * adjncy, 
    adj_t * radj);


/**
 * @brief Remove a fraction of the edges from a graph.
 *
 * @param nvtxs The number of vertices in the graph.
 * @param xadj The adjacency list pointer.
 * @param adjncy The adjacency list.
 * @param adjwgt The edge weight (may be NULL).
 * @param type The method for selecting the edges to remove.
 * @param frac The fraction of edges to remove.
 * @param r_xadj A reference to the modified adjacency list pointer.
 * @param r_adjncy A reference to the modified adjacecny list.
 * @param r_adjwgt A reference to the modified edge weights.
 */
void bowstring_remove_edges(
    vtx_t nvtxs, 
    adj_t const * xadj, 
    vtx_t const * adjncy,
    wgt_t const * adjwgt, 
    int type, 
    double frac, 
    adj_t ** r_xadj, 
    vtx_t ** r_adjncy, 
    wgt_t ** r_adjwgt);


/**
 * @brief Induce a subgraph given a set of vertices (based on the corresponding
 * values of the present array).
 *
 * @param nvtxs The total number of vertices in the graph.
 * @param xadj The adjacency list pointer.
 * @param adjncy The adjacency list.
 * @param adjwgt The edge weights.
 * @param vwgt The vertex weights.
 * @param present The array indicating which vertices are present in the
 *   subgraph.
 * @param r_nvtxs A reference to the number of vertices in the subgraph
 *   (output).
 * @param r_xadj A reference to the subgraph's adjacency list pointer (output).
 * @param r_adjncy A reference to the subgraph's adjacncy list (output).
 * @param r_adjwgt A reference to the subgraph's edge weight (output).
 * @param r_vwgt A reference to the subgraph's vertex weight (output).
 * @param r_alias A reference to the subgraph's vertex numbers in the original
 *   graph (output). May be NULL.
 * @param r_alias A reference to the subgraph's vertex numbers in the original
 *   graph (output). May be NULL.
 */
void bowstring_induce_subgraph(
    vtx_t nvtxs,
    adj_t const * xadj,
    vtx_t const * adjncy,
    wgt_t const * adjwgt,
    wgt_t const * vwgt,
    int const * present,
    vtx_t * r_nvtxs,
    adj_t ** r_xadj,
    vtx_t ** r_adjncy,
    wgt_t ** r_adjwgt,
    wgt_t ** r_vwgt,
    vtx_t ** r_alias,
    vtx_t ** r_rename);


/**
 * @brief Extract a subgraph given a set of vertices and edges (based on the 
 * corresponding values of the vpresent and epresent arrays).
 *
 * @param nvtxs The total number of vertices in the graph.
 * @param xadj The adjacency list pointer.
 * @param adjncy The adjacency list.
 * @param adjwgt The edge weights (can be NULL).
 * @param vwgt The vertex weights (can be NULL).
 * @param present The array indicating which vertices are present in the
 *   subgraph.
 * @param r_nvtxs A reference to the number of vertices in the subgraph
 *   (output).
 * @param r_xadj A reference to the subgraph's adjacency list pointer (output).
 * @param r_adjncy A reference to the subgraph's adjacncy list (output).
 * @param r_adjwgt A reference to the subgraph's edge weight (output).
 * @param r_vwgt A reference to the subgraph's vertex weights (output).
 * @param r_alias A reference to the subgraph's vertex numbers in the original
 *   graph (output). May be NULL.
 * @param r_alias A reference to the subgraph's vertex numbers in the original
 *   graph (output). May be NULL.
 */
void bowstring_extract_subgraph(
    vtx_t nvtxs,
    adj_t const * xadj,
    vtx_t const * adjncy,
    wgt_t const * adjwgt,
    wgt_t const * vwgt,
    int const * vpresent,
    int const * epresent,
    vtx_t * r_nvtxs,
    adj_t ** r_xadj,
    vtx_t ** r_adjncy,
    wgt_t ** r_adjwgt,
    wgt_t ** r_vwgt,
    vtx_t ** r_alias,
    vtx_t ** r_rename);


/**
 * @brief Count the number of connected components in a graph.
 *
 * @param nvtxs The number of vertices in the graph.
 * @param xadj The adjacency list pointer.
 * @param adjncy The adjacency list.
 *
 * @return The number of connected components.
 */
vtx_t bowstring_nconn_components(
    vtx_t nvtxs,
    adj_t const * xadj,
    vtx_t const * adjncy);


/**
 * @brief Check that a graph structure is valid.
 *
 * @param nvtxs The number of vertices in the graph.
 * @param xadj The adjacency list pointer.
 * @param adjncy The adjacency list.
 * @param adjwgt The edge weights (can be NULL)
 *
 * @return 1 if it is a valid graph.
 */
int bowstring_check_graph(
    vtx_t nvtxs,
    adj_t const * xadj,
    vtx_t const * adjncy,
    wgt_t const * adjwgt);




#endif
