/**
 * @file graph.c
 * @brief Functions for graph operations
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-08
 */




#ifndef BURNTSIDE_GRAPH_C
#define BURNTSIDE_GRAPH_C




#include "graph.h"




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX graph
#define DLMEM_TYPE_T graph_t
#define DLMEM_DLTYPE DLTYPE_STRUCT
#define DLMEM_INITFUNCTION init_graph
#define DLMEM_STATIC
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_INITFUNCTION
#undef DLMEM_DLTYPE
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* PUBLIC SERIAL FUNCTIONS *****************************************************
******************************************************************************/


graph_t * init_graph(
    graph_t * graph)
{  
  /* should be a valid graph with 0 vertices */
  graph->nvtxs = 0;
  graph->nedges = 0;
  graph->gadjwgt = 0.0;
  /* null out pointers */
  graph->xadj = NULL;
  graph->adjncy = NULL;
  graph->adjwgt = NULL;
  graph->vwgt = NULL;
  graph->alias = NULL;

  return graph;
}


graph_t * setup_graph(
    vtx_t const nvtxs, 
    adj_t * const xadj, 
    vtx_t * const adjncy, 
    wgt_t * const vwgt, 
    wgt_t * const adjwgt) 
{
  graph_t * const graph = graph_calloc(1); 

  DL_ASSERT(xadj != NULL,"Null xadj passed into setup_graph()");
  DL_ASSERT(adjncy != NULL,"Null xadj passed into setup_graph()");

  /* set nvtxs */
  graph->nvtxs = nvtxs;

  /* set nedges */
  graph->nedges = xadj[nvtxs];

  /* these have been asserted to not be NULL */
  graph->xadj = xadj;
  graph->adjncy = adjncy;

  /* these are either NULL or their properly initialized -- good either way */
  graph->vwgt = vwgt;
  graph->adjwgt = adjwgt;

  /* calculate gadjwgt */
  if (adjwgt) {
    graph->gadjwgt = wgt_fa_sum(graph->adjwgt,graph->nedges);
  } else {
    graph->gadjwgt = (wgt_t)graph->nedges;
  }

  dprintf("Setup a graph with "PF_VTX_T" vertices, "PF_ADJ_T" edges\n",
      graph->nvtxs,graph->nedges);

  return graph;
}


int free_graph(
    graph_t * graph)
{
  /* free what should be free'd */
  if (graph->xadj) {
    dl_free(graph->xadj);
  }
  if (graph->adjncy) {
    dl_free(graph->adjncy);
  }
  if (graph->vwgt) {
    dl_free(graph->vwgt);
  }
  if (graph->adjwgt) {
    dl_free(graph->adjwgt);
  }
  if (graph->alias) {
    dl_free(graph->alias);
  }

  /* free the memory */
  dl_free(graph);

  /* we'll always assume we're successful */
  return BURNTSIDE_SUCCESS;
}


int check_graph(
    graph_t const * graph)
{
  vtx_t i,k;
  adj_t j,l;
  twgt_t gadjwgt;

  vtx_t const nvtxs = graph->nvtxs;
  adj_t const nedges = graph->nedges;
  adj_t const * const xadj = graph->xadj;
  vtx_t const * const adjncy = graph->adjncy;
  wgt_t const * const adjwgt = graph->adjwgt;

  /* xadj checks */
  if (xadj[0] != 0) {
    eprintf("graph->xadj[0] = "PF_ADJ_T"\n",xadj[0]);
    return 0;
  }
  if (nedges != xadj[nvtxs]) {
    eprintf("nedges = "PF_ADJ_T", xadj[nvtxs] = "PF_ADJ_T"\n", \
        nedges,xadj[nvtxs]);
    return 0;
  }

  /* edge doubliness checkes */
  for (i=0;i<nvtxs;++i) {
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      for (l=xadj[k];l<xadj[k+1];++l) {
        if (adjncy[l] == i) {
          break;
        }
      }
      if (l == xadj[k+1]) {
        eprintf("Edge from "PF_VTX_T" to "PF_VTX_T" missing in other "
            "direction\n",i,k);
        return 0;
      }
      if (adjwgt) {
        if (adjwgt[j] != adjwgt[l]) {
          eprintf("Edge weight of edge "PF_ADJ_T"={"PF_VTX_T","PF_VTX_T"} " \
              " is not symmetric, ["PF_WGT_T","PF_WGT_T"]\n",j,i,k,adjwgt[j], \
              adjwgt[l]);
          return 0;
        }
      }
    }
  }

  /* check totals */
  gadjwgt = wgt_fa_sum(adjwgt,nedges);
  if (graph->gadjwgt != gadjwgt) {
    eprintf("Incorrect total edge weight of "PF_TWGT_T", actual " \
        PF_TWGT_T"\n",graph->gadjwgt,gadjwgt);
    return 0;
  }

  return BURNTSIDE_SUCCESS;
}




#endif
