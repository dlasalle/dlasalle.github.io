/**
 * @file tree.h
 * @brief Structs, types, and functions for steiner trees
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-05-29
 */




#ifndef BURNTSIDE_TREE_H
#define BURNTSIDE_TREE_H




#include "base.h"
#include "graph.h"




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef struct tree_t {
  vtx_t nvtxs;
  adj_t nedges;
  adj_t * xadj;
  vtx_t * adjncy;
  wgt_t * adjwgt;
  wgt_t * vwgt;
  adj_t * edges;
  vtx_t * alias;
  int * term;
} tree_t;




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX tree
#define DLMEM_TYPE_T tree_t
#include "dlmem_headers.h"
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


/**
 * @brief Calcaulate the cost of a steiner tree.
 *
 * @param tree The steiner tree to compute the cost of.
 *
 * @return The cost of the steiner tree.
 */
twgt_t calc_cost(
    tree_t const * tree);


/**
 * @brief This function extracts a steiner tree from a graph given a set of 
 * vertices and their parents in the steiner tree.
 *
 * @param graph The graph to extract the tree from.
 * @param present A boolean array indicating if a vertex is present in the
 *   tree.
 * @param include A boolean array indicating if an edge is present in the tree.
 * @param term A sorted liste of terminal vertices.
 * @param nterm The number of terminal vertices.
 *
 * @return The extracted tree.
 */
tree_t * extract_tree(
    graph_t const * graph,
    int const * present,
    int const * include,
    vtx_t const * term,
    vtx_t nterm);


/**
 * @brief Free a steiner tree structure and associated memory. 
 *
 * @param tree The tree to free.
 */
void free_tree(
    tree_t * tree);




#endif
