/**
 * @file objective.c
 * @brief Functions for manipulating and creating objectives
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-07-23
 */




#ifndef BURNTSIDE_OBJECTIVE_C
#define BURNTSIDE_OBJECTIVE_C




#include "objective.h"




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX objective
#define DLMEM_TYPE_T objective_t
#define DLMEM_DLTYPE DLTYPE_STRUCT
#define DLMEM_INITFUNCTION init_objective
#include "dlmem_funcs.h"
#undef DLMEM_INITFUNCTION
#undef DLMEM_DLTYPE
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const unsigned int DEFAULT_SEED = 1; 
static const burntside_expansion_t DEFAULT_EXPTYPE = \
    BURNTSIDE_EXPANSION_GROW;
static const size_t DEFAULT_NRUNS = 8; 
static const burntside_verbosity_t DEFAULT_VERBOSITY = BURNTSIDE_VERBOSITY_LOW;
static const int DEFAULT_DO_TIMING = 0;
static const int DEFAULT_DO_RUNSTATS = 0;
static const tid_t DEFAULT_NTHREADS = 1;


static const char * trans_table_exptype[] = {
  [BURNTSIDE_EXPANSION_GROW] = BURNTSIDE_STR_EXPANSION_GROW
};


static const char * trans_table_verbosity[] = {
  [BURNTSIDE_VERBOSITY_MINIMUM] = BURNTSIDE_STR_VERBOSITY_MINIMUM,
  [BURNTSIDE_VERBOSITY_LOW] = BURNTSIDE_STR_VERBOSITY_LOW,
  [BURNTSIDE_VERBOSITY_MEDIUM] = BURNTSIDE_STR_VERBOSITY_MEDIUM,
  [BURNTSIDE_VERBOSITY_HIGH] = BURNTSIDE_STR_VERBOSITY_HIGH,
  [BURNTSIDE_VERBOSITY_MAXIMUM] = BURNTSIDE_STR_VERBOSITY_MAXIMUM,
};




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static inline int __find_string(
    const char * const table[], 
    const char * const str)
{
  int i;
  ssize_t n = (ssize_t)(sizeof(table)/sizeof(char*));
  if (str == NULL) {
    return -1;
  }
  for (i=0;i<n;++i) {
    if (strcmp(table[i],str) == 0) {
      break;
    }
  }
  if (i == n) {
    return -1;
  } else {
    return i;
  }
}




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


objective_t * init_objective(
    objective_t * const objective)
{
  objective->seed = (unsigned int)time(NULL); /* DEFAULT_SEED; */
  objective->nthreads = omp_get_max_threads(); /* DEFAULT_NTHREADS; */
  objective->exptype = DEFAULT_EXPTYPE;
  objective->time = DEFAULT_DO_TIMING;
  objective->runstats = DEFAULT_DO_RUNSTATS;
  objective->runs = NULL;
  objective->verbosity = DEFAULT_VERBOSITY;
  objective->nruns = DEFAULT_NRUNS;

  /* timers */
  dl_init_timer(&(objective->timers.total));
  dl_init_timer(&(objective->timers.io));
  dl_init_timer(&(objective->timers.solve));
  dl_init_timer(&(objective->timers.merge));
  dl_init_timer(&(objective->timers.expand));

  /* derived fields */
  setup_objective(objective);

  return objective;
}


int setup_objective(
    objective_t * objective)
{
  int rv = BURNTSIDE_SUCCESS;


  /* start checks */
  if (objective->nruns < 1) {
    rv = BURNTSIDE_ERROR_INVALIDOPTIONS;
    goto END;
  }
  if (objective->nthreads == 0) {
    rv = BURNTSIDE_ERROR_INVALIDOPTIONS;
    goto END;
  }

  END:

  return rv;
}


int parse_objective(
    const double * const options, 
    objective_t ** const r_objective)
{
  int rv = BURNTSIDE_SUCCESS;
  objective_t * objective = NULL;

  objective = objective_calloc(1);
  if (objective == NULL) {
    rv = BURNTSIDE_ERROR_NOTENOUGHMEMORY;
    goto END;
  }

  if (options[BURNTSIDE_OPTION_SEED] != BURNTSIDE_VAL_OFF) {
    objective->seed = (unsigned int)options[BURNTSIDE_OPTION_SEED];
  }
  if (options[BURNTSIDE_OPTION_NRUNS] != BURNTSIDE_VAL_OFF) {
    objective->nruns = (size_t)options[BURNTSIDE_OPTION_NRUNS];
  }
  if (options[BURNTSIDE_OPTION_EXPANSION] != BURNTSIDE_VAL_OFF) {
    objective->exptype = \
        (burntside_expansion_t)options[BURNTSIDE_OPTION_EXPANSION];
  }
  if (options[BURNTSIDE_OPTION_VERBOSITY] != BURNTSIDE_VAL_OFF) {
    objective->verbosity = 
        (burntside_verbosity_t)options[BURNTSIDE_OPTION_VERBOSITY];
  }
  if (options[BURNTSIDE_OPTION_TIME] != BURNTSIDE_VAL_OFF) {
    objective->time = 1;
  }
  if (options[BURNTSIDE_OPTION_NTHREADS] != BURNTSIDE_VAL_OFF) {
    objective->nthreads = (tid_t)options[BURNTSIDE_OPTION_NTHREADS];
  }
  if (options[BURNTSIDE_OPTION_RUNSTATS] != BURNTSIDE_VAL_OFF) {
    objective->runstats = (int)options[BURNTSIDE_OPTION_RUNSTATS];
    if (objective->runstats) {
      objective->runs = wgt_alloc(objective->nruns);
    }
  }
  if ((rv = setup_objective(objective)) != BURNTSIDE_SUCCESS) {
    goto END;
  }

  *r_objective = objective;
  objective = NULL;

  END:

  if (objective) {
    free_objective(objective);
    objective = NULL;
  }

  return rv;
}


int free_objective(
    objective_t * objective)
{
  if (objective->runs) {
    dl_free(objective->runs);
  }
  dl_free(objective);

  return BURNTSIDE_SUCCESS;
}


/* PRINTING FUNCTIONS ********************************************************/


void print_objective(
    objective_t const * const objective)
{
  dl_print_header("PARAMETERS",'%');
  printf("Number of Threads: "PF_TID_T" | Verbosity: %s\n", \
      objective->nthreads,trans_verbosity_string(objective->verbosity));
  printf("Number of Runs: "PF_SIZE_T"\n",objective->nruns);
  printf("Random Seed: %u\n",objective->seed);
  printf("Expansion Type: %s\n",trans_exptype_string(objective->exptype)); 
  dl_print_footer('%');

}


void print_timers(
    timers_t const * const timers)
{
  dl_print_header("TIMING",'$');
  printf("Total Time: %.05fs\n",dl_poll_timer(&(timers->total)));
  printf("\tIO: %.05fs\n",dl_poll_timer(&(timers->io)));
  printf("\tSolving: %.05fs\n",dl_poll_timer(&(timers->solve)));
  printf("\t\tExpansion: %.05fs\n",dl_poll_timer(&(timers->expand)));
  printf("\t\tMerging: %.05fs\n",dl_poll_timer(&(timers->merge)));
  dl_print_footer('$');
}


void print_runstats(
    objective_t const * const objective)
{
  size_t const nruns = objective->nruns;
  wgt_t const * const runs = objective->runs;

  dl_print_header("STATISTICS",'#');
  printf("Total Runs: %zu\n",nruns);
  printf("Max Cost: "PF_WGT_T" Min Cost: "PF_WGT_T"\n", \
      wgt_max_value(runs,nruns), wgt_min_value(runs,nruns));
  printf("Mean Geo.: %lf Ari.: %lf\n", \
      wgt_geometric_mean(runs,nruns),wgt_arithmetic_mean(runs,nruns));
  printf("Median: "PF_WGT_T" Std. Dev.: %lf\n", \
      wgt_median(runs,nruns),wgt_stddev(runs,nruns));
  dl_print_footer('#');
}


/* TRANSLATION FUNCTIONS *****************************************************/

const char * trans_exptype_string(
    const burntside_expansion_t type)
{
  return trans_table_exptype[type];
}


const char * trans_verbosity_string(
    const burntside_verbosity_t type)
{
  return trans_table_verbosity[type];
}


burntside_verbosity_t trans_string_verbosity(
    const char * const str)
{
  int i = __find_string(trans_table_verbosity,str);
  if (i < 0) {
    dl_error("Unknown Verbosity Level '%s'\n",str);
  } else {
    return (burntside_verbosity_t)i;
  }
}


burntside_expansion_t trans_string_exptype(
    const char * const str)
{
  int i = __find_string(trans_table_exptype,str);
  if (i < 0) {
    dl_error("Unknown Expansion Type '%s'\n",str);
  } else {
    return (burntside_expansion_t)i;
  }
}




#endif
