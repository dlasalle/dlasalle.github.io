/**
 * @file graph.h
 * @brief Types and function prototypes for graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-02-17
 */




#ifndef BURNTSIDE_GRAPH_H
#define BURNTSIDE_GRAPH_H




#include "base.h"




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


/**
 * @brief The structure to hold the graph information 
 */
typedef struct graph_t {
  vtx_t nvtxs; /* number of vertices */
  adj_t nedges; /* number of edges */
  twgt_t gadjwgt; /* total weight of all edges */
  adj_t * xadj;
  vtx_t * adjncy;
  wgt_t * vwgt;
  wgt_t * adjwgt;
  vtx_t * alias;
} graph_t;




/******************************************************************************
* SERIAL FUNCTION PROTOTYPES **************************************************
******************************************************************************/


/**
 * @brief Initialize (zero) the graph
 *
 * @param graph The graph to initialize
 *
 * @return The initialized graph
 */
graph_t * init_graph(
    graph_t * graph);


/**
 * @brief Initializes a graph with passed in edge and vertex arrays 
 *
 * @param nvtxs The number of vertices owned by each thread
 * @param xadj The adjncy array indicies for each vertex
 * @param adjncy The list of edges for each vertex as indexed by xadj
 * @param adjwgt The weights of the edges (indexed the same as adjancy)
 * @param iadjwgt The weights of vertex internal edges
 * @param eadjwgt The sum of edge weights per vertex (weighted degree)
 * @param maxdeg The max vertex degree for each thread
 * @param nthreads The number of threads that will be used with this graph
 *
 * @return 
 */
graph_t * setup_graph(
    vtx_t nvtxs, 
    adj_t * xadj, 
    vtx_t * adjncy, 
    wgt_t * vwgt,
    wgt_t * adjwgt);


/**
 * @brief Frees a graph and it's memory. It does not free arrays
 * (xadj,adjncy,adjwgt) unless the corresponding flag is set, free_*
 *
 * @param graph The graph to be free'd
 *
 * @return !0 if successful 
 */
int free_graph(
    graph_t * graph);


/**
 * @brief Verify the sanity of a graph structure
 *
 * @param graph The graph to verify
 *
 * @return 1 on success, 0 on invalid graph
 */
int check_graph(
    const graph_t * graph);




#endif
