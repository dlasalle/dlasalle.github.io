/**
 * @file steiner.c
 * @brief Functions for generating steiner trees
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-05-31
 */




#ifndef BURNTSIDE_STEINER_C
#define BURNTSIDE_STEINER_C




#include "steiner.h"
#include <bowstring.h>




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef enum vtx_state_t {
  VTX_NONE    = 0,
  VTX_TERMINAL   = 1,
  VTX_ADDED   = 2
} vtx_state_t;

  


/******************************************************************************
* DOMLIB MACROS ***************************************************************
******************************************************************************/


#define DLPQ_PREFIX vw
#define DLPQ_KEY_T wgt_t
#define DLPQ_VAL_T vtx_t
#define DLPQ_STATIC
#include "dlpq_headers.h"
#undef DLPQ_STATIC
#undef DLPQ_VAL_T
#undef DLPQ_KEY_T
#undef DLPQ_PREFIX


#define DLDJSET_PREFIX vtx
#define DLDJSET_TYPE_T vtx_t
#define DLDJSET_STATIC
#include "dldjset_headers.h"
#undef DLDJSET_STATIC
#undef DLDJSET_TYPE_T
#undef DLDJSET_PREFIX


#define DLHT_PREFIX vtx
#define DLHT_KEY_T vtx_t
#define DLHT_VAL_T vtx_t
#define DLHT_STATIC
#include "dlht_headers.h"
#undef DLHT_STATIC
#undef DLHT_VAL_T
#undef DLHT_KEY_T
#undef DLHT_PREFIX




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static void __free_term_tree(
    vtx_t const t,
    vtx_t ** const termadj,
    wgt_t ** const termwgt,
    adj_t ** const termori,
    adj_t ** const termradj)
{
  dl_free(termadj[t]);
  dl_free(termradj[t]);
  dl_free(termori[t]);
  
  termadj[t] = NULL;
  termradj[t] = NULL;
  termori[t] = NULL;
  
  if (termwgt) {
    dl_free(termwgt[t]);
    termwgt[t] = NULL;
  }
}


static adj_t __discard_edge(
    vtx_t const t,
    adj_t const j,
    adj_t n,
    vtx_t * const termadj,
    wgt_t * const termwgt,
    adj_t * const termori,
    adj_t * const termradj,
    adj_t * const newradj)
{
  --n;

  termadj[j] = termadj[n];
  termwgt[j] = termwgt[n];
  termori[j] = termori[n];
  termradj[j] = termradj[n];

  DL_ASSERT_EQUALS(newradj[termradj[j]],n,PF_ADJ_T);
  /* terminal tree */
  newradj[termradj[j]] = j;

  return n;
}


static adj_t __delete_edge(
    vtx_t const t,
    adj_t const j,
    adj_t n,
    vtx_t const * const rterm,
    adj_t * const mradj,
    vtx_t ** const termadj,
    wgt_t ** const termwgt,
    adj_t ** const termori,
    adj_t ** const termradj)
{
  vtx_t k;

  --n;

  k = termadj[t][j] = termadj[t][n];
  termwgt[t][j] = termwgt[t][n];
  termori[t][j] = termori[t][n];
  termradj[t][j] = termradj[t][n];

  if (rterm[k] == NULL_VTX) {
    DL_ASSERT_EQUALS(mradj[termradj[t][j]],n,PF_ADJ_T);
    /* normal vertex */
    mradj[termradj[t][j]] = j; 
  } else {
    DL_ASSERT_EQUALS(termradj[rterm[k]][termradj[t][j]],n,PF_ADJ_T);
    /* terminal tree */
    termradj[rterm[k]][termradj[t][j]] = j;
  }

  return n;
}


static void __process_edge(
    vtx_t const i,
    vtx_t const k,
    wgt_t const vw,
    wgt_t const ew,
    int * const searched,
    wgt_t * const dist,
    vtx_t * const parent,
    vtx_iset_t * const realm,
    vw_priority_queue_t * const q)
{
  if (!searched[k]) {
    dist[k] = dist[i] + ew + vw;
    vw_minpq_push(dist[k],k,q);
    searched[k] = 1;
    parent[k] = i;
    /* add this vertex to the current realm if it is not present */
    if (!vtx_iset_contains(k,realm)) {
      vtx_iset_add(k,realm);
    }
  } else {
    if (dist[k] > dist[i] + ew + vw) {
      dist[k] = dist[i] + ew + vw;
      if (vw_minpq_contains(k,q)) {
        vw_minpq_update(dist[k],k,q);
      } else {
        vw_minpq_push(dist[k],k,q);
      }
      parent[k] = i;
    }
  }
}


/**
 * @brief Perform a breadth first search from the vertex 'tree', until the two
 * specified terminal vertices are found, or the two nearest if none are
 * specified. 
 *
 * @param root The vertex to start the BFS from.
 * @param nvtxs The number of vertices in the graph.
 * @param xadj The adjacency list pointer.
 * @param adjncy The adjacency list.
 * @param adjwgt The edge weight (edges in terminal trees should have zero
 *     weight).
 * @param vwgt The vertex weights (vertices in terminal trees should have zero
 *     weights).
 * @param rterm The terminal label of each vertex (NULL_VTX if the vertex is
 *     not a terminal).
 * @param ntermadj The size of the adjacency list for each terminal.
 * @param termadj The adjacency list for each terminal.
 * @param termwgt The edge weights for each terminal.
 * @param set A distjoint representing which terminals are already connected.
 * @param realm The set containing all searched vertices.
 * @param dist The distance from the tree vertex to all other vertices in the
 *     BFS.
 * @param parent The array containing the parent of each vertex in the search.
 * @param r_u The first vertex to find (can point to a value of NULL_VTX to
 *     find the nearest).
 * @param r_v The second vertex to find (can point to a value of NULL_VTX 
 *     to find the nearest).
 */
static void __tree_search(
    vtx_t const root,
    vtx_t const nvtxs,
    adj_t const * const xadj,
    vtx_t const * const adjncy,
    wgt_t const * const adjwgt,
    wgt_t const * const vwgt,
    vtx_t const * const rterm,
    adj_t const * const ntermadj,
    vtx_t const * const * const termadj,
    wgt_t const * const * const termwgt,
    vtx_djset_t * const set,
    vtx_iset_t * const realm,
    wgt_t * const dist,
    vtx_t * const parent,
    vtx_t * const r_u,
    vtx_t * const r_v)
{
  int set_terms;
  vtx_t i, k, nterms_left, other;
  adj_t j;
  wgt_t vw, ew;
  int * searched;
  vw_priority_queue_t * q;

  /* allocate memory */
  searched = int_calloc(nvtxs);
  q = vw_priority_queue_create(0,nvtxs);

  /* set options */
  if (*r_u == NULL_VTX && r_v == NULL) {
    /* find just one near terminal vertex */
    set_terms = 0;
    nterms_left = 1;
    dprintf("Searching for just the nearest terminal to "PF_VTX_T"\n", \
        rterm[root]);
  } else if (*r_u == NULL_VTX && *r_v == NULL_VTX) {
    /* find nearest two terminal vertices */
    set_terms = 0;
    nterms_left = 2;
    dprintf("Searching for the two nearest terminals to "PF_VTX_T"\n",
        rterm[root]);
  } else {
    /* find specificed terminal vertices */
    set_terms = 1;
    nterms_left = 0x1 | 0x2;
    dprintf("Searching for "PF_VTX_T" and "PF_VTX_T" from "PF_VTX_T"\n", \
        *r_u,*r_v,rterm[root]);
  }

  /* root is also the starting vertex for it */
  parent[root] = NULL_VTX;
  vw_minpq_push(0,root,q);
  dist[root] = 0;
  searched[root] = 1;
  DL_ASSERT(rterm[root] != NULL_VTX,"Attempting search from non-terminal " \
      "vertex\n");

  /* add this vertex to the current realm if it is not present */
  if (!vtx_iset_contains(root,realm)) {
    vtx_iset_add(root,realm);
  }

  while (q->size > 0) {
    i = vw_minpq_pop(q);

    /* do special work for terminals */
    if (rterm[i] != NULL_VTX) {
      /* we found a terminal */
      other = rterm[i];

      DL_ASSERT_EQUALS(other,vtx_djset_find(other,set),PF_VTX_T);

      if (i != root) {
        if (set_terms) {
          /* we need to find two specific terms */
          if (rterm[i] == *r_u) {
            nterms_left &= 0x2; /* zero first bit */
          } else if (rterm[i] == *r_v) {
            nterms_left &= 0x1; /* zero second bit */ 
          }
        } else {
          /* we need to find the two nearest terms */
          if (*r_u == NULL_VTX) {
            *r_u = rterm[i];
            --nterms_left;
          } else {
            /* ignore termnials part of the previously found tree */
            *r_v = rterm[i];
            --nterms_left;
          }
        }

        if (nterms_left == 0) {
          /* if we have found the two terminals, exit */
          break;
        }
      }

      /* search edges */
      for (j=0;j<ntermadj[other];++j) {
        k = termadj[other][j];
        if (termwgt) {
          ew = termwgt[other][j];
        } else {
          ew = 1.0;
        }
        /* always count terminal's as zero weight */
        __process_edge(i,k,0,ew,searched,dist,parent,realm,q);
      }
    } else {
      /* search my edges */
      for (j=xadj[i];j<xadj[i+1];++j) {
        k = adjncy[j];
        if (k == NULL_VTX) {
          continue;
        }
        if (adjwgt) {
          ew = adjwgt[j];
        } else {
          ew = 1.0;
        }
        if (vwgt) {
          vw = vwgt[k];
        } else {
          vw = 0;
        }
        __process_edge(i,k,vw,ew,searched,dist,parent,realm,q);
      }
    }
  }

  dl_free(searched);
  vw_priority_queue_free(q);
}


/**
 * @brief Trace back a path from the start vertex to the parentless vertex,
 * adding all vertices and edges along the way to the pos and include arrays.
 * The weights of the edges that are added are also zeroed.
 *
 * @param start The starting vertex to trace back from.
 * @param xadj The adjacency list pointer.
 * @param adjncy The adjacency list.
 * @param adjwgt The edge weights.
 * @param vwgt The vertex weights (may be null).
 * @param rterm The terminal label of each vertex (NULL_VTX if the vertex is
 *     not a terminal).
 * @param ntermadj The size of the adjacency list for each terminal.
 * @param termadj The adjacency list for each terminal.
 * @param termwgt The edge weights for each terminal.
 * @param termori The original index for each edge in the original graph.
 * @param radj The reverse adjacnecy list index.
 * @param parent The array containg the parent of each vertex.
 * @param pos The indicator array for vertex presence in the tree.
 * @param include The indicator array for edge presence in the tree.
 *
 * @return The total weight of the traced edges.
 */
static wgt_t __trace_grow(
    vtx_t const start,
    adj_t const * const xadj,
    vtx_t const * const adjncy,
    wgt_t const * const adjwgt,
    wgt_t const * const vwgt,
    vtx_t const * const rterm,
    adj_t const * const ntermadj,
    vtx_t const * const * const termadj,
    wgt_t const * const * const termwgt,
    adj_t const * const * const termori,
    adj_t const * const radj,
    vtx_t const * const parent,
    int * const pos,
    int * const include)
{
  vtx_t i, k, t;
  adj_t j, l;
  wgt_t ewgt;

  i = start;
  ewgt = 0;

  /* perform the trace */
  do {
    pos[i] = VTX_TERMINAL;

    if (vwgt) {
      ewgt += vwgt[i];
    }

    /* update the distance from neighbors */
    if ((t = rterm[i]) == NULL_VTX) {
      for (j=xadj[i];j<xadj[i+1];++j) {
        k = adjncy[j];
        if (k == parent[i]) {
          /* add vertex and edge */
          include[j] = 1;
          include[radj[j]] = 1;

          /* count edge weight */
          if (adjwgt) {
            ewgt += 2 * adjwgt[j];
          } else {
            ewgt += 2;
          }

          /* move on */
          break;
        }
      }
    } else {
      /* tracing through a terminal */
      for (j=0;j<ntermadj[t];++j) {
        k = termadj[t][j];
        if (k == parent[i]) {
          /* add vertex and edge */
          l = termori[t][j]; 
          include[l] = 1;
          include[radj[l]] = 1;

          /* count edge weight */
          if (termwgt) {
            ewgt += 2 * termwgt[t][j];
          } else {
            ewgt += 2;
          }

          /* move on */
          break;
        }
      }
    }

    DL_ASSERT(i != parent[i],"Self-parent exists in parent array.");

    i = parent[i];
  } while (i != NULL_VTX);

  return ewgt;
}


/**
 * @brief Build a steiner tree by iterating over the terminals optimally
 * connecting three at a time.
 *
 * @param objective The objective containing runtime parameters.
 * @param graph The graph to find the steiner tree in.
 * @param term The set of terminal vertices.
 * @param nterm The number of terminal vertices.
 *
 * @return The steiner tree.
 */
static tree_t * __steiner_GROW(
    objective_t * const objective,
    graph_t const * const graph,
    vtx_t const * const term,
    vtx_t const nterm)
{
  tree_t * tree;
  vtx_t i, k, u, v, root, s, t, newtree, minidx, m, oldtree;
  adj_t j, nnewadj;
  adj_t deg;
  wgt_t ewgt, mindist, cost;
  wgt_t * dist[3];
  vtx_t * parent[3];
  adj_t * radj, * mradj;
  int * include, * pos;
  vtx_t * rterm, * newadj, * adjncy;
  adj_t * newori, * newradj;
  wgt_t * newwgt;
  vtx_iset_t * realm;
  vtx_djset_t * set;
  vw_priority_queue_t * q;
  vtx_ht_t * ht;
  wgt_t * treeweight;
  vtx_t * ntermadj;
  vtx_t ** termadj;
  adj_t ** termori, ** termradj;
  wgt_t ** termwgt = NULL; 

  vtx_t const nvtxs = graph->nvtxs;
  adj_t const nedges = graph->nedges;
  adj_t const * const xadj = graph->xadj;
  wgt_t const * const adjwgt = graph->adjwgt;
  wgt_t const * const vwgt = graph->vwgt;

  /* mutable adjacency array for redirecting edges to collapsed vertices */
  adjncy = vtx_duplicate(graph->adjncy,nedges);

  /* allocate marker arrays */
  pos = int_init_alloc(VTX_NONE,nvtxs);
  include = int_calloc(nedges);

  /* allocate individual distance and parent arrays */
  for (i=0;i<3;++i) {
    dist[i] = wgt_init_alloc(graph->gadjwgt,nvtxs);
    parent[i] = vtx_alloc(nvtxs);
  }

  /* build reverse adjacecny index for O(1) edge marking */
  radj = adj_alloc(xadj[nvtxs]);
  bowstring_build_adjncy_index(nvtxs,xadj,adjncy,radj);
  mradj = adj_duplicate(radj,nedges); 

  /* allocate space for building merged vertices */
  newadj = vtx_alloc(nvtxs);
  newwgt = wgt_alloc(nvtxs);
  newori = adj_alloc(nvtxs);
  newradj = adj_alloc(nvtxs);

  /* allocate tracking structures */
  realm = vtx_iset_create(0,nvtxs);
  set = vtx_djset_create(0,nterm);
  q = vw_priority_queue_create(0,nterm);
  ht = vtx_ht_create(nvtxs,nvtxs/8);

  /* allocate terminal tree information */
  rterm = vtx_init_alloc(NULL_VTX,nvtxs);
  treeweight = wgt_alloc(nterm);
  ntermadj = vtx_alloc(nterm);
  termadj = r_vtx_alloc(nterm);
  termori = r_adj_alloc(nterm);
  termradj = r_adj_alloc(nterm);
  if (adjwgt) {
    termwgt = r_wgt_alloc(nterm);
  }
  for (t=0;t<nterm;++t) {
    i = term[t];
    rterm[i] = t;
    deg = xadj[i+1] - xadj[i];
    ntermadj[t] = deg;
    termadj[t] = vtx_duplicate(adjncy+xadj[i],deg);
    termori[t] = adj_alloc(deg);
    termradj[t] = adj_duplicate(radj+xadj[i],deg);
    adj_incset(termori[t],xadj[i],1,deg);

    if (termwgt) {
      termwgt[t] = wgt_duplicate(adjwgt+xadj[i],deg);
    }

    if (vwgt) {
      treeweight[t] = vwgt[i];
    } else {
      treeweight[t] = 0;
    }

    vw_minpq_push(wgt_rand_r(0,1.0,&(objective->seed)),t,q);
  }

  /* modify radj */
  for (t=0;t<nterm;++t) {
    i = term[t];
    deg = ntermadj[t];
    for (j=0;j<deg;++j) {
      k = termadj[t][j];
      if (rterm[k] == NULL_VTX) {
        /* regular vertices */
        DL_ASSERT_EQUALS(mradj[termradj[t][j]],xadj[i]+j,PF_ADJ_T);
        mradj[termradj[t][j]] = j;
      } else {
        /* other terminals */
        DL_ASSERT_EQUALS(termradj[rterm[k]][mradj[xadj[i]+j]-xadj[k]], \
            xadj[i]+j,PF_ADJ_T);
        termradj[rterm[k]][mradj[xadj[i]+j]-xadj[k]] = j;
      }
    }
  }

  while (q->size > 1) {
    root = vw_minpq_pop(q);

    /* find two nearest trees */
    u = NULL_VTX;
    v = NULL_VTX;
    __tree_search(term[root],nvtxs,xadj,adjncy,adjwgt,vwgt,rterm,ntermadj, \
        (vtx_t const * const *)termadj,(wgt_t const * const *)termwgt, \
        set,realm,dist[0],parent[0],&u,&v);

    if (u == NULL_VTX) {
      /* this terminal tree is not connected to any other terminals */
      continue;
    } else if (v == NULL_VTX) {
      /* only one vertex is left in this region */
      ewgt = __trace_grow(term[u],xadj,adjncy,adjwgt,vwgt,rterm,ntermadj, \
          (vtx_t const * const *)termadj,(wgt_t const * const *)termwgt, \
          (adj_t const * const *)termori,radj,parent[0],pos,include);
    } else {
      dprintf("Found u = "PF_VTX_T"("PF_VTX_T"), and v = "PF_VTX_T"("PF_VTX_T \
          "), while t = "PF_VTX_T"\n",u,vtx_djset_find(u,set),v, \
          vtx_djset_find(v,set),root);

      /* find mininum cost connecting vertex */
      #pragma omp parallel sections default(shared) \
        num_threads(objective->nthreads)
      {
        #pragma omp section
        {
          __tree_search(term[u],nvtxs,xadj,adjncy,adjwgt,vwgt,rterm,ntermadj, \
              (vtx_t const * const *)termadj,(wgt_t const * const *)termwgt, \
              set,realm,dist[1],parent[1],&root,&v);
        }
        #pragma omp section
        {
          __tree_search(term[v],nvtxs,xadj,adjncy,adjwgt,vwgt,rterm,ntermadj, \
              (vtx_t const * const *)termadj,(wgt_t const * const *)termwgt, \
              set,realm,dist[2],parent[2],&root,&u);
        }
      }

      dprintf("Searching for minimum vertex in realm of size %zu\n",
          realm->size);
      minidx = NULL_VTX;
      mindist = graph->gadjwgt+1;
      for (t=0;t<realm->size;++t) {
        i = vtx_iset_get(t,realm);
        if (rterm[i] != NULL_VTX) {
          /* grab original distance */
          i = term[vtx_djset_find(rterm[i],set)];
        }
        cost = dist[0][i] + dist[1][i] + dist[2][i];
        if (cost < mindist) {
          mindist = cost;
          minidx = i;
        }
        /* reset dist */
        dist[0][i] = graph->gadjwgt;
        dist[1][i] = graph->gadjwgt;
        dist[2][i] = graph->gadjwgt;
      }

      DL_ASSERT(minidx < nvtxs, "Failed to find minimum vertex ("PF_VTX_T
          ")\n",minidx);

      /* add paths to minimum cost vertex */
      ewgt = 0;
      #pragma omp parallel sections default(shared) reduction(+:ewgt) \
        num_threads(objective->nthreads)
      {
        #pragma omp section
        {
          ewgt += __trace_grow(minidx,xadj,adjncy,adjwgt,vwgt,rterm,ntermadj, \
              (vtx_t const * const *)termadj,(wgt_t const * const *)termwgt, \
              (adj_t const * const *)termori,radj,parent[0],pos,include);
        }
        #pragma omp section
        {
          ewgt += __trace_grow(minidx,xadj,adjncy,adjwgt,vwgt,rterm,ntermadj, \
              (vtx_t const * const *)termadj,(wgt_t const * const *)termwgt, \
              (adj_t const * const *)termori,radj,parent[1],pos,include);
        }
        #pragma omp section
        {
          ewgt += __trace_grow(minidx,xadj,adjncy,adjwgt,vwgt,rterm,ntermadj, \
              (vtx_t const * const *)termadj,(wgt_t const * const *)termwgt, \
              (adj_t const * const *)termori,radj,parent[2],pos,include);
        }
      }
    }

    /* add trees together -- starting with the root */
    newtree = oldtree = root;
    treeweight[oldtree] += ewgt;
    for (t=realm->size;t>0;) {
      --t;
      i = vtx_iset_get(t,realm);
      if (pos[i] == VTX_TERMINAL) {
        if (rterm[i] != NULL_VTX && rterm[i] != root) {
          newtree = vtx_djset_join(oldtree,rterm[i],set);
          treeweight[newtree] = treeweight[oldtree] + treeweight[rterm[i]];
          oldtree = newtree;
          vw_minpq_delete(rterm[i],q);
        }
      } else {
        /* reduce size of realm */
        vtx_iset_remove_index(t,realm);
      }
    }

    dprintf("New tree number "PF_VTX_T"\n",newtree);

    /* calculate new edges of tree */
    nnewadj = 0;
    vtx_ht_clear(ht);
    for (t=0;t<realm->size;++t) {
      i = vtx_iset_get(t,realm);
      DL_ASSERT_EQUALS(pos[i],VTX_TERMINAL,"%d");
      /* see if the vertex is part of our tree */
      if (rterm[i] == NULL_VTX) {
        /* if its a steiner point */
        for (j=xadj[i];j<xadj[i+1];++j) {
          k = adjncy[j];
          if (k == NULL_VTX) {
            continue;
          }
          if (pos[k] != VTX_TERMINAL) {
            /* external edge */
            if ((m = vtx_ht_get(k,ht)) == NULL_VTX) {
              /* new entry */  
              newadj[nnewadj] = k; 
              newwgt[nnewadj] = adjwgt[j];
              newori[nnewadj] = j;
              newradj[nnewadj] = mradj[j];
              vtx_ht_put(k,nnewadj,ht);
              m = nnewadj++;
            } else if (adjwgt && adjwgt[j] < newwgt[m]) {
              DL_ASSERT_EQUALS(newadj[m],k,PF_VTX_T);
              /* delete duplicates -- old edge */
              if (rterm[k] == NULL_VTX) {
                adjncy[mradj[newori[m]]] = NULL_VTX;
              } else {
                if (rterm[termadj[rterm[k]][ntermadj[rterm[k]]-1]] == \
                    newtree) {
                  /* handle already processed return edges in the slot to be 
                   * deleted */
                  ntermadj[rterm[k]] = __discard_edge(rterm[k], \
                      newradj[m],ntermadj[rterm[k]],termadj[rterm[k]], \
                      termwgt[rterm[k]],termori[rterm[k]],termradj[rterm[k]], \
                      newradj);
                } else {
                  ntermadj[rterm[k]] = __delete_edge(rterm[k],newradj[m], \
                      ntermadj[rterm[k]],rterm,mradj,termadj,termwgt,termori, \
                      termradj);
                }
              }
              /* replace entry */
              newwgt[m] = adjwgt[j];
              newori[m] = j;
              newradj[m] = mradj[j];
            } else {
              /* delete duplicates -- this edge */
              if (rterm[k] == NULL_VTX) {
                adjncy[mradj[j]] = NULL_VTX;
              } else {
                if (rterm[termadj[rterm[k]][ntermadj[rterm[k]]-1]] == \
                    newtree) {
                  /* handle already processed return edges in the slot to be 
                   * deleted */
                  ntermadj[rterm[k]] = __discard_edge(rterm[k],mradj[j], \
                      ntermadj[rterm[k]],termadj[rterm[k]],termwgt[rterm[k]], \
                      termori[rterm[k]],termradj[rterm[k]],newradj);
                } else {
                  ntermadj[rterm[k]] = __delete_edge(rterm[k],mradj[j], \
                      ntermadj[rterm[k]],rterm,mradj,termadj,termwgt,termori, \
                      termradj);
                }
              }
              /* no modification necessary */
              continue;
            }
            /* modify graph */
            if (rterm[k] == NULL_VTX) {
              DL_ASSERT_EQUALS(adjncy[mradj[j]],i,PF_VTX_T);
              /* steiner point */
              adjncy[mradj[j]] = term[newtree];
              mradj[mradj[j]] = m;
            } else {
              DL_ASSERT_EQUALS(termadj[rterm[k]][mradj[j]],i,PF_VTX_T);
              /* terminal */
              termadj[rterm[k]][mradj[j]] = term[newtree];
              termradj[rterm[k]][mradj[j]] = m;
            }
          }
        }
      } else {
        /* if its a terminal */
        s = rterm[i];
        for (j=0;j<ntermadj[s];++j) {
          k = termadj[s][j];
          if (pos[k] != VTX_TERMINAL) {
            /* external edge */
            if ((m = vtx_ht_get(k,ht)) == NULL_VTX) {
              /* new entry */  
              newadj[nnewadj] = k; 
              newwgt[nnewadj] = termwgt[s][j];
              newori[nnewadj] = termori[s][j];
              newradj[nnewadj] = termradj[s][j];
              vtx_ht_put(k,nnewadj,ht);

              m = nnewadj++;
            } else if (termwgt && termwgt[s][j] < newwgt[m]) {
              DL_ASSERT_EQUALS(newadj[m],k,PF_VTX_T);
              /* delete edge duplicates -- old edge */
              if (rterm[k] == NULL_VTX) {
                adjncy[radj[newori[m]]] = NULL_VTX;
              } else {
                if (rterm[termadj[rterm[k]][ntermadj[rterm[k]]-1]] == \
                    newtree) {
                  /* handle already processed return edges in the slot to be 
                   * deleted */
                  ntermadj[rterm[k]] = __discard_edge(rterm[k], \
                      newradj[m],ntermadj[rterm[k]],termadj[rterm[k]], \
                      termwgt[rterm[k]],termori[rterm[k]],termradj[rterm[k]], \
                      newradj);
                } else {
                  ntermadj[rterm[k]] = __delete_edge(rterm[k],newradj[m], \
                      ntermadj[rterm[k]],rterm,mradj,termadj,termwgt,termori, \
                      termradj);
                }
              }
              /* replace entry */
              newwgt[m] = termwgt[s][j];
              newori[m] = termori[s][j];
              newradj[m] = termradj[s][j];
            } else {
              /* delete duplicates -- this edge */
              if (rterm[k] == NULL_VTX) {
                adjncy[termradj[s][j]] = NULL_VTX;
              } else {
                if (rterm[termadj[rterm[k]][ntermadj[rterm[k]]-1]] == \
                    newtree) {
                  /* handle already processed return edges in the slot to be 
                   * deleted */
                  ntermadj[rterm[k]] = __discard_edge(rterm[k], \
                      termradj[s][j],ntermadj[rterm[k]],termadj[rterm[k]], \
                      termwgt[rterm[k]],termori[rterm[k]],termradj[rterm[k]], \
                      newradj);
                } else {
                  ntermadj[rterm[k]] = __delete_edge(rterm[k],termradj[s][j], \
                      ntermadj[rterm[k]],rterm,mradj,termadj,termwgt,termori, \
                      termradj);
                }
              }
              /* no modification necessary */
              continue;
            }
            /* modify graph */
            if (rterm[k] == NULL_VTX) {
              DL_ASSERT_EQUALS(adjncy[termradj[s][j]],i,PF_VTX_T);
              /* steiner point */
              adjncy[termradj[s][j]] = term[newtree];
              mradj[termradj[s][j]] = m;
            } else {
              DL_ASSERT_EQUALS(termadj[rterm[k]][termradj[s][j]],i,PF_VTX_T);
              /* terminal */
              termadj[rterm[k]][termradj[s][j]] = term[newtree];
              termradj[rterm[k]][termradj[s][j]] = m;
            }
          }
        }
      }
    }

    if (u != NULL_VTX && v != NULL_VTX) {
      /* add tree back to queue */
      vw_minpq_push(treeweight[newtree],newtree,q);
    }

    /* save number of external edges of new tree */
    ntermadj[newtree] = nnewadj;

    /* save adjacency list of new tree */
    termadj[newtree] = vtx_realloc(termadj[newtree],nnewadj);
    vtx_copy(termadj[newtree],newadj,nnewadj);

    /* save revere adjacency list indexes */
    termradj[newtree] = adj_realloc(termradj[newtree],nnewadj);
    adj_copy(termradj[newtree],newradj,nnewadj);

    /* save adjacency list original indexes of new tree */
    termori[newtree] = adj_realloc(termori[newtree],nnewadj);
    adj_copy(termori[newtree],newori,nnewadj);

    if (termwgt) {
      /* save edge weights of new tree */
      termwgt[newtree] = wgt_realloc(termwgt[newtree],nnewadj);
      wgt_copy(termwgt[newtree],newwgt,nnewadj);
    }

    /* free unused tree parts */
    for (t=0;t<realm->size;++t) {
      i = vtx_iset_get(t,realm);
      if (rterm[i] != NULL_VTX && rterm[i] != newtree) {
        __free_term_tree(rterm[i],termadj,termwgt,termori,termradj);
      }
      /* clear positions */
      pos[i] = VTX_ADDED;
    }

    vtx_iset_clear(realm);
  }


  /* free the modified adjacency list */
  dl_free(adjncy);

  /* free tracking structures */
  vtx_djset_free(set);
  vtx_iset_free(realm);
  vw_priority_queue_free(q);
  vtx_ht_free(ht);

  /* free memory for merging vertices */
  dl_free(newadj);
  dl_free(newwgt);
  dl_free(newori);
  dl_free(newradj);

  /* free individual distance and parent arrays */
  for (i=0;i<3;++i) {
    dl_free(parent[i]);
    dl_free(dist[i]);
  }

  /* free reverse adjacnecy index */
  dl_free(radj);
  dl_free(mradj);
  
  /* free terminal tree memory */
  dl_free(treeweight);
  dl_free(rterm);
  for (t=0;t<nterm;++t) {
    if (termadj[t]) {
      dl_free(termadj[t]);
      dl_free(termradj[t]);
      dl_free(termori[t]);
      if (termwgt) {
        dl_free(termwgt[t]);
      }
    }
  }
  dl_free(ntermadj);
  dl_free(termadj);
  dl_free(termradj);
  dl_free(termori);
  if (termwgt) {
    dl_free(termwgt);
  }
    
  /* convert pos into a binary indicator array */
  for (i=0;i<nvtxs;++i) {
    pos[i] = (pos[i] == VTX_ADDED);
  }

  dprintf("Building tree with %d vertices\n",int_sum(pos,nvtxs));

  DL_ASSERT(int_sum(include,nedges) <= (int_sum(pos,nvtxs)-1)*2,"Tree " \
      "contains cycles.");

  /* assemble the tree */
  tree = extract_tree(graph,pos,include,term,nterm);    

  /* free allocations for tree extraction */
  dl_free(pos);
  dl_free(include);

  return tree;
}




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


/**
 * @brief Build a steiner tree using the method specified by the objective.
 *
 * @param objective The objective containing runtime parameters.
 * @param graph The graph to find the steiner tree in.
 * @param term The set of terminal vertices.
 * @param nterm The number of terminal vertices.
 *
 * @return The steiner tree.
 */
tree_t * build_steiner_tree(
    objective_t * const objective,
    graph_t const * const graph,
    vtx_t const * const term,
    vtx_t const nterm)
{
  tree_t * tree = NULL;

  #pragma omp master 
  { 
    if (objective->time) {
      dl_start_timer(&(objective->timers.expand));
    }
  }
  switch (objective->exptype) {
    case BURNTSIDE_EXPANSION_GROW:
      tree = __steiner_GROW(objective,graph,term,nterm);
      break;
    default:
      dl_error("Unknown expansion type: %d\n",objective->exptype);
  }
  #pragma omp master 
  { 
    if (objective->time) {
      dl_stop_timer(&(objective->timers.expand));
    }
  }

  return tree;
}



#endif
