/**
 * @file objective.h
 * @brief Types and function prototypes for manipulating and maintaining 
 * objectives
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-07-24
 */




#ifndef BURNTSIDE_OBJECTIVE_H
#define BURNTSIDE_OBJECTIVE_H




#include "base.h"




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef struct timers_t {
  dl_timer_t total;
  dl_timer_t io;
  dl_timer_t merge;
  dl_timer_t expand;
  dl_timer_t solve;
} timers_t;


typedef struct objective_t {
  unsigned int seed;
  int time;
  int exptype;
  int verbosity;
  int runstats;
  wgt_t * runs;
  size_t nruns;
  tid_t nthreads;
  timers_t timers;
} objective_t;




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX objective
#define DLMEM_TYPE_T objective_t
#include "dlmem_headers.h"
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


/**
 * @brief Initialize an objective structure
 *
 * @param objective The objective to initalize
 *
 * @return The initialized structure
 */
objective_t * init_objective(
    objective_t * objective);


/**
 * @brief Calculate derived fields of an objective structure 
 *
 * @param objective The objective to setup
 *
 * @return BURNTSIDE_SUCCESS if successful, or an error code otherwise
 */
int setup_objective(
    objective_t * objective);


/**
 * @brief Create an objective struct from a list of options
 *
 * @param options An array indexed by options.
 * @param r_objective A reference to the objective pointer that will be
 * allocated.
 *
 * @return BURNTSIDE_SUCCESS if successful, or an error if invalid values are
 * encountered.
 */
int parse_objective(
    const double * options, 
    objective_t ** r_objective);


/**
 * @brief Free an objective structure and associated memory
 *
 * @param objective The objective structure to free
 *
 * @return !0 on success
 */
int free_objective(
    objective_t * objective);


/**
 * @brief Print the options and state of the objective.
 *
 * @param objective The objective to print the options of.
 */
void print_objective(
    objective_t const * objective);


/**
 * @brief Print the value of the timers.
 *
 * @param timers The timers to print.
 */
void print_timers(
    timers_t const * timers);


/**
 * @brief Print the statistics of the runs associated with this objective.
 * Should not be called if objective->runstats == 0.
 *
 * @param objective The objective to print the runs of.
 */
void print_runstats(
    objective_t const * objective);



/* TRANSLATION FUNCTIONS *****************************************************/

const char * trans_verbosity_string(
    burntside_verbosity_t type);


const char * trans_exptype_string(
    burntside_expansion_t type);


burntside_verbosity_t trans_string_verbosity(
    const char * str);


burntside_expansion_t trans_string_exptype(
    const char * str);




#endif
