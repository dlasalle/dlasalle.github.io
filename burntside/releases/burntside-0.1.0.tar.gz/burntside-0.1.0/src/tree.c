/**
 * @file tree.c
 * @brief Functions for manipulating and analyzing steiner trees 
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-05-29
 */





#ifndef BURNTSIDE_TREE_C
#define BURNTSIDE_TREE_C




#include "tree.h"
#include <bowstring.h>



/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef enum vertex_status_t {
  VTX_NONE = 0x00,
  VTX_A    = 0x01,
  VTX_B    = 0x02,
  VTX_BOTH = 0x03
} vertex_status_t;




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX tree
#define DLMEM_TYPE_T tree_t
#define DLMEM_DLTYPE DLTYPE_STRUCT
#include "dlmem_funcs.h"
#undef DLMEM_DLTYPE
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


twgt_t calc_cost(
    tree_t const * const tree)
{
  twgt_t cost;

  vtx_t const nvtxs = tree->nvtxs;
  adj_t const nedges = tree->xadj[tree->nvtxs];

  cost = 0;

  if (tree->vwgt) {
    cost += (twgt_t)wgt_fa_sum(tree->vwgt,nvtxs);
  }

  if (tree->adjwgt) {
    cost += (twgt_t)(wgt_fa_sum(tree->adjwgt,nedges) / 2.0);
  } else {
    cost += (twgt_t)(nedges / 2.0);
  }

  return cost;
}


tree_t * extract_tree(
    graph_t const * const graph,
    int const * const present,
    int const * const include,
    vtx_t const * const term,
    vtx_t const nterm)
{
  vtx_t i, k, tnvtxs, t;
  adj_t j, l;
  adj_t * txadj, * tedges;
  vtx_t * tadjncy, * talias, * rename;
  wgt_t * tadjwgt, * tvwgt;
  int * tterm;
  tree_t * tree;

  vtx_t const nvtxs = graph->nvtxs;
  adj_t const * const xadj = graph->xadj;
  vtx_t const * const adjncy = graph->adjncy;
  wgt_t const * const adjwgt = graph->adjwgt;
  wgt_t const * const vwgt = graph->vwgt;

  /* count the number of tree verrtices */
  tnvtxs = 0;
  for (i=0;i<nvtxs;++i) {
    tnvtxs += present[i]; 
  }
  
  /* allocate tree */
  tree = tree_calloc(1);
  tree->nvtxs = tnvtxs;
  tree->xadj = txadj = adj_alloc(tnvtxs+1);
  tree->adjncy = tadjncy = vtx_alloc(2*(tnvtxs-1));
  tree->alias = talias = vtx_alloc(tnvtxs);
  tree->edges = tedges = adj_alloc(2*(tnvtxs-1));
  tree->term = tterm = int_calloc(tnvtxs);

  /* allocate rename array */
  rename = vtx_alloc(nvtxs);

  if (adjwgt) {
    tree->adjwgt = tadjwgt = wgt_alloc(2*(tnvtxs-1));
  }
  if (vwgt) {
    tree->vwgt = tvwgt = wgt_alloc(tnvtxs);
  }


  /* fill tree */
  tnvtxs = 0;
  t = 0;
  l = 0;
  txadj[0] = 0;
  for (i=0;i<nvtxs;++i) {
    if (present[i]) {
      talias[tnvtxs] = i;
      rename[i] = tnvtxs;
      if (vwgt) {
        tvwgt[tnvtxs] = vwgt[i];
      }
      for (j=xadj[i];j<xadj[i+1];++j) {
        if (include[j]) {
          k = adjncy[j];
          DL_ASSERT(present[k],"Edge to non-present vertex found.\n");
          tadjncy[l] = k;
          if (adjwgt) {
            tadjwgt[l] = adjwgt[j];
          }
          tedges[l] = j;
          ++l;
        }
      }
      if (t < nterm && term[t] == i) {
        tterm[tnvtxs] = 1;
        ++t;
      }
      ++tnvtxs;
      txadj[tnvtxs] = l;
    }
  }

  /* fix edges */
  for (j=0;j<txadj[tnvtxs];++j) { 
    tadjncy[j] = rename[tadjncy[j]];
  }
  dl_free(rename);

  tree->nedges = tree->xadj[tree->nvtxs];

  dprintf("Extracted tree with "PF_VTX_T"/"PF_VTX_T" terminals and "PF_ADJ_T \
      " edges\n",nterm,tnvtxs,txadj[tnvtxs]);

  DL_ASSERT(bowstring_check_graph(tree->nvtxs,tree->xadj,tree->adjncy, \
        tree->adjwgt),"Generated bad tree\n");

  return tree;
}


void free_tree(
    tree_t * tree)
{
  if (tree->xadj) {
    dl_free(tree->xadj);
  }
  if (tree->adjncy) {
    dl_free(tree->adjncy);
  }
  if (tree->adjwgt) {
    dl_free(tree->adjwgt);
  }
  if (tree->vwgt) {
    dl_free(tree->vwgt);
  }
  if (tree->edges) {
    dl_free(tree->edges);
  }
  if (tree->alias) {
    dl_free(tree->alias);
  }
  if (tree->term) {
    dl_free(tree->term);
  }
  dl_free(tree);
}




#endif
