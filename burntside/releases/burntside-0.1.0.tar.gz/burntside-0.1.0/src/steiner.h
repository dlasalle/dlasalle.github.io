/**
 * @file steiner.h
 * @brief Function prototypes for generating steiner trees. 
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-04-19
 */




#ifndef BURNTSIDE_STEINER_H
#define BURNTSIDE_STEINER_H




#include "base.h"
#include "tree.h"
#include "graph.h"
#include "objective.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


/**
 * @brief Build a steiner tree using the method specified by the objective.
 *
 * @param objective The objective containing runtime parameters.
 * @param graph The graph to find the steiner tree in.
 * @param term The set of terminal vertices.
 * @param nterm The number of terminal vertices.
 *
 * @return The steiner tree.
 */
tree_t * build_steiner_tree(
    objective_t * objective,
    graph_t const * graph,
    vtx_t const * term,
    vtx_t nterm);




#endif



