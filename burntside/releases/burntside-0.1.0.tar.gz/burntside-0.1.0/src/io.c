/**
 * @file io.c
 * @brief Functions for read and writing steiner tree information
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-07-30
 */




#ifndef BURNTSIDE_IO_C
#define BURNTSIDE_IO_C




#include "io.h"




/******************************************************************************
* MACROS **********************************************************************
******************************************************************************/


#define __SECTION_STR "SECTION"
#define __STP_HEADER "33D32945 STP File, STP Format Version 1.0"




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const size_t BUFFERSIZE = 0x1000;




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


/**
 * @brief Wrapper around the dl_file routines to handle error codes
 *
 * @param filename The file to open
 * @param mode The mode to open the file in
 * @param r_file The reference to the file pointer
 *
 * @return BURNTSIDE_SUCCESS, or an error code
 */
static int __open_file(
    char const * const filename, 
    char const * const mode, 
    file_t ** const r_file)
{
  int rv;

  if ((rv = dl_open_file(filename,mode,r_file)) != DL_FILE_SUCCESS) {
    switch (rv) {
      case DL_FILE_BAD_PARAMETERS:
      case DL_FILE_PATH_PARSE_FAILURE:
        eprintf("Bad filename '%s'\n",filename);
        rv = BURNTSIDE_ERROR_IO;
        break;
      case DL_FILE_PATH_BAD:
        eprintf("File not found '%s'\n",filename);
        rv = BURNTSIDE_ERROR_IO;
        break;
      case DL_FILE_PATH_ACCESS_DENIED:
      case DL_FILE_READ_ACCESS_DENIED:
      case DL_FILE_WRITE_ACCESS_DENIED:
        eprintf("Permission denied '%s'\n",filename);
        rv = BURNTSIDE_ERROR_IO;
        break;
      default:
        eprintf("Unknown failure: %d opening '%s'\n",rv,filename);
        rv = BURNTSIDE_ERROR_UNKNOWN;
        break;
    }
  } else {
    rv = BURNTSIDE_SUCCESS;
  }

  return rv;
}


/**
 * @brief Move the current curser in the file to a specific section.
 *
 * @param file The file to move the cursor of.
 * @param section The name of the section to move to.
 * @param r_bufsize A reference to the current/resulting buffer size.
 *
 * @return 1 if the section is found.
 */
static int __find_section(
    file_t * file, 
    char const * const section, 
    size_t * const r_bufsize)
{
  int found = 0;
  ssize_t ll;
  char * line = NULL;
  size_t bufsize;
  char str[512];

  bufsize = *r_bufsize;

  while((ll = dl_get_next_line(file,&line,&bufsize)) >= 0) {
    dl_string_upperize(line);
    if (sscanf(line,__SECTION_STR"%*[ \t]%512s",str) != 1) {
      continue;
    } else {
      if (strcmp(section,str) == 0) {
        /* found the section */
        found = 1;
        break;
      } else {
        /* some other section */
      }
    }
  }

  dl_free(line);

  *r_bufsize = bufsize;

  return found;
}




static int __read_terminals_stp(
    char const * const filename,
    vtx_t * const r_nterm,
    vtx_t ** const r_term)
{
  int rv;
  vtx_t nterm, i;
  ssize_t ll;
  char * line = NULL;
  size_t bufsize = BUFFERSIZE;
  vtx_t * term = NULL;
  file_t * ifile = NULL;

  if ((rv = __open_file(filename,"r",&ifile)) != BURNTSIDE_SUCCESS) {
    goto END;
  }
  line = char_alloc(bufsize);

  /* find the graph section */
  if (!__find_section(ifile,"TERMINALS",&bufsize)) {
    eprintf("Could not find terminal section\n");
    rv = BURNTSIDE_ERROR_INVALIDINPUT; 
    goto END;
  }

  /* read the number of terminals */
  if ((ll = dl_get_next_line(ifile,&line,&bufsize)) < 0 || 
      sscanf(line,"Terminals%*[ \t]"PF_VTX_T,&nterm) != 1) {
    eprintf("Could not read number of terminals from terminal section\n");
    rv = BURNTSIDE_ERROR_INVALIDINPUT; 
    goto END;
  }

  /* read the terminals */
  term = vtx_alloc(nterm);
  for (i=0;i<nterm;++i) {
    if ((ll = dl_get_next_line(ifile,&line,&bufsize)) < 0 || 
        sscanf(line,"T%*[ \t]"PF_VTX_T,term+i) != 1) {
      eprintf("Could not read terminal number of term '"PF_VTX_T"': '%s'\n",i,
          line);
      rv = BURNTSIDE_ERROR_INVALIDINPUT; 
      goto END;
    }
  }
  if ((ll = dl_get_next_line(ifile,&line,&bufsize)) < 0 || 
      dl_strncmp_nocase("END",line,3) != 0) {
    eprintf("Did not find end of section where expected: '%s'\n",line);
    rv = BURNTSIDE_ERROR_INVALIDINPUT; 
    goto END;
  }

  /* adjust for 1 based ordering */
  for (i=0;i<nterm;++i) {
    --term[i];
  }

  dl_close_file(ifile);
  ifile = NULL;

  /* save output */
  *r_nterm = nterm;
  *r_term = term;
  term = NULL;

  END:

  if (ifile) {
    dl_close_file(ifile);
  }
  if (term) {
    dl_free(term);
  }
  if (line) {
    dl_free(line);
  }

  return rv;
}



/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int read_terminals(
    char const * const termfile,
    int const format,
    vtx_t * const r_nterm,
    vtx_t ** const r_term)
{
  switch (format) {
    case BURNTSIDE_FORMAT_STP:
      return __read_terminals_stp(termfile,r_nterm,r_term);
    default:  
      dl_error("Unknown file format for terminals: '%d'\n",format);
  }
}



#endif
