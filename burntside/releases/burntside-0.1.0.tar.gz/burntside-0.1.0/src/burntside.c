/**
 * @file burntside.c
 * @brief Top level functions for burntside
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-01-23
 */




#ifndef BURNTSIDE_C
#define BURNTSIDE_C




#include "base.h"
#include "graph.h"
#include "tree.h"
#include "objective.h"
#include "steiner.h"
#include <bowstring.h>




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static tree_t * __solve(
    objective_t * const objective, 
    graph_t const * const graph, 
    vtx_t const * const term, 
    vtx_t const nterm)
{
  size_t r;
  wgt_t best, cur;
  vtx_t i;
  tree_t * solution = NULL, * cursolution = NULL;

  /* set best as worst */
  best = graph->gadjwgt;

  #pragma omp parallel for default(none) shared(best,solution) \
    private(cursolution,cur) schedule(dynamic) \
    num_threads(objective->nthreads)
  for (r=0;r<objective->nruns;++r) {
    /* initialize present array */
    cursolution = build_steiner_tree(objective,graph,term,nterm);

    cur = calc_cost(cursolution);

    if (objective->runstats) {
      objective->runs[r] = cur;
    }

    #pragma omp critical
    {
      if (cur < best) {
        if (solution) {
          free_tree(solution);
        }
        solution = cursolution;
        best = cur;
      } else {
        free_tree(cursolution);
      }
    }
  }

  if (graph->alias) {
    #pragma omp parallel for default(none) shared(solution) \
      num_threads(objective->nthreads)
    for (i=0;i<solution->nvtxs;++i) {
      solution->alias[i] = graph->alias[solution->alias[i]];
    }
  }

  return solution;
}


/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


double * burntside_init_options(void)
{
  double * options = double_init_alloc(BURNTSIDE_VAL_OFF,BURNTSIDE_NOPTIONS);
  return options; 
}


int burntside_internal_solve(
    objective_t * objective, 
    graph_t const * graph, 
    vtx_t const * term, 
    vtx_t nterm,
    tree_t ** r_solution);


int burntside_internal_solve(
    objective_t * const objective, 
    graph_t const * const graph, 
    vtx_t const * const term, 
    vtx_t const nterm,
    tree_t ** const r_solution)
{
  int rv;
  tree_t * solution;

  if (objective->time) {
    dl_start_timer(&(objective->timers.solve));
  }

  solution = __solve(objective,graph,term,nterm);

  if (objective->time) {
    dl_stop_timer(&(objective->timers.solve));
  }

  if (solution == NULL) {
    *r_solution = NULL;
    rv = BURNTSIDE_ERROR_UNKNOWN;
  } else {
    *r_solution = solution;
    rv = BURNTSIDE_SUCCESS;
  }

  return rv;
}


int burntside_solve(
    vtx_t const * const r_nvtxs, 
    adj_t const * const xadj, 
    vtx_t const * const adjncy, 
    wgt_t const * const adjwgt, 
    vtx_t const * const term, 
    vtx_t const * const r_nterm, 
    double const * const options, 
    adj_t ** const r_links, 
    adj_t * const r_nlinks)
{

  
  return BURNTSIDE_SUCCESS;
}





#endif
