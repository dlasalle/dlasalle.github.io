/**
 * @file io.c
 * @brief Functions for read and writing steiner tree information
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-07-30
 */




#ifndef BURNTSIDE_IO_C
#define BURNTSIDE_IO_C




#include "io.h"




/******************************************************************************
* MACROS **********************************************************************
******************************************************************************/


#define __SECTION_STR "SECTION"
#define __STP_HEADER "33D32945 STP File, STP Format Version 1.0"




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const size_t BUFFERSIZE = 0x1000;




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


/**
 * @brief Wrapper around the dl_file routines to handle error codes
 *
 * @param filename The file to open
 * @param mode The mode to open the file in
 * @param r_file The reference to the file pointer
 *
 * @return BURNTSIDE_SUCCESS, or an error code
 */
static int __open_file(
    char const * const filename, 
    char const * const mode, 
    file_t ** const r_file)
{
  int rv;

  if ((rv = dl_open_file(filename,mode,r_file)) != DL_FILE_SUCCESS) {
    switch (rv) {
      case DL_FILE_BAD_PARAMETERS:
      case DL_FILE_PATH_PARSE_FAILURE:
        eprintf("Bad filename '%s'\n",filename);
        rv = BURNTSIDE_ERROR_IO;
        break;
      case DL_FILE_PATH_BAD:
        eprintf("File not found '%s'\n",filename);
        rv = BURNTSIDE_ERROR_IO;
        break;
      case DL_FILE_PATH_ACCESS_DENIED:
      case DL_FILE_READ_ACCESS_DENIED:
      case DL_FILE_WRITE_ACCESS_DENIED:
        eprintf("Permission denied '%s'\n",filename);
        rv = BURNTSIDE_ERROR_IO;
        break;
      default:
        eprintf("Unknown failure: %d opening '%s'\n",rv,filename);
        rv = BURNTSIDE_ERROR_UNKNOWN;
        break;
    }
  } else {
    rv = BURNTSIDE_SUCCESS;
  }

  return rv;
}


/**
 * @brief Move the current curser in the file to a specific section.
 *
 * @param file The file to move the cursor of.
 * @param section The name of the section to move to.
 * @param r_bufsize A reference to the current/resulting buffer size.
 *
 * @return 1 if the section is found.
 */
static int __find_section(
    file_t * file, 
    char const * const section, 
    size_t * const r_bufsize)
{
  int found = 0;
  ssize_t ll;
  char * line = NULL;
  size_t bufsize;
  char str[512];

  bufsize = *r_bufsize;

  while((ll = dl_get_next_line(file,&line,&bufsize)) >= 0) {
    dl_string_upperize(line);
    if (sscanf(line,__SECTION_STR"%*[ \t]%512s",str) != 1) {
      continue;
    } else {
      if (strcmp(section,str) == 0) {
        /* found the section */
        found = 1;
        break;
      } else {
        /* some other section */
      }
    }
  }

  dl_free(line);

  *r_bufsize = bufsize;

  return found;
}




static int __read_terminals_stp(
    char const * const filename,
    vtx_t * const r_nterm,
    vtx_t ** const r_term)
{
  int rv;
  vtx_t nterm, i;
  ssize_t ll;
  char * line = NULL;
  size_t bufsize = BUFFERSIZE;
  vtx_t * term = NULL;
  file_t * ifile = NULL;

  if ((rv = __open_file(filename,"r",&ifile)) != BURNTSIDE_SUCCESS) {
    goto END;
  }
  line = char_alloc(bufsize);

  /* find the graph section */
  if (!__find_section(ifile,"TERMINALS",&bufsize)) {
    eprintf("Could not find terminal section\n");
    rv = BURNTSIDE_ERROR_INVALIDINPUT; 
    goto END;
  }

  /* read the number of terminals */
  if ((ll = dl_get_next_line(ifile,&line,&bufsize)) < 0 || 
      sscanf(line,"Terminals%*[ \t]"PF_VTX_T,&nterm) != 1) {
    eprintf("Could not read number of terminals from terminal section\n");
    rv = BURNTSIDE_ERROR_INVALIDINPUT; 
    goto END;
  }

  /* read the terminals */
  term = vtx_alloc(nterm);
  for (i=0;i<nterm;++i) {
    if ((ll = dl_get_next_line(ifile,&line,&bufsize)) < 0 || 
        sscanf(line,"T%*[ \t]"PF_VTX_T,term+i) != 1) {
      eprintf("Could not read terminal number of term '"PF_VTX_T"': '%s'\n",i,
          line);
      rv = BURNTSIDE_ERROR_INVALIDINPUT; 
      goto END;
    }
  }
  if ((ll = dl_get_next_line(ifile,&line,&bufsize)) < 0 || 
      dl_strncmp_nocase("END",line,3) != 0) {
    eprintf("Did not find end of section where expected: '%s'\n",line);
    rv = BURNTSIDE_ERROR_INVALIDINPUT; 
    goto END;
  }

  /* adjust for 1 based ordering */
  for (i=0;i<nterm;++i) {
    --term[i];
  }

  dl_close_file(ifile);
  ifile = NULL;

  /* save output */
  *r_nterm = nterm;
  *r_term = term;
  term = NULL;

  END:

  if (ifile) {
    dl_close_file(ifile);
  }
  if (term) {
    dl_free(term);
  }
  if (line) {
    dl_free(line);
  }

  return rv;
}


static int __write_solution_dimacs(
    char const * const filename,
    objective_t const * const objective,
    tree_t const * const solution)
{
  int rv;
  vtx_t i, k;
  adj_t j;
  twgt_t cost;
  file_t * file;

  if ((rv = __open_file(filename,"w",&file)) != BURNTSIDE_SUCCESS) {
    return rv;
  }

  cost = calc_cost(solution);

  /* print out header comment */
  dl_fprintf(file,"SECTION Comment\n");
  dl_fprintf(file,"Name \"%s\"\n","null"/*objective->instname*/);
  if (solution->vwgt) {
    dl_fprintf(file,"Problem \"NWSPG\"\n");
  } else {
    dl_fprintf(file,"Problem \"SPG\"\n");
  }
  dl_fprintf(file,"Program \"Burntside\"\n");
  dl_fprintf(file,"Version \"%d.%d.%d\"\n",BURNTSIDE_VER_MAJOR, \
      BURNTSIDE_VER_MINOR,BURNTSIDE_VER_SUBMINOR);
  dl_fprintf(file,"End\n\n");

  /* solution section */
  dl_fprintf(file,"SECTION Solutions\n");
  dl_fprintf(file,"Solution %0.05lf "PF_TWGT_T"\n", \
      dl_poll_timer(&(objective->timers.solve)),cost);
  dl_fprintf(file,"End\n\n");

  /* run section */
  dl_fprintf(file,"SECTION Run\n");
  dl_fprintf(file,"Threads "PF_TID_T"\n",objective->nthreads);
  dl_fprintf(file,"Time %0.05lf\n",dl_poll_timer(&(objective->timers.solve)));
  dl_fprintf(file,"Primal "PF_TWGT_T"\n",cost);
  dl_fprintf(file,"End\n\n");

  /* final solution section */
  dl_fprintf(file,"SECTION Finalsolution\n");
  dl_fprintf(file,"Vertices "PF_VTX_T"\n",solution->nvtxs);
  for (i=0;i<solution->nvtxs;++i) {
    dl_fprintf(file,"V "PF_VTX_T"\n",solution->alias[i]+1);
  } 
  dl_fprintf(file,"Edges "PF_ADJ_T"\n",solution->nedges/2);
  for (i=0;i<solution->nvtxs;++i) {
    for (j=solution->xadj[i];j<solution->xadj[i+1];++j) {
      k = solution->adjncy[j];
      if (solution->alias[i] < solution->alias[k]) {
        dl_fprintf(file,"E "PF_VTX_T" "PF_VTX_T"\n",solution->alias[i]+1,
            solution->alias[k]+1);
      }
    }
  }
  dl_fprintf(file,"End\n");

  dl_close_file(file);

  return BURNTSIDE_SUCCESS; 
}



/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int read_terminals(
    char const * const termfile,
    int const format,
    vtx_t * const r_nterm,
    vtx_t ** const r_term)
{
  switch (format) {
    case BURNTSIDE_FORMAT_STP:
      return __read_terminals_stp(termfile,r_nterm,r_term);
    default:  
      dl_error("Unknown file format for terminals: '%d'\n",format);
  }
}


int write_solution(
    char const * const filename,
    int const format,
    objective_t const * const objective,
    tree_t const * const solution)
{
  switch (format) {
    case BURNTSIDE_FORMAT_DIMACS:
      return __write_solution_dimacs(filename,objective,solution);
    default:
      dl_error("Unknown file format for solution: '%d'\n",format);
  }
}




#endif
