/**
 * @file burntside.c
 * @brief Top level functions for burntside
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-01-23
 */




#ifndef BURNTSIDE_C
#define BURNTSIDE_C




#include "base.h"
#include "graph.h"
#include "tree.h"
#include "objective.h"
#include "steiner.h"
#include "refine.h"




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLPQ_PREFIX aw
#define DLPQ_KEY_T wgt_t
#define DLPQ_VAL_T adj_t
#define DLPQ_STATIC
#include "dlpq_headers.h"
#undef DLPQ_STATIC
#undef DLPQ_VAL_T
#undef DLPQ_KEY_T
#undef DLPQ_PREFIX




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static void __prune(
    objective_t * const objective,
    graph_t * const graph,
    vtx_t * const term,
    vtx_t const nterm)
{
  #pragma omp master
  {
    if (objective->time) {
      dl_start_timer(&(objective->timers.prune));
    }
  }
  graph_prune(graph,term,nterm,NULL);
  #pragma omp master
  {
    if (objective->time) {
      dl_stop_timer(&(objective->timers.prune));
    }
  }
}


/**
 * @brief Contract a graph given a set of trees.
 *
 * @param objective The objective containing runtime parameters.
 * @param graph The graph to collapse.
 * @param trees The number of terminal trees.
 * @param ntrees The number of trees.
 * @param r_term A reference to the terminal list (output).
 * @param r_nterm A reference to the number of terminals (output).
 *
 * @return The contracted graph.
 */
static graph_t * __contract(
    objective_t * const objective,
    graph_t const * const graph,
    tree_t ** const trees,
    vtx_t const ntrees,
    vtx_t ** const r_term,
    vtx_t * const r_nterm)
{
  vtx_t cnvtxs, i, k, t, n, nterm, nlbl;
  vtx_t * cptr, * cvtx, * cmap, * term, * label, * counts;
  graph_t * cgraph;

  vtx_t const nvtxs = graph->nvtxs;

  /* determine number of coarse vertices */
  nterm = 0;
  cnvtxs = nvtxs;
  for (t=0;t<ntrees;++t) {
    /* the number of edges contracted equals the number of vertices removed */
    cnvtxs -= (trees[t]->nedges/2);
    /* the number of terminals is equal to the total number of trees */
    nterm += trees[t]->nvtxs - (trees[t]->nedges/2);
  }

  DL_ASSERT(cnvtxs > 0,"Attempting to contract graph to 0 vertices using "
      PF_VTX_T" trees from "PF_VTX_T" vertices\n",ntrees,nvtxs);

  /* allocate arrays */
  cptr = vtx_alloc(cnvtxs+1);
  cvtx = vtx_alloc(nvtxs);
  cmap = vtx_init_alloc(NULL_VTX,nvtxs);

  /* allocate term */
  term = vtx_alloc(nterm);

  dprintf("Contracting a graph of "PF_VTX_T" vertices and " \
      PF_VTX_T" components to "PF_VTX_T"/"PF_VTX_T" terms/vertices\n",nvtxs,
      nconn_components(graph->nvtxs,graph->xadj,graph->adjncy),nterm,cnvtxs);

  /* fill arrays */
  nterm = 0;
  n = 0;
  cptr[0] = 0;
  cnvtxs = 0;
  for (t=0;t<ntrees;++t) {
    /* it's possible my splitting resulted in disconnected components, and 
     * thus the subsequent trees may be forests */
    if (trees[t]->nvtxs > 0) {
      bowstring_label_components(trees[t]->nvtxs,trees[t]->xadj, \
          trees[t]->adjncy,&label,&nlbl);
      counts = vtx_init_alloc(0,nlbl);
      /* adjust cptr */
      for (i=0;i<trees[t]->nvtxs;++i) {
        ++counts[label[i]];
      }
      vtx_prefixsum_exc(counts,nlbl);
      for (i=0;i<trees[t]->nvtxs;++i) {
        k = trees[t]->alias[i];
        cvtx[n + counts[label[i]]++] = k;
        cmap[k] = cnvtxs + label[i];
      }
      for (i=0;i<nlbl;++i) {
        cptr[cnvtxs+i+1] = n + counts[i];
        term[nterm++] = cnvtxs+i;
      }
      n += counts[nlbl-1];
      cnvtxs += nlbl;

      dl_free(counts);
      dl_free(label);
    }
  }
  for (i=0;i<nvtxs;++i) {
    if (cmap[i] == NULL_VTX) {
      cvtx[n] = i;
      cmap[i] = cnvtxs;
      ++n;
      cptr[cnvtxs+1] = n;
      ++cnvtxs;
    }
  }

  cgraph = graph_build(graph,cptr,cvtx,cmap,cnvtxs);

  dl_free(cptr);
  dl_free(cvtx);
  dl_free(cmap);

  if (objective->prune) {
    __prune(objective,cgraph,term,nterm);
  }

  *r_term = term;
  *r_nterm = nterm;

  DL_ASSERT_EQUALS( \
      nconn_components(graph->nvtxs,graph->xadj,graph->adjncy), \
      nconn_components(cgraph->nvtxs,cgraph->xadj, \
        cgraph->adjncy), \
      PF_VTX_T);

  return cgraph;
}


/**
 * @brief Project a tree and its subtrees from a coarse graph to a find graph.
 *
 * @param graph The graph to project the solution to.
 * @param cgraph The graph to project the solution from.
 * @param ctree The solution on the coarse graph.
 * @param subtrees The contracted subtrees on the original graph.
 * @param nsubtrees The number of contracted subtrees.
 * @param term The terminal list.
 * @param nterm the number of terminals.
 *
 * @return The projected solution.
 */
static tree_t * __project(
    graph_t const * const graph,
    graph_t const * const cgraph,
    tree_t const * const ctree,
    tree_t const * const * const subtrees,
    vtx_t const nsubtrees,
    vtx_t const * const term,
    vtx_t const nterm)
{
  vtx_t i, t, k;
  adj_t j;
  int * present, * include;
  vtx_djset_t * set;
  aw_priority_queue_t * q;
  adj_t * radj;
  tree_t * tree;

  vtx_t const nvtxs = graph->nvtxs;
  adj_t const nedges = graph->nedges;
  adj_t const * const xadj = graph->xadj;
  vtx_t const * const adjncy = graph->adjncy;
  wgt_t const * const adjwgt = graph->adjwgt;


  /* allocate mst structures */
  set = vtx_djset_create(0,graph->nvtxs);
  q = aw_priority_queue_create(0,nedges);

  /* allocate reverse adjancy array */
  radj = adj_alloc(nedges);
  bowstring_build_adjncy_index(nvtxs,xadj,adjncy,radj);

  /* allocate tree building arrays */
  present = int_init_alloc(0,nvtxs);
  include = int_init_alloc(0,nedges);

  /* mark present vertices */
  for (i=0;i<ctree->nvtxs;++i) {
    k = cgraph->alias[ctree->alias[i]];
    present[k] = 1;
  }
  for (t=0;t<nsubtrees;++t) {
    for (i=0;i<subtrees[t]->nvtxs;++i) {
      k = subtrees[t]->alias[i];
      if (!present[k]) {
        present[k] = 1; 
      }
    }
  }

  /* added eligable edges to queue */
  for (i=0;i<nvtxs;++i) {
    if (present[i]) {
      for (j=xadj[i];j<xadj[i+1];++j) {
        k = adjncy[j];
        if (i < k && present[k]) {
          /* insert on upstream edges into the priority qeuue */
          if (adjwgt) {
            aw_minpq_push(adjwgt[j],j,q); 
          } else {
            aw_minpq_push(1.0,j,q);
          }
        }
      }
    }
  }

  /* create an mst to find present edges -- we ignore vertex weights as all 
   * vertices are included anyways */
  while (q->size > 0) {
    j = aw_minpq_pop(q);

    /* find the ends of the edge */
    k = adjncy[j];
    i = adjncy[radj[j]];

    DL_ASSERT(present[i],"Non-present vertex I attached to MST edge\n");
    DL_ASSERT(present[k],"Non-present vertex K attached to MST edge\n");

    if (vtx_djset_find(i,set) != vtx_djset_find(k,set)) {
      /* join the two subtrees */
      vtx_djset_join(i,k,set);
      include[j] = 1;
      include[radj[j]] = 1;
    }
  }

  dl_free(radj);
  vtx_djset_free(set);
  aw_priority_queue_free(q);

  tree = extract_tree(graph,present,include,term,nterm);

  dl_free(present);
  dl_free(include);

  return tree;
}


/**
 * @brief Partition a graph using an mst on the voronoi diagram while using
 * post-order to segment it.
 *
 * @param graph
 * @param term
 * @param nterm
 * @param labels
 */
static void __partition_MST(
    graph_t const * const graph,
    vtx_t const * const term,
    vtx_t const nterm,
    vtx_t const nparts,
    vtx_t * const labels)
{
  vtx_t i, k, partsize, p, cpartsize;
  int * adjmask, * ones;
  vtx_t * region, * tterm, * perm, * tsize, * parent;
  wgt_t * dist;
  graph_t * vgraph;
  tree_t * tree;

  partsize = graph->nvtxs / nparts;

  vgraph = graph_create();
  vgraph->nvtxs = nterm;

  region = vtx_alloc(graph->nvtxs);
  parent = vtx_alloc(graph->nvtxs);
  dist = wgt_alloc(graph->nvtxs);

  bowstring_voronoi_regions(graph->nvtxs,graph->xadj,graph->adjncy, \
      graph->adjwgt,term,nterm,region,parent,dist);

  dl_free(parent);

  bowstring_voronoi_diagram(graph->nvtxs,graph->xadj,graph->adjncy, \
      graph->adjwgt,nterm,region,dist,&vgraph->xadj,&vgraph->adjncy, \
      &vgraph->adjwgt,NULL,NULL);

  dl_free(dist);

  vgraph->nedges = vgraph->xadj[vgraph->nvtxs];

  /* build mst */
  bowstring_build_tree(BOWSTRING_TREE_MST,vgraph->nvtxs,vgraph->xadj, \
      vgraph->adjncy,vgraph->adjwgt,NULL,NULL,NULL,&adjmask);

  ones = int_init_alloc(1,nterm);
  tterm = vtx_alloc(nterm);
  vtx_incset(tterm,0,1,nterm);

  tree = extract_tree(vgraph,ones,adjmask,tterm,nterm);

  dl_free(ones);
  dl_free(adjmask);

  /* count the size of voronoi regions */
  tsize = vtx_init_alloc(0,nterm);
  for (i=0;i<graph->nvtxs;++i) {
    ++tsize[region[i]];
  }

  /* create post-order permutation */
  perm = vtx_alloc(vgraph->nvtxs);

  bowstring_permutation(BOWSTRING_ORDER_POST,vgraph->nvtxs,vgraph->xadj, \
      vgraph->adjncy,NULL,NULL,perm);

  tree_free(tree);

  /* induce cut */
  p = 0;
  cpartsize = 0;
  for (k=0;k<vgraph->nvtxs;++k) {
    i = perm[k];
    cpartsize += tsize[i];
    tterm[i] = p;
    if (cpartsize > partsize && p < nparts-1) {
      cpartsize = 0;
      ++p;
    }
  }
  dl_free(tsize);

  printf("p = "PF_VTX_T", nparts = "PF_VTX_T", and partisze = "PF_VTX_T", " \
      "cpartsize = "PF_VTX_T"\n",p,nparts,partsize,cpartsize);


  /* apply labels */
  for (i=0;i<graph->nvtxs;++i) {
    labels[i] = tterm[region[i]];
  }

  dl_free(tterm);
  dl_free(region);
}


#ifdef USE_MTMETIS

#include <mtmetis.h>

static void __partition_MTMETIS(
    graph_t const * const graph,
    vtx_t const * const term,
    vtx_t const nterm,
    vtx_t const nparts,
    vtx_t * const labels)
{
  adj_t j;
  wgt_t w, avge;
  vtx_t * iadjwgt;
  vtx_t * ivwgt;
  /* setup reverse adjwgt */
  if (graph->adjwgt) {
    iadjwgt = vtx_alloc(graph->nedges);

    /* build an rterm */
    avge = graph->gadjwgt / graph->nedges;

    /* set new edge weights */
    for (i=0;i<graph->nvtxs;++i) {
      for (j=graph->xadj[i];j<graph->xadj[i+1];++j) {
        w = graph->adjwgt[j];
        if (w < avge*0.5) {
          iadjwgt[j] = 4;
        } else if (w < avge) {
          iadjwgt[j] = 2;
        } else {
          iadjwgt[j] = 1;
        }
      }
    }
  } else {
    iadjwgt = NULL;
  }

  ivwgt = vtx_calloc(graph->nvtxs);
  for (i=0;i<nterm;++i) {
    ivwgt[i] = 1;
  }

  mtmetis_partkway((int32_t*)&graph->nvtxs,(int32_t*)graph->xadj, \
      (int32_t*)graph->adjncy,(int32_t*)ivwgt,(int32_t*)iadjwgt, \
      (int32_t*)&nparts,(int32_t*)labels,NULL);

  dl_free(ivwgt);

  if (iadjwgt) {
    dl_free(iadjwgt);
  }
}


#endif


#ifdef USE_NERSTRAND


#include <nerstrand.h>


static void __partition_NERSTRAND(
    graph_t const * const graph,
    vtx_t const * const term,
    vtx_t const nterm,
    vtx_t const nparts,
    vtx_t * const labels)
{
  vtx_t i;
  adj_t j;
  wgt_t w, avge;
  wgt_t * radjwgt;

  /* setup reverse adjwgt */
  if (graph->adjwgt) {
    radjwgt = wgt_alloc(graph->nedges);

    /* build an rterm */
    avge = graph->gadjwgt / graph->nedges;

    /* set new edge weights */
    for (i=0;i<graph->nvtxs;++i) {
      for (j=graph->xadj[i];j<graph->xadj[i+1];++j) {
        w = graph->adjwgt[j];
        if (w < avge*0.5) {
          radjwgt[j] = 4;
        } else if (w < avge) {
          radjwgt[j] = 2;
        } else {
          radjwgt[j] = 1;
        }
      }
    }
  } else {
    radjwgt = NULL;
  }

  nerstrand_cluster_kway(&graph->nvtxs,graph->xadj,graph->adjncy, \
      radjwgt,&nparts,labels,NULL);

  if (radjwgt) {
    dl_free(radjwgt);
  }
}


#endif



/**
 * @brief Solve a steiner tree problem using a divide and conquer approach.
 *
 * @param objective The objective specifying runtime information.
 * @param graph The graph to find the steiner tree within.
 * @param term The list of terminal vertices.
 * @param nterm The number of terminal vertices.
 *
 * @return The steiner tree.
 */
static tree_t * __split_solve(
    objective_t * const objective, 
    graph_t const * const graph, 
    vtx_t const * const term, 
    vtx_t const nterm)
{
  vtx_t i,k,cnterm,nparts,p;
  vtx_t * xnterm, * cterm, * where, * labels;
  vtx_t ** xterm;
  tree_t * solution = NULL, * csolution = NULL;
  tree_t ** trees;
  graph_t * cgraph;
  /* subgraph junk */
  graph_t * xgraph;
  vtx_t * xnvtxs, * rename;
  adj_t ** xxadj;
  vtx_t ** xadjncy;
  wgt_t ** xadjwgt = NULL;
  wgt_t ** xvwgt = NULL;
  vtx_t ** xalias;

  if (objective->minsplit == 0 || nterm <= objective->minsplit) {
    /* don't bother splitting */
    return build_steiner_tree(objective,graph,term,nterm);
  }

  #pragma omp master 
  { 
    if (objective->time) {
      dl_start_timer(&(objective->timers.split));
    }
  }

  where = vtx_alloc(graph->nvtxs);
  nparts = ceil(nterm / (double)objective->minsplit);

  switch (objective->parttype) {
    #ifdef USE_MTMETIS
    case BURNTSIDE_PARTITION_EDGECUT:
      __partition_MTMETIS(graph,term,nterm,nparts,where); 
      break;
    #endif
    #ifdef USE_NERSTRAND
    case BURNTSIDE_PARTITION_MODULARITY:
      __partition_NERSTRAND(graph,term,nterm,nparts,where); 
      break;
    #endif
    case BURNTSIDE_PARTITION_MST:
      __partition_MST(graph,term,nterm,nparts,where); 
      break;
    default:
      dl_error("Unknown/Unsupported partitioning type '%d'\n", \
          objective->parttype);
  }

  /* make sure each partition is connected */
  bowstring_label_partition_components(graph->nvtxs,graph->xadj, \
      graph->adjncy,where,&labels,&nparts);

  dl_free(where);

  vprintf(objective->verbosity,BURNTSIDE_VERBOSITY_MEDIUM,"Created a " \
      "partitioning with "PF_VTX_T" partitions\n",nparts);

  /* allocate subgraphs */
  xnvtxs = vtx_alloc(nparts);
  xxadj = r_adj_alloc(nparts);
  xadjncy = r_vtx_alloc(nparts);
  xadjwgt = r_wgt_alloc(nparts);
  xvwgt = r_wgt_alloc(nparts);
  xalias = r_vtx_alloc(nparts);

  /* build subgraphs */
  bowstring_induce_subgraphs(graph->nvtxs,graph->xadj,graph->adjncy, \
      graph->adjwgt,graph->vwgt,labels,nparts,xnvtxs,xxadj,xadjncy,xadjwgt, \
      xvwgt,xalias,&rename);

  /* build xterms */
  xterm = r_vtx_alloc(nparts);
  xnterm = vtx_calloc(nparts);
  for (i=0;i<nterm;++i) {
    ++xnterm[labels[term[i]]];
  }
  for (p=0;p<nparts;++p) {
    xterm[p] = vtx_alloc(xnterm[p]);
    xnterm[p] = 0;
  }
  for (i=0;i<nterm;++i) {
    k = term[i];
    p = labels[k];
    xterm[p][xnterm[p]++] = rename[k];
  }
  dl_free(rename); 
  dl_free(labels);

  #pragma omp master 
  { 
    if (objective->time) {
      dl_stop_timer(&(objective->timers.split));
    }
  }

  /* allocate space to store trees */
  trees = (tree_t**)malloc(sizeof(tree_t*)*nparts);

  #pragma omp parallel for default(none) private(xgraph,i) shared(nparts, \
      xnvtxs,xxadj,xadjncy,xvwgt,xadjwgt,xnterm,xterm,xalias,trees,stdout)
  for (p=0;p<nparts;++p) {
    /* setup graph */
    xgraph = graph_setup(xnvtxs[p],xxadj[p],xadjncy[p],xvwgt[p],xadjwgt[p]);
    xgraph->alias = xalias[p];

    if (objective->prune) {
      __prune(objective,xgraph,xterm[p],xnterm[p]);
    }

    if (xnterm[p] > 1) {
      if (xnterm[p] == nterm) {
        /* if we failed to actually partition usefully */
        trees[p] = build_steiner_tree(objective,xgraph,xterm[p],xnterm[p]);
      } else {
        trees[p] = __split_solve(objective,xgraph,xterm[p],xnterm[p]);
      }
    } else if (xnterm[p] == 1) {
      trees[p] = create_tree(); 
      trees[p]->nvtxs = 1;
      trees[p]->xadj = adj_calloc(2);
      trees[p]->nedges = 0;
      if (xgraph->vwgt) {
        trees[p]->vwgt = wgt_alloc(1);
        trees[p]->vwgt[0] = xgraph->vwgt[xterm[p][0]];
      }
      trees[p]->alias = vtx_alloc(1);
      trees[p]->alias[0] = xterm[p][0];
    } else {
      trees[p] = create_tree(); 
      trees[p]->nvtxs = 0;
      trees[p]->nedges = 0;
    }

    dprintf("__split_solve() created tree with "PF_VTX_T" vertices, "PF_ADJ_T \
        " edges, and "PF_VTX_T" components\n",trees[p]->nvtxs, \
        trees[p]->nedges,nconn_components(trees[p]->nvtxs,trees[p]->xadj, \
        trees[p]->adjncy));


    /* fix alias */
    for (i=0;i<trees[p]->nvtxs;++i) {
      trees[p]->alias[i] = xgraph->alias[trees[p]->alias[i]];
    }
    
    /* free stuff */
    graph_free(xgraph);
  }

  /* free graph duouble pointers */
  dl_free(xnvtxs); 
  dl_free(xxadj);
  dl_free(xadjncy);
  dl_free(xadjwgt);
  dl_free(xvwgt);
  dl_free(xalias);

  r_vtx_free(xterm,nparts);
  dl_free(xnterm);

  #pragma omp master 
  { 
    if (objective->time) {
      dl_start_timer(&(objective->timers.merge));
    }
  }

  cgraph = __contract(objective,graph,trees,nparts,&cterm,&cnterm);

  #pragma omp master 
  { 
    if (objective->time) {
      dl_stop_timer(&(objective->timers.merge));
    }
  }

  /* build larger tree */
  csolution = __split_solve(objective,cgraph,cterm,cnterm);

  dl_free(cterm);

  #pragma omp master 
  { 
    if (objective->time) {
      dl_start_timer(&(objective->timers.merge));
    }
  }

  solution = __project(graph,cgraph,csolution, \
      (tree_t const * const *)trees,nparts,term,nterm);

  /* delete me */
  DL_ASSERT_EQUALS( \
      nconn_components(csolution->nvtxs,csolution->xadj, \
        csolution->adjncy), \
      nconn_components(solution->nvtxs,solution->xadj, \
        solution->adjncy), \
      PF_VTX_T);

  #pragma omp master 
  { 
    if (objective->time) {
      dl_stop_timer(&(objective->timers.merge));
    }
  }

  /* free trees */
  tree_free(csolution);
  for (p=0;p<nparts;++p) {
    tree_free(trees[p]);
  }
  dl_free(trees);

  /* free coarse graph */
  graph_free(cgraph);

  DL_ASSERT(nconn_components(graph->nvtxs,graph->xadj,graph->adjncy) >= \
      nconn_components(solution->nvtxs,solution->xadj,solution->adjncy), \
      "Solution has more components than graph");

  return solution;
}


/**
 * @brief 
 *
 * @param objective
 * @param graph
 * @param term
 * @param nterm
 *
 * @return 
 */
static tree_t * __solve(
    objective_t * const objective, 
    graph_t const * const graph, 
    vtx_t const * const term, 
    vtx_t const nterm)
{
  size_t r;
  wgt_t best, cur;
  vtx_t i;
  tree_t * solution = NULL, * cursolution = NULL;

  /* set best as worst */
  best = graph->gadjwgt;

  if (objective->nruns > 1) {
    /* run in parallel since we have multiple runs */
    #pragma omp parallel for default(none) shared(best,solution) \
      private(cursolution,cur) schedule(dynamic)
    for (r=0;r<objective->nruns;++r) {
      cursolution = __split_solve(objective,graph,term,nterm);

      refine(objective,graph,cursolution);

      cur = cursolution->cost;

      if (objective->runstats) {
        objective->runs[r] = cur;
      }

      #pragma omp critical
      {
        if (cur < best) {
          if (solution) {
            tree_free(solution);
          }
          solution = cursolution;
          best = cur;
        } else {
          tree_free(cursolution);
        }
      }
    }

  } else {
    /* don't start a parallel region */
    solution = __split_solve(objective,graph,term,nterm);

    refine(objective,graph,solution);

    cur = solution->cost;

    if (objective->runstats) {
      objective->runs[0] = cur;
    }
  }

  if (graph->alias) {
    #pragma omp parallel for default(none) shared(solution)
    for (i=0;i<solution->nvtxs;++i) {
      solution->alias[i] = graph->alias[solution->alias[i]];
    }
  }

  #ifdef USE_ASSERTS
  vtx_t n;
  n = 0;
  for (i=0;i<solution->nvtxs;++i) {
    if (solution->term[i]) {
      ++n;
    }
  }
  DL_ASSERT_EQUALS(n,nterm,PF_VTX_T);
  #endif

  return solution;
}


/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


double * burntside_init_options(void)
{
  double * options = double_init_alloc(BURNTSIDE_VAL_OFF,BURNTSIDE_NOPTIONS);
  return options; 
}


int burntside_internal_solve(
    objective_t * objective, 
    graph_t * graph, 
    vtx_t * term, 
    vtx_t nterm,
    tree_t ** r_solution);


int burntside_internal_solve(
    objective_t * const objective, 
    graph_t * const graph, 
    vtx_t * const term, 
    vtx_t const nterm,
    tree_t ** const r_solution)
{
  int rv;
  tree_t * solution;

  if (objective->prune) {
    __prune(objective,graph,term,nterm);
  }

  if (objective->time) {
    dl_start_timer(&(objective->timers.solve));
  }

  solution = __solve(objective,graph,term,nterm);

  if (objective->time) {
    dl_stop_timer(&(objective->timers.solve));
  }

  if (solution == NULL) {
    *r_solution = NULL;
    rv = BURNTSIDE_ERROR_UNKNOWN;
  } else {
    *r_solution = solution;
    rv = BURNTSIDE_SUCCESS;
  }

  return rv;
}


int burntside_solve(
    vtx_t const * const r_nvtxs, 
    adj_t const * const xadj, 
    vtx_t const * const adjncy, 
    wgt_t const * const adjwgt, 
    vtx_t const * const term, 
    vtx_t const * const r_nterm, 
    double const * const options, 
    adj_t ** const r_links, 
    adj_t * const r_nlinks)
{

  
  return BURNTSIDE_SUCCESS;
}





#endif
