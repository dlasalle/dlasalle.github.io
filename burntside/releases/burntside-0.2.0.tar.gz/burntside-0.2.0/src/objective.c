/**
 * @file objective.c
 * @brief Functions for manipulating and creating objectives
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-07-23
 */




#ifndef BURNTSIDE_OBJECTIVE_C
#define BURNTSIDE_OBJECTIVE_C




#include "objective.h"




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX objective
#define DLMEM_TYPE_T objective_t
#define DLMEM_DLTYPE DLTYPE_STRUCT
#define DLMEM_INITFUNCTION init_objective
#define DLMEM_STATIC
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_INITFUNCTION
#undef DLMEM_DLTYPE
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const unsigned int DEFAULT_SEED = 1; 
static const burntside_expansion_t DEFAULT_EXPTYPE = \
    BURNTSIDE_EXPANSION_GROW;
static const int DEFAULT_REFTYPE = BURNTSIDE_REFINE_NONE;
static const size_t DEFAULT_NRUNS = 8; 
static const size_t DEFAULT_NREFPASS = 8;
static const burntside_verbosity_t DEFAULT_VERBOSITY = BURNTSIDE_VERBOSITY_LOW;
static const int DEFAULT_DO_TIMING = 0;
static const int DEFAULT_DO_RUNSTATS = 0;
static const tid_t DEFAULT_NTHREADS = 1;
static const vtx_t DEFAULT_MIN_SPLIT = 2048;
static const int DEFAULT_IGNORE = 1;
static const int DEFAULT_PRUNE = 0;
static const int DEFAULT_PARTTYPE = BURNTSIDE_PARTITION_MST;


static const char * const trans_table_exptype[] = {
  [BURNTSIDE_EXPANSION_GROW] = BURNTSIDE_STR_EXPANSION_GROW,
  [BURNTSIDE_EXPANSION_MST] = BURNTSIDE_STR_EXPANSION_MST,
  [BURNTSIDE_EXPANSION_SPH] = BURNTSIDE_STR_EXPANSION_SPH
};


static const char * const trans_table_reftype[] = {
  [BURNTSIDE_REFINE_NONE] = BURNTSIDE_STR_REFINE_NONE,
  [BURNTSIDE_REFINE_VTX] = BURNTSIDE_STR_REFINE_VTX,
  [BURNTSIDE_REFINE_KP] = BURNTSIDE_STR_REFINE_KP,
  [BURNTSIDE_REFINE_KV] = BURNTSIDE_STR_REFINE_KV,
  [BURNTSIDE_REFINE_VKP] = BURNTSIDE_STR_REFINE_VKP,
  [BURNTSIDE_REFINE_VKK] = BURNTSIDE_STR_REFINE_VKK
};


static const char * const trans_table_parttype[] = {
  [BURNTSIDE_PARTITION_NONE] = BURNTSIDE_STR_PARTITION_NONE,
  [BURNTSIDE_PARTITION_MODULARITY] = BURNTSIDE_STR_PARTITION_MODULARITY,
  [BURNTSIDE_PARTITION_EDGECUT] = BURNTSIDE_STR_PARTITION_EDGECUT,
  [BURNTSIDE_PARTITION_MST] = BURNTSIDE_STR_PARTITION_MST
};


static const char * const trans_table_verbosity[] = {
  [BURNTSIDE_VERBOSITY_MINIMUM] = BURNTSIDE_STR_VERBOSITY_MINIMUM,
  [BURNTSIDE_VERBOSITY_LOW] = BURNTSIDE_STR_VERBOSITY_LOW,
  [BURNTSIDE_VERBOSITY_MEDIUM] = BURNTSIDE_STR_VERBOSITY_MEDIUM,
  [BURNTSIDE_VERBOSITY_HIGH] = BURNTSIDE_STR_VERBOSITY_HIGH,
  [BURNTSIDE_VERBOSITY_MAXIMUM] = BURNTSIDE_STR_VERBOSITY_MAXIMUM
};




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static inline int __find_string(
    const char * const table[], 
    const char * const str)
{
  int i;
  ssize_t n = (ssize_t)(sizeof(table)/sizeof(char*));
  if (str == NULL) {
    return -1;
  }
  for (i=0;i<n;++i) {
    if (strcmp(table[i],str) == 0) {
      break;
    }
  }
  if (i == n) {
    return -1;
  } else {
    return i;
  }
}




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


objective_t * init_objective(
    objective_t * const objective)
{
  objective->seed = (unsigned int)time(NULL); /* DEFAULT_SEED; */
  objective->nthreads = omp_get_max_threads(); /* DEFAULT_NTHREADS; */
  objective->exptype = DEFAULT_EXPTYPE;
  objective->reftype = DEFAULT_REFTYPE;
  objective->time = DEFAULT_DO_TIMING;
  objective->runstats = DEFAULT_DO_RUNSTATS;
  objective->runs = NULL;
  objective->verbosity = DEFAULT_VERBOSITY;
  objective->nruns = DEFAULT_NRUNS;
  objective->nrefpass = DEFAULT_NREFPASS;
  objective->parttype = DEFAULT_PARTTYPE;
  objective->minsplit = DEFAULT_MIN_SPLIT;
  objective->ignore = DEFAULT_IGNORE;
  objective->prune = DEFAULT_PRUNE;

  /* timers */
  dl_init_timer(&(objective->timers.total));
  dl_init_timer(&(objective->timers.io));
  dl_init_timer(&(objective->timers.prune));
  dl_init_timer(&(objective->timers.solve));
  dl_init_timer(&(objective->timers.split));
  dl_init_timer(&(objective->timers.merge));
  dl_init_timer(&(objective->timers.expand));
  dl_init_timer(&(objective->timers.refine));

  /* derived fields */
  setup_objective(objective);

  return objective;
}


int setup_objective(
    objective_t * objective)
{
  int rv = BURNTSIDE_SUCCESS;


  /* start checks */
  if (objective->nruns < 1) {
    rv = BURNTSIDE_ERROR_INVALIDOPTIONS;
    goto END;
  }
  if (objective->nthreads == 0) {
    rv = BURNTSIDE_ERROR_INVALIDOPTIONS;
    goto END;
  } else {
    omp_set_num_threads(objective->nthreads);
  }
  if (objective->parttype == BURNTSIDE_PARTITION_NONE) {
    objective->minsplit = 0;
  }

  END:

  return rv;
}


int parse_objective(
    double const * const options, 
    objective_t ** const r_objective)
{
  int rv = BURNTSIDE_SUCCESS;
  objective_t * objective = NULL;

  objective = objective_calloc(1);
  if (objective == NULL) {
    rv = BURNTSIDE_ERROR_NOTENOUGHMEMORY;
    goto END;
  }

  if (options[BURNTSIDE_OPTION_SEED] != BURNTSIDE_VAL_OFF) {
    objective->seed = (unsigned int)options[BURNTSIDE_OPTION_SEED];
  }

  /* intialize seed */
  dl_set_rand(objective->seed);

  if (options[BURNTSIDE_OPTION_NRUNS] != BURNTSIDE_VAL_OFF) {
    objective->nruns = (size_t)options[BURNTSIDE_OPTION_NRUNS];
  }
  if (options[BURNTSIDE_OPTION_EXPANSION] != BURNTSIDE_VAL_OFF) {
    objective->exptype = \
        (burntside_expansion_t)options[BURNTSIDE_OPTION_EXPANSION];
  }
  if (options[BURNTSIDE_OPTION_VERBOSITY] != BURNTSIDE_VAL_OFF) {
    objective->verbosity = 
        (burntside_verbosity_t)options[BURNTSIDE_OPTION_VERBOSITY];
  }
  if (options[BURNTSIDE_OPTION_TIME] != BURNTSIDE_VAL_OFF) {
    objective->time = 1;
  }
  if (options[BURNTSIDE_OPTION_NTHREADS] != BURNTSIDE_VAL_OFF) {
    objective->nthreads = (tid_t)options[BURNTSIDE_OPTION_NTHREADS];
  }
  if (options[BURNTSIDE_OPTION_RUNSTATS] != BURNTSIDE_VAL_OFF) {
    objective->runstats = (int)options[BURNTSIDE_OPTION_RUNSTATS];
    if (objective->runstats) {
      objective->runs = wgt_alloc(objective->nruns);
    }
  }
  if (options[BURNTSIDE_OPTION_MINSPLIT] != BURNTSIDE_VAL_OFF) {
    objective->minsplit = (vtx_t)options[BURNTSIDE_OPTION_MINSPLIT];
  }
  if (options[BURNTSIDE_OPTION_IGNORE] != BURNTSIDE_VAL_OFF) {
    objective->ignore = (int)options[BURNTSIDE_OPTION_IGNORE];
  }
  if (options[BURNTSIDE_OPTION_PRUNE] != BURNTSIDE_VAL_OFF) {
    objective->prune = (int)options[BURNTSIDE_OPTION_PRUNE];
  }
  if (options[BURNTSIDE_OPTION_REFINE] != BURNTSIDE_VAL_OFF) {
    objective->reftype = (int)options[BURNTSIDE_OPTION_REFINE];
  }
  if (options[BURNTSIDE_OPTION_PARTITION] != BURNTSIDE_VAL_OFF) {
    objective->parttype = (int)options[BURNTSIDE_OPTION_PARTITION];
  }
  if ((rv = setup_objective(objective)) != BURNTSIDE_SUCCESS) {
    goto END;
  }

  *r_objective = objective;
  objective = NULL;

  END:

  if (objective) {
    free_objective(objective);
    objective = NULL;
  }

  return rv;
}


int free_objective(
    objective_t * objective)
{
  if (objective->runs) {
    dl_free(objective->runs);
  }
  dl_free(objective);

  return BURNTSIDE_SUCCESS;
}


/* PRINTING FUNCTIONS ********************************************************/


void print_objective(
    objective_t const * const objective)
{
  dl_print_header("PARAMETERS",'%');
  printf("Number of Threads: "PF_TID_T" | Verbosity: %s\n", \
      objective->nthreads,trans_verbosity_string(objective->verbosity));
  printf("Number of Runs: "PF_SIZE_T" | Random Seed: %u\n",objective->nruns, \
      objective->seed);
  printf("Expansion Type: %s | Refinement Type: %s\n", \
      trans_exptype_string(objective->exptype), \
      trans_reftype_string(objective->reftype));
  printf("Ignore Vertices: %s | Prune Vertices: %s\n", \
      objective->ignore ? "YES" : "NO",objective->prune ? "YES" : "NO");
  printf("Partition Type: %s | Minimum Split: "PF_VTX_T"\n", \
      trans_parttype_string(objective->parttype),objective->minsplit);

  dl_print_footer('%');
}


void print_timers(
    timers_t const * const timers)
{
  dl_print_header("TIMING",'$');
  printf("Total Time: %.05fs\n",dl_poll_timer(&(timers->total)));
  printf("\tIO: %.05fs\n",dl_poll_timer(&(timers->io)));
  printf("\tSolving: %.05fs\n",dl_poll_timer(&(timers->solve)));
  printf("\t\tPrunning: %.05fs\n",dl_poll_timer(&(timers->prune)));
  printf("\t\tSplitting: %.05fs\n",dl_poll_timer(&(timers->split)));
  printf("\t\tMerging: %.05fs\n",dl_poll_timer(&(timers->merge)));
  printf("\t\tExpansion: %.05fs\n",dl_poll_timer(&(timers->expand)));
  printf("\t\tRefinement: %.05fs\n",dl_poll_timer(&(timers->refine)));
  dl_print_footer('$');
}


void print_runstats(
    objective_t const * const objective)
{
  size_t const nruns = objective->nruns;
  wgt_t const * const runs = objective->runs;

  dl_print_header("STATISTICS",'#');
  printf("Total Runs: %zu\n",nruns);
  printf("Max Cost: "PF_WGT_T" Min Cost: "PF_WGT_T"\n", \
      wgt_max_value(runs,nruns), wgt_min_value(runs,nruns));
  printf("Mean Geo.: %lf Ari.: %lf\n", \
      wgt_geometric_mean(runs,nruns),wgt_arithmetic_mean(runs,nruns));
  printf("Median: "PF_WGT_T" Std. Dev.: %lf\n", \
      wgt_median(runs,nruns),wgt_stddev(runs,nruns));
  dl_print_footer('#');
}


/* TRANSLATION FUNCTIONS *****************************************************/

char const * trans_exptype_string(
    int const type)
{
  return trans_table_exptype[type];
}


char const * trans_reftype_string(
    int const type)
{
  return trans_table_reftype[type];
}


char const * trans_parttype_string(
    int const type)
{
  return trans_table_parttype[type];
}


char const * trans_verbosity_string(
    int const type)
{
  return trans_table_verbosity[type];
}


int trans_string_verbosity(
    char const * const str)
{
  int i = __find_string(trans_table_verbosity,str);
  if (i < 0) {
    dl_error("Unknown Verbosity Level '%s'\n",str);
  } else {
    return i;
  }
}


int trans_string_exptype(
    char const * const str)
{
  int i = __find_string(trans_table_exptype,str);
  if (i < 0) {
    dl_error("Unknown Expansion Type '%s'\n",str);
  } else {
    return i;
  }
}


int trans_string_reftype(
    char const * const str)
{
  int i = __find_string(trans_table_reftype,str);
  if (i < 0) {
    dl_error("Unknown Expansion Type '%s'\n",str);
  } else {
    return i;
  }
}


int trans_string_parttype(
    char const * const str)
{
  int i = __find_string(trans_table_parttype,str);
  if (i < 0) {
    dl_error("Unknown Expansion Type '%s'\n",str);
  } else {
    return i;
  }
}

#endif
