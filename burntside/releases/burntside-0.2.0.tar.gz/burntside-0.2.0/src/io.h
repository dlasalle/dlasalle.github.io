/**
 * @file io.h
 * @brief Function prototypes for reading and writing steiner tree information.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-07-30
 */




#ifndef BURNTSIDE_IO_H
#define BURNTSIDE_IO_H



#include "base.h"
#include "tree.h"
#include "objective.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


int read_terminals(
    char const * termfile,
    int format,
    vtx_t * r_nterm,
    vtx_t ** r_term);


int write_solution(
    char const * filename,
    int format,
    objective_t const * objective,
    tree_t const * solution);




#endif

