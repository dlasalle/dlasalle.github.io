/**
 * @file graph.h
 * @brief Types and function prototypes for graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-02-17
 */




#ifndef BURNTSIDE_GRAPH_H
#define BURNTSIDE_GRAPH_H




#include "base.h"




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


/**
 * @brief The structure to hold the graph information 
 */
typedef struct graph_t {
  vtx_t nvtxs; /* number of vertices */
  adj_t nedges; /* number of edges */
  twgt_t gadjwgt; /* total weight of all edges */
  adj_t * xadj;
  vtx_t * adjncy;
  wgt_t * vwgt;
  wgt_t * adjwgt;
  vtx_t * alias;
} graph_t;




/******************************************************************************
* SERIAL FUNCTION PROTOTYPES **************************************************
******************************************************************************/


#define graph_create __burntside_graph_create
/**
 * @brief Allocate and initialize a graph structure.
 *
 * @return Return the graph.
 */
graph_t * graph_create(void);


#define graph_init __burntside_graph_init
/**
 * @brief Initialize (zero) the graph
 *
 * @param graph The graph to initialize
 *
 * @return The initialized graph
 */
graph_t * graph_init(
    graph_t * graph);


#define graph_prune __burntside_graph_prune
/**
 * @brief Prune all degree one vertices from a graph.
 *
 * @param graph The graph to prune.
 * @param term The terminals in the graph.
 * @param nterm The number of terminals in the graph.
 * @param r_rename The vertex renaming ID's. Deleted vertices
 *
 */
void graph_prune(
    graph_t * graph,
    vtx_t * term,
    vtx_t nterm,
    vtx_t ** r_rename);


#define graph_setup __burntside_graph_setup
/**
 * @brief Initializes a graph with passed in edge and vertex arrays 
 *
 * @param nvtxs The number of vertices owned by each thread
 * @param xadj The adjncy array indicies for each vertex
 * @param adjncy The list of edges for each vertex as indexed by xadj
 * @param adjwgt The weights of the edges (indexed the same as adjancy)
 * @param iadjwgt The weights of vertex internal edges
 * @param eadjwgt The sum of edge weights per vertex (weighted degree)
 * @param maxdeg The max vertex degree for each thread
 * @param nthreads The number of threads that will be used with this graph
 *
 * @return The setup graph.
 */
graph_t * graph_setup(
    vtx_t nvtxs, 
    adj_t * xadj, 
    vtx_t * adjncy, 
    wgt_t * vwgt,
    wgt_t * adjwgt);


#define graph_build __burntside_graph_build
/**
 * @brief Instantiate a contracted graph.
 *
 * @param graph The graph before contraction.
 * @param cptr The pointer into the cvtx array for each coarse vertex.
 * @param cvtx The list of fine vertices that make up a coarse vertex.
 * @param cmap The course vertex to fine vertex map.
 * @param cnvtxs The number of coarse vertices.
 *
 * @return The contracted graph.
 */
graph_t * graph_build(
    graph_t const * graph,
    vtx_t const * cptr,
    vtx_t const * cvtx,
    vtx_t const * cmap,
    vtx_t cnvtxs);


#define graph_free __burntside_graph_free
/**
 * @brief Frees a graph and it's memory. It does not free arrays
 * (xadj,adjncy,adjwgt) unless the corresponding flag is set, free_*
 *
 * @param graph The graph to be free'd
 *
 * @return !0 if successful 
 */
int graph_free(
    graph_t * graph);


#define graph_check __burntside_graph_check
/**
 * @brief Verify the sanity of a graph structure
 *
 * @param graph The graph to verify
 *
 * @return 1 on success, 0 on invalid graph
 */
int graph_check(
    const graph_t * graph);




#endif
