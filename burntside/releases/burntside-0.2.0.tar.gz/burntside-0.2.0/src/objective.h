/**
 * @file objective.h
 * @brief Types and function prototypes for manipulating and maintaining 
 * objectives
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-07-24
 */




#ifndef BURNTSIDE_OBJECTIVE_H
#define BURNTSIDE_OBJECTIVE_H




#include "base.h"




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef struct timers_t {
  dl_timer_t total;
  dl_timer_t io;
  dl_timer_t prune;
  dl_timer_t split;
  dl_timer_t merge;
  dl_timer_t expand;
  dl_timer_t refine;
  dl_timer_t solve;
} timers_t;


typedef struct objective_t {
  unsigned int seed;
  int time;
  int exptype;
  int reftype;
  int verbosity;
  int runstats;
  int ignore;
  int prune;
  int parttype;
  vtx_t minsplit;
  wgt_t * runs;
  size_t nruns;
  size_t nrefpass;
  tid_t nthreads;
  timers_t timers;
} objective_t;




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


#define init_objective __burntside_init_objective
/**
 * @brief Initialize an objective structure
 *
 * @param objective The objective to initalize
 *
 * @return The initialized structure
 */
objective_t * init_objective(
    objective_t * objective);


#define setup_objective __burntside_setup_objective
/**
 * @brief Calculate derived fields of an objective structure 
 *
 * @param objective The objective to setup
 *
 * @return BURNTSIDE_SUCCESS if successful, or an error code otherwise
 */
int setup_objective(
    objective_t * objective);


#define parse_objective __burntside_parse_objective
/**
 * @brief Create an objective struct from a list of options
 *
 * @param options An array indexed by options.
 * @param r_objective A reference to the objective pointer that will be
 * allocated.
 *
 * @return BURNTSIDE_SUCCESS if successful, or an error if invalid values are
 * encountered.
 */
int parse_objective(
    const double * options, 
    objective_t ** r_objective);


#define free_objective __burntside_free_objective
/**
 * @brief Free an objective structure and associated memory
 *
 * @param objective The objective structure to free
 *
 * @return !0 on success
 */
int free_objective(
    objective_t * objective);


#define print_objective __burntside_print_objective
/**
 * @brief Print the options and state of the objective.
 *
 * @param objective The objective to print the options of.
 */
void print_objective(
    objective_t const * objective);


#define print_timers __burntside_print_timers
/**
 * @brief Print the value of the timers.
 *
 * @param timers The timers to print.
 */
void print_timers(
    timers_t const * timers);


#define print_runstats __burntside_print_runstats
/**
 * @brief Print the statistics of the runs associated with this objective.
 * Should not be called if objective->runstats == 0.
 *
 * @param objective The objective to print the runs of.
 */
void print_runstats(
    objective_t const * objective);




/* TRANSLATION FUNCTIONS *****************************************************/

#define trans_verbosity_string __burntside_trans_verbosity_string
char const * trans_verbosity_string(
    int type);


#define trans_exptype_string __burntside_trans_exptype_string
char const * trans_exptype_string(
    int type);


#define trans_exptype_string __burntside_trans_exptype_string
char const * trans_reftype_string(
    int type);


#define trans_exptype_string __burntside_trans_exptype_string
char const * trans_parttype_string(
    int type);


#define trans_string_verbosity __burntside_trans_string_verbosity
int trans_string_verbosity(
    char const * str);


#define trans_string_exptype __burntside_trans_string_exptype
int trans_string_exptype(
    char const * str);


#define trans_string_reftype __burntside_trans_string_reftype
int trans_string_reftype(
    char const * str);


#define trans_string_parttype __burntside_trans_string_parttype
int trans_string_parttype(
    char const * str);


#endif
