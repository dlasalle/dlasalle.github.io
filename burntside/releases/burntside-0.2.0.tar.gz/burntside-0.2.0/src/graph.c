/**
 * @file graph.c
 * @brief Functions for graph operations
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-08
 */




#ifndef BURNTSIDE_GRAPH_C
#define BURNTSIDE_GRAPH_C




#include "graph.h"




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX graph
#define DLMEM_TYPE_T graph_t
#define DLMEM_DLTYPE DLTYPE_STRUCT
#define DLMEM_INITFUNCTION graph_init
#define DLMEM_STATIC
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_INITFUNCTION
#undef DLMEM_DLTYPE
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


graph_t * graph_create(void)
{
  graph_t * graph;

  graph = graph_calloc(1);

  return graph;
}


graph_t * graph_init(
    graph_t * const graph)
{  
  /* should be a valid graph with 0 vertices */
  graph->nvtxs = 0;
  graph->nedges = 0;
  graph->gadjwgt = 0.0;
  /* null out pointers */
  graph->xadj = NULL;
  graph->adjncy = NULL;
  graph->adjwgt = NULL;
  graph->vwgt = NULL;
  graph->alias = NULL;

  return graph;
}


void graph_prune(
    graph_t * const graph,
    vtx_t * const term,
    vtx_t const nterm,
    vtx_t ** const r_rename)
{
  vtx_t nvtxs, i, k, n, sq, nq;
  adj_t j, l;
  int * remove;
  adj_t * xadj, * deg;
  vtx_t * adjncy, * alias, * rename, * q;
  wgt_t * adjwgt, * vwgt;

  nvtxs = graph->nvtxs;
  xadj = graph->xadj;
  adjncy = graph->adjncy;
  vwgt = graph->vwgt;
  adjwgt = graph->adjwgt;

  if (graph->alias) {
    alias = graph->alias;
  } else {
    alias = graph->alias = vtx_alloc(nvtxs);
    vtx_incset(alias,0,1,nvtxs);
  }

  q = vtx_alloc(nvtxs);
  deg = adj_alloc(nvtxs);
  remove = int_init_alloc(0,nvtxs);
 
  /* add vertices for removal */
  for (i=0;i<nvtxs;++i) {
    deg[i] = xadj[i+1] - xadj[i];
  }

  /* make terminals unremovable */
  for (i=0;i<nterm;++i) {
    deg[term[i]] = nvtxs+2;
  }

  /* add vertices for removal */
  sq = 0;
  nq = 0;
  for (i=0;i<nvtxs;++i) {
    if (deg[i] < 2) {
      q[nq++] = i;
    }
  }

  /* delete degree one and zero vertices */
  while (sq < nq) {
    i = q[sq++];
    remove[i] = 1;
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (!remove[k]) {
        --deg[k];
        if (deg[k] < 2) {
          deg[k] = nvtxs+2; /* make sure it won't get processed again */
          q[nq++] = k;
        }
        break;
      }
    }
  }

  dl_free(deg);
  dl_free(q);

  rename = vtx_alloc(nvtxs); 

  /* modify graph */
  l = 0;
  n = 0;
  for (i=0;i<nvtxs;++i) {
    if (!remove[i]) {
      /* keep me */
      rename[i] = n;
      alias[n] = alias[i];
      if (vwgt) {
        vwgt[n] = vwgt[i];
      }
      j = xadj[i];
      xadj[n] = l;
      for (;j<xadj[i+1];++j) {
        k = adjncy[j];
        if (!remove[k]) {
          adjncy[l] = k;
          adjwgt[l] = adjwgt[j];
          ++l;
        } else {

        }
      }
      ++n;
    }
  }

  /* rename edges */
  for (j=0;j<l;++j) {
    adjncy[j] = rename[adjncy[j]];
  }

  /* rename terminals */
  for (i=0;i<nterm;++i) {
    term[i] = rename[term[i]];
  }

  dprintf("Pruned "PF_VTX_T"/"PF_VTX_T" vertices and "PF_ADJ_T"/"PF_ADJ_T" " \
      "edges\n",n,nvtxs,l,xadj[nvtxs]);

  xadj[n] = l;
  graph->nvtxs = n;
  graph->nedges = l;
  graph->gadjwgt = wgt_fa_sum(adjwgt,l);

  DL_ASSERT(graph_check(graph),"Pruned to a bad graph"); 

  if (r_rename) {
    *r_rename = rename;
  } else {
    dl_free(rename);
  }
}


graph_t * graph_setup(
    vtx_t const nvtxs, 
    adj_t * const xadj, 
    vtx_t * const adjncy, 
    wgt_t * const vwgt, 
    wgt_t * const adjwgt) 
{
  graph_t * const graph = graph_calloc(1); 

  DL_ASSERT(xadj != NULL,"Null xadj passed into setup_graph()");
  DL_ASSERT(adjncy != NULL,"Null xadj passed into setup_graph()");

  /* set nvtxs */
  graph->nvtxs = nvtxs;

  /* set nedges */
  graph->nedges = xadj[nvtxs];

  /* these have been asserted to not be NULL */
  graph->xadj = xadj;
  graph->adjncy = adjncy;

  /* these are either NULL or their properly initialized -- good either way */
  graph->vwgt = vwgt;
  if (adjwgt) {
    graph->adjwgt = adjwgt;
  } else {
    graph->adjwgt = wgt_init_alloc(1,graph->nedges);
  }

  /* calculate gadjwgt */
  graph->gadjwgt = wgt_fa_sum(graph->adjwgt,graph->nedges);

  dprintf("Setup a graph with "PF_VTX_T" vertices, "PF_ADJ_T" edges\n",
      graph->nvtxs,graph->nedges);

  DL_ASSERT(graph_check(graph),"Setup a bad graph\n");

  return graph;
}


graph_t * graph_build(
    graph_t const * const graph,
    vtx_t const * const cptr,
    vtx_t const * const cvtx,
    vtx_t const * const cmap,
    vtx_t const cnvtxs)
{
  graph_t * cgraph;
  vtx_t i, f, k, v;
  adj_t j, m, cnedges;
  adj_t * cxadj;
  vtx_t * cadjncy, * calias;
  wgt_t * cadjwgt = NULL, * cvwgt = NULL;
  adj_t * ht;

  DL_ASSERT(graph_check(graph),"graph_build given a bad graph.");

  /* expose graph parts */
  adj_t const nedges = graph->nedges;
  adj_t const * const xadj = graph->xadj;
  vtx_t const * const adjncy = graph->adjncy;
  wgt_t const * const adjwgt = graph->adjwgt;
  wgt_t const * const vwgt = graph->vwgt;

  /* allocate hashtable */
  ht = adj_init_alloc(NULL_ADJ,cnvtxs);

  /* allocate graph */
  cxadj = adj_alloc(cnvtxs+1);
  calias = vtx_alloc(cnvtxs);
  cadjncy = vtx_alloc(nedges);
  cadjwgt = wgt_alloc(nedges);

  if (vwgt) {
    cvwgt = wgt_alloc(cnvtxs);
  }

  /* populate vertex arrays */
  for (i=0;i<cnvtxs;++i) {
    f = cvtx[cptr[i]];
    calias[i] = f;
    /* terminal weights will be wrong, but we don't care */
    if (vwgt) {
      cvwgt[i] = vwgt[f]; 
    }
  }

  /* populate graph */
  cnedges = 0;
  cxadj[0] = 0;
  for (i=0;i<cnvtxs;++i) {
    /* for each fine vertex that makes up the coarse one */
    for (f=cptr[i];f<cptr[i+1];++f) {
      v = cvtx[f];
      DL_ASSERT_EQUALS(cmap[v],i,PF_VTX_T);
      for (j=xadj[v];j<xadj[v+1];++j) {
        k = cmap[adjncy[j]]; 
        if (k != i) {
          if ((m = ht[k]) == NULL_ADJ) {
            cadjncy[cnedges] = k;
            cadjwgt[cnedges] = adjwgt[j];
            ht[k] = cnedges;
            ++cnedges;
          } else {
            if (adjwgt[j] < cadjwgt[m]) {
              /* replace the edge with the lower weight one */
              cadjwgt[m] = adjwgt[j];
            }
          }
        }
      }
    }
    for (j=cxadj[i];j<cnedges;++j) {
      k = cadjncy[j];
      ht[k] = NULL_ADJ;
    }
    cxadj[i+1] = cnedges;
  }

  dl_free(ht);

  /* resize edge arrays if neccesary */
  if (cnedges < 0.75*nedges) {
    cadjncy = vtx_realloc(cadjncy,cnedges);
    cadjwgt = wgt_realloc(cadjwgt,cnedges);
  }
  
  cgraph = graph_setup(cnvtxs,cxadj,cadjncy,cvwgt,cadjwgt);
  cgraph->alias = calias;

  return cgraph;
}


int graph_free(
    graph_t * graph)
{
  /* free what should be free'd */
  if (graph->xadj) {
    dl_free(graph->xadj);
  }
  if (graph->adjncy) {
    dl_free(graph->adjncy);
  }
  if (graph->vwgt) {
    dl_free(graph->vwgt);
  }
  if (graph->adjwgt) {
    dl_free(graph->adjwgt);
  }
  if (graph->alias) {
    dl_free(graph->alias);
  }

  /* free the memory */
  dl_free(graph);

  /* we'll always assume we're successful */
  return BURNTSIDE_SUCCESS;
}


int graph_check(
    graph_t const * graph)
{
  vtx_t i,k;
  adj_t j,l;
  twgt_t gadjwgt;

  vtx_t const nvtxs = graph->nvtxs;
  adj_t const nedges = graph->nedges;
  adj_t const * const xadj = graph->xadj;
  vtx_t const * const adjncy = graph->adjncy;
  wgt_t const * const adjwgt = graph->adjwgt;

  /* xadj checks */
  if (xadj[0] != 0) {
    eprintf("graph->xadj[0] = "PF_ADJ_T"\n",xadj[0]);
    return 0;
  }
  if (nedges != xadj[nvtxs]) {
    eprintf("nedges = "PF_ADJ_T", xadj[nvtxs] = "PF_ADJ_T"\n", \
        nedges,xadj[nvtxs]);
    return 0;
  }

  /* edge doubliness checkes */
  for (i=0;i<nvtxs;++i) {
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      for (l=xadj[k];l<xadj[k+1];++l) {
        if (adjncy[l] == i) {
          break;
        }
      }
      if (l == xadj[k+1]) {
        eprintf("Edge from "PF_VTX_T" to "PF_VTX_T" missing in other "
            "direction\n",i,k);
        return 0;
      }
      if (adjwgt[j] != adjwgt[l]) {
        eprintf("Edge weight of edge "PF_ADJ_T"={"PF_VTX_T","PF_VTX_T"} " \
            " is not symmetric, ["PF_WGT_T","PF_WGT_T"]\n",j,i,k,adjwgt[j], \
            adjwgt[l]);
        return 0;
      }
    }
  }

  /* check totals */
  gadjwgt = wgt_fa_sum(adjwgt,nedges);
  if (!dl_near_equal(graph->gadjwgt,gadjwgt)) {
    eprintf("Incorrect total edge weight of "PF_TWGT_T", actual " \
        PF_TWGT_T"\n",graph->gadjwgt,gadjwgt);
    return 0;
  }

  return 1;
}


#ifdef XXX
void graph_term_mindist(
    graph_t const * const graph,
    vtx_t const * const rterm,
    vtx_t const * const term,
    vtx_t const nterm,
    wgt_t * const mindist)
{
  vtx_t i, k, t;
  adj_t j;
  vw_priority_queue_t * q;
  vtx_iset_t * searched;

  vtx_t const nvtxs = graph->nvtxs;
  adj_t const * const xadj = graph->xadj;
  vtx_t const * const adjncy = graph->adjncy;
  wgt_t const * const adjwgt = graph->adjwgt;
  wgt_t const * const vwgt = graph->vwgt;

  /* allocate structures */
  q = vw_priority_queue_create(0,nvtxs);
  searched = vtx_iset_create(0,nvtxs);

  for (t=0;t<nterm;++t) {
    i = term[t];
    vtx_iset_add(i,searched);
    vw_minpq_push(0,i,q);

    mindist = graph->gadjwgt;

    /* perform breadfirst search */
    while (q->size > 0) {
      i = vw_minpq_pop(q);

    }
  }
}
#endif


#endif
