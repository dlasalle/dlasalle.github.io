/**
 * @file lctree.c
 * @brief Link/Cut Tree Functions (Sleator-Tarjan Dynamic Tree)
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2014-10-16
 */




#ifndef BURNTSIDE_LCTREE_C
#define BURNTSIDE_LCTREE_C




#include "lctree.h"




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX lcnode
#define DLMEM_TYPE_T lcnode_t
#define DLMEM_DLTYPE DLTYPE_STRUCT
#define DLMEM_STATIC 1
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_DLTYPE
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


lctree_t * lctree_create(
    vtx_t const nvtxs)
{
  lctree_t * tree;

  tree = (lctree_t*)malloc(sizeof(lctree_t));

  tree->nnodes = nvtxs;
  tree->nodes = lcnode_alloc(tree->nnodes);

  lctree_reset(tree);

  return tree;
}


void lctree_reset(
    lctree_t * const tree)
{
  vtx_t i;

  for (i=0;i<tree->nnodes;++i) {
    tree->nodes[i].p = NULL_VTX;
    tree->nodes[i].w = 0.0;
  }
}


void lctree_link(
    vtx_t const v,
    vtx_t const u,
    wgt_t const w,
    lctree_t * const tree)
{
  if (tree->nodes[u].p == v || tree->nodes[v].p == u) {
    /* do nothing, they're already linked */
  } else if (tree->nodes[u].p == NULL_VTX) {
    /* if u is already the root of its tree, insert it in constant time */
    tree->nodes[u].p = v;
    tree->nodes[u].w = w;
  } else {
    /* make v the root of its tree */
    lctree_setroot(v,tree); 

    /* add v to u's tree */
    tree->nodes[v].p = u;
    tree->nodes[v].w = w;
  }
}


void lctree_cut(
    vtx_t const v,
    vtx_t const u,
    lctree_t * const tree)
{
  if (tree->nodes[v].p == u) {
    tree->nodes[v].p = NULL_VTX;
  } else if (tree->nodes[u].p == v) {
    tree->nodes[u].p = NULL_VTX;
  }
}


void lctree_setroot(
    vtx_t const v,
    lctree_t * const tree)
{
  vtx_t root, u, p;
  wgt_t w, x;

  root = v;

  u = tree->nodes[root].p;
  w = tree->nodes[root].w;

  while (u != NULL_VTX) {
    /* save u's parent info */
    p = tree->nodes[u].p;
    x = tree->nodes[u].w;

    /* update u */
    tree->nodes[u].p = root;
    tree->nodes[u].w = w;

    /* prepare for next iteration */
    root = u;
    u = p;
    w = x;
  }

  /* fix v as the root */
  tree->nodes[v].p = NULL_VTX;
}


vtx_t lctree_findroot(
    vtx_t const v,
    lctree_t const * const tree)
{
  vtx_t u;

  u = v;
  while (tree->nodes[u].p != NULL_VTX) {
    u = tree->nodes[u].p;
  }

  return u;
}


vtx_t lctree_findmax(
    vtx_t const v,
    lctree_t const * const tree)
{
  vtx_t u, mv;
  wgt_t max, w;

  mv = u = v;
  max = tree->nodes[u].w;

  while (tree->nodes[u].p != NULL_VTX) {
    w = tree->nodes[u].w;
    if (w > max) {
      mv = u;
    }
    u = tree->nodes[u].p;
  }

  return mv;
}


void lctree_free(
    lctree_t * tree) 
{
  if (tree->nodes) {
    dl_free(tree->nodes); 
  }
  dl_free(tree);
}




#endif
