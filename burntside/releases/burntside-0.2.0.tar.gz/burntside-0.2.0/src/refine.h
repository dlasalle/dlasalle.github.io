/**
 * @file refine.h
 * @brief Functions for making local improvements to established steiner trees.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2014-10-15
 */




#ifndef BURNTSIDE_REFINE_H
#define BURNTSIDE_REFINE_H




#include "base.h"
#include "objective.h"
#include "tree.h"
#include "graph.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


void refine(
    objective_t * objective,
    graph_t const * graph,
    tree_t * tree);




#endif
