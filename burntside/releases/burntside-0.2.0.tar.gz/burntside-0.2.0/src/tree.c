/**
 * @file tree.c
 * @brief Functions for manipulating and analyzing steiner trees 
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-05-29
 */





#ifndef BURNTSIDE_TREE_C
#define BURNTSIDE_TREE_C




#include "tree.h"
#include "graph.h"
#include <bowstring.h>



/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef enum vertex_status_t {
  VTX_NONE = 0x00,
  VTX_A    = 0x01,
  VTX_B    = 0x02,
  VTX_BOTH = 0x03
} vertex_status_t;




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX tree
#define DLMEM_TYPE_T tree_t
#define DLMEM_DLTYPE DLTYPE_STRUCT
#define DLMEM_STATIC 
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_DLTYPE
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


tree_t * create_tree(void)
{
  tree_t * tree;

  tree = tree_alloc(1);
  tree->nvtxs = 0;
  tree->nedges = 0;
  tree->cost = 0;
  tree->xadj = NULL;
  tree->adjncy = NULL;
  tree->adjwgt = NULL;
  tree->vwgt = NULL;
  tree->alias = NULL;
  tree->term = NULL;

  return tree;
}


twgt_t calc_cost(
    tree_t const * const tree)
{
  twgt_t cost;

  vtx_t const nvtxs = tree->nvtxs;
  adj_t const nedges = tree->xadj[tree->nvtxs];

  cost = 0;

  if (tree->vwgt) {
    cost += (twgt_t)wgt_fa_sum(tree->vwgt,nvtxs);
  }

  if (tree->adjwgt) {
    cost += (twgt_t)(wgt_fa_sum(tree->adjwgt,nedges) / 2.0);
  } else {
    cost += (twgt_t)(nedges / 2.0);
  }

  return cost;
}


tree_t * extract_tree(
    graph_t const * const graph,
    int const * const present,
    int const * const include,
    vtx_t const * const term,
    vtx_t const nterm)
{
  vtx_t i, k, tnvtxs, t;
  adj_t j, l;
  adj_t * txadj;
  vtx_t * tadjncy, * talias, * rename;
  wgt_t * tadjwgt = NULL, * tvwgt = NULL;
  int * tterm;
  tree_t * tree;

  vtx_t const nvtxs = graph->nvtxs;
  adj_t const * const xadj = graph->xadj;
  vtx_t const * const adjncy = graph->adjncy;
  wgt_t const * const adjwgt = graph->adjwgt;
  wgt_t const * const vwgt = graph->vwgt;

  /* count the number of tree verrtices */
  tnvtxs = 0;
  for (i=0;i<nvtxs;++i) {
    if (present[i]) {
      DL_ASSERT_EQUALS(present[i],1,"%d");
      ++tnvtxs; 
    }
  }
  
  /* allocate tree */
  tree = tree_calloc(1);
  tree->nvtxs = tnvtxs;
  tree->xadj = txadj = adj_alloc(tnvtxs+1);
  tree->adjncy = tadjncy = vtx_alloc(2*(tnvtxs-1));
  tree->alias = talias = vtx_alloc(tnvtxs);
  tree->term = tterm = int_init_alloc(0,tnvtxs);

  /* allocate rename array */
  rename = vtx_alloc(nvtxs);

  if (adjwgt) {
    tree->adjwgt = tadjwgt = wgt_alloc(2*(tnvtxs-1));
  }
  if (vwgt) {
    tree->vwgt = tvwgt = wgt_alloc(tnvtxs);
  }

  /* fill tree */
  tnvtxs = 0;
  l = 0;
  txadj[0] = 0;
  for (i=0;i<nvtxs;++i) {
    if (present[i]) {
      talias[tnvtxs] = i;
      rename[i] = tnvtxs;
      if (vwgt) {
        tvwgt[tnvtxs] = vwgt[i];
      }
      for (j=xadj[i];j<xadj[i+1];++j) {
        if (include[j]) {
          k = adjncy[j];
          DL_ASSERT(present[k],"Edge to non-present vertex found ("PF_VTX_T \
              ":"PF_VTX_T").\n",i,k);
          tadjncy[l] = k;
          if (adjwgt) {
            tadjwgt[l] = adjwgt[j];
          }
          ++l;
        }
      }
      ++tnvtxs;
      txadj[tnvtxs] = l;
    }
  }

  /* mark terminals */
  for (t=0;t<nterm;++t) {
    tterm[rename[term[t]]] = 1;
  }

  DL_ASSERT_EQUALS(tnvtxs,tree->nvtxs,PF_VTX_T);

  /* fix edges */
  for (j=0;j<txadj[tnvtxs];++j) { 
    tadjncy[j] = rename[tadjncy[j]];
  }
  dl_free(rename);

  tree->nedges = tree->xadj[tnvtxs];

  DL_ASSERT_EQUALS(tree->nedges,(adj_t)int_sum(include,xadj[nvtxs]),PF_ADJ_T);

  dprintf("Extracted tree with "PF_VTX_T"/"PF_VTX_T", "PF_ADJ_T"/"PF_ADJ_T \
      " edges, and "PF_VTX_T" terminals\n",tnvtxs,nvtxs, \
      txadj[tnvtxs],xadj[nvtxs],nterm);

  DL_ASSERT(bowstring_check_graph(tnvtxs,tree->xadj,tree->adjncy, \
        tree->adjwgt),"Generated bad tree\n");

  return tree;
}


void tree_post_order(
    tree_t * const tree,
    vtx_t * const rename)
{
  vtx_t nparent, i, n, p, k, l, nconn;
  adj_t j;
  int * visited;
  vtx_t * parent;
  adj_t * mark;
  vtx_t * perm, * alias;

  vtx_t const nvtxs = tree->nvtxs;

  DL_ASSERT(bowstring_check_graph(nvtxs,tree->xadj,tree->adjncy, \
      tree->adjwgt),"Bad graph after permutation\n");

  perm = vtx_alloc(nvtxs);
  parent = vtx_alloc(nvtxs);
  mark = adj_duplicate(tree->xadj,nvtxs);
  visited = int_init_alloc(0,nvtxs);

  nconn = 0;
  l = 0;
  n = 0;
  while (n < nvtxs) {
    dprintf("Ordering component "PF_VTX_T"\n",nconn);
    /* find a terminal */
    for (;l<nvtxs;++l) {
      if (!visited[l] && tree->term[l]) {
        break;
      }
    }

    /* post-order traversal */
    nparent = 0;
    visited[l] = 1;
    parent[nparent++] = l;
    while (nparent > 0) {
      i = parent[nparent-1];
      if (nparent > 1) {
        p = parent[nparent-2];
      } else {
        p = NULL_VTX;
      }
      for (j=mark[i];j<tree->xadj[i+1];++j) {
        k = tree->adjncy[j];
        if (p != k && !visited[k]) {
          mark[i] = j+1;
          visited[k] = 1;
          parent[nparent++] = k;
          goto NEXT;
        }
      }
      /* visit */
      perm[n++] = i;
      --nparent;
      NEXT:;
    }
    ++nconn;
  }

  dl_free(visited);
  dl_free(mark);
  dl_free(parent);

  bowstring_order_graph(tree->nvtxs,tree->xadj,tree->adjncy,tree->vwgt, \
      tree->adjwgt,perm);

  /* update the tree's alias information and create the rename array */
  alias = vtx_alloc(tree->nvtxs);
  for (i=0;i<tree->nvtxs;++i) {
    alias[i] = tree->alias[perm[i]];
    rename[alias[i]] = i;
  }
  dl_free(tree->alias);
  tree->alias = alias;

  /* update tree's terminal array -- bit magic */
  for (i=0;i<tree->nvtxs;++i) {
    tree->term[i] += (tree->term[perm[i]] & 0x01) << 1;
  }
  for (i=0;i<tree->nvtxs;++i) {
    tree->term[i] >>= 1;
  }
  dl_free(perm);
}


int check_tree(
    graph_t const * const graph,
    tree_t const * const tree)
{
  vtx_t i, k, v, u;
  adj_t j, jj;
  vtx_t * present;

  present = vtx_init_alloc(NULL_VTX,graph->nvtxs); 

  for (i=0;i<tree->nvtxs;++i) {
    v = tree->alias[i];
    if (present[v] != NULL_VTX) {
      eprintf("Vertex "PF_VTX_T" is present twice in tree ("PF_VTX_T" and " \
          PF_VTX_T")\n",v,i,present[v]);
      return 0;
    } else {
      present[v] = i;
    }
    for (j=tree->xadj[i];j<tree->xadj[i+1];++j) {
      k = tree->adjncy[j];
      u = tree->alias[k];
      /* check that this edge exists with the same weight in the graph */
      for (jj=graph->xadj[v];jj<graph->xadj[v+1];++jj) {
        if (graph->adjncy[jj] == u) {
          if (dl_near_equal(graph->adjwgt[jj],tree->adjwgt[j])) {
            break;
          } else {
            eprintf("Edge weight in tree is "PF_WGT_T" but in graph it is " \
                PF_WGT_T" for edge "PF_VTX_T":"PF_VTX_T"\n",tree->adjwgt[j], \
                graph->adjwgt[jj],v,u);
            return 0;
          }
        }
      }
      if (jj == graph->xadj[v+1]) {
        eprintf("Cound not find edge "PF_VTX_T":"PF_VTX_T" in graph\n",v,u);
        return 0;
      }
    }
  }

  dl_free(present);

  return 1;
}


void tree_free(
    tree_t * tree)
{
  if (tree->xadj) {
    dl_free(tree->xadj);
  }
  if (tree->adjncy) {
    dl_free(tree->adjncy);
  }
  if (tree->adjwgt) {
    dl_free(tree->adjwgt);
  }
  if (tree->vwgt) {
    dl_free(tree->vwgt);
  }
  if (tree->alias) {
    dl_free(tree->alias);
  }
  if (tree->term) {
    dl_free(tree->term);
  }
  dl_free(tree);
}




#endif
