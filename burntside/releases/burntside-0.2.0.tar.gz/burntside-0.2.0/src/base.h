/**
 * @file base.h
 * @brief Base types etc. for Burntside
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-02-17
 */




#ifndef BURNTSIDE_BASE_H
#define BURNTSIDE_BASE_H




/******************************************************************************
* EXTERNAL INCLUDES ***********************************************************
******************************************************************************/


/* external libraires */
#include <domlib.h>

/* c includes */
#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <float.h>
#include <omp.h>
#include <inttypes.h>

/* include burntside header */
#include <burntside.h>




/******************************************************************************
* MACRO INCLUDES **************************************************************
******************************************************************************/


/* theses are needed before any real code gets included -- and should not 
 * refernce base.h */
#include "strings.h"




/******************************************************************************
* MACROS **********************************************************************
******************************************************************************/

#ifdef DEBUG
  #define par_dprintf(...) \
    do { \
      _Pragma("omp master") \
      { \
        dprintf( __VA_ARGS__ ); \
      } \
    } while(0)
#else
  #define par_dprintf(...)
#endif

#define par_vprintf(...) \
  do { \
    _Pragma("omp master") \
    { \
      vprintf( __VA_ARGS__ ); \
    } \
  } while(0)




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef long double twgt_t;
typedef uint32_t tid_t;




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


/* macros */
#define YES_POINTER ((void*)-1)
#define DEF_NULL_VTX ((vtx_t)-1)
#define DEF_NULL_WGT ((wgt_t)-1.0)
#define DEF_NULL_ADJ ((adj_t)-1)
#define DEF_NULL_TID ((tid_t)-1)


/* type null values */
static const vtx_t NULL_VTX = DEF_NULL_VTX;
static const wgt_t NULL_WGT = DEF_NULL_WGT;
static const adj_t NULL_ADJ = DEF_NULL_ADJ;
static const tid_t NULL_TID = DEF_NULL_TID;


/* thread specific constants */
static const vtx_t BLOCKSIZE = 0x1000;
static const int BLOCKSHIFT = 12;
static const vtx_t BLOCKMASK = 0x0FFF;




/******************************************************************************
* DOMLIB FUNCTION PROTOTYPES **************************************************
******************************************************************************/


/* vtx_t */
#define DLMEM_PREFIX vtx
#define DLMEM_TYPE_T vtx_t
#define DLMEM_STATIC
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


#define DLMATH_PREFIX vtx
#define DLMATH_TYPE_T vtx_t
#define DLMATH_DLTYPE DLTYPE_INTEGRAL
#define DLMATH_STATIC
#include "dlmath_headers.h"
#undef DLMATH_STATIC
#undef DLMATH_DLTYPE 
#undef DLMATH_PREFIX
#undef DLMATH_TYPE_T


#define DLRAND_PREFIX vtx
#define DLRAND_TYPE_T vtx_t
#define DLRAND_STATIC
#include "dlrand_headers.h"
#undef DLRAND_STATIC
#undef DLRAND_PREFIX
#undef DLRAND_TYPE_T


#define DLSTATS_PREFIX vtx
#define DLSTATS_TYPE_T vtx_t
#define DLSTATS_STATIC
#include "dlstats_headers.h"
#undef DLSTATS_STATIC
#undef DLSTATS_PREFIX
#undef DLSTATS_TYPE_T


#define DLISET_PREFIX vtx
#define DLISET_TYPE_T vtx_t
#define DLISET_SYNC
#define DLISET_STATIC
#include "dliset_headers.h"
#undef DLISET_STATIC
#undef DLISET_SYNC
#undef DLISET_PREFIX
#undef DLISET_TYPE_T


#define DLDJSET_PREFIX vtx
#define DLDJSET_TYPE_T vtx_t
#define DLDJSET_STATIC
#include "dldjset_headers.h"
#undef DLDJSET_STATIC
#undef DLDJSET_TYPE_T
#undef DLDJSET_PREFIX


/* adj_t */
#define DLMEM_PREFIX adj
#define DLMEM_TYPE_T adj_t
#define DLMEM_STATIC
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


#define DLMATH_PREFIX adj
#define DLMATH_TYPE_T adj_t
#define DLMATH_DLTYPE DLTYPE_INTEGRAL
#define DLMATH_STATIC
#include "dlmath_headers.h"
#undef DLMATH_STATIC
#undef DLMATH_DLTYPE
#undef DLMATH_PREFIX
#undef DLMATH_TYPE_T


#define DLRAND_PREFIX adj
#define DLRAND_TYPE_T adj_t
#define DLRAND_STATIC 
#include "dlrand_headers.h"
#undef DLRAND_STATIC
#undef DLRAND_PREFIX
#undef DLRAND_TYPE_T


#define DLSTATS_PREFIX adj
#define DLSTATS_TYPE_T adj_t
#define DLSTATS_STATIC
#include "dlstats_headers.h"
#undef DLSTATS_STATIC
#undef DLSTATS_PREFIX
#undef DLSTATS_TYPE_T


/* wgt_t */
#define DLMEM_PREFIX wgt
#define DLMEM_TYPE_T wgt_t
#define DLMEM_DLTYPE DLTYPE_FLOAT
#define DLMEM_STATIC
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_DLTYPE 
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


#define DLMATH_PREFIX wgt
#define DLMATH_TYPE_T wgt_t
#define DLMATH_DLTYPE DLTYPE_FLOAT
#define DLMATH_STATIC
#include "dlmath_headers.h"
#undef DLMATH_STATIC
#undef DLMATH_DLTYPE 
#undef DLMATH_PREFIX
#undef DLMATH_TYPE_T


#define DLRAND_PREFIX wgt
#define DLRAND_TYPE_T wgt_t
#define DLRAND_DLTYPE DLTYPE_FLOAT
#define DLRAND_STATIC
#include "dlrand_headers.h"
#undef DLRAND_STATIC
#undef DLRAND_DLTYPE
#undef DLRAND_PREFIX
#undef DLRAND_TYPE_T


#define DLSTATS_PREFIX wgt
#define DLSTATS_TYPE_T wgt_t
#define DLSTATS_STATIC
#include "dlstats_headers.h"
#undef DLSTATS_STATIC
#undef DLSTATS_PREFIX
#undef DLSTATS_TYPE_T


DL_MK_SORTKV_HEADERS(vtx,vtx_t,vtx_t)
DL_MK_OMP_REDUCTION_HEADERS(vtx,vtx_t)
DL_MK_OMP_REDUCTION_HEADERS(adj,adj_t)
DL_MK_OMP_REDUCTION_HEADERS(wgt,wgt_t)



/******************************************************************************
* INLINE FUNCTIONS ************************************************************
******************************************************************************/


#include <bowstring.h>


static inline vtx_t nconn_components(
    vtx_t const nvtxs,
    adj_t const * const xadj,
    vtx_t const * const adjncy)
{
  vtx_t nconn;

  bowstring_label_components(nvtxs,xadj,adjncy,NULL,&nconn);

  return nconn;
}




#endif
