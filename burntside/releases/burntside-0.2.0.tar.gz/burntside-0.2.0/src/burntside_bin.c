/**
 * @file burntside_bin.c
 * @brief The command line binary for burntside
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-02-18
 */




#ifndef BURNTSIDE_BIN_C
#define BURNTSIDE_BIN_C




#include <domlib.h>
#include <burntside.h>
#include <bowstring.h>
#include "base.h"
#include "graph.h"
#include "objective.h"
#include "tree.h"
#include "io.h"




/******************************************************************************
* MACROS **********************************************************************
******************************************************************************/


#define __ARRAY_SIZE(a) \
  (sizeof(a) > 0 ? (sizeof(a) / sizeof((a)[0])) : 0)




/******************************************************************************
* OPTION **********************************************************************
******************************************************************************/


static const cmd_opt_pair_t VERBOSITY_CHOICES[] = {
  {BURNTSIDE_STR_VERBOSITY_NONE,"Print nothing.",BURNTSIDE_VERBOSITY_NONE},
  {BURNTSIDE_STR_VERBOSITY_MINIMUM,"Print minimal information.", \
      BURNTSIDE_VERBOSITY_MINIMUM},
  {BURNTSIDE_STR_VERBOSITY_LOW,"Print only aggregate cluster information.", \
      BURNTSIDE_VERBOSITY_LOW},
  {BURNTSIDE_STR_VERBOSITY_MEDIUM,"Print individual cluster information.", \
      BURNTSIDE_VERBOSITY_MEDIUM},
  {BURNTSIDE_STR_VERBOSITY_HIGH,"Print cluster and progress information.", \
      BURNTSIDE_VERBOSITY_HIGH},
  {BURNTSIDE_STR_VERBOSITY_MAXIMUM,"Print everything.", \
      BURNTSIDE_VERBOSITY_MAXIMUM}
};


static const cmd_opt_pair_t EXPANSION_CHOICES[] = {
  {BURNTSIDE_STR_EXPANSION_GROW,"Expand the steiner optimally connecting " \
      "three nodes at a time.",BURNTSIDE_EXPANSION_GROW},
  {BURNTSIDE_STR_EXPANSION_MST,"Create a metric closure on the terminal " \
      "set and find an MST.",BURNTSIDE_EXPANSION_MST},
  {BURNTSIDE_STR_EXPANSION_SPH,"Iteratively join vertices using the " \
      "shortest path heuristic.",BURNTSIDE_EXPANSION_SPH}
};


static cmd_opt_pair_t const REFINE_CHOICES[] = {
  {BURNTSIDE_STR_REFINE_NONE,"Do not perform refinement.", \
      BURNTSIDE_REFINE_NONE},
  {BURNTSIDE_STR_REFINE_VTX,"Perform steiner vertex insertion refinement.", \
      BURNTSIDE_REFINE_VTX},
  {BURNTSIDE_STR_REFINE_KP,"Perform key-path exchange refinement.", \
      BURNTSIDE_REFINE_KP},
  {BURNTSIDE_STR_REFINE_KV,"Perform key-vertex elimination.", \
      BURNTSIDE_REFINE_KV},
  {BURNTSIDE_STR_REFINE_VKP,"Perform steiner vertex inserction followed by " \
    "key-path exchange refinement.",BURNTSIDE_REFINE_VKP},
  {BURNTSIDE_STR_REFINE_VKK,"Perform steiner vertex inserction followed by " \
    "key-path exchange + key-vertex elimination refinement.", \
      BURNTSIDE_REFINE_VKK}
};


static cmd_opt_pair_t const PART_CHOICES[] = {
  {BURNTSIDE_STR_PARTITION_NONE,"Do not partition.", \
      BURNTSIDE_PARTITION_NONE},
  {BURNTSIDE_STR_PARTITION_MST,"Perform partition via an MST.", \
      BURNTSIDE_PARTITION_MST},
  {BURNTSIDE_STR_PARTITION_EDGECUT,"Perform edgecut partitioning.", \
      BURNTSIDE_PARTITION_EDGECUT},
  {BURNTSIDE_STR_PARTITION_MODULARITY,"Perform modulartiy partitioning.", \
      BURNTSIDE_PARTITION_MODULARITY},
};


static const cmd_opt_t OPTS[] = {
  {BURNTSIDE_OPTION_HELP,'h',"help","Display this help page.",CMD_OPT_FLAG, \
      NULL,0},
  {BURNTSIDE_OPTION_NRUNS,'n',"runs","The number of clustering solutions to " \
      "generate using succesive random seeds.",CMD_OPT_INT,NULL,0},
  {BURNTSIDE_OPTION_VERBOSITY,'v',"verbosity","The verbosity level of " \
      "execution",CMD_OPT_CHOICE,VERBOSITY_CHOICES, \
      __ARRAY_SIZE(VERBOSITY_CHOICES)},
  {BURNTSIDE_OPTION_EXPANSION,'e',"expansion","The expanion algorithm used " \
      "to build steiner trees.",CMD_OPT_CHOICE,EXPANSION_CHOICES, \
      __ARRAY_SIZE(EXPANSION_CHOICES)},
  {BURNTSIDE_OPTION_REFINE,'r',"refine","The refinement algorithm to use.", \
      CMD_OPT_CHOICE,REFINE_CHOICES,__ARRAY_SIZE(REFINE_CHOICES)},
  {BURNTSIDE_OPTION_BLOCKSIZE,'B',"blocksize","The number of vertices " \
      "in block for block-cyclic distribution.",CMD_OPT_INT,NULL,0},
  {BURNTSIDE_OPTION_NTHREADS,'T',"threads","The number of threads to use " \
      "for clustering",CMD_OPT_INT,NULL,0},
  {BURNTSIDE_OPTION_TIME,'t',"times","Print timing information",CMD_OPT_FLAG, \
      NULL,0},
  {BURNTSIDE_OPTION_RUNSTATS,'S',"statistics","Print solution statistics", \
      CMD_OPT_FLAG,NULL,0},
  {BURNTSIDE_OPTION_SEED,'s',"seed","The random seed to use.",CMD_OPT_INT, \
      NULL,0},
  {BURNTSIDE_OPTION_PARTITION,'p',"partition","The type of partitioning to " \
      "use.",CMD_OPT_CHOICE,PART_CHOICES,__ARRAY_SIZE(PART_CHOICES)},
  {BURNTSIDE_OPTION_MINSPLIT,'m',"minsplit","The minimum number of terminal " \
      "vertices for splitting to take place (0 for never).",CMD_OPT_INT,NULL, \
      0},
  {BURNTSIDE_OPTION_IGNORE,'I',"ignore","Ignore peak distance vertices.", \
    CMD_OPT_BOOL,NULL,0},
  {BURNTSIDE_OPTION_PRUNE,'P',"prune","Prune degree one vertices.", \
    CMD_OPT_BOOL,NULL,0},
  {BURNTSIDE_OPTION_NOVWGT,'V',"novwgt","Do not use vertex/node weights.", \
    CMD_OPT_FLAG,NULL,0}
};


static const size_t NOPTS = __ARRAY_SIZE(OPTS);


#undef __ARRAY_SIZE




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static int __usage(
    const char * const name)
{
  fprintf(stderr,"USAGE:\n");
  fprintf(stderr,"%s [options] <graphfile> [ <clusterfile> | - ]\n",name);
  fprintf(stderr,"\n");
  fprintf(stderr,"Options:\n");
  fprint_cmd_opts(stderr,OPTS,NOPTS);
  return 1;
}


static double * __parse_args(
    cmd_arg_t * args, 
    size_t const nargs,
    char const ** r_input, 
    char const ** r_output)
{
  size_t i, xarg;
  double * options = NULL;
  char const * input_file = NULL, * output_file = NULL;

  options = burntside_init_options();

  for (i=0;i<nargs;++i) {
    switch (args[i].type) {
      case CMD_OPT_CHOICE:
        options[args[i].id] = (double)args[i].val.o;
        break;
      case CMD_OPT_BOOL:
        options[args[i].id] = (double)args[i].val.b;
        break;
      case CMD_OPT_INT:
        options[args[i].id] = (double)args[i].val.i;
        break;
      case CMD_OPT_FLOAT:
        options[args[i].id] = (double)args[i].val.f;
        break;
      case CMD_OPT_FLAG:
        options[args[i].id] = 1.0;
        break;
      default:
        break;
    }
  }

  xarg = 0;
  for (i=0;i<nargs;++i) {
    /* check for help */
    if (args[i].id == BURNTSIDE_OPTION_HELP) {
      goto CLEANUP;
    }
    if (args[i].type == CMD_OPT_XARG) {
      switch (xarg) {
        case 0 :
          input_file = args[i].val.s;
          break;
        case 1 :
          output_file = args[i].val.s;
          if (strcmp(output_file,"-") == 0) {
            output_file = NULL;
          }
          break;
        default :
          eprintf("Unknown extra argument '%s'\n",args[i].val.s);
          goto CLEANUP;
      }
      ++xarg;
    }
  }

  if (input_file == NULL) {
    eprintf("Must supply at least an input graph to cluster\n");
    goto CLEANUP;
  }

  *r_output = output_file;
  *r_input = input_file;

  return options;

  CLEANUP:
  dl_free(options);
  *r_output = NULL;
  *r_input = NULL;

  return NULL;
}




/******************************************************************************
* MAIN ************************************************************************
******************************************************************************/

/* expose internal function */
int burntside_internal_solve(
    objective_t * objective, 
    graph_t * graph, 
    vtx_t * term, 
    vtx_t nterm,
    tree_t ** r_solution);


int main(
    int const argc, 
    char ** const argv)
{
  int rv, err, do_vwgt;
  size_t nargs;
  vtx_t nvtxs, nterm;
  double * options = NULL;
  adj_t * xadj = NULL;
  vtx_t * adjncy = NULL, * term = NULL;
  wgt_t * adjwgt = NULL, * vwgt = NULL;
  char const * input_file = NULL;
  char const * output_file = NULL;
  cmd_arg_t * args = NULL;

  tree_t * solution = NULL;
  graph_t * graph = NULL;
  objective_t * objective = NULL;

  rv = cmd_parse_args(argc-1,argv+1,OPTS,NOPTS,&args,&nargs);
  if (rv != DL_CMDLINE_SUCCESS) {
    printf("Failed with %d\n",rv);
    __usage(argv[0]);
    rv = 1;
    goto CLEANUP;
  }

  options = __parse_args(args,nargs,&input_file,&output_file);

  if (options == NULL) {
    __usage(argv[0]);
    rv = 1;
    goto CLEANUP;
  }

  if (parse_objective(options,&objective) != BURNTSIDE_SUCCESS) {
    __usage(argv[0]);
    rv = 1;
    goto CLEANUP;
  }
  do_vwgt = options[BURNTSIDE_OPTION_NOVWGT] == BURNTSIDE_VAL_OFF;
  dl_free(options);
  options = NULL;

  if (objective->time) {
    dl_start_timer(&(objective->timers.total));
    dl_start_timer(&(objective->timers.io));
  }
 
  if (objective->verbosity >= BURNTSIDE_VERBOSITY_LOW) {
    printf("Reading '%s'\n",input_file);
  }

  /* read the graph */
  err = bowstring_read_graph(input_file,BOWSTRING_FORMAT_STP,&nvtxs,&xadj,
      &adjncy,&vwgt,&adjwgt);

  /* dispose of vwgt */
  if (vwgt && !do_vwgt) {
    dl_free(vwgt);
    vwgt = NULL;
  }

  if (err != BOWSTRING_SUCCESS) {
    eprintf("Failed reading graph\n");
    rv = 1;
    goto CLEANUP;
  }

  graph = graph_setup(nvtxs,xadj,adjncy,vwgt,adjwgt);

  /* read the terminal information */
  err = read_terminals(input_file,BURNTSIDE_FORMAT_STP,&nterm,&term);

  if (err != BURNTSIDE_SUCCESS) {
    eprintf("Failed reading terminals\n");
    rv = 1;
    goto CLEANUP;
  }

  dprintf("Marked "PF_VTX_T"/"PF_VTX_T" vertices as terminals\n",nterm,nvtxs);

  vprintf(objective->verbosity,BURNTSIDE_VERBOSITY_LOW,"Vertices: "PF_VTX_T \
      ", Edges: "PF_ADJ_T", Terminals: "PF_VTX_T", Components: "PF_VTX_T"\n", \
      nvtxs,xadj[nvtxs],nterm,nconn_components(nvtxs,xadj,adjncy));

  if (objective->time) {
    dl_stop_timer(&(objective->timers.io));
  }

  if (objective->verbosity >= BURNTSIDE_VERBOSITY_LOW) {
    print_objective(objective);
  }

  /* solve */
  burntside_internal_solve(objective,graph,term,nterm,&solution);

  if (objective->runstats) {
    print_runstats(objective);
  }

  if (objective->time) {
    dl_start_timer(&(objective->timers.io));
  }

  if (output_file) {
    /* write out tree */
    write_solution(output_file,BURNTSIDE_FORMAT_DIMACS,objective,solution);
  }

  vprintf(objective->verbosity,BURNTSIDE_VERBOSITY_LOW,"Solution weight: " \
      PF_TWGT_T"\n",calc_cost(solution));
  vprintf(objective->verbosity,BURNTSIDE_VERBOSITY_LOW,"Solution " \
      "Components: "PF_VTX_T"\n",nconn_components(solution->nvtxs, \
        solution->xadj,solution->adjncy));

  if (objective->time) {
    dl_stop_timer(&(objective->timers.io));
    dl_stop_timer(&(objective->timers.total));

    print_timers(&(objective->timers));
  }

  CLEANUP:

  if (args) {
    dl_free(args);
  }
  if (objective) {
    free_objective(objective);
  }
  if (graph) {
    graph_free(graph);
  }
  if (solution) {
    tree_free(solution);
  }
  if (options) {
    dl_free(options);
  }
  if (term) {
    dl_free(term);
  }

  return rv;
}




#endif
