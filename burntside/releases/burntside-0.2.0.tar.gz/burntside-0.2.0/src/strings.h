/**
 * @file strings.h
 * @brief String constants
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-04-02
 */




#ifndef STRINGS_H
#define STRINGS_H




/******************************************************************************
* PRINT FORMAT STRINGS ********************************************************
******************************************************************************/


#define PF_REAL_T "%0.5f"
#define RF_REAL_T "%f"
#define PF_TWGT_T "%0.07Lf"
#define RF_TWGT_T "%Lf"
#define PF_UINT32_T "%"PRIu32
#define RF_UINT32_T "%"PRIu32
#define PF_UINT64_T "%"PRIu64
#define RF_UINT64_T "%"PRIu64
#define PF_FLOAT_T "%0.05f"
#define RF_FLOAT_T "%f"
#define PF_DOUBLE_T "%0.05lf"
#define RF_DOUBLE_T "%lf"


#ifdef BURNTSIDE_64BIT_VERTICES
#define PF_VTX_T PF_UINT64_T
#define RF_VTX_T RF_UINT64_T
#else
#define PF_VTX_T PF_UINT32_T
#define RF_VTX_T RF_UINT32_T
#endif
#ifdef BURNTSIDE_64BIT_EDGES
#define PF_ADJ_T PF_UINT64_T
#define RF_ADJ_T RF_UINT64_T
#else
#define PF_ADJ_T PF_UINT32_T
#define RF_ADJ_T RF_UINT32_T
#endif
#ifdef BURNTSIDE_64BIT_THREADS
#define PF_TID_T PF_UINT64_T
#define RF_TID_T RF_UINT64_T
#else
#define PF_TID_T PF_UINT32_T
#define RF_TID_T RF_UINT32_T
#endif
#ifdef BURNTSIDE_DOUBLE_WEIGHTS
#define PF_WGT_T PF_DOUBLE_T
#define RF_WGT_T RF_DOUBLE_T
#else
#define PF_WGT_T PF_FLOAT_T
#define RF_WGT_T RF_FLOAT_T
#endif




/******************************************************************************
* OPTION STRINGS **************************************************************
******************************************************************************/


/* verbosity strings */
#define BURNTSIDE_STR_VERBOSITY_NONE "none"
#define BURNTSIDE_STR_VERBOSITY_MINIMUM "minimum"
#define BURNTSIDE_STR_VERBOSITY_LOW "low"
#define BURNTSIDE_STR_VERBOSITY_MEDIUM "medium"
#define BURNTSIDE_STR_VERBOSITY_HIGH "high"
#define BURNTSIDE_STR_VERBOSITY_MAXIMUM "maximum"


/* expansion strings */
#define BURNTSIDE_STR_EXPANSION_GROW "grow"
#define BURNTSIDE_STR_EXPANSION_MST "mst"
#define BURNTSIDE_STR_EXPANSION_SPH "sph"


/* refinement strings */
#define BURNTSIDE_STR_REFINE_NONE "none"
#define BURNTSIDE_STR_REFINE_VTX "vtx"
#define BURNTSIDE_STR_REFINE_KP "kp"
#define BURNTSIDE_STR_REFINE_KV "kv"
#define BURNTSIDE_STR_REFINE_VKP "vkp"
#define BURNTSIDE_STR_REFINE_VKK "vkk"


/* partition strings */
#define BURNTSIDE_STR_PARTITION_NONE "none"
#define BURNTSIDE_STR_PARTITION_MODULARITY "modularity"
#define BURNTSIDE_STR_PARTITION_EDGECUT "edgecut"
#define BURNTSIDE_STR_PARTITION_MST "mst"




#endif
