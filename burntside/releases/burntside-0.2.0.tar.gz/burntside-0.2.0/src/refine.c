/**
 * @file refine.c
 * @brief Functions for refining steiner trees.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2014-10-15
 */





#ifndef BURNTSIDE_REFINE_C
#define BURNTSIDE_REFINE_C




#include "refine.h"
#include "lctree.h"
#include <bowstring_dynamic.h>




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef struct link_t {
  vtx_t src;
  vtx_t dst;
  wgt_t wgt;
} link_t;


typedef enum vtx_status_t {
  STATUS_NONE,
  STATUS_PINNED,
  STATUS_FORBIDDEN
} vtx_status_t;
  



/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX link
#define DLMEM_TYPE_T link_t
#define DLMEM_STATIC
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX


#define DLHEAP_PREFIX link
#define DLHEAP_TYPE_T link_t
#define DLHEAP_KEY wgt
#define DLHEAP_MIN 1
#define DLHEAP_STATIC 1
#include "dlheap_headers.h"
#undef DLHEAP_STATIC
#undef DLHEAP_MIN
#undef DLHEAP_KEY
#undef DLHEAP_TYPE_T
#undef DLHEAP_PREFIX


#define DLPQ_PREFIX vw
#define DLPQ_KEY_T wgt_t
#define DLPQ_VAL_T vtx_t
#define DLPQ_STATIC
#include "dlpq_headers.h"
#undef DLPQ_STATIC
#undef DLPQ_VAL_T
#undef DLPQ_KEY_T
#undef DLPQ_PREFIX




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static void __forbid_subtree(
    vtx_t const t,
    tree_t const * const tree,
    vtx_t * const stack,
    int * const status)
{
  vtx_t n, i, v, k; 
  adj_t j;

  n = 0;

  stack[n++] = t;

  while (n > 0) {
    i = stack[--n];
    v = tree->alias[i];
    if (status[v] != STATUS_FORBIDDEN) {
      status[v] = STATUS_FORBIDDEN;
      for (j=tree->xadj[i];j<tree->xadj[i+1];++j) {
        k = tree->adjncy[j];
        if (k < i) {
          stack[n++] = k;
        }
      }
    }
  }
}


/**
 * @brief Create a dynamic graph representing the tree.
 *
 * @param graph The original static graph.
 * @param tree The steiner tree.
 *
 * @return The dynamic graph.
 */
static bowstring_dyngraph_t * __dynamic_tree(
    graph_t const * const graph,
    tree_t const * const tree)
{
  vtx_t i,v;
  adj_t j, l;
  bowstring_dyngraph_t * dgraph;

  dgraph = bowstring_dg_create(graph->nvtxs);

  for (i=0;i<tree->nvtxs;++i) {
    v = tree->alias[i];
    j = tree->xadj[i];  
    bowstring_dg_addvtx(v,tree->adjncy+j,tree->adjwgt+j,tree->xadj[i+1]-j, \
        dgraph);

    /* correct adjncy */
    l = 0;
    for (;j<tree->xadj[i+1];++j) {
      dgraph->nodes[v].adj[l] = tree->alias[tree->adjncy[j]];
      ++l;
    }
  }

  dgraph->nedges = tree->xadj[tree->nvtxs]/2;

  return dgraph;
}


static void __update_tree(
    bowstring_dyngraph_t * const graph,
    tree_t * const tree)
{
  vtx_t i, k, nq, sq;
  vtx_t * q;
  int * term;

  /* free tree components */
  dl_free(tree->xadj);
  dl_free(tree->adjncy);
  dl_free(tree->adjwgt);
  if (tree->vwgt) {
    dl_free(tree->vwgt);
  }

  /* create a global term array */
  term = int_init_alloc(0,graph->max_nvtxs);
  for (i=0;i<tree->nvtxs;++i) {
    if (tree->term[i]) {
      term[tree->alias[i]] = 1;
    }
  }
  dl_free(tree->term);
  dl_free(tree->alias);

  /* prune non-terminals from graph */
  q = vtx_alloc(graph->nvtxs);
  nq = 0;
  for (i=0;i<graph->max_nvtxs;++i) {
    if (!term[i] && graph->nodes[i].nadj < 2) {
      q[nq++] = i;
    }
  }
  sq = 0;
  while (sq < nq) {
    i = q[sq++];    
    DL_ASSERT(!term[i],"Terminal inserted for pruning");
    if (graph->nodes[i].nadj == 0) {
      bowstring_dg_delvtx(i,graph);
    } else {
      DL_ASSERT_EQUALS(graph->nodes[i].nadj,1,PF_VTX_T);
      k = graph->nodes[i].adj[0];
      bowstring_dg_delvtx(i,graph);
      if (!term[k] && graph->nodes[k].nadj < 2) {
        q[nq++] = k;
      }
    }
  }
  dl_free(q);
  dprintf("Pruned "PF_VTX_T" vertices\n",nq);

  bowstring_dg_tostatic(graph,&tree->xadj,&tree->adjncy,&tree->adjwgt, \
      &tree->alias);
  tree->nvtxs = graph->nvtxs;
  tree->nedges = tree->xadj[tree->nvtxs];

  tree->term = int_init_alloc(0,tree->nvtxs);
  for (i=0;i<tree->nvtxs;++i) {
    tree->term[i] = term[tree->alias[i]];
  }
  dl_free(term);

  tree->cost = wgt_fa_sum(tree->adjwgt,tree->nedges) / 2.0;
}


/**
 * @brief Find the shortest paths accross the voronoi regions removed by path.
 *
 * @param home The home half of the graph.
 * @param branch The id of the removed branch.
 * @param path The path being removed.
 * @param npath The number of nodes in the path.
 * @param graph The graph.
 * @param vxadj The adjacency list pointer of the voronoi diagram.
 * @param vadjncy The adjacency list of the voronoi diagram.
 * @param vadjwgt The edge weights of the voronoi diagram.
 * @param adjsrc The source vertex of each edge in the voronoi diagram.
 * @param set The disjoint set marking connected components.
 * @param h The heap to add the shortest paths to.
 * @param dist The distance array for updating.
 * @param parent The parent array for updating.
 * @param q The scratch space priority queue.
 *
 * @return The weight of the shortest path.
 */
static void __repair_voronoi(
    vtx_t const home,
    vtx_t const branch,
    graph_t const * const graph,
    vtx_t const * const path,
    vtx_t const npath,
    adj_t const * const vxadj,
    vtx_t const * const vadjncy,
    wgt_t const * const vadjwgt,
    vtx_t const * const adjsrc,
    adj_t const * const adjori,
    vtx_t * const where,
    vtx_djset_t * const set,
    link_heap_t * const h, 
    wgt_t * const dist, 
    vtx_t * const parent,
    vw_priority_queue_t * const q)
{
  vtx_t i, k, v, u, other, p, pv;
  adj_t j;
  wgt_t d;
  link_t link;

  DL_ASSERT_EQUALS(q->size,0UL,"%zu");

  /* scan the voronoi regions associated with the vertices in the path to find
   * the border vertices to being our search from */
  for (p=0;p<npath;++p) {
    i = path[p];
    for (j=vxadj[i];j<vxadj[i+1];++j) {
      k = vadjncy[j];
      if (vtx_djset_find(k,set) == home) {
        /* this edge is attached to our home component -- add the src vertex to 
         * our queue with its distance from the tree */
        v = adjsrc[j];
        pv = graph->adjncy[adjori[j]];
        d = dist[pv] + graph->adjwgt[adjori[j]];
        DL_ASSERT_EQUALS(d-dist[pv],graph->adjwgt[adjori[j]],PF_WGT_T);
        /* the same vertex may be connected to multiple regions */
        if (!vw_minpq_contains(v,q)) {
          where[v] = where[pv];
          parent[v] = pv;
          dist[v] = d;
          vw_minpq_push(d,v,q);
        } else if (d < dist[v]) {
          where[v] = where[pv];
          parent[v] = pv;
          dist[v] = d;
          vw_minpq_update(d,v,q);
        }
      }
    }
  }

  /* add all connections to non-home vertices */
  while (q->size > 0) {
    v = vw_minpq_pop(q);
    /* only set distance for c == branch vertices */
    /* continue the search */
    for (j=graph->xadj[v];j<graph->xadj[v+1];++j) {
      u = graph->adjncy[j];
      other = where[u];
      k = vtx_djset_find(other,set);
      /* only search non-home vertice */
      if (k == branch) {
        d = dist[v] + graph->adjwgt[j];
        if (d < dist[u]) {
          where[u] = where[v];
          parent[u] = v;
          dist[u] = d;
          if (vw_minpq_contains(u,q)) {
            vw_minpq_update(d,u,q);
          } else {
            vw_minpq_push(d,u,q);
          }
        }
      } else if (k != home) {
        /* we found a connection to the other side */
        link.src = v;
        link.dst = u;
        link.wgt = dist[v] + graph->adjwgt[j] + dist[u];
        link_heap_push(link,h);
      }
    }
  }
}


static void __restore_voronoi(
    graph_t const * const graph,
    vtx_t const * const path,
    vtx_t const npath,
    vtx_t const * const alias,
    vtx_t * const where,
    wgt_t * const dist, 
    vtx_t * const parent,
    vw_priority_queue_t * const q)
{
  vtx_t i, v, u, p, me;
  adj_t j;
  wgt_t d;

  DL_ASSERT_EQUALS(q->size,0UL,"%zu");

  /* add path vertices to queue */
  for (p=0;p<npath;++p) {
    i = path[p];
    v = alias[i];
    where[v] = i;
    dist[v] = 0;
    parent[v] = NULL_VTX;
    vw_minpq_push(0,v,q);
  }

  /* add all connections to non-home vertices */
  while (q->size > 0) {
    v = vw_minpq_pop(q);
    me = where[v];
    for (j=graph->xadj[v];j<graph->xadj[v+1];++j) {
      u = graph->adjncy[j];
      d = dist[v] + graph->adjwgt[j];
      if (d < dist[u]) {
        where[u] = me;
        parent[u] = v;
        dist[u] = d;
        if (vw_minpq_contains(u,q)) {
          vw_minpq_update(d,u,q);
        } else {
          vw_minpq_push(d,u,q);
        }
      }
    }
  }
}


/**
 * @brief Find a path to a parent key vertex in the tree.
 *
 * @param start The vertex to start the search from.
 * @param tree The tree to search in.
 * @param path A list of vertices (tree numbers) in path.
 * @param r_npath A reference to the number of vertices in the path.
 *
 * @return The weight of the path. 
 */
static wgt_t __find_parent_path(
    vtx_t const start,
    tree_t const * const tree,
    vtx_t * const path,
    vtx_t * const r_npath)
{
  vtx_t i, k, n;
  adj_t j;
  wgt_t w;

  /* find the neighbor on the way to the parent */
  i = start;
  n = 0;
  w = 0;
  for (j=tree->xadj[start];j<tree->xadj[start+1];++j) {
    if (tree->adjncy[j] > start) {
      i = tree->adjncy[j];
      w = tree->adjwgt[j];
      /* trace the neighbor to a key vertex */
      while (!tree->term[i] && tree->xadj[i+1] - tree->xadj[i] < 3) {
        path[n++] = i;
        /* search for this vertex's parent */
        for (j=tree->xadj[i];j<tree->xadj[i+1];++j) {
          k = tree->adjncy[j];
          if (k > i) {
            w += tree->adjwgt[j];
            i = k;
            break;
          }
        }
        DL_ASSERT(j < tree->xadj[i+1],"Reached end of edge list\n");
      }
      break;
    }
  }
  path[n++] = i;

  *r_npath = n;

  DL_ASSERT(start <= i,"Invalid parent\n");

  return w;
}


static vtx_t __lctree_components(
    lctree_t const * const tree)
{
  vtx_t i, ncomp, k;
  vtx_t * where;

  where = vtx_init_alloc(NULL_VTX,tree->nnodes);

  ncomp = 0;
  for (i=0;i<tree->nnodes;++i) {
    k = lctree_findroot(i,tree);
    if (k != i) {
      if (where[k] == NULL_VTX) {
        where[k] = ++ncomp;
      }
    }
  }

  dl_free(where);

  return ncomp;
}


static wgt_t __inject_edge(
    vtx_t const v,
    vtx_t const u,
    wgt_t const w,
    link_t * const cut,
    vtx_t * const r_ncut,
    lctree_t * const tree)
{
  vtx_t j,k,i,ncut;
  wgt_t e;

  ncut = *r_ncut;

  /* check if either vertex is the root */
  if (tree->nodes[v].p == NULL_VTX) {
    i = v;
    k = u;
  } else if (tree->nodes[u].p == NULL_VTX) {
    k = v;
    i = u;
  } else {
    /* if neither vertex is the root, force a new root */
    lctree_setroot(u,tree);
    k = v;
    i = u;
  }

  if (lctree_findroot(k,tree) != i) {
    /* there's no cutting to be done */
    lctree_link(k,i,w,tree);
    return -w;
  }

  /* now i is the root of the tree, and k is below it somewhere */
  j = lctree_findmax(k,tree);

  e = tree->nodes[j].w;

  if (w < e) {
    /* cut the edge of {j,p(j)} and instert (v,u) */
    cut[ncut].src = j;
    cut[ncut].dst = tree->nodes[j].p;
    cut[ncut].wgt = e;
    *r_ncut = ++ncut;
    lctree_cut(j,tree->nodes[j].p,tree);
    lctree_link(k,i,w,tree);
    return e - w;
  } else {
    /* do nothing, the new edge is heaviest */
    return 0;
  }
}


static lctree_t * __convert_tree(
    vtx_t const nvtxs,
    tree_t * const tree)
{
  vtx_t i, k, v, u;
  adj_t j;
  wgt_t w;
  lctree_t * lctree;

  lctree = lctree_create(nvtxs);

  for (i=0;i<tree->nvtxs;++i) {
    v = tree->alias[i];
    for (j=tree->xadj[i];j<tree->xadj[i+1];++j) {
      k = tree->adjncy[j];
      if (k < i) {
        u = tree->alias[k];
        w = tree->adjwgt[j];
        lctree_link(v,u,w,lctree);
      }
    }
  }

  return lctree;
}


static tree_t * __convert_lctree(
    lctree_t const * const lctree,
    graph_t const * const graph,
    tree_t * const tree)
{
  vtx_t nvtxs, i, k, v, u, nterm;
  wgt_t w;
  adj_t nedges;
  adj_t * xadj;
  vtx_t * adjncy, * alias, * rename, * term;
  wgt_t * adjwgt;

  xadj = adj_init_alloc(0,graph->nvtxs+2);

  /* save terminals */
  term = vtx_alloc(tree->nvtxs);
  nterm = 0;
  for (i=0;i<tree->nvtxs;++i) {
    if (tree->term[i]) {
      term[nterm++] = tree->alias[i];
    }
  }

  /* count edges (and an upper bound on vertices) */
  nvtxs = 1;
  for (i=0;i<graph->nvtxs;++i) {
    if ((k = lctree->nodes[i].p) != NULL_VTX) {
      ++xadj[i]; 
      ++xadj[k];
      nvtxs+=2;
    }
  }
  nedges = vtx_prefixsum_exc(xadj,graph->nvtxs+1);

  alias = vtx_alloc(nvtxs);
  rename = vtx_alloc(graph->nvtxs);

  /* compact xadj */
  k = 0;
  for (i=0;i<graph->nvtxs;++i) {
    if (xadj[i] < xadj[i+1]) {
      xadj[k+1] = xadj[i+1];
      alias[k] = i;
      rename[i] = k;
      ++k;
    } else {
      DL_ASSERT_EQUALS(lctree->nodes[i].p,NULL_VTX,PF_VTX_T);
      rename[i] = NULL_VTX;
    }
  }

  /* set the correct number of vertices */
  nvtxs = k;

  /* set the terminals */
  dl_free(tree->term);
  tree->term = int_init_alloc(0,nvtxs);
  for (i=0;i<nterm;++i) {
    tree->term[rename[term[i]]] = 1;
  }
  dl_free(term);

  /* shift xadj by one */
  for (k=nvtxs;k>0;--k) {
    xadj[k] = xadj[k-1];
  }

  adjncy = vtx_alloc(nedges);
  adjwgt = wgt_alloc(nedges);

  /* insert edges */ 
  for (i=0;i<nvtxs;++i) {
    v = alias[i];
    DL_ASSERT_EQUALS(rename[v],i,PF_VTX_T);
    if ((u = lctree->nodes[v].p) != NULL_VTX) {
      w = lctree->nodes[v].w;
      k = rename[u];
      DL_ASSERT(k!=i,"Loop in tree");
      DL_ASSERT(k!=NULL_VTX,"Bad rename vector");
      DL_ASSERT_EQUALS(alias[k],u,PF_VTX_T);
      adjncy[xadj[i+1]] = k; 
      adjwgt[xadj[i+1]] = w;
      ++xadj[i+1];
      adjncy[xadj[k+1]] = i; 
      adjwgt[xadj[k+1]] = w;
      ++xadj[k+1];
    }
  }

  DL_ASSERT_EQUALS(xadj[nvtxs],nedges,PF_ADJ_T);

  dl_free(rename);

  DL_ASSERT(bowstring_check_graph(nvtxs,xadj,adjncy,adjwgt), \
      "Generated bad tree\n");

  DL_ASSERT_EQUALS(__lctree_components(lctree), \
      nconn_components(tree->nvtxs,tree->xadj,tree->adjncy),PF_VTX_T);

  DL_ASSERT_EQUALS(__lctree_components(lctree), \
      nconn_components(nvtxs,xadj,adjncy),PF_VTX_T);

  tree->nvtxs = nvtxs;
  tree->nedges = xadj[nvtxs];
  if (tree->xadj) {
    dl_free(tree->xadj);
  }
  tree->xadj = xadj;
  if (tree->adjncy) {
    dl_free(tree->adjncy);
  }
  tree->adjncy = adjncy;
  if (tree->adjwgt) {
    dl_free(tree->adjwgt);
  }
  tree->adjwgt = adjwgt;
  if (tree->alias) {
    dl_free(tree->alias);
  }
  tree->alias = alias;
  tree->cost = calc_cost(tree); 

  /* add vertex weights */
  if (graph->vwgt) {
    if (tree->vwgt) {
      dl_free(tree->vwgt);
    }
    tree->vwgt = wgt_alloc(nvtxs);
    for (i=0;i<nvtxs;++i) {
      tree->vwgt[i] = graph->vwgt[alias[i]];
    }
    tree->cost += wgt_fa_sum(tree->vwgt,tree->nvtxs);
  }

  return tree;
}


static int __refine_VTX(
    objective_t * const objective,
    graph_t const * const graph,
    tree_t * const tree)
{
  vtx_t i, v, u, nnew, nadded;
  adj_t j;
  wgt_t gain;
  int * intree;
  link_t * cut;
  vtx_iset_t * nbrset;
  lctree_t * lctree;

  lctree = __convert_tree(graph->nvtxs,tree);

  intree = int_init_alloc(0,graph->nvtxs);
  nbrset = vtx_iset_create(0,graph->nvtxs);
  cut = link_alloc(tree->nvtxs);

  /* mark all of our tree vertices */
  for (i=0;i<tree->nvtxs;++i) {
    v = tree->alias[i];
    intree[v] = 1;
  }

  /* add all neighbor vertices to the set */
  for (i=0;i<tree->nvtxs;++i) {
    v = tree->alias[i];
    for (j=graph->xadj[v];j<graph->xadj[v+1];++j) {
      u = graph->adjncy[j];
      if (!intree[u] && !vtx_iset_contains(u,nbrset)) {
        vtx_iset_add(u,nbrset);
      }
    }
  }

  nadded = 0;

  /* perform moves */
  for (i=0;i<nbrset->size;++i) {
    v = vtx_iset_get(i,nbrset);
    /* need to save state and restore if this does not improve teh solution */
    gain = 0;
    nnew = 0;
    for (j=graph->xadj[v];j<graph->xadj[v+1];++j) {
      u = graph->adjncy[j];
      if (intree[u]) {
        gain += __inject_edge(v,u,graph->adjwgt[j],cut,&nnew,lctree);
      }
    }
    if (gain <= 0) {
      /* undo links incident to v */
      for (j=graph->xadj[v];j<graph->xadj[v+1];++j) {
        u = graph->adjncy[j];
        if (intree[u]) {
          lctree_cut(v,u,lctree);
        }
      }
      /* undo cuts not incident to v */
      for (;nnew>0;) {
        --nnew;
        if (cut[nnew].src != v && cut[nnew].dst != v) {
          lctree_link(cut[nnew].src,cut[nnew].dst,cut[nnew].wgt,lctree);
        }
      }
    } else {
      intree[v] = 1;
      ++nadded;
    }
  }

  dl_free(cut);
  dl_free(intree);
  vtx_iset_free(nbrset);

  DL_ASSERT_EQUALS(__lctree_components(lctree),nconn_components(tree->nvtxs, \
        tree->xadj,tree->adjncy),PF_VTX_T);

  __convert_lctree(lctree,graph,tree);

  lctree_free(lctree);

  return nadded > 0;
}


static int __refine_KP(
    objective_t * const objective,
    graph_t const * const graph,
    tree_t * const tree)
{
  vtx_t v, t, i, p, k, npath, nkvtxs, other, branch, home, newhome, dst, src, \
      old, nchanged, tt, kk;
  adj_t j;
  wgt_t w;
  link_t link;
  vtx_t * where, * vadjncy, * adjsrc, * parent, * path, * rename, * kvtxs, \
      * stack;
  adj_t * vxadj, * adjori;
  wgt_t * dist, * vadjwgt;
  int * status;
  link_heap_t * q, ** vq;
  vw_priority_queue_t * pq;
  vtx_djset_t * set;
  bowstring_dyngraph_t * dgraph;

  /* re-order my tree */
  rename = vtx_alloc(graph->nvtxs);
  tree_post_order(tree,rename);

  /* build a dynamic tree for modification */
  dgraph = __dynamic_tree(graph,tree);

  /* the root of my tree must be a terminal or this will not work */
  DL_ASSERT_EQUALS(tree->term[tree->nvtxs-1],1,"%d");

  /* build a static voronoi region of the tree */
  where = vtx_alloc(graph->nvtxs);
  parent = vtx_alloc(graph->nvtxs);
  dist = wgt_alloc(graph->nvtxs);
  bowstring_voronoi_regions(graph->nvtxs,graph->xadj,graph->adjncy, \
      graph->adjwgt,tree->alias,tree->nvtxs,where,parent,dist);

  /* build the voronoi diagram */
  bowstring_voronoi_diagram(graph->nvtxs,graph->xadj,graph->adjncy, \
      graph->adjwgt,tree->nvtxs,where,dist,&vxadj,&vadjncy,&vadjwgt, \
      &adjsrc,&adjori);

  /* find all of my key vertices */
  nkvtxs = 0;
  kvtxs = vtx_alloc(tree->nvtxs);
  for (i=0;i<tree->nvtxs;++i) {
    if (tree->term[i] || tree->xadj[i+1] - tree->xadj[i] >= 3) {
      kvtxs[nkvtxs++] = tree->alias[i];
    }
  }
  kvtxs = vtx_realloc(kvtxs,nkvtxs);

  /* allocate tracking strucutres */
  status = int_init_alloc(0,graph->nvtxs);
  set = vtx_djset_create(0,tree->nvtxs);
  path = vtx_alloc(tree->nvtxs);
  vq = (link_heap_t**)malloc(sizeof(link_heap_t*)*tree->nvtxs);
  stack = vtx_alloc(tree->nvtxs);

  /* set all heaps to NULL */
  for (i=0;i<tree->nvtxs;++i) {
    vq[i] = NULL;
  }

  /* create my priority queue for voronoi repair operations */
  pq = vw_priority_queue_create(0,graph->nvtxs);

  /* actual refinement pass to evaulate all key-vertex paths */
  nchanged = 0;
  p = NULL_VTX;
  for (i=0;i<nkvtxs-1;++i) {
    #ifdef USE_ASSERTS
    for (k=0;k<dgraph->max_nvtxs;++k) {
      if (dgraph->nodes[k].nadj != NULL_VTX) {
        DL_ASSERT(parent[k] == NULL_VTX,"Vertex "PF_VTX_T" in tree has a " \
            "parent "PF_VTX_T,k,parent[k]);
        DL_ASSERT(dist[k] == 0.0,"Vertex "PF_VTX_T" in tree has a distance " \
            "of "PF_WGT_T,k,dist[k]);
      }
    }
    #endif

    /* the vertex id in the graph */
    v = kvtxs[i];

    /* the vertex id in the tree -- same as voronoi region id */
    t = rename[v];

    DL_ASSERT_EQUALS(t,where[v],PF_VTX_T);
    DL_ASSERT(tree->term[t] || tree->xadj[t+1]-tree->xadj[t] >= 3, \
        "Non-tree vertex "PF_VTX_T" in keyvertex list\n",t);

    /* find component this vertex belongs to */ 
    home = vtx_djset_find(t,set);
    DL_ASSERT_EQUALS(where[v],t,PF_VTX_T);

    dprintf("Finding keypath of vertex "PF_VTX_T"("PF_VTX_T") in "PF_VTX_T \
        "\n",v,t,home);

    /* find it's parent and path */ 
    w = __find_parent_path(t,tree,path,&npath);

    DL_ASSERT(path[0] != t,"Path starts with same vertex "PF_VTX_T"("PF_VTX_T \
        ")/"PF_VTX_T"("PF_VTX_T").",i,v,nkvtxs,graph->nvtxs);
    DL_ASSERT(path[npath-1] != t,"Path ends with same vertex.");

    p = vtx_djset_find(path[--npath],set); /* vertex tree id */

    dprintf("Found parent "PF_VTX_T" in "PF_VTX_T"\n", \
        tree->alias[path[npath]],p);

    DL_ASSERT(p != home,"Home and parent are part of same component.");
    DL_ASSERT_EQUALS(path[npath],where[tree->alias[path[npath]]], \
        PF_VTX_T);

    /* join the path into a single component */
    if (npath > 0) {
      dprintf("Starting branch from "PF_VTX_T"("PF_VTX_T")\n", \
          tree->alias[path[0]],path[0]);
      branch = vtx_djset_find(path[0],set);
      kk = vxadj[path[0]+1] - vxadj[path[0]];
      for (k=1;k<npath;++k) {
        branch = vtx_djset_join(branch,path[k],set);
        kk += vxadj[path[k]+1] - vxadj[path[k]];
      }
      vq[branch] = link_heap_create(kk);

      DL_ASSERT(branch != vtx_djset_find(p,set),"Parent vertex is part of " \
          "branch.");
      DL_ASSERT(branch != home,"Branch and home are the same ("PF_VTX_T").", \
          home);
    } else {
      /* there is no branch region */
      branch = NULL_VTX;
    }

    /* create a heap if I'm missing one */
    if (vq[home] == NULL) {
      DL_ASSERT_EQUALS(t,home,PF_VTX_T);
      q = vq[home] = link_heap_create(vxadj[t+1] - vxadj[t]);
    } else {
      /* pickup my existing heap */
      q = vq[home];
    }

    /* populate my heap */
    for (j=vxadj[t];j<vxadj[t+1];++j) {
      link.dst = graph->adjncy[adjori[j]];
      other = vtx_djset_find(where[link.dst],set);
      if (other != home && other != branch && \
          status[tree->alias[where[link.dst]]] != STATUS_FORBIDDEN) {
        /* filter out forbidden links */
        k = adjsrc[j];
        link.src = k;
        link.wgt = dist[k] + dist[link.dst] + graph->adjwgt[adjori[j]];
        link_heap_push(link,q);
      }
    }

    for (k=0;k<npath;++k) {
      /* we have status vertices on our path and thus can't change */
      if (status[tree->alias[path[k]]] == STATUS_PINNED) {
        /* the heap must already be populated by this poipnt */
        goto NEXT;
      }
    }

    if (npath > 0) {
      /* repair the voronoi diagram, and add new paths to q */
      __repair_voronoi(home,branch,graph,path,npath,vxadj,vadjncy,vadjwgt, \
          adjsrc,adjori,where,set,vq[branch],dist,parent,pq);
    }

    /* find a new key-path */
    while (q->size > 0 || (branch != NULL_VTX && vq[branch]->size > 0)) {
      if (branch != NULL_VTX && vq[branch]->size > 0 && (q->size == 0 ||  \
          link_heap_peek(q).wgt > link_heap_peek(vq[branch]).wgt)) {
        link = link_heap_pop(vq[branch]);
      } else {
        link = link_heap_pop(q);
      }

      DL_ASSERT_EQUALS(vtx_djset_find(where[link.src],set),home,PF_VTX_T);

      if (status[tree->alias[where[link.dst]]] == STATUS_FORBIDDEN) {
        continue;
      }

      other = vtx_djset_find(where[link.dst],set);

      if (other > branch)  {
        DL_ASSERT(other > home,"Invalid perspective parent");
        DL_ASSERT(branch > home,"Invalid branch");
        /* this link connects to the other component */
        if (link.wgt < w) {
          /* we want to exchange key paths */
          ++nchanged;

          /* delete old path */
          if (npath > 0) {
            /* delete whole path */
            for (k=0;k<npath;++k) {
              bowstring_dg_delvtx(tree->alias[path[k]],dgraph);
              DL_ASSERT_EQUALS(status[tree->alias[path[k]]],STATUS_NONE,"%d");
              /* forbid the branch */
              status[tree->alias[path[k]]] = STATUS_FORBIDDEN;
            }
          } else {
            /* delete the link */
            bowstring_dg_deledge(v,tree->alias[path[0]],dgraph);
            DL_ASSERT_EQUALS(status[v],STATUS_NONE,"%d");
            DL_ASSERT_EQUALS(status[tree->alias[path[0]]],STATUS_NONE,"%d");
          }

          src = link.src;
          dst = link.dst;

          if (bowstring_dg_connected(src,dst,dgraph) < 0) {
            bowstring_dg_addedge(src,dst,link.wgt-dist[src]-dist[dst],dgraph);
          }

          /* trace source to add new edges */
          while (parent[src] != NULL_VTX) {
            /* add the edge */
            if (bowstring_dg_connected(src,parent[src],dgraph) < 0) {
              bowstring_dg_addedge(src,parent[src], \
                  dist[src]-dist[parent[src]],dgraph);
            }

            /* mark src as its own parent */           
            old = src;
            src = parent[src];
            parent[old] = NULL_VTX;
            dist[old] = 0;
          }
          DL_ASSERT_EQUALS(vtx_djset_find(where[src],set),home,PF_VTX_T);

          /* trace destination to add new edges */
          while (parent[dst] != NULL_VTX) {
            DL_ASSERT(status[dst] != STATUS_FORBIDDEN,"Attempting to link " \
                "through forbidden vertex "PF_VTX_T"\n",dst);
            DL_ASSERT_EQUALS(where[dst],where[parent[dst]],PF_VTX_T);
            /* add the edge */
            if (bowstring_dg_connected(dst,parent[dst],dgraph) < 0) {
              bowstring_dg_addedge(dst,parent[dst], \
                  dist[dst]-dist[parent[dst]],dgraph);
            }
            /* mark src as its own parent */           
            old = dst;
            dst = parent[dst];
            parent[old] = NULL_VTX;
            dist[old] = 0;
          }
          status[dst] = STATUS_PINNED;

          DL_ASSERT_EQUALS(vtx_djset_find(where[src],set),home,PF_VTX_T);
          DL_ASSERT(vtx_djset_find(where[dst],set) != home,"Connected to " \
              "same component.");

          /* set new parent */
          p = vtx_djset_find(where[dst],set);
          DL_ASSERT_EQUALS(p,other,PF_VTX_T);
          DL_ASSERT(p != home,"New parent is in the same component as home: " \
              PF_VTX_T,home);

          /* make my subtree as forbidden */
          __forbid_subtree(t,tree,stack,status);

          DL_ASSERT(dgraph->nodes[v].nadj > 0,"Island vertex "PF_VTX_T,v);

          goto NEXT;
        }
        break;
      }
    }

    /* undo voronoi diagram mayhem -- and branch as part of search tree */
    __restore_voronoi(graph,path,npath,tree->alias,where,dist,parent,pq);
    for (k=0;k<npath;++k) {
      tt = path[k];
      for (j=vxadj[tt];j<vxadj[tt+1];++j) {
        link.dst = graph->adjncy[adjori[j]];
        if (status[tree->alias[where[link.dst]]] != STATUS_FORBIDDEN) {
          /* filter out forbidden links */
          other = vtx_djset_find(where[link.dst],set);
          if (other != home && other != branch) {
            kk = adjsrc[j];
            link.src = kk;
            link.wgt = dist[kk] + dist[link.dst] + graph->adjwgt[adjori[j]];
            link_heap_push(link,q);
          }
        }
      }
    }

    if (branch != NULL_VTX) {
      newhome = vtx_djset_join(home,branch,set);
    }

    NEXT:

    /* join this vertex with its (maybe new) parent */
    newhome = vtx_djset_join(home,p,set);
    /* add all of vq[p] and vq[branch] to q */
    if (vq[p] != NULL) {
      DL_ASSERT(vq[p] != q,"vq["PF_VTX_T"] and q are the same",p);
      while (vq[p]->size > 0) {
        link = link_heap_pop(vq[p]);
        /* drop edges between p and home */
        if (link.dst != home && \
            status[tree->alias[where[link.dst]]] != STATUS_FORBIDDEN) {
          link_heap_push(link,q);
        }
      }
      link_heap_free(vq[p]);
      vq[p] = NULL;
    }
    if (branch != NULL_VTX) {
      while (vq[branch]->size > 0) {
        link = link_heap_pop(vq[branch]);
        /* drop edges between p and home */
        if (link.dst != home && \
            status[tree->alias[where[link.dst]]] != STATUS_FORBIDDEN) {
          link_heap_push(link,q);
        }
      }
      link_heap_free(vq[branch]);
      vq[branch] = NULL;
    }
    vq[home] = NULL;
    vq[newhome] = q;

    DL_ASSERT_EQUALS(bowstring_dg_ncomp(dgraph),1,PF_VTX_T);
  }

  #ifdef USE_ASSERTS
  for (i=0;i<dgraph->max_nvtxs;++i) {
    DL_ASSERT(dgraph->nodes[i].nadj != 0,"Island vertex "PF_VTX_T"("PF_VTX_T \
        ")",i,where[i]);
  }
  #endif

  /* free voronoi parts */
  dl_free(adjsrc);
  dl_free(adjori);
  dl_free(vxadj);
  dl_free(vadjncy);
  dl_free(vadjwgt);

  /* free tracking structures */
  dl_free(dist);
  dl_free(kvtxs);
  dl_free(rename);
  dl_free(where);
  dl_free(parent);
  dl_free(status);
  dl_free(path);
  dl_free(stack);

  vtx_djset_free(set);
  vw_priority_queue_free(pq);

  for (i=0;i<tree->nvtxs;++i) {
    if (vq[i] != NULL) {
      link_heap_free(vq[i]);
    }
  }
  dl_free(vq);

  __update_tree(dgraph,tree);
  bowstring_dg_free(dgraph);

  DL_ASSERT_EQUALS(nconn_components(tree->nvtxs,tree->xadj,tree->adjncy),1, \
      PF_VTX_T);

  return nchanged > 0;
}




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/



void refine(
    objective_t * const objective,
    graph_t const * const graph,
    tree_t * const tree)
{
  int moved;
  size_t r;
  twgt_t init_cost;

  init_cost = tree->cost;

  #pragma omp master
  {
    dl_start_timer(&(objective->timers.refine));
  }

  for (r=0;r<objective->nrefpass;) { /* incremented below */
    moved = 0;
    switch (objective->reftype) {
      case BURNTSIDE_REFINE_NONE:
        /* do nothing */
        break;
      case BURNTSIDE_REFINE_VTX:
        moved = __refine_VTX(objective,graph,tree);
        break;
      case BURNTSIDE_REFINE_KP:
        moved = __refine_KP(objective,graph,tree);
        break;
      case BURNTSIDE_REFINE_VKP:
        moved = __refine_VTX(objective,graph,tree);
        moved += __refine_KP(objective,graph,tree);
        break;
      default:
        dl_error("Unknown refine type '%d'\n",objective->reftype);
    }
    ++r;

    DL_ASSERT(check_tree(graph,tree),"Bad tree after refinement pass %zu\n",r);

    if (!moved) {
      break;
    }
  }

  #pragma omp master
  {
    dl_stop_timer(&(objective->timers.refine));
    vprintf(objective->verbosity,BURNTSIDE_VERBOSITY_MEDIUM,"Made %zu " \
        "refinment passes to improve solution by "PF_TWGT_T"\n",r, \
        init_cost-tree->cost);
  }

}


#endif
