/**
 * @file tree.h
 * @brief Structs, types, and functions for steiner trees
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-05-29
 */




#ifndef BURNTSIDE_TREE_H
#define BURNTSIDE_TREE_H




#include "base.h"
#include "graph.h"




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef struct tree_t {
  vtx_t nvtxs;
  adj_t nedges;
  wgt_t cost;
  adj_t * xadj;
  vtx_t * adjncy;
  wgt_t * adjwgt;
  wgt_t * vwgt;
  vtx_t * alias;
  int * term;
} tree_t;



/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


#define create_tree __burntside_create_tree
/**
 * @brief Allocate and initialize a tree structure.
 *
 * @return The tree.
 */
tree_t * create_tree(void);


#define calc_cost __burntside_calc_cost
/**
 * @brief Calcaulate the cost of a steiner tree.
 *
 * @param tree The steiner tree to compute the cost of.
 *
 * @return The cost of the steiner tree.
 */
twgt_t calc_cost(
    tree_t const * tree);


#define extract_tree __burntside_extract_tree
/**
 * @brief This function extracts a steiner tree from a graph given a set of 
 * vertices and their parents in the steiner tree.
 *
 * @param graph The graph to extract the tree from.
 * @param present A boolean array indicating if a vertex is present in the
 *   tree.
 * @param include A boolean array indicating if an edge is present in the tree.
 * @param term A sorted liste of terminal vertices.
 * @param nterm The number of terminal vertices.
 *
 * @return The extracted tree.
 */
tree_t * extract_tree(
    graph_t const * graph,
    int const * present,
    int const * include,
    vtx_t const * term,
    vtx_t nterm);


#define tree_post_order __burntside_tree_post_order
/**
 * @brief Re-order a tree to be in post-order.
 *
 * @param tree The tree to re-order.
 * @param rename The rename vector (inverse of tree->alias).
 */
void tree_post_order(
    tree_t * tree,
    vtx_t * rename);


#define check_tree __burntside_check_tree
/**
 * @brief Check a tree for validity as a solution for the steiner tree problem.
 *
 * @param graph The base graph.
 * @param tree The solution.
 *
 * @return 1 if the solution is valid.
 */
int check_tree(
    graph_t const * graph,
    tree_t const * tree);


#define tree_free __burntside_tree_free
/**
 * @brief Free a steiner tree structure and associated memory. 
 *
 * @param tree The tree to free.
 */
void tree_free(
    tree_t * tree);




#endif
