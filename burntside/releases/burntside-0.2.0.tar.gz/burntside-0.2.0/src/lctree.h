/**
 * @file lctree.h
 * @brief Functions for link/cut trees.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-10-15
 */




#ifndef BURNTSIDE_LCTREE_H
#define BURNTSIDE_LCTREE_H




#include "base.h"
#include "tree.h"




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef struct lcnode_t {
  vtx_t p;
  wgt_t w;
} lcnode_t;


typedef struct lctree_t {
  size_t nnodes;
  struct lcnode_t * nodes;
} lctree_t;




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


lctree_t * lctree_create(
    vtx_t nvtxs);


void lctree_reset(
    lctree_t * tree);


void lctree_link(
    vtx_t v,
    vtx_t u,
    wgt_t w,
    lctree_t * tree);


void lctree_cut(
    vtx_t v,
    vtx_t u,
    lctree_t * tree);


void lctree_setroot(
    vtx_t v,
    lctree_t * tree);


vtx_t lctree_findroot(
    vtx_t v,
    lctree_t const * tree);


vtx_t lctree_findmax(
    vtx_t v,
    lctree_t const * tree);


void lctree_free(
    lctree_t * tree);


#endif
