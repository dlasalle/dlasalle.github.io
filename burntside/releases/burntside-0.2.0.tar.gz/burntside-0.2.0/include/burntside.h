/**
 * @file burntside.h
 * @brief Main header for for burntside 
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-02-17
 */




#ifndef BURNTSIDE_H
#define BURNTSIDE_H



#include <stdint.h>
#include <float.h>
#include <unistd.h>




/******************************************************************************
* VERSION *********************************************************************
******************************************************************************/


#define BURNTSIDE_VER_MAJOR 0
#define BURNTSIDE_VER_MINOR 2
#define BURNTSIDE_VER_SUBMINOR 0




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


#ifdef BURNTSIDE_64BIT_VERTICES
typedef uint64_t vtx_t;
#else
typedef uint32_t vtx_t;
#endif
#ifdef BURNTSIDE_64BIT_EDGES
typedef uint64_t adj_t;
#else
typedef uint32_t adj_t;
#endif
#ifdef BURNTSIDE_DOUBLE_WEIGHTS
typedef double wgt_t;
#else
typedef float wgt_t;
#endif




/******************************************************************************
* ENUMS ***********************************************************************
******************************************************************************/


typedef enum burntside_error_t {
  BURNTSIDE_SUCCESS = 1,
  BURNTSIDE_ERROR_INVALIDOPTIONS,
  BURNTSIDE_ERROR_INVALIDINPUT,
  BURNTSIDE_ERROR_NOTENOUGHMEMORY,
  BURNTSIDE_ERROR_IO,
  BURNTSIDE_ERROR_UNIMPLEMENTED,
  BURNTSIDE_ERROR_UNKNOWN
} burntside_error_t;


typedef enum burntside_option_t {
  BURNTSIDE_OPTION_HELP,
  BURNTSIDE_OPTION_NTHREADS,
  BURNTSIDE_OPTION_SEED,
  BURNTSIDE_OPTION_NRUNS,
  BURNTSIDE_OPTION_VERBOSITY,
  BURNTSIDE_OPTION_TIME,
  BURNTSIDE_OPTION_RUNSTATS,
  BURNTSIDE_OPTION_BLOCKSIZE,
  BURNTSIDE_OPTION_EXPANSION,
  BURNTSIDE_OPTION_REFINE,
  BURNTSIDE_OPTION_PARTITION,
  BURNTSIDE_OPTION_MINSPLIT,
  BURNTSIDE_OPTION_IGNORE,
  BURNTSIDE_OPTION_PRUNE,
  BURNTSIDE_OPTION_NOVWGT,
  __BURNTSIDE_OPTION_TERM
} burntside_option_t;


typedef enum burntside_verbosity_t {
  BURNTSIDE_VERBOSITY_NONE=0,
  BURNTSIDE_VERBOSITY_MINIMUM=10,
  BURNTSIDE_VERBOSITY_LOW=20,
  BURNTSIDE_VERBOSITY_MEDIUM=30,
  BURNTSIDE_VERBOSITY_HIGH=40,
  BURNTSIDE_VERBOSITY_MAXIMUM=50
} burntside_verbosity_t;


typedef enum burntside_expansion_t {
  BURNTSIDE_EXPANSION_GROW,
  BURNTSIDE_EXPANSION_MST,
  BURNTSIDE_EXPANSION_SPH
} burntside_expansion_t;


typedef enum burntside_refine_t {
  BURNTSIDE_REFINE_NONE,
  BURNTSIDE_REFINE_VTX,
  BURNTSIDE_REFINE_KP,
  BURNTSIDE_REFINE_KV,
  BURNTSIDE_REFINE_VKP,
  BURNTSIDE_REFINE_VKK
} burntside_refine_t;


typedef enum burntside_partition_t {
  BURNTSIDE_PARTITION_NONE,
  BURNTSIDE_PARTITION_EDGECUT,
  BURNTSIDE_PARTITION_MODULARITY,
  BURNTSIDE_PARTITION_MST
} burntside_partition_t;


typedef enum burntside_format_t {
  BURNTSIDE_FORMAT_STP,
  BURNTSIDE_FORMAT_DIMACS
} burntside_format_t;




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static size_t const BURNTSIDE_NOPTIONS = __BURNTSIDE_OPTION_TERM;
static double const BURNTSIDE_VAL_OFF = -DBL_MAX;




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


#ifdef __cplusplus
extern "C" {
#endif


double * burntside_init_options(void);


int burntside_solve(
    vtx_t const * nvtxs, 
    adj_t const * xadj, 
    vtx_t const * adjncy, 
    wgt_t const * adjwgt, 
    vtx_t const * terminals,
    vtx_t const * nterm, 
    double const * options, 
    adj_t ** links, 
    adj_t * nlinks);




#ifdef __cplusplus
}
#endif




#endif
