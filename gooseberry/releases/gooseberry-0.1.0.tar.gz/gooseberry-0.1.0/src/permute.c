/**
 * @file permute.c
 * @brief Functions for re-ordering a matrix
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-06-05
 */




#ifndef GOOSEBERRY_PERMUTE_C
#define GOOSEBERRY_PERMUTE_C




#include "permute.h"




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int permute_sparse(
    const dim_t nrows,
    const dim_t ncols,
    ind_t * const rowptr,
    dim_t * const rowind,
    real_t * const rowval,
    const dim_t * const rowperm,
    const dim_t * const colperm)
{
  dim_t i, k, v;
  ind_t j;
  dim_t * rename;
  ind_t * prowptr;
  dim_t * prowind;
  real_t * prowval;

  if (rowperm) {
    /* perform a row and possibly a column permutation */
    prowptr = ind_alloc(nrows+1);
    prowind = dim_alloc(rowptr[nrows]);
    prowval = real_alloc(rowptr[nrows]);
    prowptr[0] = 0;
    for (i=0;i<nrows;++i) {
      v = rowperm[i];
      prowptr[i+1] = prowptr[i] + (rowptr[v+1] - rowptr[v]);
    }
    
    k = 0;
    if (colperm) {
      rename = dim_alloc(nrows);
      /* reverse the colperm */
      for (i=0;i<ncols;++i) {
        v = colperm[i];
        rename[v] = i;
      }
      /* apply the colperm while filling rowindex and rowvalue arrays */
      for (i=0;i<nrows;++i) {
        v = rowperm[i];
        for (j=rowptr[v];j<rowptr[v+1];++j) {
          prowind[k] = rename[rowind[j]];
          prowval[k] = rowval[j];
          ++k;
        }
      }
      dl_free(rename);
    } else {
      /* fill rowindex and rowvalue arrays */
      for (i=0;i<nrows;++i) {
        v = rowperm[i];
        for (j=rowptr[v];j<rowptr[v+1];++j) {
          prowind[k] = rowind[j];
          prowval[k] = rowval[j];
          ++k;
        }
      }
    }
    ind_copy(rowptr,prowptr,nrows);
    dim_copy(rowind,prowind,rowptr[nrows]);
    real_copy(rowval,prowval,rowptr[nrows]);

    dl_free(prowind);
    dl_free(prowptr);
    dl_free(prowval);
  } else if (colperm) {
    /* perform only a column permutation */
    prowind = dim_alloc(rowptr[nrows]);
    rename = dim_alloc(nrows);
    /* reverse the colperm */
    for (i=0;i<ncols;++i) {
      v = colperm[i];
      rename[v] = i;
    }
    /* apply the colperm while filling rowindex and rowvalue arrays */
    for (i=0;i<nrows;++i) {
      for (j=rowptr[i];j<rowptr[i+1];++j) {
        prowind[j] = rename[rowind[j]];
      }
    }

    dim_copy(rowind,prowind,rowptr[nrows]);
    dl_free(rename);
    dl_free(prowind);
  }

  return GOOSEBERRY_SUCCESS;
}


int permute_dense(
    const dim_t nrows,
    const dim_t ncols,
    real_t * const rowval,
    const dim_t * const rowperm,
    const dim_t * const colperm)
{
  dim_t i,v,j,u;
  real_t * prowval;

  if (rowperm || colperm) {
    prowval = real_alloc(nrows*ncols);

    for (i=0;i<nrows;++i) {
      if (rowperm) {
        v = rowperm[i];
      } else {
        v = i;
      }
      if (colperm) {
        for (j=0;j<ncols;++j) {
          u = colperm[j];
          prowval[(i*ncols)+j] = rowval[(v*ncols)+u];
        }
      } else {
        for (j=0;j<ncols;++j) {
          prowval[(i*ncols)+j] = rowval[(v*ncols)+j];
        }
      }
    }

    real_copy(rowval,prowval,nrows*ncols);

    dl_free(prowval);
  }
  
  return GOOSEBERRY_SUCCESS;
}


int permute_dense_rev(
    const dim_t nrows,
    const dim_t ncols,
    real_t * const rowval,
    const dim_t * const rowperm,
    const dim_t * const colperm)
{
  dim_t i,v,j,u;
  real_t * prowval;

  if (rowperm || colperm) {
    prowval = real_alloc(nrows*ncols);

    for (i=0;i<nrows;++i) {
      if (rowperm) {
        v = rowperm[i];
      } else {
        v = i;
      }
      if (colperm) {
        for (j=0;j<ncols;++j) {
          u = colperm[j];
          prowval[(v*ncols)+u] = rowval[(i*ncols)+j];
        }
      } else {
        for (j=0;j<ncols;++j) {
          prowval[(v*ncols)+j] = rowval[(i*ncols)+j];
        }
      }
    }

    real_copy(rowval,prowval,nrows*ncols);

    dl_free(prowval);
  }
  
  return GOOSEBERRY_SUCCESS;
}




#endif
