/**
 * @file dlmath_funcs.h
 * @brief Mathematical functions
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-06
 */




/* prefixing ugliness */
#define DLMATH_PRE2(prefix,suffix) prefix ## _ ## suffix
#define DLMATH_PRE1(prefix,suffix) DLMATH_PRE2(prefix,suffix)
#define DLMATH_PUB(name) DLMATH_PRE1(DLMATH_PREFIX,name)
#define DLMATH_PRI(name) DLMATH_PRE1(_,DLMATH_PRE1(DLMATH_PREFIX,name))


/******************************************************************************
* PRIVATE CONSTANTS ***********************************************************
******************************************************************************/


#define R2(n)    n,     n + 2*64,     n + 1*64,     n + 3*64
#define R4(n) R2(n), R2(n + 2*16), R2(n + 1*16), R2(n + 3*16)
#define R6(n) R4(n), R4(n + 2*4 ), R4(n + 1*4 ), R4(n + 3*4 )

static const unsigned char DLMATH_PRI(rbyte)[256] = {
    R6(0), R6(2), R6(1), R6(3)
};

#undef R2
#undef R4
#undef R6




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


#ifndef DLMATH_VISIBILITY
  #define DLMATH_DEFVIS
  #define DLMATH_VISIBILITY
#endif


#if defined(DLMATH_DLTYPE) && DLMATH_DLTYPE == DLTYPE_FLOAT


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(sum)(
    const DLMATH_TYPE_T * const ptr, const size_t n)
{
  size_t i,pend;
  DLMATH_TYPE_T sum = 0;
  DLMATH_TYPE_T pagesum;
  const size_t psize = __DL_PAGESIZE / sizeof(DLMATH_TYPE_T);
  for (i=0;i<n;) {
    pagesum = 0;
    for (pend=dl_min(i+psize,n);i<pend;++i) {
      pagesum += ptr[i];
    }
    sum += pagesum;
  }
  return sum;
}


#else


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(sum)(
    const DLMATH_TYPE_T * const ptr, const size_t n)
{
  size_t i;
  DLMATH_TYPE_T sum = 0;
  for (i=0;i<n;++i) {
    sum += ptr[i];
  }
  return sum;
}


#endif


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(product)(
    const DLMATH_TYPE_T * const ptr, size_t n) 
{
  size_t i;
  DLMATH_TYPE_T product = 1;
  for (i=0;i<n;++i) {
    product *= ptr[i];
  }
  return product;
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(differentiate)(
    DLMATH_TYPE_T * const ptr, const size_t n)
{
  size_t i;
  if (n > 0) {
    for (i=0;i<n-1;++i) {
      ptr[i] = ptr[i+1] - ptr[i];
    }
    ptr[i] = 0;
  }
  return ptr;
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(prefixsum_exc)(
    DLMATH_TYPE_T * const ptr, const size_t n)
{
  size_t i;
  DLMATH_TYPE_T tmp1,tmp2;
  tmp1 = ptr[0];
  ptr[0] = 0;
  for (i=1;i<n;++i) {
    tmp2 = ptr[i];
    ptr[i] = tmp1 + ptr[i-1];
    tmp1 = tmp2;
  }
  return ptr;
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(prefixsum_inc)(
    DLMATH_TYPE_T * const ptr, const size_t n)
{
  size_t i;
  for (i=1;i<n;++i) {
    ptr[i] += ptr[i-1];
  }
  return ptr;
}
/* max */


DLMATH_VISIBILITY size_t DLMATH_PUB(find_max_index)(
    const DLMATH_TYPE_T * const ptr, const size_t n)
{
  size_t i,maxidx;
  for (maxidx=0,i=1; i<n;++i) {
    if (ptr[i] > ptr[maxidx] || 
        (ptr[i] == ptr[maxidx] && i < maxidx)) {
      maxidx = i;
    }
  }
  return maxidx;
}


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(find_max_value)(
    const DLMATH_TYPE_T * const ptr, const size_t n)
{
  DL_ASSERT(n > 0, "Passed in an empty array");
  return ptr[DLMATH_PUB(find_max_index)(ptr,n)];
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(set_max)(
    DLMATH_TYPE_T * const ptr, const DLMATH_TYPE_T max, const size_t n)
{
  size_t i;
  DLMATH_TYPE_T diff;
  const size_t maxidx = DLMATH_PUB(find_max_index)(ptr,n);
  /* Have to do this for unsigned types */
  if (ptr[maxidx] < max) {
    diff = max - ptr[maxidx];
    for (i=0;i<n;++i) {
      ptr[i] += diff;
    }
  } else {
    diff = ptr[maxidx] - max;
    for (i=0;i<n;++i) {
      ptr[i] -= diff;
    }
  }
  return ptr;
}
/* min */


DLMATH_VISIBILITY size_t DLMATH_PUB(find_min_index)(
    const DLMATH_TYPE_T * const ptr, const size_t n)
{
  size_t i,minidx;
  for (minidx=0,i=1; i<n;++i) {
    if (ptr[i] < ptr[minidx] ||
        (ptr[i] == ptr[minidx] && i < minidx)) {
      minidx = i;
    }
  }
  return minidx;
}


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(find_min_value)(
    const DLMATH_TYPE_T * const ptr, const size_t n)
{
  DL_ASSERT(n > 0, "Passed in an empty array");
  return ptr[DLMATH_PUB(find_min_index)(ptr,n)];
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(set_min)(
    DLMATH_TYPE_T * const ptr, const DLMATH_TYPE_T min, const size_t n)
{
  size_t i;
  DLMATH_TYPE_T diff;
  const size_t minidx = DLMATH_PUB(find_min_index)(ptr,n);
  /* Have to do this for unsigned types */
  if (ptr[minidx] < min) {
    diff = min - ptr[minidx];
    for (i=0;i<n;++i) {
      ptr[i] += diff;
    }
  } else {
    diff = ptr[minidx] - min;
    for (i=0;i<n;++i) {
      ptr[i] -= diff;
    }
  }
  return ptr;
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(incset)(DLMATH_TYPE_T * const ptr,
    const DLMATH_TYPE_T start, const DLMATH_TYPE_T inc, size_t n)
{
  size_t i;
  for (i=0;i<n;++i) {
    ptr[i] = start + (inc*i);
  }
  return ptr;
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(cyclicperm)(
    DLMATH_TYPE_T * const ptr, const size_t cyclesize, const size_t n)
{
  size_t i,j,k;
  size_t * counts = size_calloc(cyclesize);
  for (i=0;i<n;++i) {
    j = i % cyclesize;
    k = size_chunkstart(j,cyclesize,n);
    ptr[k + counts[j]++] = i;
  }
  dl_free(counts);
  return ptr;
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(blockcyclicperm)(
    DLMATH_TYPE_T * const ptr, const size_t cyclesize, const size_t blocksize, 
    const size_t n)
{
  size_t i,j,k;
  size_t * counts = size_calloc(cyclesize);
  if (n == 0) {
    return ptr;
  }
  for (i=0;i<n;++i) {
    j = (i/blocksize) % cyclesize;
    k = size_chunkstart(j*blocksize,cyclesize*blocksize,n);
    ptr[k + counts[j]++] = i;
  }
  dl_free(counts);
  return ptr;
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(max_merge)(
    DLMATH_TYPE_T * const dst, const DLMATH_TYPE_T * const src, const size_t n,
    const DLMATH_TYPE_T empty_value)
{
  size_t i;
  for (i=0;i<n;++i) {
    if (src[i] != empty_value) {
      if (dst[i] != empty_value) {
        dst[i] = dl_max(dst[i],src[i]);
      } else {
        dst[i] = src[i];
      }
    }
  }
  return dst;
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(min_merge)(
    DLMATH_TYPE_T * const dst, const DLMATH_TYPE_T * const src,
    const size_t n, const DLMATH_TYPE_T empty_value)
{
  size_t i;
  for (i=0;i<n;++i) {
    if (src[i] != empty_value) {
      if (dst[i] != empty_value) {
        dst[i] = dl_min(dst[i],src[i]);
      } else {
        dst[i] = src[i];
      }
    }
  }
  return dst;
}


DLMATH_VISIBILITY DLMATH_TYPE_T * DLMATH_PUB(avg_merge)(
    DLMATH_TYPE_T * const dst, const DLMATH_TYPE_T * const src,
    const size_t n, const DLMATH_TYPE_T empty_value)
{
  size_t i;
  for (i=0;i<n;++i) {
    if (src[i] != empty_value) {
      if (dst[i] != empty_value) {
        dst[i] = (DLMATH_TYPE_T)((dst[i]+src[i])/2.0);
      } else {
        dst[i] = src[i];
      }
    }
  }
  return dst;
}


DLMATH_VISIBILITY size_t DLMATH_PUB(intersection_size)(
    const DLMATH_TYPE_T * const a, size_t n, const DLMATH_TYPE_T * const b, 
    size_t m)
{
  size_t i,j,matches;
  matches = i = j = 0;
  while (i<n && j < m) {
    if (a[i] > b[j]) {
      ++j;
    } else if (a[i] < b[j]) {
      ++i;
    } else {
      ++i;
      ++j;
      ++matches;
    }
  }
  return matches;
}



#if defined(DLMATH_DLTYPE) && DLMATH_DLTYPE == DLTYPE_FLOAT


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(stable_sum)(
    const DLMATH_TYPE_T * const ptr, const size_t n)
{ /* kahan algorithm */
  size_t i;
  DLMATH_TYPE_T y, t;
  DLMATH_TYPE_T sum = 0, c = 0;
  for (i=0;i<n;++i) {
    y = ptr[i] - c;
    t = sum + y;
    c = (t - sum) - y;
    sum = t;
  }
  return sum;
}


DLMATH_VISIBILITY long double DLMATH_PUB(fa_sum)(const DLMATH_TYPE_T * ptr,
    size_t n)
{
  size_t i,pend;
  long double sum = 0;
  double pagesum;
  const size_t psize = __DL_PAGESIZE / sizeof(DLMATH_TYPE_T);
  for (i=0;i<n;) {
    pagesum = 0;
    for (pend=dl_min(i+psize,n);i<pend;++i) {
      pagesum += ptr[i];
    }
    sum += pagesum;
  }
  return sum;
}


#endif


#if defined(DLMATH_DLTYPE) && DLMATH_DLTYPE == DLTYPE_INTEGRAL


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(updiv)(const DLMATH_TYPE_T a, 
    const DLMATH_TYPE_T b)
{
  return (a/b) + (a%b > 0 ? 1 : 0);
}


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(chunksize)(const DLMATH_TYPE_T i, 
    const DLMATH_TYPE_T n, const DLMATH_TYPE_T m)
{
  return (m/n) + (i < (m%n) ? 1 : 0);
}


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(chunkstart)(const DLMATH_TYPE_T i, 
    const DLMATH_TYPE_T n, const DLMATH_TYPE_T m)
{
  return ((m/n)*i) + dl_min(i,m%n);
}


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(uplog2)(DLMATH_TYPE_T n)
{
  return dl_bitsize(DLMATH_TYPE_T)-dl_clz((n-1) | 1);
}


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(downlog2)(DLMATH_TYPE_T n)
{
  return (dl_bitsize(DLMATH_TYPE_T)-1)-dl_clz(n | 1);
}


/* the sizeof(DLMATH_TYPE_T) >= x check get compiled and the following code */
/* becomes branchless -- dl_maxshift is to supress warnings */
DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(uppow2)(DLMATH_TYPE_T n)
{
  if (n <= 1) {
    return 1;
  }
  n = n -1;
  n = n | (n >> 1);
  n = n | (n >> 2);
  n = n | (n >> 4);
  if (sizeof(DLMATH_TYPE_T) >= 2) {
    n = n | (n >> dl_maxshift(DLMATH_TYPE_T,8));
    if (sizeof(DLMATH_TYPE_T) >= 4) {
      n = n | (n >> dl_maxshift(DLMATH_TYPE_T,16));
      if (sizeof(DLMATH_TYPE_T) >= 8) {
        n = n | (n >> dl_maxshift(DLMATH_TYPE_T,32));
        if (sizeof(DLMATH_TYPE_T) >= 16) {
          n = n | (n >> dl_maxshift(DLMATH_TYPE_T,64));
        }
      }
    }
  }
  return n + 1;
}


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(downpow2)(DLMATH_TYPE_T n)
{
  if (n <= 1) {
    return 1;
  }
  n = n | (n >> 1);
  n = n | (n >> 2);
  n = n | (n >> 4);
  if (sizeof(DLMATH_TYPE_T) >= 2) {
    n = n | (n >> dl_maxshift(DLMATH_TYPE_T,8));
    if (sizeof(DLMATH_TYPE_T) >= 4) {
      n = n | (n >> dl_maxshift(DLMATH_TYPE_T,16));
      if (sizeof(DLMATH_TYPE_T) >= 8) {
        n = n | (n >> dl_maxshift(DLMATH_TYPE_T,32));
        if (sizeof(DLMATH_TYPE_T) >= 16) {
          n = n | (n >> dl_maxshift(DLMATH_TYPE_T,64));
        }
      }
    }
  }
  return n - (n >> 1);
}


DLMATH_VISIBILITY DLMATH_TYPE_T DLMATH_PUB(reversebits)(DLMATH_TYPE_T n)
{
  DLMATH_TYPE_T r;
  size_t i;

  r = 0;

  for (i=0;i<sizeof(DLMATH_TYPE_T);++i) {
    r |= DLMATH_PRI(rbyte)[(n >> (8*i)) & 0xFF] << 
        ((sizeof(DLMATH_TYPE_T)-i-1)*8);
  }

  return r;
}


#endif


#ifdef DLMATH_DEFVIS  
  #undef DLMATH_DEFVIS
  #undef DLMATH_VISIBILITY
#endif


#undef DLMATH_PRE1
#undef DLMATH_PRE2
#undef DLMATH_PUB
#undef DLMATH_PRI
