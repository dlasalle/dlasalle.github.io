/**
 * @file dldebug.h
 * @brief Debugging functions
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-08
 */



#ifndef DL_DEBUG_H
#define DL_DEBUG_H




/******************************************************************************
* PRIVATE MACROS **************************************************************
******************************************************************************/


#define __BACKTRACE() \
  do { \
    void * _buffer[255]; \
    int _size = backtrace(_buffer,255); \
    char ** _strings = backtrace_symbols(_buffer,_size); \
    int _i; \
    for (_i=0;_i<_size;++_i) { \
      fprintf(stderr,"%d:[%p] %s\n",_i,_buffer[_i],_strings[_i]); \
    } \
    free(_strings); \
  } while(0)




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static const char * __current_time(void)
{
  time_t tm = time(NULL);
  char * str = ctime(&tm);
  str[24] = '\0';
  return str;
}




/******************************************************************************
* Output Macros ***************************************************************
******************************************************************************/


#ifdef DEBUG
#define eprintf(...) \
  do { \
    fprintf(stderr,"At %s: %d, in %s()", __FILE__, __LINE__, __func__); \
    fprintf(stderr, "%s ERROR: ",__current_time()); \
    fprintf(stderr, __VA_ARGS__); \
    fflush(stderr); \
  } while (0)
#else
#define eprintf(...) \
  do { \
    fprintf(stderr, "%s ERROR: ",__current_time()); \
    fprintf(stderr, __VA_ARGS__); \
    fflush(stderr); \
  } while (0)
#endif

#define dl_error(...) \
  do { \
    eprintf( __VA_ARGS__); \
    fprintf(stderr,"At %s: %d ", __FILE__, __LINE__); \
    fflush(stderr); \
    abort(); \
  } while (0)

#define dl_unimplemented() \
  dl_error("Unimplemented function '%s' in '%s' called.\n", __func__,__FILE__)

#ifdef DEBUG
  #define wprintf( ...) \
    do { \
      fprintf(stderr,"%s WARN: ",__current_time()); \
      fprintf(stderr,__VA_ARGS__); \
      fflush(stderr); \
    } while (0)

  #define dprintf( ...) \
    do { \
      fprintf(stdout,"%s DEBUG: ",__current_time()); \
      fprintf(stdout,__VA_ARGS__); \
      fflush(stdout); \
    } while (0)
#else
  #define wprintf( ...)
  #define dprintf( ...)
#endif

#ifdef ASSERT
  #define DL_ASSERT(cond, ...) \
    do { \
      if (!(cond)) { \
        eprintf( __VA_ARGS__); \
        /* print the stack trace */ \
        __BACKTRACE(); \
        assert(0); /* will always fail */ \
      } \
    } while (0)
  #define DL_ASSERT_EQUALS(a,b,fmt) \
    DL_ASSERT(a == b,"("#a" = "fmt") != ("#b" = "fmt")",a,b)
#else
  #define DL_ASSERT(cnd, ...)
  #define DL_ASSERT_EQUALS(a,b,fmt)
#endif

#define DL_STATIC_ASSERT(x) \
  enum { __static_assertion = (2/(x)) }




#endif
