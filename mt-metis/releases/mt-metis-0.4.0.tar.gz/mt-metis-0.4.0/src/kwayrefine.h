/**
 * @file kwayrefine.h
 * @brief KWay refinement function prototypes.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2014-09-19
 */




#ifndef MTMETIS_KWAYREFINE_H
#define MTMETIS_KWAYREFINE_H




#include "base.h"
#include "graph.h"
#include "ctrl.h"
#include "kwinfo.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


#define par_kwawyrefine_GREEDY __mtmetis_par_kwayrefine_GREEDY
/**
* @brief Parallel greedy kway-refinement.
*
* @param ctrl control strucutre
* @param graph the graph who's partition to refine
* @param niter number of iterations of refinement to perform
* @param ffactor Fudge factor (allow positive gains at teh cost of balance)
* @param kwinfo The uncoarsening informatino struct. 
*
* @return Total of moved vertices.
*/
vtx_t par_kwayrefine_GREEDY(
    ctrl_t * const ctrl, 
    graph_t * const graph,
    size_t niter, 
    real_t ffactor,
    kwinfo_t * kwinfo);




#endif
