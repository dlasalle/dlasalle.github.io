/**
 * @file internal.c
 * @brief Internal mtmetis toplevel functions. 
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2015, Regents of the University of Minnesota
 * @version 1
 * @date 2015-01-17
 */




#ifndef MTMETIS_INTERNAL_C
#define MTMETIS_INTERNAL_C




#include "internal.h"
#include "partition.h"
#include "order.h"
#include "check.h"




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static void __unify_where(
    pid_t * const * const where, 
    graph_t const * const graph, 
    pid_t * const uwhere)
{
  vtx_t i;

  tid_t const myid = dlthread_get_id(graph->comm);

  for (i=0;i<graph->mynvtxs[myid];++i) {
    uwhere[graph->label[myid][i]] = where[myid][i];
  }
}




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


void mtmetis_partition_internal(
    ctrl_t * const ctrl,
    graph_t * const graph,
    pid_t * const where)
{
  pid_t ** dwhere;
  tid_t const nthreads = ctrl->nthreads;

  dwhere = r_vtx_alloc(ctrl->nthreads);

  #pragma omp parallel shared(dwhere) num_threads(nthreads) \
    default(none)
  {
    dlthread_comm_t comm;

    comm = dlthread_comm_init();

    tid_t const myid = dlthread_get_id(comm);

    if (myid == 0) {
      ctrl->comm = comm;
      graph->comm = comm;
    }

    dlthread_barrier(comm);

    dwhere[myid] = pid_alloc(graph->mynvtxs[myid]);

    par_partition_kway(ctrl,graph,dwhere);

    if (where) {
      __unify_where(dwhere,graph,where);
    }

    if (ctrl->verbosity >= MTMETIS_VERBOSITY_LOW) {
      dlthread_barrier(comm);
      if (myid == 0) {
        partition_print_info(ctrl,graph,(pid_t const **)dwhere);
      }
      dlthread_barrier(comm);
    }

    dl_free(dwhere[myid]);

    dlthread_comm_finalize(comm);
  }

  dl_free(dwhere);
}


void mtmetis_partition_vsep_int(
    ctrl_t * const ctrl,
    graph_t * const graph,
    pid_t * const where)
{
  pid_t ** dwhere;
  tid_t const nthreads = ctrl->nthreads;

  dwhere = r_vtx_alloc(ctrl->nthreads);

  #pragma omp parallel shared(dwhere) num_threads(nthreads) \
    default(none)
  {
    dlthread_comm_t comm;

    comm = dlthread_comm_init();

    tid_t const myid = dlthread_get_id(comm);

    if (myid == 0) {
      ctrl->comm = comm;
      graph->comm = comm;
    }

    dlthread_barrier(comm);

    if (nthreads > 1) {
      par_partition_pre(ctrl,graph);
    }

    dwhere[myid] = pid_alloc(graph->mynvtxs[myid]);

    par_partition_vertexseparator(ctrl,graph,dwhere);

    if (where) {
      __unify_where(dwhere,graph,where);
    }

    if (ctrl->verbosity >= MTMETIS_VERBOSITY_LOW) {
      dlthread_barrier(comm);
      if (myid == 0) {
        partition_print_info(ctrl,graph,(pid_t const **)dwhere);
      }
      dlthread_barrier(comm);
    }

    dl_free(dwhere[myid]);
    dlthread_comm_finalize(comm);
  }

  dl_free(dwhere);
}




#endif
