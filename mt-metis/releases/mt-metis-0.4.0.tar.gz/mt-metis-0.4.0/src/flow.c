/**
 * @file flow.c
 * @brief Function for inducing vertex and edges flows. 
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2014-12-20
 */





#ifndef MTMETIS_FLOW_C
#define MTMETIS_FLOW_C




#include "flow.h"





/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static int const MAXQSIZE = 7;



/******************************************************************************
* PRIVATE SERIAL FUNCTIONS ****************************************************
******************************************************************************/


static inline void __enqueue(
    tid_t nbrid,
    vtx_t lvtx,
    vtx_t * const * const q,
    vtx_t * const * const nq,
    vtx_t const * const mynvtxs,
    int * const * const queued)
{
  vtx_t l;

  if (!queued[nbrid][lvtx]) {
    l = nq[nbrid][0]++;
    if (l < mynvtxs[nbrid]*MAXQSIZE) {
      q[nbrid][l] = lvtx;
      queued[nbrid][lvtx] = 1;
    }
  }
}


static void __par_save_flow_height(
    graph_t const * const graph,
    wgt_t const * const * const flow,
    vtx_t * const * const height,
    vsinfo_t const * const vsinfo)
{
  vtx_t i, k, lvtx, h, g, nlabeled, minh;
  adj_t j;
  tid_t nbrid;
  int noflow;

  tid_t const myid = dlthread_get_id(graph->comm);

  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const * const xadj = graph->xadj[myid];
  vtx_t const * const adjncy = graph->adjncy[myid]; 

  vtx_set(height[myid],0,mynvtxs);

  dlthread_barrier(graph->comm);

  /* set height of those adjacenct to dest */
  for (j=xadj[1];j<xadj[2];++j) {
    k = adjncy[j];
    if (k < mynvtxs) {
      lvtx = k;
      nbrid = myid;
    } else {
      lvtx = gvtx_to_lvtx(k,graph->dist);
      nbrid = gvtx_to_tid(k,graph->dist);
    }
    if (flow[myid][j] < 0) {
      height[nbrid][lvtx] = 1;
    }
  }

  /* iterate to set all heights */
  do {
    nlabeled = 0;
    for (i=2;i<mynvtxs;++i) {
      h = height[myid][i];
      if (h == 0) {
        ++nlabeled;
      }
      noflow = 1;
      minh = graph->nvtxs;
      for (j=xadj[i];j<xadj[i+1];++j) {
        k = adjncy[j];
        if (k < mynvtxs) {
          lvtx = k;
          nbrid = myid;
        } else {
          lvtx = gvtx_to_lvtx(k,graph->dist);
          nbrid = gvtx_to_tid(k,graph->dist);
        }
        g = height[nbrid][lvtx];
        if (flow[myid][j] > 0) {
          noflow = 0;
          if (h <= g) {
            h = height[myid][i] = g+1;
            break;
          }
        }
        if (g < minh && g > 0) {
          minh = g;
        }
      }
      if (noflow) {
        /* will never get labeled */
        height[myid][i] = minh;
      }
    }
  } while (nlabeled > 0);

  for (i=2;i<graph->mynvtxs[myid];++i) {
    vsinfo->height[graph->label[myid][i]] = height[myid][i];
    dprintf("Saving height of %"PF_VTX_T" for vertex %"PF_VTX_T"\n", \
        height[myid][i],graph->label[myid][i]);
  }
}


static vtx_t __par_init_height(
    ctrl_t const * const ctrl,
    graph_t const * const graph,
    vsinfo_t const * const vsinfo,
    vtx_t * const * const height,
    vtx_t * const * const oheight)
{
  vtx_t i, k, lvtx, nlabel, minh, h, maxh;
  adj_t j;
  tid_t nbrid;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  vtx_t const nvtxs = graph->nvtxs;
  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const * const xadj = graph->xadj[myid];
  vtx_t const * const adjncy = graph->adjncy[myid];

  if (ctrl->global_relabel) {
    vtx_set(height[myid],NULL_VTX,mynvtxs);
    
    height[myid][1] = 0;

    dlthread_barrier(ctrl->comm);

    do {
      nlabel = 0;
      for (i=0;i<mynvtxs;++i) {
        if (height[myid][i] == NULL_VTX) {
          minh = graph->nvtxs;
          for (j=xadj[i];j<xadj[i+1];++j) {
            k = adjncy[j];
            if (k < mynvtxs) {
              lvtx = k;
              nbrid = myid;
            } else {
              lvtx = gvtx_to_lvtx(k,graph->dist);
              nbrid = gvtx_to_tid(k,graph->dist);
            }
            h = height[nbrid][lvtx];
            if (h != NULL_VTX && h < minh) {
              minh = h;
            }
          }
          if (minh < graph->nvtxs) {
            height[myid][i] = minh+1;
            ++nlabel;
          }
        }
      }
      nlabel = vtx_dlthread_sumreduce(nlabel,ctrl->comm);
    } while (nlabel > 0);

    /* expand height for two-part vertices */
    for (i=2;i<graph->mynvtxs[myid];++i) {
      h = height[myid][i]*2; 
      height[myid][i] = h; 
      oheight[myid][i] = h-1;
    }

    height[myid][0] = nvtxs*2;
    oheight[myid][0] = nvtxs*2;
  } else {
    /* expand height for two-part vertices */
    maxh = nvtxs;
    for (i=2;i<graph->mynvtxs[myid];++i) {
      h = vsinfo->height[graph->label[myid][i]]; 
      height[myid][i] = h; 
      oheight[myid][i] = h-1;
      if (h > maxh) {
        maxh = h;
      }
    }

    maxh = vtx_dlthread_maxreduce_value(maxh,ctrl->comm);

    height[myid][0] = nvtxs+maxh;
    oheight[myid][0] = nvtxs+maxh;
  }

  height[myid][1] = 0;
  oheight[myid][1] = 0;

  maxh = height[myid][0] + 2*nvtxs;

  return maxh;
}


static int __flow_check_cut(
    graph_t const * const graph,
    pid_t const * const * const where)
{
  int rv;
  vtx_t i, k, mynvtxs, lvtx;
  adj_t j;
  pid_t me, other;
  tid_t nbrid, myid;
  int con[3];
  adj_t * xadj;
  vtx_t * adjncy;

  tid_t const nthreads = graph->dist.nthreads;

  rv = 1;

  for (myid=0;myid<nthreads;++myid) {
    /* graph parts */
    mynvtxs = graph->mynvtxs[myid];
    xadj = graph->xadj[myid];
    adjncy = graph->adjncy[myid];
    for (i=0;i<mynvtxs;++i) {
      me = where[myid][i];
      con[0] = con[1] = 0;
      for (j=xadj[i];j<xadj[i+1];++j) {
        k = adjncy[j];
        if (k < mynvtxs) {
          lvtx = k;
          nbrid = myid;
        } else {
          lvtx = gvtx_to_lvtx(k,graph->dist);
          nbrid = gvtx_to_tid(k,graph->dist);
        }
        other = where[nbrid][lvtx];
        DL_ASSERT(other < 3,"Bad partition for vertex %" \
            PF_TID_T":%"PF_VTX_T" of %"PF_PID_T"\n",nbrid,lvtx,other);
        ++con[other];
        if (me != MTMETIS_VSEP_SEP && (con[0] && con[1])) {
          eprintf("Vertex %"PF_TID_T":%"PF_VTX_T" is in %"PF_PID_T" is " \
              "connected to both sides (via %"PF_TID_T":%"PF_VTX_T")\n",myid, \
              i,me,nbrid,lvtx);
          rv = 0;
          goto END;
        }
      }
    }
  }

  END:

  dlthread_barrier(graph->comm);

  return rv;
}


static int __flow_check_flow(
    graph_t const * const graph,
    wgt_t const * const * const flow)
{
  vtx_t i, mynvtxs;
  adj_t j;
  tid_t myid;
  wgt_t flowstart, flowend, in, out, f;
  adj_t const * xadj;
  wgt_t const * vwgt;

  tid_t const nthreads = dlthread_get_nthreads(graph->comm);

  flowstart = 0;
  flowend = 0;
  for (myid=0;myid<nthreads;++myid) {
    mynvtxs = graph->mynvtxs[myid];
    xadj = graph->xadj[myid];
    vwgt = graph->vwgt[myid];
    /* handle source and dst */
    for (j=xadj[0];j<xadj[1];++j) {
      flowstart += flow[myid][j];
    }
    for (j=xadj[1];j<xadj[2];++j) {
      flowend += -flow[myid][j];
    }
    /* handle rest of vertices */
    for (i=2;i<mynvtxs;++i) {
      in = 0;
      out = 0;
      for (j=xadj[i];j<xadj[i+1];++j) {
        f = flow[myid][j];
        if (f > 0) {
          out += f;
        } else {
          in += -f;
        }
      }
      if (in != out) {
        eprintf("%"PF_WGT_T" flow into vertex %"PF_VTX_T" with capacity %" \
            PF_WGT_T" but %"PF_WGT_T" flow being sent out.\n",in,i,vwgt[i], \
            out);
        return 0;
      }
      if (in > vwgt[i]) {
        eprintf("Overflowed vertex %"PF_VTX_T": %"PF_WGT_T"/%"PF_WGT_T"\n",i, \
            in,vwgt[i]);
        return 0;
      }
    }
  }

  if (flowstart != flowend) {
    eprintf("%"PF_WGT_T" being sent from sources and only %"PF_WGT_T" being " \
        "recieved by destinations\n",flowstart,flowend);
    return 0;
  }

  return 1;
}




/******************************************************************************
* PUBLIC PARALLEL FUNCTIONS ***************************************************
******************************************************************************/


wgt_t par_pseudoflow_vertex(
    ctrl_t const * const ctrl,
    graph_t const * const graph,
    vsinfo_t * const vsinfo,
    wgt_t ** const flow)
{
  vtx_t i, p, k, h, lvtx, nfq, nloop;
  adj_t j;
  tid_t nbrid;
  wgt_t maxflow, cap;
  size_t iter;
  wgt_t excess[2];
  int ** queued;
  vtx_t * fq;
  vtx_t ** nfqs, ** fqs, ** height, ** oheight;
  adj_t * radj;
  wgt_t * myflow;

  /* instead of actually creating the expanded graph, we emulate it via several
   * arrays.
   *
   * myflow is the flow of the vertex internal edges of this thread.
   * oheight height of the out half.
   * height keeps track of both v_out and v_in (constrained to be equal).
   */

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const nedges = graph->xadj[myid][mynvtxs];

  adj_t const * const xadj = graph->xadj[myid];
  vtx_t const * const adjncy = graph->adjncy[myid]; 

  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;

  dprintf("Performing flow on n = %"PF_VTX_T" and m = %"PF_ADJ_T"\n",mynvtxs, \
      xadj[mynvtxs]);

  radj = par_graph_build_radj(graph);

  height = dlthread_get_shmem(2*(sizeof(vtx_t*)*nthreads) + \
      (sizeof(vtx_t*)*nthreads) + (sizeof(vtx_t*)*nthreads) + \
      (sizeof(int*)*nthreads),ctrl->comm);

  oheight = (vtx_t**)(height+nthreads);

  nfqs = (vtx_t**)(oheight+nthreads);
  fqs = (vtx_t**)(nfqs+nthreads);
  queued = (int**)(fqs+nthreads);

  nfqs[myid] = &nfq;
  queued[myid] = int_init_alloc(0,mynvtxs);
  fqs[myid] = vtx_alloc(mynvtxs*MAXQSIZE);
  fq = vtx_alloc(mynvtxs*MAXQSIZE);

  /* make sure source and dest are never processed */
  queued[myid][0] = 1;
  queued[myid][1] = 1;

  myflow = wgt_init_alloc(0,mynvtxs);

  height[myid] = vtx_alloc(mynvtxs); 
  oheight[myid] = vtx_alloc(mynvtxs); 

  wgt_set(flow[myid],0,nedges);

  __par_init_height(ctrl,graph,vsinfo,height,oheight);

  /* delete me */
  dl_timer_t tmr;
  dl_init_timer(&tmr);
  dl_start_timer(&tmr);

  /* seed my iteration */
  nfq = 0;

  dlthread_barrier(ctrl->comm);

  for (j=xadj[0];j<xadj[1];++j) {
    k = adjncy[j];    
    if (k < mynvtxs) {
      lvtx = k;
      nbrid = myid;
    } else {
      lvtx = gvtx_to_lvtx(k,graph->dist);
      nbrid = gvtx_to_tid(k,graph->dist);
    }
    flow[myid][j] = gvwgt[nbrid][lvtx];
    flow[nbrid][radj[j]] = -gvwgt[nbrid][lvtx];
    __enqueue(nbrid,lvtx,fqs,nfqs,graph->mynvtxs,queued);

    dprintf("Sending flow of %"PF_WGT_T" from %"PF_VTX_T" to %" \
        PF_VTX_T"\n",gvwgt[nbrid][lvtx],0,lvtx);
  }

  iter = 0;

  /* begin the actual max flow computation */
  do {
    /* copy buffer over */
    nloop = *nfqs[myid];
    vtx_copy(fq,fqs[myid],nloop);
    *nfqs[myid] = 0;

    /* flow computation is done in two passes:
     *  1. push flows
     *  2. adjust heights
     */

    /* process flows *********************************************************/
    for (p=0;p<nloop;++p) {
      i = fq[p];
      queued[myid][i] = 0;

      /* calculate excess */
      excess[0] = -myflow[i];
      excess[1] = myflow[i];
      for (j=xadj[i];j<xadj[i+1];++j) {
        if (flow[myid][j] < 0) {
          excess[0] -= flow[myid][j];
        } else {
          excess[1] -= flow[myid][j];
        }
      }

      dprintf("Vertex %"PF_VTX_T" has excess of %"PF_WGT_T":%"PF_WGT_T"\n",i, \
          excess[0],excess[1]);
      
      /* handle -in- half of vertex first */
      if (excess[0] > 0) {
        h = height[myid][i]; 
        if (h > oheight[myid][i] && myflow[i] < gvwgt[myid][i]) {
          cap = dl_min(excess[0],gvwgt[myid][i] - myflow[i]);
          excess[0] -= cap;
          excess[1] += cap;
          myflow[i] += cap;
          __enqueue(myid,i,fqs,nfqs,graph->mynvtxs,queued);
          dprintf("Sending %"PF_WGT_T" flow to -out- half of vertex %" \
              PF_VTX_T"\n",cap,i);
        }
        /* back flow excess */
        for (j=xadj[i];excess[0] > 0 && j < xadj[i+1];++j) {
          k = adjncy[j];    
          if (k < mynvtxs) {
            lvtx = k;
            nbrid = myid;
          } else {
            lvtx = gvtx_to_lvtx(k,graph->dist);
            nbrid = gvtx_to_tid(k,graph->dist);
          }
          if (h > oheight[nbrid][lvtx]) {
            if (flow[myid][j] < 0) {
              cap = dl_min(excess[0],-flow[myid][j]);
              excess[0] -= cap;
              flow[myid][j] += cap;
              flow[nbrid][radj[j]] -= cap;

              __enqueue(nbrid,lvtx,fqs,nfqs,graph->mynvtxs,queued);
              dprintf("Back flowing %"PF_WGT_T" from %"PF_VTX_T" to %" \
                  PF_VTX_T"\n",cap,i,lvtx);
            }
          }
        }
      }

      /* handle -out- half */
      if (excess[1] > 0) {
        h = oheight[myid][i];
        for (j=xadj[i];excess[1] > 0 && j < xadj[i+1];++j) {
          k = adjncy[j];    
          if (k < mynvtxs) {
            lvtx = k;
            nbrid = myid;
          } else {
            lvtx = gvtx_to_lvtx(k,graph->dist);
            nbrid = gvtx_to_tid(k,graph->dist);
          }
          if (h > height[nbrid][lvtx]) {
            if (flow[myid][j] >= 0) {
              cap = dl_min(excess[1],gvwgt[nbrid][lvtx]-flow[myid][j]);
              excess[1] -= cap;
              flow[myid][j] += cap;
              flow[nbrid][radj[j]] -= cap;
              __enqueue(nbrid,lvtx,fqs,nfqs,graph->mynvtxs,queued);
              dprintf("Pushing flow of %"PF_WGT_T" from %"PF_VTX_T" to %" \
                  PF_VTX_T"\n",cap,i,lvtx);
            }
          }
        }
        /* back flow excess if possible */
        if (excess[1] > 0) {
          if (h > height[myid][i]) {
            cap = excess[1];
            excess[1] -= cap;
            myflow[i] -= cap;
            __enqueue(myid,i,fqs,nfqs,graph->mynvtxs,queued);
            dprintf("Back flowing %"PF_WGT_T" to the -in- half of vertex %" \
                PF_VTX_T"\n",cap,i);
          }
        }
      }
    }
    ++iter;
  } while (*nfqs[myid] > 0);

  dl_stop_timer(&tmr);
  printf("Flow took %0.05lfs in %zu iterations\n",dl_poll_timer(&tmr),iter);

  /* copy heights back to vsinfo */
  __par_save_flow_height(graph,(wgt_t const **)flow,height,vsinfo);

  /* the sink */
  maxflow = 0;
  for (j=xadj[1];j<xadj[2];++j) {
    maxflow -= flow[myid][j];
  }

  maxflow = wgt_dlthread_sumreduce(maxflow,ctrl->comm);

  dl_free(radj);
  dl_free(myflow);
  dl_free(fq);
  dl_free(height[myid]);
  dl_free(oheight[myid]);
  dl_free(queued[myid]);

  dlthread_free_shmem(height,ctrl->comm);

  par_dprintf("Maximum flow of %"PF_WGT_T"\n",maxflow);

  DL_ASSERT(__flow_check_flow(graph,(wgt_t const **)flow),"Bad flow computed");

  return maxflow;
}


wgt_t par_flow_vertex(
    ctrl_t const * const ctrl,
    graph_t const * const graph,
    vsinfo_t * const vsinfo,
    wgt_t ** const flow)
{
  vtx_t i, p, k, na, h, lvtx, minh, maxh, nfq, nhq, nloop;
  adj_t j;
  tid_t nbrid;
  wgt_t maxflow, cap;
  int firsttry;
  size_t iter;
  wgt_t excess[2];
  int * hqd;
  int ** queued;
  vtx_t * fq, * hq;
  vtx_t ** nfqs, ** fqs, ** height, ** oheight;
  adj_t * radj;
  wgt_t * myflow;

  /* instead of actually creating the expanded graph, we emulate it via several
   * arrays.
   *
   * myflow is the flow of the vertex internal edges of this thread.
   * oheight height of the out half.
   * height keeps track of both v_out and v_in (constrained to be equal).
   */

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const nedges = graph->xadj[myid][mynvtxs];

  adj_t const * const xadj = graph->xadj[myid];
  vtx_t const * const adjncy = graph->adjncy[myid]; 

  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;

  dprintf("Performing flow on n = %"PF_VTX_T" and m = %"PF_ADJ_T"\n",mynvtxs, \
      xadj[mynvtxs]);

  radj = par_graph_build_radj(graph);

  height = dlthread_get_shmem(2*(sizeof(vtx_t*)*nthreads) + \
      (sizeof(vtx_t*)*nthreads) + (sizeof(vtx_t*)*nthreads) + \
      (sizeof(int*)*nthreads),ctrl->comm);

  oheight = (vtx_t**)(height+nthreads);

  nfqs = (vtx_t**)(oheight+nthreads);
  fqs = (vtx_t**)(nfqs+nthreads);
  queued = (int**)(fqs+nthreads);

  nfqs[myid] = &nfq;
  queued[myid] = int_init_alloc(0,mynvtxs);
  fqs[myid] = vtx_alloc(mynvtxs*MAXQSIZE);
  fq = vtx_alloc(mynvtxs*MAXQSIZE);
  hq = vtx_alloc(mynvtxs*MAXQSIZE);

  /* make sure source and dest are never processed */
  queued[myid][0] = 1;
  queued[myid][1] = 1;

  myflow = wgt_init_alloc(0,mynvtxs);

  height[myid] = vtx_alloc(mynvtxs); 
  oheight[myid] = vtx_alloc(mynvtxs); 

  hqd = int_init_alloc(0,mynvtxs);

  wgt_set(flow[myid],0,nedges);

  maxh = __par_init_height(ctrl,graph,vsinfo,height,oheight);

  /* delete me */
  dl_timer_t tmr;
  dl_init_timer(&tmr);
  dl_start_timer(&tmr);

  /* seed my iteration */
  nfq = 0;

  dlthread_barrier(ctrl->comm);

  for (j=xadj[0];j<xadj[1];++j) {
    k = adjncy[j];    
    if (k < mynvtxs) {
      lvtx = k;
      nbrid = myid;
    } else {
      lvtx = gvtx_to_lvtx(k,graph->dist);
      nbrid = gvtx_to_tid(k,graph->dist);
    }
    flow[myid][j] = gvwgt[nbrid][lvtx];
    flow[nbrid][radj[j]] = -gvwgt[nbrid][lvtx];
    __enqueue(nbrid,lvtx,fqs,nfqs,graph->mynvtxs,queued);

    dprintf("Sending flow of %"PF_WGT_T" from %"PF_VTX_T" to %" \
        PF_VTX_T"\n",gvwgt[nbrid][lvtx],0,lvtx);
  }

  iter = 0;
  firsttry = 1;
  nhq = 0;

  /* begin the actual max flow computation */
  do {
    na = 0;

    /* flow computation is done in two passes:
     *  1. push flows
     *  2. adjust heights
     */

    do {
      /* copy buffer over */
      nloop = *nfqs[myid];
      vtx_copy(fq,fqs[myid],nloop);
      *nfqs[myid] = 0;

      /* process flows *******************************************************/
      for (p=0;p<nloop;++p) {
        i = fq[p];

        /* calculate excess */
        excess[0] = -myflow[i];
        excess[1] = myflow[i];
        for (j=xadj[i];j<xadj[i+1];++j) {
          if (flow[myid][j] < 0) {
            excess[0] -= flow[myid][j];
          } else {
            excess[1] -= flow[myid][j];
          }
        }

        dprintf("Vertex %"PF_VTX_T" has excess of %"PF_WGT_T":%"PF_WGT_T"\n", \
            i,excess[0],excess[1]);
        
        /* handle -in- half of vertex first */
        if (excess[0] > 0) {
          h = height[myid][i]; 
          if (h > oheight[myid][i] && myflow[i] < gvwgt[myid][i]) {
            cap = dl_min(excess[0],gvwgt[myid][i] - myflow[i]);
            excess[0] -= cap;
            excess[1] += cap;
            myflow[i] += cap;
            __enqueue(myid,i,fqs,nfqs,graph->mynvtxs,queued);
            dprintf("Sending %"PF_WGT_T" flow to -out- half of vertex %" \
                PF_VTX_T"\n",cap,i);
          }
          /* back flow excess */
          for (j=xadj[i];excess[0] > 0 && j < xadj[i+1];++j) {
            k = adjncy[j];    
            if (k < mynvtxs) {
              lvtx = k;
              nbrid = myid;
            } else {
              lvtx = gvtx_to_lvtx(k,graph->dist);
              nbrid = gvtx_to_tid(k,graph->dist);
            }
            if (h > oheight[nbrid][lvtx]) {
              if (flow[myid][j] < 0) {
                cap = dl_min(excess[0],-flow[myid][j]);
                excess[0] -= cap;
                flow[myid][j] += cap;
                flow[nbrid][radj[j]] -= cap;

                __enqueue(nbrid,lvtx,fqs,nfqs,graph->mynvtxs,queued);
                dprintf("Back flowing %"PF_WGT_T" from %"PF_VTX_T"(%"PF_VTX_T \
                    ") to %"PF_VTX_T"(%"PF_VTX_T")\n",cap,i,h,lvtx, \
                    oheight[nbrid][lvtx]);
              }
            }
          }
        }

        /* handle -out- half */
        if (excess[1] > 0) {
          h = oheight[myid][i];
          for (j=xadj[i];excess[1] > 0 && j < xadj[i+1];++j) {
            k = adjncy[j];    
            if (k < mynvtxs) {
              lvtx = k;
              nbrid = myid;
            } else {
              lvtx = gvtx_to_lvtx(k,graph->dist);
              nbrid = gvtx_to_tid(k,graph->dist);
            }
            if (h > height[nbrid][lvtx]) {
              if (flow[myid][j] >= 0) {
                cap = dl_min(excess[1],gvwgt[nbrid][lvtx]-flow[myid][j]);
                excess[1] -= cap;
                flow[myid][j] += cap;
                flow[nbrid][radj[j]] -= cap;
                __enqueue(nbrid,lvtx,fqs,nfqs,graph->mynvtxs,queued);
                dprintf("Pushing flow of %"PF_WGT_T" from %"PF_VTX_T" to %" \
                    PF_VTX_T"\n",cap,i,lvtx);
              }
            }
          }
          /* back flow excess if possible */
          if (excess[1] > 0) {
            if (h > height[myid][i]) {
              cap = excess[1];
              excess[1] -= cap;
              myflow[i] -= cap;
              __enqueue(myid,i,fqs,nfqs,graph->mynvtxs,queued);
              dprintf("Back flowing %"PF_WGT_T" to the -in- half of vertex %" \
                  PF_VTX_T"\n",cap,i);
            }
          }
        }
        if (excess[0] + excess[1] > 0 && !hqd[i]) {
          /* queue this vertex for re-heighting */
          hq[nhq++] = i;
          hqd[i] = 1;
          dprintf("Queuing vertex %"PF_VTX_T" for re-heightening (%"PF_WGT_T \
              ":%"PF_WGT_T")\n",i,excess[0],excess[1]);
        }
        queued[myid][i] = 0;
      }
    } while (*nfqs[myid] > 0);

    dlthread_barrier(ctrl->comm);

    /* process heights *******************************************************/
    if (!firsttry) {
      /* we need to check every vertex if this is our last pass */
      nhq = mynvtxs-2;
      vtx_incset(hq,2,1,nhq); 
    }
    for (p=0;p<nhq;++p) {
      i = hq[p];
      hqd[i] = 0;

      excess[0] = -myflow[i];
      excess[1] = myflow[i];
      for (j=xadj[i];j<xadj[i+1];++j) {
        if (flow[myid][j] < 0) {
          excess[0] -= flow[myid][j];
        } else {
          excess[1] -= flow[myid][j];
        }
      }

      /* re-height the -out- half of the vertex first */ 
      if (excess[1] > 0) {
        h = oheight[myid][i];
        minh = height[myid][i];
        for (j=xadj[i];j<xadj[i+1];++j) {
          k = adjncy[j];    
          if (k < mynvtxs) {
            lvtx = k;
            nbrid = myid;
          } else {
            lvtx = gvtx_to_lvtx(k,graph->dist);
            nbrid = gvtx_to_tid(k,graph->dist);
          }         
          if (height[nbrid][lvtx] < minh) {
            if (flow[myid][j] >= 0 && \
                flow[myid][j] < gvwgt[nbrid][lvtx]) {

              minh = height[nbrid][lvtx];
            }
          }
        }
        if (minh >= h) { 
          h = oheight[myid][i] = minh+1;
          dprintf("Increasing height of -out- vertex %"PF_VTX_T" to %" \
              PF_VTX_T"/%"PF_VTX_T" due to excess of %"PF_WGT_T"\n", \
              i,h,graph->nvtxs,excess[1]);
        } else {
          dprintf("Vertex %"PF_VTX_T" -out- is at a sufficient height to " \
              "push flows\n",i);
        }
      }

      /* re-height the -in- half of the vertex second */
      if (excess[0] > 0) {
        h = height[myid][i];
        if (myflow[i] == gvwgt[myid][i]) {
          minh = maxh;
        } else {
          minh = oheight[myid][i];
          dprintf("Second half is flowable (%"PF_VTX_T")\n",i);
        }
        for (j=xadj[i];j<xadj[i+1];++j) {
          k = adjncy[j];    
          if (k < mynvtxs) {
            lvtx = k;
            nbrid = myid;
          } else {
            lvtx = gvtx_to_lvtx(k,graph->dist);
            nbrid = gvtx_to_tid(k,graph->dist);
          }         
          if (oheight[nbrid][lvtx] < minh && flow[myid][j] < 0) {
            minh = oheight[nbrid][lvtx];
            dprintf("Found new lower vertex for %"PF_VTX_T", %"PF_VTX_T"\n", \
                i,lvtx);
          }
        }

        if (minh >= h) {
          h = height[myid][i] = minh+1;
          dprintf("Increasing height of -in- vertex %"PF_VTX_T" to %" \
              PF_VTX_T"/%"PF_VTX_T" due to excess of %"PF_WGT_T"\n",i, \
              height[myid][i],graph->nvtxs,excess[0]);
        } else {
          dprintf("Vertex %"PF_VTX_T" -in- is at a sufficient height to " \
              "push flows (%"PF_WGT_T" vs %"PF_WGT_T"\n",i,h,minh);
        }
      }

      if (excess[0] + excess[1] > 0) {
        /* queue this vertex for flowage */
        __enqueue(myid,i,fqs,nfqs,graph->mynvtxs,queued);
      }
    }
    nhq = 0;
    na = vtx_dlthread_sumreduce(nfq,ctrl->comm);
    if (na == 0 && firsttry) {
      /* do an extra pass of every vertex to make sure we didn't miss any due to
       * race condititions */
      na = 1;
      firsttry = 0;
      nfq = mynvtxs-2;
      vtx_incset(fqs[myid],2,1,mynvtxs-2);
      int_set(queued[myid]+2,1,mynvtxs-2);
      dprintf("Empty queues, doing final full pass\n");
      dlthread_barrier(ctrl->comm); /* make sure things are queued */
    } else if (na > 0) {
      /* if we had a real pass with activity, reset first try */
      firsttry = 1;
    }
    ++iter;
  } while (na > 0);

  dl_stop_timer(&tmr);
  printf("Flow took %0.05lfs in %zu iterations\n",dl_poll_timer(&tmr),iter);

  /* copy heights back to vsinfo */
  __par_save_flow_height(graph,(wgt_t const **)flow,height,vsinfo);

  /* the sink */
  maxflow = 0;
  for (j=xadj[1];j<xadj[2];++j) {
    maxflow -= flow[myid][j];
  }

  maxflow = wgt_dlthread_sumreduce(maxflow,ctrl->comm);

  dl_free(radj);
  dl_free(myflow);
  dl_free(fq);
  dl_free(hq);
  dl_free(hqd);
  dl_free(fqs[myid]);
  dl_free(height[myid]);
  dl_free(oheight[myid]);
  dl_free(queued[myid]);

  dlthread_free_shmem(height,ctrl->comm);

  par_dprintf("Maximum flow of %"PF_WGT_T"\n",maxflow);

  DL_ASSERT(__flow_check_flow(graph,(wgt_t const **)flow),"Bad flow computed");

  return maxflow;
}


#ifdef LOCK_FLOW
wgt_t par_flow_vertex(
    ctrl_t const * const ctrl,
    graph_t const * const graph,
    vsinfo_t * const vsinfo,
    wgt_t ** const flow)
{
  vtx_t i, p, k, h, lvtx, minh, maxh, nq, nloop;
  adj_t j;
  tid_t nbrid;
  wgt_t maxflow, cap;
  size_t iter;
  wgt_t excess[2];
  int lasttry;
  int ** queued;
  vtx_t * q;
  vtx_t ** nqs, ** qs, ** height, ** oheight;
  adj_t * radj;
  wgt_t * myflow;
  omp_lock_t ** locks;

  /* instead of actually creating the expanded graph, we emulate it via several
   * arrays.
   *
   * myflow is the flow of the vertex internal edges of this thread.
   * oheight height of the out half.
   * height keeps track of both v_out and v_in (constrained to be equal).
   */

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const nedges = graph->xadj[myid][mynvtxs];

  adj_t const * const xadj = graph->xadj[myid];
  vtx_t const * const adjncy = graph->adjncy[myid]; 

  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;

  dprintf("Performing flow on n = %"PF_VTX_T" and m = %"PF_ADJ_T"\n",mynvtxs, \
      xadj[mynvtxs]);

  radj = par_graph_build_radj(graph);

  height = dlthread_get_shmem(2*(sizeof(vtx_t*)*nthreads) + \
      (sizeof(vtx_t*)*nthreads) + (sizeof(vtx_t*)*nthreads) + \
      (sizeof(omp_lock_t*)*nthreads) + (sizeof(int*)*nthreads),ctrl->comm);

  oheight = (vtx_t**)(height+nthreads);
  nqs = (vtx_t**)(oheight+nthreads);
  qs = (vtx_t**)(nqs+nthreads);
  queued = (int**)(qs+nthreads);
  locks = (omp_lock_t**)(queued+nthreads);

  nqs[myid] = &nq;
  queued[myid] = int_init_alloc(0,mynvtxs);
  qs[myid] = vtx_alloc(mynvtxs*MAXQSIZE);
  locks[myid] = malloc(sizeof(omp_lock_t)*mynvtxs);
  q = vtx_alloc(mynvtxs*MAXQSIZE);

  /* initialize locks */
  for (i=0;i<mynvtxs;++i) {
    omp_init_lock(locks[myid]+i);
  }

  /* make sure source and dest are never processed */
  queued[myid][0] = 1;
  queued[myid][1] = 1;

  myflow = wgt_init_alloc(0,mynvtxs);

  height[myid] = vtx_alloc(mynvtxs); 
  oheight[myid] = vtx_alloc(mynvtxs); 

  wgt_set(flow[myid],0,nedges);

  maxh = __par_init_height(ctrl,graph,vsinfo,height,oheight);

  /* delete me */
  dl_timer_t tmr;
  dl_init_timer(&tmr);
  dl_start_timer(&tmr);

  /* seed my iteration */
  nq = 0;

  dlthread_barrier(ctrl->comm);

  for (j=xadj[0];j<xadj[1];++j) {
    k = adjncy[j];    
    if (k < mynvtxs) {
      lvtx = k;
      nbrid = myid;
    } else {
      lvtx = gvtx_to_lvtx(k,graph->dist);
      nbrid = gvtx_to_tid(k,graph->dist);
    }
    flow[myid][j] = gvwgt[nbrid][lvtx];
    flow[nbrid][radj[j]] = -gvwgt[nbrid][lvtx];
    __enqueue(nbrid,lvtx,qs,nqs,graph->mynvtxs,queued);

    dprintf("Sending flow of %"PF_WGT_T" from %"PF_VTX_T" to %" \
        PF_VTX_T"\n",gvwgt[nbrid][lvtx],0,lvtx);
  }

  iter = 0;
  lasttry = 0;

  /* begin the actual max flow computation */
  do {
    /* copy buffer over */
    nloop = *nqs[myid];
    vtx_copy(q,qs[myid],nloop);
    *nqs[myid] = 0;

    /* process flows *********************************************************/
    for (p=0;p<nloop;++p) {
      i = q[p];

      omp_set_lock(locks[myid]+i);
      queued[myid][i] =0;

      /* calculate excess */
      excess[0] = -myflow[i];
      excess[1] = myflow[i];
      for (j=xadj[i];j<xadj[i+1];++j) {
        if (flow[myid][j] < 0) {
          excess[0] -= flow[myid][j];
        } else {
          excess[1] -= flow[myid][j];
        }
      }

      dprintf("Vertex %"PF_VTX_T" has excess of %"PF_WGT_T":%"PF_WGT_T"\n",i, \
          excess[0],excess[1]);
      
      /* handle -in- half of vertex first */
      h = height[myid][i]; 
      if (excess[0] > 0) {
        if (h > oheight[myid][i] && myflow[i] < gvwgt[myid][i]) {
          cap = dl_min(excess[0],gvwgt[myid][i] - myflow[i]);
          excess[0] -= cap;
          excess[1] += cap;
          myflow[i] += cap;
          __enqueue(myid,i,qs,nqs,graph->mynvtxs,queued);
          dprintf("Sending %"PF_WGT_T" flow to -out- half of vertex %" \
              PF_VTX_T"\n",cap,i);
        }
        /* back flow excess */
        for (j=xadj[i];excess[0] > 0 && j < xadj[i+1];++j) {
          k = adjncy[j];    
          if (k < mynvtxs) {
            lvtx = k;
            nbrid = myid;
          } else {
            lvtx = gvtx_to_lvtx(k,graph->dist);
            nbrid = gvtx_to_tid(k,graph->dist);
          }
          if (h > oheight[nbrid][lvtx]) {
            if (flow[myid][j] < 0) {
              omp_set_lock(locks[nbrid]+lvtx);
              cap = dl_min(excess[0],-flow[myid][j]);
              excess[0] -= cap;
              flow[myid][j] += cap;
              flow[nbrid][radj[j]] -= cap;

              __enqueue(nbrid,lvtx,qs,nqs,graph->mynvtxs,queued);
              dprintf("Back flowing %"PF_WGT_T" from %"PF_VTX_T" to %" \
                  PF_VTX_T"\n",cap,i,lvtx);
              omp_unset_lock(locks[nbrid]+lvtx);
            }
          }
        }
        if (excess[0] > 0) {
          /* adjust height */
          if (myflow[i] == gvwgt[myid][i]) {
            minh = maxh;
          } else {
            minh = oheight[myid][i];
            dprintf("Second half is flowable (%"PF_VTX_T")\n",i);
          }
          for (j=xadj[i];j<xadj[i+1];++j) {
            k = adjncy[j];    
            if (k < mynvtxs) {
              lvtx = k;
              nbrid = myid;
            } else {
              lvtx = gvtx_to_lvtx(k,graph->dist);
              nbrid = gvtx_to_tid(k,graph->dist);
            }         
            if (oheight[nbrid][lvtx] < minh && flow[myid][j] < 0) {
              minh = oheight[nbrid][lvtx];
              dprintf("Found new lower vertex for %"PF_VTX_T", %"PF_VTX_T"\n", \
                  i,lvtx);
            }
          }

          if (minh >= h) {
            h = height[myid][i] = minh+1;
            dprintf("Increasing height of -in- vertex %"PF_VTX_T" to %" \
                PF_VTX_T"/%"PF_VTX_T" due to excess of %"PF_WGT_T"\n",i, \
                height[myid][i],graph->nvtxs,excess[0]);
          } else {
            dprintf("Vertex %"PF_VTX_T" -in- is at a sufficient height to " \
                "push flows (%"PF_WGT_T" vs %"PF_WGT_T"\n",i,h,minh);
          }
        }
      }

      /* handle -out- half */
      h = oheight[myid][i];
      if (excess[1] > 0) {
        for (j=xadj[i];excess[1] > 0 && j < xadj[i+1];++j) {
          k = adjncy[j];    
          if (k < mynvtxs) {
            lvtx = k;
            nbrid = myid;
          } else {
            lvtx = gvtx_to_lvtx(k,graph->dist);
            nbrid = gvtx_to_tid(k,graph->dist);
          }
          if (h > height[nbrid][lvtx]) {
            if (flow[myid][j] >= 0) {
              omp_set_lock(locks[nbrid]+lvtx);
              cap = dl_min(excess[1],gvwgt[nbrid][lvtx]-flow[myid][j]);
              excess[1] -= cap;
              flow[myid][j] += cap;
              flow[nbrid][radj[j]] -= cap;
              __enqueue(nbrid,lvtx,qs,nqs,graph->mynvtxs,queued);
              dprintf("Pushing flow of %"PF_WGT_T" from %"PF_VTX_T" to %" \
                  PF_VTX_T"\n",cap,i,lvtx);
              omp_unset_lock(locks[nbrid]+lvtx);
            }
          }
        }
        /* back flow excess if possible */
        if (excess[1] > 0) {
          if (h > height[myid][i]) {
            cap = excess[1];
            excess[1] -= cap;
            myflow[i] -= cap;
            __enqueue(myid,i,qs,nqs,graph->mynvtxs,queued);
            dprintf("Back flowing %"PF_WGT_T" to the -in- half of vertex %" \
                PF_VTX_T"\n",cap,i);
          }
        }
        if (excess[1] > 0) {
          /* adjust height */
          minh = height[myid][i];
          for (j=xadj[i];j<xadj[i+1];++j) {
            k = adjncy[j];    
            if (k < mynvtxs) {
              lvtx = k;
              nbrid = myid;
            } else {
              lvtx = gvtx_to_lvtx(k,graph->dist);
              nbrid = gvtx_to_tid(k,graph->dist);
            }         
            if (height[nbrid][lvtx] < minh) {
              if (flow[myid][j] >= 0 && \
                  flow[myid][j] < gvwgt[nbrid][lvtx]) {

                minh = height[nbrid][lvtx];
              }
            }
          }
          if (minh >= h) { 
            h = oheight[myid][i] = minh+1;
            dprintf("Increasing height of -out- vertex %"PF_VTX_T" to %" \
                PF_VTX_T"/%"PF_VTX_T" due to excess of %"PF_WGT_T"\n", \
                i,h,graph->nvtxs,excess[1]);
          } else {
            dprintf("Vertex %"PF_VTX_T" -out- is at a sufficient height to " \
                "push flows\n",i);
          }
        }
      }
      queued[myid][i] = 0;

      omp_unset_lock(locks[myid]+i);
    }

    if (*nqs[myid] == 0) {
      if (!lasttry) {
        lasttry = 1;
        *nqs[myid] = mynvtxs-2;
        vtx_incset(qs[myid],2,1,*nqs[myid]);
      }
    } else {
      lasttry = 0;
    }

    ++iter;
  } while (*nqs[myid] > 0);

  dl_stop_timer(&tmr);
  printf("Flow took %0.05lfs in %zu iterations\n",dl_poll_timer(&tmr),iter);

  /* copy heights back to vsinfo */
  __par_save_flow_height(graph,(wgt_t const **)flow,height,vsinfo);

  /* the sink */
  maxflow = 0;
  for (j=xadj[1];j<xadj[2];++j) {
    maxflow -= flow[myid][j];
  }

  maxflow = wgt_dlthread_sumreduce(maxflow,ctrl->comm);

  dl_free(radj);
  dl_free(myflow);
  dl_free(q);
  dl_free(qs[myid]);
  dl_free(height[myid]);
  dl_free(oheight[myid]);
  dl_free(queued[myid]);

  /* free locks */
  for (i=0;i<mynvtxs;++i) {
    omp_destroy_lock(locks[myid]+i);
  }
  dl_free(locks[myid]);

  dlthread_free_shmem(height,ctrl->comm);

  par_dprintf("Maximum flow of %"PF_WGT_T"\n",maxflow);

  DL_ASSERT(__flow_check_flow(graph,(wgt_t const **)flow),"Bad flow computed");

  return maxflow;
}
#endif



void par_flow_cutvertex(
    ctrl_t const * const ctrl,
    graph_t const * const graph,
    wgt_t const * const flow,
    pid_t * const where)
{
  vtx_t i, k, nlc, ml, lvtx;
  adj_t j;
  tid_t nbrid;
  wgt_t in;
  int ** maxed;
  vtx_t ** label;

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  vtx_t const mynvtxs = graph->mynvtxs[myid];

  adj_t const * const xadj = graph->xadj[myid];
  vtx_t const * const adjncy = graph->adjncy[myid]; 
  wgt_t const * const vwgt = graph->vwgt[myid];

  label = dlthread_get_shmem((sizeof(vtx_t*)*nthreads) + \
      (sizeof(int*)*nthreads),ctrl->comm);
  maxed = (int**)(label + nthreads);

  label[myid] = vtx_init_alloc(1,mynvtxs);
  maxed[myid] = int_init_alloc(0,mynvtxs);

  dprintf("mynvtxs = %"PF_VTX_T", vwgt= %p, label = %p\n",mynvtxs, \
      (void*)vwgt,(void*)label);

  label[myid][0] = 0;
  label[myid][1] = 1;

  /* figure out which vertices are max-flowed */
  for (i=2;i<mynvtxs;++i) { /* skip src and dst vertices */
    in = 0;
    for (j=xadj[i];j<xadj[i+1];++j) {
      if (flow[j] < 0) {
        in -= flow[j];
      }
    }
    if (in == vwgt[i]) {
      maxed[myid][i] = 1;
    }
  }

  dlthread_barrier(ctrl->comm);

  /* propagate labels */
  do {
    nlc = 0;
    for (i=2;i<mynvtxs;++i) {
      ml = label[myid][i];
      if (ml == 1) {
        /* label possible separator vertices */
        for (j=xadj[i];j<xadj[i+1];++j) {
          k = adjncy[j];    
          if (k < mynvtxs) {
            lvtx = k;
            nbrid = myid;
          } else {
            lvtx = gvtx_to_lvtx(k,graph->dist);
            nbrid = gvtx_to_tid(k,graph->dist);
          }        
          if (label[nbrid][lvtx] == 0) {
            if (maxed[myid][i]) {
              label[myid][i] = MTMETIS_VSEP_SEP;
              dprintf("Marking vertex %"PF_VTX_T" as part of the " \
                  "separator due to vertex %"PF_VTX_T".\n",i,lvtx);
            } else {
              label[myid][i] = 0;
              dprintf("Marking vertex %"PF_VTX_T" with capacity %"PF_WGT_T \
                  " as part of partition 0 due to vertex %"PF_VTX_T".\n",i, \
                  vwgt[i],lvtx);
            }
            ++nlc;
            break;
          } else if (label[nbrid][lvtx] == MTMETIS_VSEP_SEP) {
            if (flow[j] > 0) {
              label[myid][i] = 0;
              dprintf("Marking vertex %"PF_VTX_T" as partition 0 due to " \
                  "separator directed flow\n",i);
              ++nlc;
            }
          }
        }
      } else if (ml == MTMETIS_VSEP_SEP) {
        /* push vertices out of separator placed there in a previous 
         * iteration */
        for (j=xadj[i];j<xadj[i+1];++j) {
          k = adjncy[j];    
          if (k < mynvtxs) {
            lvtx = k;
            nbrid = myid;
          } else {
            lvtx = gvtx_to_lvtx(k,graph->dist);
            nbrid = gvtx_to_tid(k,graph->dist);
          }
          if (flow[j] > 0 && label[nbrid][lvtx] != 1) {
            /* this vertex is giving flow to another vertex on the separator 
             * and thus cannot be part of the separator */
            label[myid][i] = 0;
            dprintf("Marking vertex %"PF_VTX_T" as part of partition 0 " \
                "from separator due to in-flow to vertex %"PF_VTX_T".\n",i, \
                lvtx);
            ++nlc;
          }
        }
      }
    }
    nlc = vtx_dlthread_sumreduce(nlc,ctrl->comm);
    dprintf("Relabeled %"PF_VTX_T" vertices\n",nlc);
  } while (nlc > 0);

  dl_free(maxed[myid]);

  DL_ASSERT(__flow_check_cut(graph,(pid_t const **)label),"Bad labeling");

  /* set where */
  for (i=0;i<mynvtxs;++i) {
    where[i] = label[myid][i];
  }

  dl_free(label[myid]);
  
  dlthread_free_shmem(label,ctrl->comm);
}




#endif
