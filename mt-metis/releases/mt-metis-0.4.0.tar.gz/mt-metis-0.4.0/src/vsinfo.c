/**
 * @file vsinfo.c
 * @brief FUnctions for allocating vertex separator refinement information.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2014-11-11
 */




#ifndef MTMETIS_VSINFO_C
#define MTMETIS_VSINFO_C




#include "vsinfo.h"




/******************************************************************************
* DOMLIB MACROS ***************************************************************
******************************************************************************/


#define DLMEM_PREFIX vsnbrinfo
#define DLMEM_TYPE_T vsnbrinfo_t
#include <dlmem_funcs.h>
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


vsinfo_t * vsinfo_create(
    ctrl_t const * const ctrl,
    graph_t const * const graph)
{
  vsinfo_t * vsinfo;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  vsinfo = (vsinfo_t*)malloc(sizeof(vsinfo_t));

  vsinfo->bnd = vtx_iset_create(0,graph->mynvtxs[myid]);
  if (ctrl->rtype == MTMETIS_RTYPE_FLOW) {
    vsinfo->height = vtx_alloc(graph->mynvtxs[myid]);
    vsinfo->nbrinfo = NULL;
  } else {
    vsinfo->height = NULL;
    vsinfo->nbrinfo = vsnbrinfo_alloc(graph->mynvtxs[myid]);
  }

  return vsinfo;
}


void vsinfo_free(
    vsinfo_t * vsinfo)
{
  if (vsinfo->height) {
    dl_free(vsinfo->height);
  }
  if (vsinfo->bnd) {
    vtx_iset_free(vsinfo->bnd);
  }
  if (vsinfo->nbrinfo) {
    dl_free(vsinfo->nbrinfo);
  }
  dl_free(vsinfo);
}




#endif
