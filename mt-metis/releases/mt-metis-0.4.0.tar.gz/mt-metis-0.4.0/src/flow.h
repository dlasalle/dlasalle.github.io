/**
 * @file flow.h
 * @brief Function prototypes for inducing vertex and edge flows.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2014-12-20
 */




#ifndef MTMETIS_FLOW_H
#define MTMETIS_FLOW_H




#include "base.h"
#include "ctrl.h"
#include "graph.h"
#include "vsinfo.h"




/******************************************************************************
* PARALLEL FUNCTION PROTOTYPES ************************************************
******************************************************************************/


#define par_pseudoflow_vertex __mtmetis_par_pseudoflow_vertex
/**
 * @brief Induce a vertex limited flow pseudo-flow, for finding vertex 
 * separator. Each thread has a source and a sink vertex at 0 and 1. This will
 * not be a valid max flow as some vertices will have excess.
 *
 * @param ctrl The control structure.
 * @param graph The boundary graph.
 * @param vsinfo The vsinfo containing multilevel information about height.
 * @param flow The resulting flow from this operation.
 *
 * @return The maximum flow.
 */
wgt_t par_pseudoflow_vertex(
    ctrl_t const * ctrl,
    graph_t const * graph,
    vsinfo_t * vsinfo,
    wgt_t ** flow);




#define par_flow_vertex __mtmetis_par_flow_vertex
/**
 * @brief Induce a vertex limited flow, for finding vertex separator. Each
 * thread has a source and a sink vertex at 0 and 1.
 *
 * @param ctrl The control structure.
 * @param graph The boundary graph.
 * @param vsinfo The vsinfo containing multilevel information about height.
 * @param flow The resulting flow from this operation.
 *
 * @return The maximum flow.
 */
wgt_t par_flow_vertex(
    ctrl_t const * ctrl,
    graph_t const * graph,
    vsinfo_t * vsinfo,
    wgt_t ** flow);


#define par_flow_cutvertex __mtmetis_par_flow_cutvertex
/**
 * @brief Given a flow, find a minimum cut labeling of the vertices.
 *
 * @param ctrl The control structure.
 * @param graph The graph.
 * @param flow The induced flows.
 * @param where The resulting partition assignment of each vertex (0 and 1 are
 * partitions, and 2 is a the vertex separator).
 */
void par_flow_cutvertex(
    ctrl_t const * ctrl,
    graph_t const * graph,
    wgt_t const * flow,
    pid_t * where);




#endif
