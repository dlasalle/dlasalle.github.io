/**
 * @file coarsen.c
 * @brief Coarsening functions
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013, Regents of the University of Minnesota
 * @version 1
 * @date 2013-05-20
 */




#ifndef MTMETIS_COARSEN_C
#define MTMETIS_COARSEN_C




#include "coarsen.h"
#include "check.h"
#include "contract.h"




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLSORTKV_PREFIX vv
#define DLSORTKV_KEY_T vtx_t
#define DLSORTKV_VAL_T vtx_t
#define DLSORTKV_STATIC
#include "dlsortkv_headers.h"
#undef DLSORTKV_STATIC
#undef DLSORTKV_VAL_T
#undef DLSORTKV_KEY_T
#undef DLSORTKV_PREFIX


#define DLHT_PREFIX vw
#define DLHT_KEY_T vtx_t
#define DLHT_VAL_T wgt_t
#define DLHT_STATIC
#include "dlht_headers.h"
#undef DLHT_STATIC
#undef DLHT_VAL_T
#undef DLHT_KEY_T
#undef DLHT_PREFIX




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


#define DEF_MASK_SIZE (0x1000)
#define CYCLE_MASK_SIZE (0x100000)
static vtx_t const MASK_SIZE = DEF_MASK_SIZE;
static vtx_t const MASK = DEF_MASK_SIZE - 1;
static vtx_t const CYCLE_MASK = CYCLE_MASK_SIZE-1;
static vtx_t const MAX_CYCLE_SIZE = CYCLE_MASK_SIZE >> 1;
static adj_t const MAXDEG2HOP = 3;
static adj_t const MAXSEARCH2HOP = 32;
static vtx_t const DESIRED_VERTEX_SIZE = 4;
static vtx_t const MAX_VERTEX_SIZE = 32;
static wgt_t const REMOTE_PENALTY = 0.75;





/******************************************************************************
* INLINE FUNCTIONS ************************************************************
******************************************************************************/


/**
 * @brief Determine if enough vertices have been aggregated together.
 *
 * @param nvtxs The number of vertices in the graph.
 * @param collapsed The number of vertices that have been collapsed.
 * @param max_agg_rate The minimum ratio of coarse vertices to fine vertices.
 *
 * @return 1 if aggregation should stop.
 */
static inline int __agg_limit_reached(
    vtx_t const nvtxs, 
    vtx_t const collapsed, 
    double const max_agg_rate)
{
  double agg_rate;
  
  agg_rate = (double)(nvtxs - collapsed);
  return (agg_rate < (double)(max_agg_rate*nvtxs));
}


/**
 * @brief Find an index in the hash table corresponding to the key.
 *
 * @param i The key.
 * @param htable The hashtable.
 *
 * @return The index corresponding to the key.
 */
static inline vtx_t __htable_idx(
    vtx_t const i, 
    vtx_t const * const htable)
{
  vtx_t idx,m,j;

  idx = i&CYCLE_MASK;
  m = htable[idx];

  if (m == NULL_VTX || m == i) {
    return idx;
  } else {
    for (j=(idx+1)&CYCLE_MASK;;j=(j+1)&CYCLE_MASK) {
      if (htable[j] == NULL_VTX || htable[j] == i) {
        break;
      }
    }
    return j;
  }
}


/**
 * @brief Match a vertex with itself.
 *
 * @param i The vertex to match with itself.
 * @param cnvtxs The number of coarse vertices.
 * @param myid The id of the calling thread.
 * @param match The calling thread's matching vector.
 * @param cmap The calling thread's coarse vertex map.
 * @param fmap The calling thread's fine vertex map.
 * @param dist The distribution structure of the graph.
 *
 * @return The new number of coarse vertices. 
 */
static inline vtx_t __match_self(
    vtx_t const i, 
    vtx_t const cnvtxs, 
    vtx_t const myid, 
    vtx_t * const match, 
    vtx_t * const cmap, 
    vtx_t * const fmap, 
    graphdist_t const dist)
{
  match[i] = i; 
  fmap[cnvtxs] = i;
  cmap[i] = lvtx_to_gvtx(cnvtxs,myid,dist);

  return cnvtxs+1;
}


/**
 * @brief Add a vertex i to the same cluster as the vertex maxidx.
 *
 * @param i The vertex to add.
 * @param maxidx The vertex who's cluster to join.
 * @param myid The calling thread's id.
 * @param match The matching vector.
 * @param graph The graph.
 *
 * @return The number of vertices collapsed (1 if formed a cluster, 0 if
 * aggreagted with itself). 
 */
static inline vtx_t __cluster(
    vtx_t const i, 
    vtx_t const maxidx,
    tid_t const myid, 
    vtx_t * const * const match, 
    graph_t const * const graph)
{
  vtx_t l, matched;
  tid_t o;
  vtx_t const mynvtxs = graph->mynvtxs[myid];
  if (maxidx == i) {
    /* if we didn't match */
    match[myid][i] = i;
    return 0;
  } else if (maxidx < mynvtxs) {
    /* if I'm matching with something local */
    matched = match[myid][maxidx];
    if (matched == NULL_VTX) {
      match[myid][i] = maxidx;
      match[myid][maxidx] = i;
      return 1;
    } else {
      match[myid][i] = matched;
      match[myid][maxidx] = i;
      return 1;
    }
  } else {
    /* matching with something remote */
    o = gvtx_to_tid(maxidx,graph->dist);
    l = gvtx_to_lvtx(maxidx,graph->dist);
    matched = match[o][l];
    if (matched == NULL_VTX) {
      /* setting up a single match */
      match[myid][i] = maxidx;
      match[o][l] = lvtx_to_gvtx(i,myid,graph->dist);
      return 1;
    } else {
      /* joining a cluster */
      if (matched < graph->mynvtxs[o]) { /* o owns it */
        match[myid][i] = lvtx_to_gvtx(matched,o,graph->dist);
        match[o][l] = lvtx_to_gvtx(i,myid,graph->dist);
      } else if (gvtx_to_tid(matched,graph->dist) == myid) { /* i own it */
        match[myid][i] = gvtx_to_lvtx(matched,graph->dist);
        match[o][l] = lvtx_to_gvtx(i,myid,graph->dist);
      } else { /* third party */
        match[myid][i] = matched;
        match[o][l] = lvtx_to_gvtx(i,myid,graph->dist);
      }
      return 1;
    }
  }
}







/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static vtx_t __cleanup_match(
    graph_t const * const graph,
    vtx_t * const * const gmatch,
    vtx_t * const * const gcmap,
    vtx_t * const fcmap)
{
  vtx_t i, lvtx, gvtx, cnvtxs, maxidx;
  tid_t nbrid;

  tid_t const myid = dlthread_get_id(graph->comm);

  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const * const * const gxadj = (adj_t const * const *)graph->xadj;

  cnvtxs = 0;
  for (i=0;i<mynvtxs;++i) {
    gvtx = lvtx_to_gvtx(i,myid,graph->dist);
    DL_ASSERT(gvtx_to_lvtx(gvtx,graph->dist) == i,"Mismatch local-global " \
        "vertex id");
    maxidx = gmatch[myid][i];
    if (maxidx == NULL_VTX) {
      /* match any unmatched vertices with themselves */
      gmatch[myid][i] = i;
    } else if (maxidx < mynvtxs) {
      if (gmatch[myid][maxidx] != i) {
        gmatch[myid][i] = i;
      }
    } else {
      nbrid = gvtx_to_tid(maxidx,graph->dist);
      lvtx = gvtx_to_lvtx(maxidx,graph->dist);
      if (gmatch[nbrid][lvtx] != gvtx) {
        /* match vertices in broken matches with themselves */
        gmatch[myid][i] = i;
      } else {
        if (MY_CVTX(gvtx,gmatch[myid][i],gxadj[myid][i+1]-gxadj[myid][i],
            gxadj[nbrid][lvtx+1]-gxadj[nbrid][lvtx])) {
          /* use global cmap[i] id */
          gcmap[myid][i] = lvtx_to_gvtx(cnvtxs,myid,graph->dist); 
          fcmap[cnvtxs++] = i;
        }
      }
    }

    if (gmatch[myid][i] < mynvtxs && i <= gmatch[myid][i]) {
      /* use global cmap[i] id */
      gcmap[myid][i] = lvtx_to_gvtx(cnvtxs,myid,graph->dist); 
      fcmap[cnvtxs++] = i;
    }
  }

  dlthread_barrier(graph->comm);
  /* tries to avoid false sharing */
  for (i=mynvtxs;i>0;) {
    --i;
    gvtx = lvtx_to_gvtx(i,myid,graph->dist);
    maxidx = gmatch[myid][i];
    if (maxidx < mynvtxs) {
      nbrid = myid;
      lvtx = maxidx;
    } else {
      nbrid = gvtx_to_tid(maxidx,graph->dist);
      lvtx = gvtx_to_lvtx(maxidx,graph->dist);
    }
    if (i > gmatch[myid][i] || (gmatch[myid][i] >= mynvtxs && \
        !MY_CVTX(gvtx,gmatch[myid][i],gxadj[myid][i+1]-gxadj[myid][i], \
        gxadj[nbrid][lvtx+1]-gxadj[nbrid][lvtx]))) {
      gcmap[myid][i] = gcmap[nbrid][lvtx];
    }
  }

  return cnvtxs;
}


/**
 * @brief Cleanup broken clusters by removing tail vertices on cluster cycles.
 *
 * @param mynvtxs The number of vertices the calling thread owns.
 * @param myid The id of the calling thread.
 * @param match The global match vector.
 * @param cmap The global coarse vertex map.
 * @param fmap The global fine vertex map.
 * @param graph The graph.
 *
 * @return The number of coarse vertices this thread owns.
 */
static vtx_t __cleanup_cluster(
    vtx_t const mynvtxs,
    tid_t const myid,
    vtx_t * const * const match, 
    vtx_t * const * const cmap, 
    vtx_t * const * const fmap, 
    graph_t const * const graph)
{
  vtx_t i, g, maxidx, idx, l, j, gvtx, ncycle, minvtx, mycnvtxs, cnvtxs;
  tid_t o, maxtid;

  vtx_t * vtxs = vtx_init_alloc(NULL_VTX,CYCLE_MASK_SIZE);
  vtx_t * ptxs = vtx_alloc(MAX_CYCLE_SIZE);

  ncycle = 0;
  mycnvtxs = 0;
  for (i=0;i<mynvtxs;++i) {
    DL_ASSERT_EQUALS(ncycle,(vtx_t)0,"%"PF_VTX_T);
    maxidx = match[myid][i];
    if (maxidx == NULL_VTX) { /* if we didn't get matched */
      mycnvtxs = __match_self(i,mycnvtxs,myid,match[myid],cmap[myid],
          fmap[myid],graph->dist);
    } else if (cmap[myid][i] == NULL_VTX) {
      /* check if the vertex is part of a cycle --
       * if it is, and I own the minimum lvtx (ties go to lower tid's) in that 
       * cycle, assign the cmap and the fmap
       */
      minvtx = i;
      maxtid = myid;
      gvtx = lvtx_to_gvtx(i,myid,graph->dist);
      idx = __htable_idx(gvtx,vtxs);
      vtxs[idx] = gvtx;
      ptxs[ncycle++] = idx;
      o = myid;
      do {
        DL_ASSERT(maxidx<max_gvtx(graph),"Invalid maxidx of %"PF_VTX_T"\n",
            maxidx);

        if (maxidx < graph->mynvtxs[o]) {
          g = lvtx_to_gvtx(maxidx,o,graph->dist);
        } else {
          o = gvtx_to_tid(maxidx,graph->dist); 
          g = maxidx;
          maxidx = gvtx_to_lvtx(maxidx,graph->dist);
        }

        DL_ASSERT_EQUALS(gvtx_to_lvtx(g,graph->dist),maxidx,"%"PF_VTX_T);
        DL_ASSERT_EQUALS(gvtx_to_tid(g,graph->dist),o,"%"PF_VTX_T);
        DL_ASSERT_EQUALS(lvtx_to_gvtx(maxidx,o,graph->dist),g,"%"PF_VTX_T);

        idx = __htable_idx(g,vtxs);
        if (vtxs[idx] == NULL_VTX) {
          /* no cycle yet -- will stay in do-while */
          if (maxidx < minvtx || (maxidx == minvtx && o > maxtid)) {
            /* set as owner of the cycle */
            minvtx = maxidx;
            maxtid = o;
          }
          /* record vertex */
          vtxs[idx] = g;
          ptxs[ncycle++] = idx;
          /* jump to next */
          maxidx = match[o][maxidx];
          DL_ASSERT(maxidx < graph->mynvtxs[o] ||
              maxidx > graph->dist.mask,"Invalid match of %"PF_VTX_T"/%" \
              PF_VTX_T" for thread with only %"PF_VTX_T" vertices\n",maxidx, \
              graph->dist.mask,graph->mynvtxs[o]);
        } else {
          /* found a cycle -- will exit do-while */
          if (g == gvtx) {
            /* found the cycle gvtx is a part of */
            if (maxtid == myid) {
              fmap[myid][mycnvtxs] = i;
              cnvtxs = lvtx_to_gvtx(mycnvtxs,myid,graph->dist);
              for (j=0;j<ncycle;++j) {
                o = gvtx_to_tid(vtxs[ptxs[j]],graph->dist);
                l = gvtx_to_lvtx(vtxs[ptxs[j]],graph->dist);
                DL_ASSERT_EQUALS(cmap[o][l],NULL_VTX,"%"PF_VTX_T);
                cmap[o][l] = cnvtxs;
              }
              ++mycnvtxs;
            }
            break;
          } else {
            /* gvtx is not part of a cycle */
            mycnvtxs = __match_self(i,mycnvtxs,myid,match[myid],cmap[myid],
                fmap[myid],graph->dist);
            break;
          }
        }
        if (ncycle >= MAX_CYCLE_SIZE) {
          /* maximum cycle size reached */
          mycnvtxs = __match_self(i,mycnvtxs,myid,match[myid],cmap[myid],
              fmap[myid],graph->dist);
          break;
        }
      } while (1);
      /* now I need to cleanup my garbage */
      if (ncycle < MAX_CYCLE_SIZE) {
        while (ncycle > 0) {
          vtxs[ptxs[--ncycle]] = NULL_VTX;
        }
      } else {
        vtx_set(vtxs,NULL_VTX,CYCLE_MASK_SIZE);
        ncycle = 0;
      }
    }
  }

  dl_free(vtxs);
  dl_free(ptxs);

  return mycnvtxs;
}





static vtx_t __coarsen_match_RM(
    ctrl_t * const ctrl, 
    graph_t const * const graph,
    vtx_t * const * const gmatch, 
    vtx_t * const fcmap) 
{
  vtx_t i, pi, k, maxidx, last_unmatched, seed,nbrid,lvtx,gvtx,cnvtxs;
  adj_t j;
  vtx_t * match, * perm;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  vtx_t ** const gcmap = graph->cmap;

  wgt_t const maxvwgt = ctrl->maxvwgt;

  /* local graph pointers */
  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const * const xadj = gxadj[myid];
  wgt_t const * const vwgt = gvwgt[myid];
  vtx_t const * const adjncy = gadjncy[myid];

  DL_ASSERT_EQUALS(graph->dist.nthreads, \
      (tid_t)dlthread_get_nthreads(ctrl->comm),"%"PF_TID_T);

  if (myid == 0) {
    dl_start_timer(&(ctrl->timers.matching));
  }

  perm = vtx_alloc(mynvtxs);

  k = 0;
  seed = ctrl->seed + myid;

  vtx_incset(perm,0,1,mynvtxs);
  vtx_pseudo_shuffle_r(perm,mynvtxs/8,mynvtxs,&seed);

  last_unmatched=0; /* this is private but ... */

  match = gmatch[myid];

  for (pi=0; pi<mynvtxs;++pi) {
    /* request my matches */
    i = perm[pi];

    if (match[i] == NULL_VTX) { /* Unmatched */
      gvtx = lvtx_to_gvtx(i,myid,graph->dist);
      maxidx = gvtx;
      
      if (vwgt[i] < maxvwgt) {
        /* Deal with island vertices. Match locally */
        if (xadj[i+1] == xadj[i]) { 
          last_unmatched = dl_max(pi, last_unmatched)+1;
          for (; last_unmatched<mynvtxs; last_unmatched++) {
            k = perm[last_unmatched];
            if (match[k] == NULL_VTX) {
              maxidx = lvtx_to_gvtx(k,myid,graph->dist);
              break;
            }
          }
        } else {
          /* Find a heavy-edge matching, subject to maxvwgt constraints */
          for (j=xadj[i]; j<xadj[i+1]; ++j) {
            k = adjncy[j];
            if (k < mynvtxs) {
              lvtx = k;
              nbrid = myid;
            } else {
              nbrid = gvtx_to_tid(k,graph->dist);
              lvtx = gvtx_to_lvtx(k,graph->dist);
            }
            if (vwgt[i]+gvwgt[nbrid][lvtx] <= maxvwgt && 
                (gmatch[nbrid][lvtx] == NULL_VTX)) {
              if (nbrid == myid) {
                /* I own it, lets go with it */
                maxidx = k;
                break;
              } else if (maxidx == gvtx) {
                maxidx = k;
              }
            }
          }
        }
      }
      if (maxidx < mynvtxs) {
        match[i] = maxidx;
        match[maxidx] = i;
      } else {
        nbrid = gvtx_to_tid(maxidx,graph->dist);
        lvtx = gvtx_to_lvtx(maxidx,graph->dist);
        if (gvtx < maxidx) {
          match[i] = maxidx;
          gmatch[nbrid][lvtx] = gvtx;
        } else if (gvtx > maxidx) {
          gmatch[nbrid][lvtx] = gvtx;
          match[i] = maxidx;
        }
      }
    }
  } /* outer match loop */
  dlthread_barrier(ctrl->comm);

  gcmap[myid] = perm;  /* re-use perm */

  cnvtxs = __cleanup_match(graph,gmatch,gcmap,fcmap);

  dlthread_barrier(ctrl->comm);
  if (myid == 0) {
    dl_stop_timer(&(ctrl->timers.matching));
  }

  return cnvtxs;
}


/**
* @brief Match the vertices in a graph using the SHEM coarsening scheme in
*   parallel and create a coarse graph and store it in graph->coarse
*
* @param ctrl THe control structure to use
* @param graph The fine graph to coarsen
* @param nthreads The number of vertices to use
*
* @return The number of vertices in the coarse graph 
*/
static vtx_t __coarsen_match_SHEM(
    ctrl_t * const ctrl, 
    graph_t const * const graph,
    vtx_t * const * const gmatch, 
    vtx_t * const fcmap) 
{
  unsigned int seed;
  vtx_t cnvtxs, i, pi, k, maxidx, maxwgt, last_unmatched, \
      lvtx, gvtx, lcl;
  wgt_t mywgt;
  tid_t nbrid;
  adj_t j, avgdegree;
  vtx_t * perm, * tperm, * degrees;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  vtx_t ** const gcmap = graph->cmap;

  wgt_t const maxvwgt  = ctrl->maxvwgt;

  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;
  wgt_t const * const * const gadjwgt = (wgt_t const **)graph->adjwgt;

  /* thread local graph pointers */
  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const * const xadj = gxadj[myid];
  vtx_t const * const adjncy = gadjncy[myid];
  wgt_t const * const vwgt = gvwgt[myid];
  wgt_t const * const adjwgt = gadjwgt[myid];
  vtx_t * const match = gmatch[myid];

  if (myid == 0) {
    dl_start_timer(&(ctrl->timers.matching));
  }

  /* matching vectors */

  k = 0;
  cnvtxs = 0;

  /* calculate the degree of each vertex, truncating to the average */
  if (mynvtxs > 0) {
    perm = vtx_alloc(mynvtxs);
    tperm = vtx_alloc(mynvtxs);
    degrees = vtx_alloc(mynvtxs);

    avgdegree = (0.7*(graph->mynedges[myid]/mynvtxs))+1;
    for (i=0;i<mynvtxs;++i) {
      j = xadj[i+1] - xadj[i];
      degrees[i] = (j > avgdegree ? avgdegree : j);
    }

    /* create a pre-permutation array */
    vtx_incset(tperm,0,1,mynvtxs);

    /* shuffle permutation array and degrees the same */
    seed = ctrl->seed + myid;
    vtx_pseudo_shuffle_r(tperm,mynvtxs/8,mynvtxs,&seed);
    seed = ctrl->seed + myid;
    vtx_pseudo_shuffle_r(degrees,mynvtxs/8,mynvtxs,&seed);

    DL_ASSERT_EQUALS(degrees[0], \
        dl_min(avgdegree,xadj[tperm[0]+1]-xadj[tperm[0]]),"%"PF_ADJ_T);

    /* create permutation */
    vv_countingsort_kv(degrees,tperm,0,avgdegree,mynvtxs,perm,NULL);

    DL_ASSERT(mynvtxs < 2 || dl_min(xadj[perm[0]+1] - xadj[perm[0]],avgdegree) \
        <= xadj[perm[mynvtxs-1]+1] - xadj[perm[mynvtxs-1]],"Sorting failed\n");

    /* free scratch space */
    dl_free(tperm);
    dl_free(degrees);
  } else {
    perm = NULL;
  }

  last_unmatched=0; 

  for (pi=0; pi<mynvtxs;++pi) {
    /* request my matches */
    i = perm[pi];
      
    if (match[i] == NULL_VTX) {  /* Unmatched */
      mywgt = vwgt[i];
      maxwgt = 0;
      gvtx = lvtx_to_gvtx(i,myid,graph->dist);
      maxidx = gvtx;
      lcl = 0;

      if (mywgt < maxvwgt) {
        /* Deal with island vertices. Find a non-island and match it with. 
           The matching ignores ctrl->maxvwgt requirements */
        if (xadj[i+1] == xadj[i]) { 
          last_unmatched = dl_max(pi, last_unmatched)+1;
          for (; last_unmatched<mynvtxs; last_unmatched++) {
            k = perm[last_unmatched];
            if (match[k] == NULL_VTX) {
              maxidx = k;
              break;
            }
          }
        } else {
          /* Find a heavy-edge matching, subject to maxvwgt constraints */
          for (j=xadj[i]; j<xadj[i+1]; ++j) {
            k = adjncy[j];
            if (k < mynvtxs) {
              lvtx = k;
              nbrid = myid;
              lcl = adjwgt[j] * LWGT;
            } else {
              nbrid = gvtx_to_tid(k,graph->dist);
              lvtx = gvtx_to_lvtx(k,graph->dist);
              lcl = adjwgt[j];
            }
            if (maxwgt < lcl && mywgt+gvwgt[nbrid][lvtx] <= maxvwgt && \
                gmatch[nbrid][lvtx] == NULL_VTX) {
              maxidx = k;
              maxwgt = lcl;
            }
          }
        }
      }
      /* handle unmatched vertices later */
      if (maxidx < mynvtxs) {
        match[i] = maxidx;
        match[maxidx] = i;
      } else {
        nbrid = gvtx_to_tid(maxidx,graph->dist);
        lvtx = gvtx_to_lvtx(maxidx,graph->dist);
        if (gvtx < maxidx) {
          match[i] = maxidx;
          gmatch[nbrid][lvtx] = gvtx;
        } else if (gvtx > maxidx) {
          gmatch[nbrid][lvtx] = gvtx;
          match[i] = maxidx;
        }
      }
    }
  } /* outer match loop */
  dlthread_barrier(ctrl->comm);

  gcmap[myid] = perm;

  cnvtxs = __cleanup_match(graph,gmatch,gcmap,fcmap);

  dlthread_barrier(ctrl->comm);
  if (myid == 0) {
    dl_stop_timer(&(ctrl->timers.matching));
  }

  return cnvtxs;
}


static vtx_t __coarsen_cluster_FC(
    ctrl_t * const ctrl, 
    graph_t const * const graph,
    vtx_t * const * const gmatch, 
    vtx_t * const fcmap) 
{
  unsigned int seed;
  vtx_t v, i, k, l, cl, cg, maxidx, mycnvtxs, maxdeg, last_unmatched, \
      collapsed;
  tid_t o,co;
  adj_t j, astart,aend;
  wgt_t cwgt, twgt, nvwgt, maxwgt;
  wgt_t ** cvwgt;
  vtx_t ** gfcmap;

  vw_ht_t * conn;

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  /* set up graph stuff */
  vtx_t const nvtxs = graph->nvtxs;
  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const * const * const gxadj = (adj_t const * const *)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const * const *)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const * const *)graph->vwgt;
  wgt_t const * const * const gadjwgt = (wgt_t const * const *)graph->adjwgt;

  adj_t const * myxadj = gxadj[myid];
  vtx_t const * myadjncy = gadjncy[myid];
  wgt_t const * myadjwgt = gadjwgt[myid];

  vtx_t ** const gcmap = graph->cmap;

  wgt_t const maxvwgt = ctrl->maxvwgt;

  vtx_t * perm = vtx_alloc(nvtxs);

  /* do the real work */
  vtx_set(gmatch[myid],NULL_VTX,mynvtxs);

  /* store total degree of coarse vertices */
  cvwgt = dlthread_get_shmem((sizeof(vtx_t*)*nthreads) + \
      (sizeof(wgt_t*)*nthreads),ctrl->comm);
  gfcmap = (vtx_t**)(cvwgt+nthreads);

  cvwgt[myid] = wgt_alloc(mynvtxs);
  gfcmap[myid] = fcmap;
  gcmap[myid] = vtx_alloc(mynvtxs);

  seed = ctrl->seed+myid;

  dlthread_barrier(ctrl->comm);

  /* determine maximum degree */
  maxdeg = 0;
  for (v=0;v<mynvtxs;++v) {
    if (myxadj[v+1] - myxadj[v] > maxdeg) {
      maxdeg = myxadj[v+1] - myxadj[v];
    }
  }

  conn = vw_ht_create(maxdeg,maxdeg/4);

  last_unmatched=0; /* this is private but ... */
  mycnvtxs = 0;
  collapsed = 0;

  vtx_incset(perm,0,1,mynvtxs);
  vtx_shuffle_r(perm,mynvtxs,&seed);

  for (v=0;v<mynvtxs;++v) {
    if (__agg_limit_reached(mynvtxs,collapsed,0.7)) {
      break;
    }
    i = perm[v];
    if (gmatch[myid][i] == NULL_VTX) {
      maxidx = i;
      maxwgt = 0;
      nvwgt = graph->tvwgt;
      astart = myxadj[i];
      aend = myxadj[i+1];
      if (astart == aend) {
        last_unmatched = dl_max(v, last_unmatched)+1;
        for (; last_unmatched<mynvtxs; last_unmatched++) {
          k = perm[last_unmatched];
          if (gmatch[myid][k] == NULL_VTX) {
            maxidx = k;
            break;
          }
        }
      } else if (astart == aend+1) {
        /* if we only have one option, always match it. Brandes et al. '08
         * "On Modularity", showed that 1-degree vertices should never be in
         * their own cluster. */
        maxidx = myadjncy[astart];
      } else {
        /* hopefully for many graphs this will fit in cache */
        for (j=astart;j<aend;++j) {
          k = myadjncy[j];
          if (k < mynvtxs) {
            o = myid;
            l = k;
          } else {
            o = gvtx_to_tid(k,graph->dist);
            l = gvtx_to_lvtx(k,graph->dist);
          }
          if (gmatch[o][l] != NULL_VTX) {
            cg = gcmap[o][l];
            vw_ht_add(cg,myadjwgt[j],conn);
          }
        }
        for (j=astart;j<aend;++j) {
          k = myadjncy[j];
          if (k < mynvtxs) {
            o = myid;
            l = k;
          } else {
            o = gvtx_to_tid(k,graph->dist);
            l = gvtx_to_lvtx(k,graph->dist);
          }
          if (gmatch[o][l] == NULL_VTX) {
            cwgt = myadjwgt[j];
            twgt = gvwgt[o][l];
          } else {
            cg = gcmap[o][l];
            cl = gvtx_to_lvtx(cg,graph->dist);
            co = gvtx_to_tid(cg,graph->dist);
            twgt = cvwgt[co][cl];
            cwgt = vw_ht_get(cg,conn);
          }
          cwgt = (double)ceil(cwgt / sqrt(twgt));
          if (twgt + gvwgt[myid][i] < maxvwgt && (cwgt > maxwgt || \
              (cwgt == maxwgt && twgt < nvwgt))) {
            maxidx = k;
            maxwgt = cwgt;
            nvwgt = twgt;
          }
        }
        /* clear the conn map */
        vw_ht_clear_chains(conn);
        for (j=astart;j<aend;++j) {
          k = myadjncy[j];
          if (k < mynvtxs) {
            o = myid;
            l = k;
          } else {
            o = gvtx_to_tid(k,graph->dist);
            l = gvtx_to_lvtx(k,graph->dist);
          }
          if (gmatch[o][l] != NULL_VTX) {
            vw_ht_clear_slot(gcmap[o][l],conn);
          }
        }
      }
      /* match maker make me a match */
      if (maxidx == i) {
        cvwgt[myid][mycnvtxs] = gvwgt[myid][i];
        gcmap[myid][i] = lvtx_to_gvtx(mycnvtxs,myid,graph->dist);
        DL_ASSERT(gcmap[myid][i]>=graph->dist.offset,"Generated global "
            "coarse vertex number is smaller than graph offset (gvtx = %"
            PF_VTX_T", offset = %"PF_VTX_T"\n",v,graph->dist.offset);
        ++mycnvtxs;
      } else {
        if (maxidx < mynvtxs) {
          o = myid;
          l = maxidx;
        } else {
          o = gvtx_to_tid(maxidx,graph->dist);
          l = gvtx_to_lvtx(maxidx,graph->dist);
        }
        if (gmatch[o][l] == NULL_VTX) { /* duh */
          cg = lvtx_to_gvtx(mycnvtxs,myid,graph->dist);
          cl = gvtx_to_lvtx(cg,graph->dist);
          co = gvtx_to_tid(cg,graph->dist);
          cvwgt[co][cl] = nvwgt + gvwgt[myid][i];
          DL_ASSERT(cg>=graph->dist.offset,"Generated global coarse vertex "
              "number is smaller than graph offset (gvtx = %"PF_VTX_T
              ", offset = %"PF_VTX_T"\n",cg,graph->dist.offset);
          gcmap[myid][i] = gcmap[o][l] = cg;
          ++mycnvtxs;
        } else {
          cg = gcmap[myid][i] = gcmap[o][l];
          cl = gvtx_to_lvtx(cg,graph->dist);
          co = gvtx_to_tid(cg,graph->dist);
          cvwgt[co][cl] += gvwgt[myid][i];
        }
      }
      collapsed += __cluster(i,maxidx,myid,gmatch,graph);
    }
  }
  vw_ht_free(conn);

  dlthread_barrier(ctrl->comm);

  /* reset the cmap so I perform cycle clean up */
  vtx_set(gcmap[myid],NULL_VTX,mynvtxs);

  dl_free(perm);

  dlthread_barrier(ctrl->comm);

  mycnvtxs = __cleanup_cluster(mynvtxs,myid,gmatch,gcmap,gfcmap,graph);

  /* implicit barrier */ 
  dl_free(cvwgt[myid]);
  dlthread_free_shmem(cvwgt,ctrl->comm);

  if (myid == 0) {
    ++ctrl->seed;
  }

  return mycnvtxs;
}



/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


graph_t * par_coarsen_graph(
    ctrl_t * ctrl,
    graph_t * graph)
{
  vtx_t i, cnvtxs;
  wgt_t base;
  int neqewgts;
  vtx_t ** gmatch;

  if (graph->nvtxs <= 1) {
    return graph;
  }

  DL_ASSERT_EQUALS((size_t)ctrl->comm,(size_t)graph->comm,"%zu");

  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);
  tid_t const myid = dlthread_get_id(ctrl->comm);

  vtx_t * const fcmap = vtx_alloc(graph->mynvtxs[myid]);
  vtx_t * const match = vtx_init_alloc(NULL_VTX,graph->mynvtxs[myid]);

  /* ward off compiler warnings */
  cnvtxs = 0;

  if (myid == 0) { 
    dl_start_timer(&ctrl->timers.coarsening);
  }

  DL_ASSERT(check_graph(graph),"Invalid graph");

  neqewgts=0;

  gmatch = dlthread_get_shmem(sizeof(vtx_t*)*nthreads,ctrl->comm);

  gmatch[myid] = match;

  if (ctrl->ctype != MTMETIS_CTYPE_RM) {
    if (graph->mynvtxs[myid] > 0) {
      base = graph->adjwgt[myid][0]; 
      for (i=1;i<graph->xadj[myid][graph->mynvtxs[myid]];++i) {
        if (graph->adjwgt[myid][i] != base) {
          neqewgts = 1;
          break;
        }
      }
    }
  }

  /* implicit barrier */
  neqewgts = int_dlthread_sumreduce(neqewgts,ctrl->comm);

  /* set the maximum allowed coarsest vertex weight */
  ctrl->maxvwgt = 1.5*graph->tvwgt/ctrl->coarsen_to;

  do {
    par_vprintf(ctrl->verbosity,MTMETIS_VERBOSITY_HIGH,"Graph{%zu} has %" \
        PF_VTX_T" vertices, %"PF_ADJ_T" edges, and %"PF_WGT_T" exposed edge " \
        "weight.\n",graph->level,graph->nvtxs,graph->nedges,graph->tadjwgt);

    /* allocate memory for cmap, if it has not already been done due to
       multiple cuts */
    if (myid == 0) {
      if (graph->cmap == NULL) {
        /* threads need to allocate their own chunk inside the matching 
         * functions */
        graph->cmap = r_vtx_alloc(nthreads);
      }
    }
    dlthread_barrier(ctrl->comm);

    /* coarsening scheme selection used to go here */
    switch(ctrl->ctype) {
      case MTMETIS_CTYPE_RM:
        cnvtxs = __coarsen_match_RM(ctrl,graph,gmatch,fcmap);
        break;
      case MTMETIS_CTYPE_SHEM:
        if (!neqewgts) {
          cnvtxs = __coarsen_match_RM(ctrl,graph,gmatch,fcmap);
        } else {
          cnvtxs = __coarsen_match_SHEM(ctrl,graph,gmatch,fcmap);
        }
        break;
      case MTMETIS_CTYPE_FC:
        if (!neqewgts) {
          cnvtxs = __coarsen_match_RM(ctrl,graph,gmatch,fcmap);
        } else {
          cnvtxs = __coarsen_cluster_FC(ctrl,graph,gmatch,fcmap);
        }
        break;
      default:
        dl_error("Unknown ctype: %d\n",ctrl->ctype);
        break;
    }

    par_contract_graph(ctrl,graph,cnvtxs,(vtx_t const **)gmatch,fcmap);

    vtx_set(match,NULL_VTX,cnvtxs);

    graph = graph->coarser;

    neqewgts = 1;
  } while (graph->nvtxs > ctrl->coarsen_to && \
           graph->nvtxs < PAR_COARSEN_FRACTION*graph->finer->nvtxs && \
           graph->nedges > graph->nvtxs/2);

  par_vprintf(ctrl->verbosity,MTMETIS_VERBOSITY_HIGH,"Graph{%zu} has %" \
      PF_VTX_T" vertices, %"PF_ADJ_T" edges, and %"PF_WGT_T" exposed edge " \
      "weight.\n",graph->level,graph->nvtxs,graph->nedges,graph->tadjwgt);

  dl_free(fcmap);
  dl_free(match);

  dlthread_free_shmem(gmatch,ctrl->comm);

  DL_ASSERT(check_graph(graph),"Invalid graph");

  if (myid == 0) {
    dl_stop_timer(&ctrl->timers.coarsening);
  }

  return graph;
}




#endif
