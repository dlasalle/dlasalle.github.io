/**
 * @file contract.c
 * @brief Functions for performing contraction
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2015-01-21
 */




#ifndef MTMETIS_CONTACT_C
#define MTMETIS_CONTACT_C




#include "contract.h"
#include "check.h"




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


#define DEF_MASK_SIZE (0x1000)
static vtx_t const MASK_SIZE = DEF_MASK_SIZE;
#define DEF_MASK_MIN_SIZE (0x10)
static vtx_t const MASK_MIN_SIZE = DEF_MASK_MIN_SIZE;
static vtx_t const MASK_MAX_SIZE = DEF_MASK_SIZE >> 2; 
static vtx_t const MASK_MIN_VTXS = DEF_MASK_SIZE << 3;




/******************************************************************************
* INLINE FUNCTIONS ************************************************************
******************************************************************************/


/**
 * @brief Reverse the bits of a key for a given mask. Use for hashing into a
 * secondary hash table to prevent collisions.
 *
 * @param n The key to reverse.
 * @param mask The mask of the bits to be reversed.
 *
 * @return The reversed key.
 */
static inline vtx_t __reverse(
    vtx_t const n, 
    vtx_t const mask)
{
  vtx_t r = vtx_reversebits(n);
  int const mb = vtx_downlog2(mask);
  int const vs = sizeof(vtx_t)*8;
  if (vs >= 2*mb) {
    return (r >> (vs - (2*mb))) & mask;
  } else {
    return r >> (vs - mb);
  }
}


/**
 * @brief Internal function for collapsing edges together using a double-hash
 * table.
 *
 * @param mask The bit mask to use for hashing.
 * @param c The local coarse vertex edges are being collapsed for.
 * @param cg The global coarse vertex edges are being collapsed for.
 * @param k The coarse neighbor of the edge.
 * @param ewgt The weight of the edge.
 * @param cadjncy The coarse adjacency list.
 * @param cadjwgt The coarse edge weight.
 * @param htable The primary hash table.
 * @param htable2 The secondary hash table (for reverse hashing).
 * @param cnedges The number of coarse edges genrated so far.
 *
 * @return The new number of coarse edges.
 */
static inline adj_t __handle_edge_masked(
    vtx_t const mask,
    vtx_t const mask2,
    vtx_t const c, 
    vtx_t const cg,
    vtx_t const k,
    wgt_t const ewgt,
    vtx_t * cadjncy, 
    wgt_t * cadjwgt,
    adj_t * htable,
    adj_t * htable2, 
    adj_t cnedges)
{
  vtx_t l;
  adj_t i;

  if (k == c || k == cg) {
    /* internal edge */
  } else {
    /* external edge */
    l = k&mask;
    i = htable[l];
    if (i == NULL_ADJ) {
      /* new edge */
      cadjncy[cnedges] = k;
      cadjwgt[cnedges] = ewgt;
      htable[l] = cnedges++; 
    } else if (k == cadjncy[i]) {
      /* duplicate edge */
      cadjwgt[i] += ewgt;
    } else {
      l = k % mask2;
      for (;;l=((l+1)%mask2)) {
        i = htable2[l];
        if (i == NULL_ADJ) {
          /* new edge */
          cadjncy[cnedges] = k;
          cadjwgt[cnedges] = ewgt;
          htable2[l] = cnedges++; 
          break;
        } else if (k == cadjncy[i]) {
          /* duplicate edge */
          cadjwgt[i] += ewgt;
          break;
        } 
      }
    }
  }
  return cnedges;
}




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static void __adjust_cmap(
    vtx_t * const cmap, 
    vtx_t const mynvtxs, 
    graphdist_t const olddist, 
    graphdist_t const newdist)
{
  vtx_t i,k;
  tid_t o;

  for (i=0;i<mynvtxs;++i) {
    if (cmap[i] >= olddist.offset) { /* remote vertex */
      k = gvtx_to_lvtx(cmap[i],olddist);
      o = gvtx_to_tid(cmap[i],olddist);
      cmap[i] = lvtx_to_gvtx(k,o,newdist);
    }
  }
}


/**
 * @brief Perform contraction using a single hash table, performing a linear
 * scan on the edge list in the case of a collsion.
 *
 * @param ctrl The control structure.
 * @param graph The graph structure.
 * @param mycnvtxs The number of coarse vertices owned by this thread.
 * @param gmatch The global match array.
 * @param fcmap The first fine vertex for each coarse vertex.
 */
static void __par_contract_CLS(
    ctrl_t * const ctrl, 
    graph_t * const graph, 
    vtx_t const mycnvtxs, 
    vtx_t const * const * const gmatch, 
    vtx_t const * const fcmap)
{
  adj_t cnedges, l, maxdeg, j, i, jj;
  tid_t o, t;
  vtx_t v, c, cg, mask, k;
  adj_t * htable;
  graph_t * cgraph;
  graphdist_t dist;

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  /* make accessing my old graph easy */
  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const * const * const gxadj = (adj_t const * const *)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const * const *)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const * const *)graph->vwgt;
  wgt_t const * const * const gadjwgt = (wgt_t const * const *)graph->adjwgt;

  vtx_t const * const * const gcmap = (vtx_t const **)graph->cmap;

  if (myid == 0) {
    dl_start_timer(&(ctrl->timers.contraction));
  }

  cgraph = par_graph_setup_coarse(graph,mycnvtxs);

  dist = cgraph->dist;

  __adjust_cmap(graph->cmap[myid],mynvtxs,graph->dist,dist);

  /* count possible edges */
  cnedges = 0;
  maxdeg = 0;
  for (c=0;c<mycnvtxs;++c) {
    v = fcmap[c];
    o = myid;
    l = 0;
    do {
      l += gxadj[o][v+1] - gxadj[o][v];
      v = gmatch[o][v];
      if (v >= graph->mynvtxs[o]) {
        o = gvtx_to_tid(v,graph->dist);
        v = gvtx_to_lvtx(v,graph->dist);
      }
    } while (!(o == myid && v == fcmap[c]));
    dl_storemax(maxdeg,l);
    cnedges += l;
  }

  adj_t * const mycxadj = cgraph->xadj[myid];
  vtx_t * const mycadjncy = cgraph->adjncy[myid] = vtx_alloc(cnedges);
  wgt_t * const mycvwgt = cgraph->vwgt[myid];
  wgt_t * const mycadjwgt = cgraph->adjwgt[myid] = wgt_alloc(cnedges);

  htable = NULL;

  /* set up edge hash table */
  mask = MASK_SIZE;

  /* this could be problematic regarding max degree */
  while (maxdeg > (mask >> 3) && graph->nvtxs > mask) {
    dprintf("[%"PF_TID_T"] Bumping up mask size from %"PF_VTX_T" to %"PF_VTX_T
        "\n",myid,mask,(mask << 1));
    mask <<=1;
  }
  htable = adj_init_alloc(NULL_ADJ,mask);

  --mask;

  dprintf("[%"PF_TID_T"] Using a mask of %"PF_VTX_T" (%lX) for %"PF_VTX_T
      " coarse vertices\n",myid,mask,(long unsigned int)mask,mycnvtxs);

  cnedges = 0;
  mycxadj[0] = 0;

  dlthread_barrier(ctrl->comm);

  /* set max degree for the coarse graph */
  for (c=0;c<mycnvtxs;++c) {
    cg = lvtx_to_gvtx(c,myid,dist);
    /* initialize the coarse vertex */
    mycvwgt[c] = 0;

    v = fcmap[c];
    o = myid;
    DL_ASSERT_EQUALS(myid,gvtx_to_tid(lvtx_to_gvtx(v,myid,graph->dist),
        graph->dist),"%"PF_TID_T);
    do { 
      DL_ASSERT_EQUALS(c,gvtx_to_lvtx(gcmap[o][v],dist),"%"PF_VTX_T);

      /* transfer over vertex stuff from v and u */
      mycvwgt[c] += gvwgt[o][v];

      for (j=gxadj[o][v];j<gxadj[o][v+1];++j) {
        k = gadjncy[o][j];
        if (k < graph->mynvtxs[o]) {
          t = o;
        } else {
          t = gvtx_to_tid(k,graph->dist);
          k = gvtx_to_lvtx(k,graph->dist);
        }
        k = gcmap[t][k];
        if (gvtx_to_tid(k,dist) == myid) {
          k = gvtx_to_lvtx(k,dist);
        }
        if (k == c || k == cg) {
          /* internal edge */
        } else {
          /* external edge */
          l = k&mask;
          i = htable[l];
          if (i == NULL_ADJ) {
            /* new edge */
            mycadjncy[cnedges] = k;
            mycadjwgt[cnedges] = gadjwgt[o][j];
            htable[l] = cnedges++; 
          } else if (k == mycadjncy[i]) {
            /* duplicate edge */
            mycadjwgt[i] += gadjwgt[o][j];
          } else {
            for (jj=mycxadj[c];jj<cnedges;++jj) {
              if (mycadjncy[jj] == k) {
                mycadjwgt[jj] += gadjwgt[o][j];
                break;
              }
            }
            if (jj == cnedges) {
              mycadjncy[cnedges] = k;
              mycadjwgt[cnedges++] = gadjwgt[o][j];
            }
          }
        }
      }

      v = gmatch[o][v];
      if (v >= graph->mynvtxs[o]) {
        o = gvtx_to_tid(v,graph->dist);
        v = gvtx_to_lvtx(v,graph->dist);
      }
    } while (!(myid == o && v == fcmap[c]));

    /* clear the htable */
    for (j = cnedges;j > mycxadj[c];) {
      --j;
      k = mycadjncy[j];
      l = (k&mask);
      htable[l] = NULL_ADJ;
    }

    mycxadj[c+1] = cnedges;
  }

  dl_free(htable);

  cgraph->mynedges[myid] = cnedges;

  //graph_readjust_memory(cgraph,adjsize);

  dlthread_barrier(ctrl->comm);
  if (myid == 0) {
    cgraph->nedges = adj_sum(cgraph->mynedges,nthreads);
  }

  par_graph_setup_twgts(cgraph);
  
  if (myid == 0) {
    dl_stop_timer(&(ctrl->timers.contraction));
  }

  DL_ASSERT(check_graph(cgraph) == 1, "Bad graph generated in coarsening\n");
}


/**
 * @brief Perform contraction using a single hash table, performing linear
 * probing on collisions.
 *
 * @param ctrl The control structure.
 * @param graph The graph structure.
 * @param mycnvtxs The number of coarse vertices owned by this thread.
 * @param gmatch The global match array.
 * @param fcmap The first fine vertex for each coarse vertex.
 */
static void __par_contract_CLP(
    ctrl_t * const ctrl, 
    graph_t * const graph, 
    vtx_t const mycnvtxs, 
    vtx_t const * const * const gmatch, 
    vtx_t const * const fcmap)
{
  adj_t cnedges, l, maxdeg, j, i;
  tid_t o, t;
  vtx_t v, c, cg, mask, k;
  adj_t * htable;
  graph_t * cgraph;
  graphdist_t dist;

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  /* make accessing my old graph easy */
  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const * const * const gxadj = (adj_t const * const *)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const * const *)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const * const *)graph->vwgt;
  wgt_t const * const * const gadjwgt = (wgt_t const * const *)graph->adjwgt;

  vtx_t const * const * const gcmap = (vtx_t const **)graph->cmap;

  if (myid == 0) {
    dl_start_timer(&(ctrl->timers.contraction));
  }

  cgraph = par_graph_setup_coarse(graph,mycnvtxs);

  dist = cgraph->dist;

  __adjust_cmap(graph->cmap[myid],mynvtxs,graph->dist,dist);

  /* count possible edges */
  cnedges = 0;
  maxdeg = 0;
  for (c=0;c<mycnvtxs;++c) {
    v = fcmap[c];
    o = myid;
    l = 0;
    do {
      l += gxadj[o][v+1] - gxadj[o][v];
      v = gmatch[o][v];
      if (v >= graph->mynvtxs[o]) {
        o = gvtx_to_tid(v,graph->dist);
        v = gvtx_to_lvtx(v,graph->dist);
      }
    } while (!(o == myid && v == fcmap[c]));
    dl_storemax(maxdeg,l);
    cnedges += l;
  }

  adj_t * const mycxadj = cgraph->xadj[myid];
  vtx_t * const mycadjncy = cgraph->adjncy[myid] = vtx_alloc(cnedges);
  wgt_t * const mycvwgt = cgraph->vwgt[myid];
  wgt_t * const mycadjwgt = cgraph->adjwgt[myid] = wgt_alloc(cnedges);

  htable = NULL;

  /* set up edge hash table */
  mask = MASK_SIZE;

  /* this could be problematic regarding max degree */
  while (maxdeg > (mask >> 3) && graph->nvtxs > mask) {
    dprintf("[%"PF_TID_T"] Bumping up mask size from %"PF_VTX_T" to %"PF_VTX_T
        "\n",myid,mask,(mask << 1));
    mask <<=1;
  }
  htable = adj_init_alloc(NULL_ADJ,mask);

  --mask;

  dprintf("[%"PF_TID_T"] Using a mask of %"PF_VTX_T" (%lX) for %"PF_VTX_T
      " coarse vertices\n",myid,mask,(long unsigned int)mask,mycnvtxs);

  cnedges = 0;
  mycxadj[0] = 0;

  dlthread_barrier(ctrl->comm);

  /* set max degree for the coarse graph */
  for (c=0;c<mycnvtxs;++c) {
    cg = lvtx_to_gvtx(c,myid,dist);
    /* initialize the coarse vertex */
    mycvwgt[c] = 0;

    v = fcmap[c];
    o = myid;
    DL_ASSERT_EQUALS(myid,gvtx_to_tid(lvtx_to_gvtx(v,myid,graph->dist),
        graph->dist),"%"PF_TID_T);
    do { 
      DL_ASSERT_EQUALS(c,gvtx_to_lvtx(gcmap[o][v],dist),"%"PF_VTX_T);

      /* transfer over vertex stuff from v and u */
      mycvwgt[c] += gvwgt[o][v];

      for (j=gxadj[o][v];j<gxadj[o][v+1];++j) {
        k = gadjncy[o][j];
        if (k < graph->mynvtxs[o]) {
          t = o;
        } else {
          t = gvtx_to_tid(k,graph->dist);
          k = gvtx_to_lvtx(k,graph->dist);
        }
        k = gcmap[t][k];
        if (gvtx_to_tid(k,dist) == myid) {
          k = gvtx_to_lvtx(k,dist);
        }
        if (k == c || k == cg) {
          /* internal edge */
        } else {
          /* external edge */
          l = k&mask;
          i = htable[l];
          if (i == NULL_ADJ) {
            /* new edge */
            mycadjncy[cnedges] = k;
            mycadjwgt[cnedges] = gadjwgt[o][j];
            htable[l] = cnedges++; 
          } else if (k == mycadjncy[i]) {
            /* duplicate edge */
            mycadjwgt[i] += gadjwgt[o][j];
          } else {
            /* linear probe */
            while ((i = htable[l]) != NULL_ADJ) {
              if (k != mycadjncy[i]) {
                mycadjwgt[i] += gadjwgt[o][j];
                break;
              }
              l = (l+1)&mask;
            }
            if (i == NULL_ADJ) {
              mycadjncy[cnedges] = k;
              mycadjwgt[cnedges] = gadjwgt[o][j];
              htable[l] = cnedges++;
            }
          }
        }
      }

      v = gmatch[o][v];
      if (v >= graph->mynvtxs[o]) {
        o = gvtx_to_tid(v,graph->dist);
        v = gvtx_to_lvtx(v,graph->dist);
      }
    } while (!(myid == o && v == fcmap[c]));

    /* clear the htable */
    for (j = cnedges;j > mycxadj[c];) {
      --j;
      k = mycadjncy[j];
      l = (k&mask);
      while ((i = htable[l]) != NULL_ADJ) {
        htable[l] = NULL_ADJ;
        l = (l+1)&mask;
      }
    }

    mycxadj[c+1] = cnedges;
  }

  dl_free(htable);

  cgraph->mynedges[myid] = cnedges;

  //graph_readjust_memory(cgraph,adjsize);

  dlthread_barrier(ctrl->comm);
  if (myid == 0) {
    cgraph->nedges = adj_sum(cgraph->mynedges,nthreads);
  }

  par_graph_setup_twgts(cgraph);
  
  if (myid == 0) {
    dl_stop_timer(&(ctrl->timers.contraction));
  }

  DL_ASSERT(check_graph(cgraph) == 1, "Bad graph generated in coarsening\n");
}




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


void par_contract_graph(
    ctrl_t * const ctrl, 
    graph_t * const graph, 
    vtx_t const mycnvtxs, 
    vtx_t const * const * const gmatch, 
    vtx_t const * const fcmap)
{
  switch (ctrl->contype) {
    case MTMETIS_CONTYPE_CLS:
      __par_contract_CLS(ctrl,graph,mycnvtxs,gmatch,fcmap);
      break;
    case MTMETIS_CONTYPE_CLP:
      __par_contract_CLP(ctrl,graph,mycnvtxs,gmatch,fcmap);
      break;
    default:
      dl_error("Unknown contraction type '%d'\n",ctrl->contype);
  }
}




#endif
