#!/bin/bash

GRAPHS="
auto
fe_ocean
m14b
wave
144
598a
af_shell9
af_shell10
ldoor
fe_tooth
delaunay_n23
333SP
hugebubbles-00000
road_usa
nlpkkt120
thermal2
G3_circuit
M6
"

MTDIR="${HOME}/src/mt-metis"
NRUNS=25
REF="greedy"
LOGDIR="${HOME}/logs"
GRAPHDIR="/scratch/glu22/graphs/dimacs-full"
NTHREADS="8"

BIN="build/Linux-x86_64/bin/mtmetis"
OPTS="-C -n${NRUNS} -T${NTHREADS} -s0 -t -pkway"

mkdir "${LOGDIR}"

pushd "${MTDIR}"
for g in ${GRAPHS}; do
  for r in ${REF}; do
    "${BIN}" ${OPTS} -r${r} "${GRAPHDIR}/${g}.graph" 64 &> "${LOGDIR}/${g}.t${NTHREADS}.r${r}.k64.n25.log"
  done
done
popd
