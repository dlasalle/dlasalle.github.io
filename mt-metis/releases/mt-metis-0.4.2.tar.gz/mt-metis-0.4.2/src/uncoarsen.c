/**
 * @file uncoarsen.c
 * @brief Uncoarsening functions
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2013-05-20
 */





#ifndef MTMETIS_UNCOARSEN_C
#define MTMETIS_UNCOARSEN_C




#include "uncoarsen.h"
#include "kwinfo.h"
#include "vsinfo.h"
#include "kwayrefine.h"
#include "eseprefine.h"
#include "vseprefine.h"
#include "check.h"




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


/**
 * @brief Compute the parameters for performing kway partitioning.
 *
 * @param ctrl The control structure.
 * @param graph The graph.
 * 
 * @return The newly setup kwinfo.
 */
static kwinfo_t * __uncoarsen_partparams_kway(
    ctrl_t * const ctrl,
    graph_t * const graph)
{
  vtx_t other,me,i,k,lvtx,nbrid,na;
  adj_t j, l;
  wgt_t mincut;
  kwnbrinfo_t * nbrinfo; 
  kwnbrinfo_t * myrinfo;
  adjinfo_t * mynbrs;
  vtx_iset_t * bnd;
  kwinfo_t * kwinfo;
  wgt_t * mypwgts;
  wgt_t ** gpwgts;

  pid_t const nparts = ctrl->nparts;

  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;
  wgt_t const * const * const gadjwgt = (wgt_t const **)graph->adjwgt;

  pid_t const * const * const gwhere  = (pid_t const **)graph->where;

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  wgt_t * const pwgts = graph->pwgts;

  vtx_t const mynvtxs = graph->mynvtxs[myid];

  adj_t const * const xadj = gxadj[myid];
  vtx_t const * const adjncy = gadjncy[myid];
  wgt_t const * const vwgt = gvwgt[myid];
  wgt_t const * const adjwgt = gadjwgt[myid];
  pid_t const * const where = gwhere[myid];

  DL_ASSERT(graph->pwgts != NULL,"Non-allocated pwgts");
  DL_ASSERT(graph->where != NULL,"Non-allocated where");

  gpwgts = dlthread_get_shmem(sizeof(wgt_t*)*nthreads,ctrl->comm);

  dlthread_barrier(ctrl->comm);

  mypwgts = gpwgts[myid] = wgt_init_alloc(0,nparts);

  /* reset the size of neighbor infor array */
  kwinfo = kwinfo_create(ctrl,graph);
  nbrinfo = kwinfo->nbrinfo;
  kwinfo->nnbrpool = 0;
  bnd = kwinfo->bnd;

  mincut = 0;
  vtx_iset_clear(bnd);

  /* calculate partition weights */
  for (i=0;i<mynvtxs;++i) {
    mypwgts[where[i]] += vwgt[i];
  }
  dlthread_barrier(ctrl->comm);

  if (myid == 0) {
    /* someday I need to parallelize this via dlthreads */
    for (i=0; i<nparts;++i) {
      k = 0;
      for (j=0; j<nthreads;++j) {
        k += gpwgts[j][i];
      }
      pwgts[i] = k;
    }
  }

  /* clear neighbor info */ 
  memset(nbrinfo,0,sizeof(kwnbrinfo_t)*mynvtxs);

  /* calculate nbrinfo for vertices */
  for (i=0; i<mynvtxs; ++i) {
    myrinfo = nbrinfo+i;

    na = dl_min(nparts,xadj[i+1]-xadj[i]);
    myrinfo->nbrstart = kwinfo->nnbrpool;
    /* check to see if we need to expand the pool */
    if ((kwinfo->nnbrpool += na) > kwinfo->maxnnbrpool) { 
      kwinfo->maxnnbrpool *= NBRPOOL_EXP_RATE;
      kwinfo->nbrpool = adjinfo_realloc(kwinfo->nbrpool,kwinfo->maxnnbrpool);
    }

    mynbrs = kwinfo->nbrpool + myrinfo->nbrstart;
    me = where[i];

    for (j=xadj[i]; j<xadj[i+1]; ++j) {
      k = adjncy[j];
      if (k < mynvtxs) {
        lvtx = k;
        nbrid = myid;
      } else {
        nbrid = gvtx_to_tid(k,graph->dist);
        lvtx = gvtx_to_lvtx(k,graph->dist); 
      }
      if (me == gwhere[nbrid][lvtx]) {
        myrinfo->id += adjwgt[j];
      } else {
        myrinfo->ed += adjwgt[j];
      }
    }

    /* Time to compute the particular external degrees */
    if (myrinfo->ed > 0) {
      mincut += myrinfo->ed;
      for (j=xadj[i]; j<xadj[i+1]; ++j) {
        k = adjncy[j];
        if (k < mynvtxs) {
          lvtx = k;
          nbrid = myid;
        } else {
          nbrid = gvtx_to_tid(k,graph->dist);
          lvtx = gvtx_to_lvtx(k,graph->dist); 
        }
        other = gwhere[nbrid][lvtx];
        if (me != other) {
          for (l=0; l<myrinfo->nnbrs; l++) {
            if (mynbrs[l].pid == other) {
              mynbrs[l].ed += adjwgt[j];
              break;
            }
          }
          if (l == myrinfo->nnbrs) {
            mynbrs[l].pid = other;
            mynbrs[l].ed  = adjwgt[j];
            myrinfo->nnbrs++;
          }
        }
      }

      /* Only ed-id>=0 nodes are considered to be in the boundary */
      if (myrinfo->ed >= myrinfo->id) {
        vtx_iset_add(i,bnd);
      }
      DL_ASSERT(myrinfo->nnbrs > 0,"No neighbors.");
    } else if (myrinfo->id == 0) {
      vtx_iset_add(i,bnd);
    } else {
      myrinfo->nbrstart = NULL_ADJ;
      kwinfo->nnbrpool -= na;
      DL_ASSERT_EQUALS(myrinfo->nnbrs,0,"%"PF_ADJ_T);
    }
  } 

  mincut = wgt_dlthread_sumreduce(mincut,ctrl->comm);

  dl_free(gpwgts[myid]);

  dlthread_barrier(ctrl->comm);
  if (myid == 0) {
    graph->mincut = mincut/2;
  }

  dlthread_free_shmem(gpwgts,ctrl->comm);

  /* the checks */
  DL_ASSERT(check_kwinfo(kwinfo,graph,(pid_t const **)gwhere),"Bad info");
  DL_ASSERT(check_kwbnd(kwinfo->bnd,graph),"Bad boundary");

  return kwinfo;
}


/**
 * @brief Compute the parameters for performing vsep partitioning.
 *
 * @param ctrl The control structure.
 * @param graph The graph.
 * 
 * @return The newly setup vsinfo.
 */
static vsinfo_t * __uncoarsen_partparams_vsep(
    ctrl_t * const ctrl,
    graph_t * const graph)
{
  vtx_t me,i,k;
  adj_t j;
  wgt_t minsep;
  vsnbrinfo_t * nbrinfo; 
  vsnbrinfo_t * myrinfo;
  vtx_iset_t * bnd;
  vsinfo_t * vsinfo;
  wgt_t * mypwgts;
  wgt_t ** gpwgts;

  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;

  pid_t const * const * const gwhere  = (pid_t const **)graph->where;

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  wgt_t * const pwgts = graph->pwgts;

  vtx_t const mynvtxs = graph->mynvtxs[myid];

  adj_t const * const xadj = gxadj[myid];
  vtx_t const * const adjncy = gadjncy[myid];
  wgt_t const * const vwgt = gvwgt[myid];
  pid_t const * const where = gwhere[myid];

  DL_ASSERT(graph->pwgts != NULL,"Non-allocated pwgts");
  DL_ASSERT(graph->where != NULL,"Non-allocated where");

  gpwgts = dlthread_get_shmem(sizeof(wgt_t*)*nthreads,ctrl->comm);

  dlthread_barrier(ctrl->comm);

  mypwgts = gpwgts[myid] = wgt_init_alloc(0,MTMETIS_VSEP_NPARTS);

  /* reset the size of neighbor infor array */
  vsinfo = vsinfo_create(ctrl,graph);
  nbrinfo = vsinfo->nbrinfo;
  bnd = vsinfo->bnd;

  minsep = 0;
  vtx_iset_clear(bnd);

  /* calculate partition weights */
  for (i=0; i<mynvtxs; ++i) {
    mypwgts[where[i]] += vwgt[i];
  }
  dlthread_barrier(ctrl->comm);

  if (myid == 0) {
    /* someday I need to parallelize this via dlthreads */
    for (i=0;i<MTMETIS_VSEP_NPARTS;++i) {
      k = 0;
      for (j=0; j<nthreads;++j) {
        k += gpwgts[j][i];
      }
      pwgts[i] = k;
    }
  }

  /* calculate nbrinfo for vertices */
  for (i=0;i<mynvtxs;++i) {
    myrinfo = nbrinfo+i;
    me = where[i];

    if (me == MTMETIS_VSEP_SEP) {
      __calc_conn(i,myid,mynvtxs,xadj,adjncy,gvwgt,gwhere,graph->dist, \
          myrinfo->con);
      minsep += vwgt[i];
      vtx_iset_add(i,bnd);
    }
  }

  minsep = wgt_dlthread_sumreduce(minsep,ctrl->comm);

  dl_free(gpwgts[myid]);

  dlthread_barrier(ctrl->comm);
  if (myid == 0) {
    graph->minsep = minsep;
  }

  dlthread_free_shmem(gpwgts,ctrl->comm);

  /* the checks */
  DL_ASSERT(check_vsinfo(vsinfo,graph,(pid_t const **)gwhere),"Bad info");
  DL_ASSERT(check_vsbnd(vsinfo->bnd,graph),"Bad boundary");

  return vsinfo;
}


/**
 * @brief Compute the parameters for performing esep partitioning.
 *
 * @param ctrl The control structure.
 * @param graph The graph.
 * 
 * @return The newly setup esinfo.
 */
static esinfo_t * __uncoarsen_partparams_esep(
    ctrl_t * const ctrl,
    graph_t * const graph)
{
  vtx_t me,i,k,lvtx;
  adj_t j;
  pid_t other;
  tid_t nbrid;
  wgt_t mincut;
  wgt_t con[2];
  esnbrinfo_t * nbrinfo; 
  esnbrinfo_t * myrinfo;
  vtx_iset_t * bnd;
  esinfo_t * esinfo;
  wgt_t * mypwgts;
  wgt_t ** gpwgts;

  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;
  wgt_t const * const * const gadjwgt = (wgt_t const **)graph->adjwgt;

  pid_t const * const * const gwhere  = (pid_t const **)graph->where;

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  wgt_t * const pwgts = graph->pwgts;

  vtx_t const mynvtxs = graph->mynvtxs[myid];

  adj_t const * const xadj = gxadj[myid];
  vtx_t const * const adjncy = gadjncy[myid];
  wgt_t const * const vwgt = gvwgt[myid];
  wgt_t const * const adjwgt = gadjwgt[myid];
  pid_t const * const where = gwhere[myid];

  DL_ASSERT(graph->pwgts != NULL,"Non-allocated pwgts");
  DL_ASSERT(graph->where != NULL,"Non-allocated where");

  gpwgts = dlthread_get_shmem(sizeof(wgt_t*)*nthreads,ctrl->comm);

  dlthread_barrier(ctrl->comm);

  mypwgts = gpwgts[myid] = wgt_init_alloc(0,MTMETIS_ESEP_NPARTS);

  /* reset the size of neighbor infor array */
  esinfo = esinfo_create(ctrl,graph);
  nbrinfo = esinfo->nbrinfo;
  bnd = esinfo->bnd;

  mincut = 0;
  vtx_iset_clear(bnd);

  /* calculate partition weights */
  for (i=0; i<mynvtxs; ++i) {
    mypwgts[where[i]] += vwgt[i];
  }
  dlthread_barrier(ctrl->comm);

  if (myid == 0) {
    /* someday I need to parallelize this via dlthreads */
    for (i=0;i<MTMETIS_ESEP_NPARTS;++i) {
      k = 0;
      for (j=0; j<nthreads;++j) {
        k += gpwgts[j][i];
      }
      pwgts[i] = k;
    }
  }

  /* calculate nbrinfo for vertices */
  for (i=0;i<mynvtxs;++i) {
    myrinfo = nbrinfo+i;
    me = where[i];

    con[0] = con[1] = 0;
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (k < mynvtxs) {
        lvtx = k;
        nbrid = myid;
      } else {
        lvtx = gvtx_to_lvtx(k,graph->dist);
        nbrid = gvtx_to_tid(k,graph->dist);
      }
      other = gwhere[nbrid][lvtx];
      con[other] += adjwgt[j];
    }
    if (con[me ^ 0x01] != 0) {
      /* boundary vertex */
      mincut += con[me ^ 0x01];
      vtx_iset_add(i,bnd);
    }

    /* copy over weights */
    myrinfo->con[0] = con[0];
    myrinfo->con[1] = con[1];
  }

  mincut = wgt_dlthread_sumreduce(mincut,ctrl->comm) / 2;

  dl_free(gpwgts[myid]);

  dlthread_barrier(ctrl->comm);
  if (myid == 0) {
    graph->mincut = mincut;
  }

  dlthread_free_shmem(gpwgts,ctrl->comm);

  /* the checks */
  DL_ASSERT(check_esinfo(esinfo,graph,(pid_t const **)gwhere),"Bad info");
  DL_ASSERT(check_esbnd(esinfo->bnd,graph),"Bad boundary");

  return esinfo;
}


/**
 * @brief Project a kway partitioning.
 *
 * @param ctrl The control structure containing runtime parameters.
 * @param graph The partitioned graph to project the partition from.
 */
static void __uncoarsen_project_kway(
    ctrl_t * const ctrl,
    graph_t * const graph,
    kwinfo_t * const kwinfo)
{
  vtx_t i, k, pi, lvtx, nbrid, ned, nid;
  adj_t j, l, istart, iend;
  pid_t me, other, na;
  wgt_t tid, ted;
  kwnbrinfo_t * myrinfo;
  adjinfo_t * mynbrs;
  vtx_t * id, * ed;
  pid_t * htable;
  vtx_iset_t * bnd;
  kwnbrinfo_t * nbrinfo;
  kwinfo_t ** kwinfos;

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  pid_t const nparts = ctrl->nparts;
  graph_t * const cgraph = graph->coarser;
  pid_t const * const * const gcwhere = (pid_t const **)cgraph->where;
  vtx_t * const * const gcmap = graph->cmap;
  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gadjwgt = (wgt_t const **)graph->adjwgt;

  if (myid == 0) {
    dl_start_timer(&(ctrl->timers.projection));
  }

  par_graph_alloc_partmemory(ctrl,graph);

  graph->mincut = cgraph->mincut;

  pid_t ** const gwhere = graph->where;
  pid_t * const where = gwhere[myid];

  vtx_t const mynvtxs = graph->mynvtxs[myid];

  vtx_t * const cmap = gcmap[myid];

  adj_t const * const xadj = gxadj[myid];
  vtx_t const * const adjncy = gadjncy[myid];
  wgt_t const * const adjwgt = gadjwgt[myid];

  kwinfos = dlthread_get_shmem(sizeof(kwinfo_t*)*nthreads,ctrl->comm);

  kwinfos[myid] = kwinfo;

  dlthread_barrier(ctrl->comm);
  
  /* Compute the required info for refinement */
  kwinfo->nnbrpool = 0;

  ed = vtx_alloc(mynvtxs);
  id = vtx_alloc(mynvtxs);

  ned = nid = 0;
  for (i=0;i<mynvtxs;++i) {
    k = cmap[i];
    if (k < cgraph->mynvtxs[myid]) {
      lvtx = k;
      nbrid = myid;
    } else {
      lvtx = gvtx_to_lvtx(k,cgraph->dist);
      nbrid = gvtx_to_tid(k,cgraph->dist);
    }
    where[i] = gcwhere[nbrid][lvtx];
    if (kwinfos[nbrid]->nbrinfo[lvtx].ed > 0) {
      ed[ned++] = i;
    } else {
      id[nid++] = i;
    }
  }

  htable = pid_init_alloc(NULL_PID,nparts);


  if (myid == 0) {
    wgt_copy(graph->pwgts,cgraph->pwgts,nparts);
  }
  dlthread_barrier(ctrl->comm);

  par_graph_free(graph->coarser);

  /* expanpd nbrinfo */
  dl_free(kwinfo->nbrinfo);
  nbrinfo = kwinfo->nbrinfo = kwnbrinfo_calloc(mynvtxs);

  /* expand boundary */
  vtx_iset_free(kwinfo->bnd);
  bnd = kwinfo->bnd = vtx_iset_create(0,mynvtxs);

  for (pi=0;pi<nid;++pi) {
    i = id[pi];
    istart = xadj[i];
    iend = xadj[i+1];

    myrinfo = nbrinfo+i;

    for (tid=0, j=istart; j<iend; j++) {
      tid += adjwgt[j];
    }
    myrinfo->id = tid;
    myrinfo->nbrstart = NULL_ADJ;
    if (tid == 0) {
      /* keep islands on the border */
      vtx_iset_add(i,bnd);
    }
    DL_ASSERT_EQUALS(myrinfo->ed,0,"%"PF_WGT_T);
    DL_ASSERT_EQUALS(myrinfo->nnbrs,0,"%"PF_PID_T);
  }
  for (pi=0;pi<ned;++pi) {
    i = ed[pi];

    istart = xadj[i];
    iend = xadj[i+1];

    myrinfo = nbrinfo+i;

    na = dl_min(nparts,xadj[i+1]-xadj[i]);
    myrinfo->nbrstart = kwinfo->nnbrpool;
    /* check to see if we need to expand the pool */
    if ((kwinfo->nnbrpool += na) > kwinfo->maxnnbrpool) { 
      kwinfo->maxnnbrpool *= NBRPOOL_EXP_RATE;
      kwinfo->nbrpool = adjinfo_realloc(kwinfo->nbrpool,kwinfo->maxnnbrpool);
    }

    mynbrs = kwinfo->nbrpool + myrinfo->nbrstart;

    me = where[i];
    tid = 0;
    ted = 0;
    for (j=istart; j<iend; ++j) {
      k = adjncy[j];
      if (k < mynvtxs) {
        lvtx = k;
        nbrid = myid;
      } else {
        lvtx = gvtx_to_lvtx(k,graph->dist);
        nbrid = gvtx_to_tid(k,graph->dist);
      }
      other = gwhere[nbrid][lvtx];
      if (me == other) {
        tid += adjwgt[j];
      } else {
        ted += adjwgt[j];
        if ((l = htable[other]) == NULL_PID) {
          htable[other] = myrinfo->nnbrs;
          mynbrs[myrinfo->nnbrs].pid = other;
          mynbrs[myrinfo->nnbrs++].ed = adjwgt[j];
        } else {
          mynbrs[l].ed += adjwgt[j];
        }
      }
    }
    myrinfo->id = tid;
    myrinfo->ed = ted;

    if (ted > 0) {
      if (ted >= tid) {
        vtx_iset_add(i,bnd);
      }
      for (j=0; j<myrinfo->nnbrs; ++j) {
        htable[mynbrs[j].pid] = NULL_ADJ;
      }
    } else if (tid == 0) {
      vtx_iset_add(i,bnd);
    }
    if (myrinfo->nnbrs == 0) {
      kwinfo->nnbrpool -= na;
      myrinfo->nbrstart = NULL_ADJ;
    }
  }

  dl_free(htable);
  dl_free(ed);
  dl_free(id);

  if (myid == 0) {
    graph->coarser = NULL;
  }

  dlthread_free_shmem(kwinfos,ctrl->comm);

  dlthread_barrier(ctrl->comm);

  if (myid == 0) {
    dl_stop_timer(&(ctrl->timers.projection));
  }

  DL_ASSERT(check_kwinfo(kwinfo,graph,(pid_t const **)gwhere),"Bad info");
  DL_ASSERT(check_kwbnd(kwinfo->bnd,graph),"Bad boundary");
}


/**
 * @brief Project an edge separator.
 *
 * @param ctrl The control structure containing runtime parameters.
 * @param graph The partitioned graph to project the partition (edge
 * separator) from.
 */
static void __uncoarsen_project_esep(
    ctrl_t * const ctrl,
    graph_t * const graph,
    esinfo_t * const esinfo)
{
  vtx_t i, k, lvtx, nbrid;
  adj_t j;
  pid_t me, other;
  esnbrinfo_t * myrinfo;
  vtx_iset_t * bnd, ** cbnds;
  esnbrinfo_t * nbrinfo;

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  graph_t * const cgraph = graph->coarser;
  pid_t const * const * const gcwhere = (pid_t const **)cgraph->where;
  vtx_t * const * const gcmap = graph->cmap;
  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gadjwgt = (wgt_t const **)graph->adjwgt;

  adj_t const * const xadj = gxadj[myid];
  vtx_t const * const adjncy = gadjncy[myid];
  wgt_t const * const adjwgt = gadjwgt[myid];

  vtx_t const mynvtxs = graph->mynvtxs[myid];

  vtx_t * const cmap = gcmap[myid];

  if (myid == 0) {
    dl_start_timer(&(ctrl->timers.projection));
  }

  par_graph_alloc_partmemory(ctrl,graph);

  graph->mincut = cgraph->mincut;

  pid_t ** const gwhere = graph->where;
  pid_t * const where = gwhere[myid];

  cbnds = dlthread_get_shmem(sizeof(vtx_iset_t*)*nthreads,ctrl->comm);

  cbnds[myid] = esinfo->bnd;

  /* expand boundary */
  dl_free(esinfo->nbrinfo);
  bnd = vtx_iset_create(0,mynvtxs);

  /* expanpd nbrinfo */
  nbrinfo = esinfo->nbrinfo = esnbrinfo_alloc(mynvtxs);

  if (myid == 0) {
    wgt_copy(graph->pwgts,cgraph->pwgts,MTMETIS_ESEP_NPARTS);
  }

  dlthread_barrier(ctrl->comm);
  
  /* project where and find boundary */
  for (i=0;i<mynvtxs;++i) {
    k = cmap[i];
    if (k < cgraph->mynvtxs[myid]) {
      lvtx = k;
      nbrid = myid;
    } else {
      lvtx = gvtx_to_lvtx(k,cgraph->dist);
      nbrid = gvtx_to_tid(k,cgraph->dist);
    }
    where[i] = gcwhere[nbrid][lvtx];
    if (vtx_iset_contains(lvtx,cbnds[nbrid])) {
      /* add it to my local boundary for filtering */
      vtx_iset_add(i,bnd);
    }
  }

  /* synchronize so that neighbor's wheres can be read */
  dlthread_free_shmem(cbnds,ctrl->comm);

  vtx_iset_free(esinfo->bnd);
  esinfo->bnd = bnd;

  for (i=0;i<mynvtxs;++i) {
    me = where[i];

    /* clear myrinfo */
    myrinfo = nbrinfo+i;

    myrinfo->con[0] = myrinfo->con[1] = 0;

    if (vtx_iset_contains(i,bnd)) {
      /* potential boundary vertex */
      for (j=xadj[i];j<xadj[i+1];++j) {
        k = adjncy[j];
        if (k < mynvtxs) {
          lvtx = k;
          nbrid = myid;
        } else {
          lvtx = gvtx_to_lvtx(k,graph->dist);
          nbrid = gvtx_to_tid(k,graph->dist);
        }
        other = gwhere[nbrid][lvtx];
        myrinfo->con[other] += adjwgt[j];
      }
      if (myrinfo->con[me ^ 0x01] == 0) {
        /* internal vertex -- remove from boundary */
        vtx_iset_remove(i,bnd);
      }
    } else {
      /* internal vertex */
      for (j=xadj[i];j<xadj[i+1];++j) {
        myrinfo->con[me] += adjwgt[j];
      }
    }
  }

  if (myid == 0) {
    graph->coarser = NULL;
  }

  par_graph_free(cgraph);

  if (myid == 0) {
    dl_stop_timer(&(ctrl->timers.projection));
  }

  DL_ASSERT(check_esinfo(esinfo,graph,(pid_t const **)gwhere),"Bad info");
  DL_ASSERT(check_esbnd(esinfo->bnd,graph),"Bad boundary");
}


/**
 * @brief Project a vertex separator.
 *
 * @param ctrl The control structure containing runtime parameters.
 * @param graph The partitioned graph to project the partition (vertex
 * separator) from.
 */
static void __uncoarsen_project_vsep(
    ctrl_t * const ctrl,
    graph_t * const graph,
    vsinfo_t * const vsinfo)
{
  vtx_t i, k, lvtx, nbrid;
  pid_t me;
  vsnbrinfo_t * myrinfo;
  vtx_iset_t * bnd;
  vsnbrinfo_t * nbrinfo;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  graph_t * const cgraph = graph->coarser;
  pid_t const * const * const gcwhere = (pid_t const **)cgraph->where;
  vtx_t * const * const gcmap = graph->cmap;
  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;

  if (myid == 0) {
    dl_start_timer(&(ctrl->timers.projection));
  }

  par_graph_alloc_partmemory(ctrl,graph);

  graph->minsep = cgraph->minsep;

  pid_t ** const gwhere = graph->where;
  pid_t * const where = gwhere[myid];

  vtx_t const mynvtxs = graph->mynvtxs[myid];

  vtx_t * const cmap = gcmap[myid];

  adj_t const * const xadj = gxadj[myid];
  vtx_t const * const adjncy = gadjncy[myid];

  /* expand boundary */
  vtx_iset_free(vsinfo->bnd);
  dl_free(vsinfo->nbrinfo);
  bnd = vsinfo->bnd = vtx_iset_create(0,mynvtxs);

  /* expanpd nbrinfo */
  nbrinfo = vsinfo->nbrinfo = vsnbrinfo_alloc(mynvtxs);

  if (myid == 0) {
    wgt_copy(graph->pwgts,cgraph->pwgts,MTMETIS_VSEP_NPARTS);
  }
  
  for (i=0;i<mynvtxs;++i) {
    k = cmap[i];
    if (k < cgraph->mynvtxs[myid]) {
      lvtx = k;
      nbrid = myid;
    } else {
      lvtx = gvtx_to_lvtx(k,cgraph->dist);
      nbrid = gvtx_to_tid(k,cgraph->dist);
    }
    where[i] = gcwhere[nbrid][lvtx];
  }

  /* synchronize so that neighbor's wheres can be read */
  dlthread_barrier(ctrl->comm);

  for (i=0;i<mynvtxs;++i) {
    me = where[i];

    /* clear myrinfo */
    myrinfo = nbrinfo+i;

    if (me == MTMETIS_VSEP_SEP) {
      /* have to compute connectivity */
      __calc_conn(i,myid,mynvtxs,xadj,adjncy,gvwgt,(pid_t const **)gwhere, \
          graph->dist,myrinfo->con);

      vtx_iset_add(i,bnd);
    }
  }

  if (myid == 0) {
    graph->coarser = NULL;
  }

  par_graph_free(cgraph);

  if (myid == 0) {
    dl_stop_timer(&(ctrl->timers.projection));
  }

  DL_ASSERT(check_vsinfo(vsinfo,graph,(pid_t const **)gwhere),"Bad info");
  DL_ASSERT(check_vsbnd(vsinfo->bnd,graph),"Bad boundary");
}




/******************************************************************************
* PUBLIC PARALLEL FUNCTIONS ***************************************************
******************************************************************************/


void par_uncoarsen_kway(
    ctrl_t * const ctrl,
    graph_t * const orggraph,
    graph_t * graph)
{
  vtx_t i;
  kwinfo_t * kwinfo;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  if (myid == 0) {
    dl_start_timer(&ctrl->timers.uncoarsening);
  }

  /* Compute the parameters of the coarsest graph */
  kwinfo = __uncoarsen_partparams_kway(ctrl,graph);
  
  /* Refine each successively finer graph */
  for (i=0; ;i++) {
    (void)par_kwayrefine(ctrl,graph,kwinfo); 

    par_vprintf(ctrl->verbosity,MTMETIS_VERBOSITY_HIGH,"Final partition on " \
        "graph %zu: %"PF_WGT_T" cut and %5.4lf balance\n",graph->level, \
        graph->mincut,graph_imbalance(graph,ctrl->nparts,ctrl->pijbm));


    /* if we finished uncoarsening, stop */
    if (graph == orggraph) {
      break;
    }

    graph = graph->finer;

    __uncoarsen_project_kway(ctrl,graph,kwinfo);
  }

  kwinfo_free(kwinfo);

  if (myid == 0) {
    dl_stop_timer(&ctrl->timers.uncoarsening);
  }
}


void par_uncoarsen_esep(
    ctrl_t * const ctrl,
    graph_t * const orggraph,
    graph_t * graph)
{
  vtx_t i;
  esinfo_t * esinfo;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  if (myid == 0) {
    dl_start_timer(&ctrl->timers.uncoarsening);
  }

  /* Compute the parameters of the coarsest graph */
  esinfo = __uncoarsen_partparams_esep(ctrl,graph);
  
  /* Refine each successively finer graph */
  for (i=0; ;i++) {
    (void)par_eseprefine(ctrl,graph,esinfo); 

    par_vprintf(ctrl->verbosity,MTMETIS_VERBOSITY_HIGH,"Final partition on " \
        "graph %zu: %"PF_WGT_T" cut and %5.4lf balance\n",graph->level, \
        graph->mincut,graph_imbalance(graph,ctrl->nparts,ctrl->pijbm));


    /* if we finished uncoarsening, stop */
    if (graph == orggraph) {
      break;
    }

    graph = graph->finer;

    __uncoarsen_project_esep(ctrl,graph,esinfo);
  }

  esinfo_free(esinfo);

  if (myid == 0) {
    dl_stop_timer(&ctrl->timers.uncoarsening);
  }
}


void par_uncoarsen_vsep(
    ctrl_t * const ctrl,
    graph_t * const orggraph,
    graph_t * graph)
{
  vtx_t i;
  vsinfo_t * vsinfo;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  if (myid == 0) {
    dl_start_timer(&ctrl->timers.uncoarsening);
  }

  /* Compute the parameters of the coarsest graph */
  vsinfo = __uncoarsen_partparams_vsep(ctrl,graph);
  
  /* Refine each successively finer graph */
  for (i=0; ;i++) {
    par_vseprefine(ctrl,graph,vsinfo); 

    /* if we finished uncoarsening, stop */
    if (graph == orggraph) {
      break;
    }

    graph = graph->finer;

    __uncoarsen_project_vsep(ctrl,graph,vsinfo);
  }

  vsinfo_free(vsinfo);

  if (myid == 0) {
    dl_stop_timer(&ctrl->timers.uncoarsening);
  }
}




#endif
