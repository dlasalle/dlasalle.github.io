/**
 * @file partition.c
 * @brief Partitioning functions
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2013-05-20
 */




#ifndef MTMETIS_PARTITION_C
#define MTMETIS_PARTITION_C




#include "partition.h"
#include "coarsen.h"
#include "initpart.h"
#include "uncoarsen.h"
#include "check.h"

#undef real_t
#include <metis.h>
#define real_t mtmetis_real_t




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


/**
 * @brief Calcuate teh edgecut of a partitioning, serially.
 *
 * @param graph The graph.
 * @param where The partition ids.
 *
 * @return  The total weight of cut edges.
 */
static wgt_t __partition_calc_cut(
    graph_t const * const graph,
    pid_t const * const * const where)
{
  vtx_t i,k,l,mynvtxs;
  adj_t j;
  wgt_t cut;
  pid_t me, other;
  tid_t myid, o;

  tid_t const nthreads = graph->dist.nthreads;

  cut = 0;
  for (myid=0;myid<nthreads;++myid) {
    mynvtxs = graph->mynvtxs[myid];
    for (i=0;i<mynvtxs;++i) {
      me = where[myid][i];
      for (j=graph->xadj[myid][i];j<graph->xadj[myid][i+1];++j) {
        k = graph->adjncy[myid][j];
        if (k > mynvtxs) {
          l = gvtx_to_lvtx(k,graph->dist);
          o = gvtx_to_tid(k,graph->dist);
        } else {
          l = k;
          o = myid;
        }
        other = where[o][l];
        if (other != me) {
          cut += graph->adjwgt[myid][j];
        }
      }
    }
  }

  return cut/2;
}


/**
 * @brief Calculate the communication volume of partitioning (serially).
 *
 * @param graph The partitioned graph.
 * @param where The partition IDs.
 * @param nparts The number of partitions.
 *
 * @return The communication volume. 
 */
static vtx_t __partition_calc_comvol(
    graph_t const * const graph,
    pid_t const * const * const where,
    pid_t const nparts)
{
  vtx_t vol, i, k, l, mynvtxs, g;
  adj_t j;
  pid_t me, other;
  tid_t o, myid;
  vtx_t * marker;

  tid_t const nthreads = graph->dist.nthreads;

  marker = vtx_init_alloc(NULL_VTX,nparts);

  vol = 0;
  for (myid=0;myid<nthreads;++myid) {
    mynvtxs = graph->mynvtxs[myid];
    for (i=0;i<mynvtxs;++i) {
      me = where[myid][i];
      g = lvtx_to_gvtx(i,myid,graph->dist);
      marker[me] = g; 
      for (j=graph->xadj[myid][i];j<graph->xadj[myid][i+1];++j) {
        k = graph->adjncy[myid][j];
        if (k > mynvtxs) {
          l = gvtx_to_lvtx(k,graph->dist);
          o = gvtx_to_tid(k,graph->dist);
        } else {
          l = k;
          o = myid;
        }
        other = where[o][l];
        if (marker[other] != g) {
          marker[other] = g;
          ++vol;
        }
      }
    }
  }

  dl_free(marker);

  return vol;
}


static wgt_t __partition_calc_vsep(
    graph_t const * const graph,
    pid_t const * const * const where)
{
  vtx_t mynvtxs, i;
  pid_t me;
  tid_t myid;
  wgt_t sep;

  tid_t const nthreads = graph->dist.nthreads;

  sep = 0;

  for (myid=0;myid<nthreads;++myid) {
    mynvtxs = graph->mynvtxs[myid];
    for (i=0;i<mynvtxs;++i) {
      me = where[myid][i];
      if (me == MTMETIS_VSEP_SEP) {
        sep += graph->vwgt[myid][i];
      }
    }
  }

  return sep;
}


static wgt_t __ser_partition_metis(
    ctrl_t * const ctrl,
    graph_t * const graph,
    pid_t * const * const where)
{
  idx_t nparts;
  idx_t cut, ncon;
  idx_t options[METIS_NOPTIONS];
  real_t ubf;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  METIS_SetDefaultOptions(options);

  ncon = 1;

  options[METIS_OPTION_NITER] = 10;
  options[METIS_OPTION_OBJTYPE] = METIS_OBJTYPE_CUT;
  options[METIS_OPTION_SEED] = ctrl->seed + myid;
  options[METIS_OPTION_NCUTS] = ctrl->ncuts;
  options[METIS_OPTION_DBGLVL] = 0;
  options[METIS_OPTION_UFACTOR] = 1000*(ctrl->ubfactor - 1.0);
  nparts = ctrl->nparts;
  ubf = ctrl->ubfactor;

  if (ctrl->ptype == MTMETIS_PTYPE_RB || nparts == 2) {
    options[METIS_OPTION_RTYPE] = METIS_RTYPE_FM;
    METIS_PartGraphRecursive((idx_t*)graph->mynvtxs,&ncon, \
        (idx_t*)graph->xadj[0],(idx_t*)graph->adjncy[0], \
        (idx_t*)graph->vwgt[0],NULL,(idx_t*)graph->adjwgt[0],&nparts,NULL, \
        &ubf,options,&cut,(idx_t*)where[0]);
  } else {
    METIS_PartGraphKway((idx_t*)graph->mynvtxs,&ncon,(idx_t*)graph->xadj[0], \
        (idx_t*)graph->adjncy[0],(idx_t*)graph->vwgt[0],NULL, \
        (idx_t*)graph->adjwgt[0],&nparts,NULL,&ubf,options,&cut, \
        (idx_t*)where[0]);
  }

  graph->mincut = cut;

  return cut;
}


/**
 * @brief Perform a multilevel kway partitioning in parallel (to be called by
 * each thread in a parallel region).
 *
 * @param ctrl The control structure.
 * @param graph The graph structure.
 * @param where The allocated where vector.
 *
 * @return Total weight of cut edges.
 */
static wgt_t __partition_mlevel_kway(
    ctrl_t * const ctrl,
    graph_t * const graph,
    pid_t * const * const where)
{
  vtx_t i;
  wgt_t curobj, bestobj;
  double curbal, bestbal;
  graph_t * cgraph;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  if (myid == 0) {
    dl_start_timer(&ctrl->timers.partitioning);
  }

  curobj = 0;
  bestobj = 0;
  curbal=0.0;
  bestbal=0.0;

  for (i=0;i<ctrl->ncuts;++i) {
    cgraph = par_coarsen_graph(ctrl,graph);

    par_initpart_kway(ctrl,cgraph);

    DL_ASSERT_EQUALS(par_graph_cut(cgraph,(pid_t const **)cgraph->where), \
        cgraph->mincut,"%"PF_WGT_T); 

    par_uncoarsen_kway(ctrl, graph, cgraph);

    curobj = graph->mincut;

    curbal = graph_imbalance(graph,ctrl->nparts,ctrl->pijbm);

    if (i == 0  \
        || (curbal <= 0.0005 && bestobj > curobj) \
        || (bestbal > 0.0005 && curbal < bestbal)) {
      pid_copy(where[myid],graph->where[myid],graph->mynvtxs[myid]);
      bestobj = curobj;
      bestbal = curbal;
    }

    par_graph_free_rdata(graph);

    ++ctrl->seed;

    if (ctrl->cutstats) {
      ctrl->cuts[i] = curobj;
    }

    if (bestobj == 0 && curbal <= 0.0005) {
      break;
    }
  }

  if (myid == 0) {
    dl_stop_timer(&ctrl->timers.partitioning);
  }

  return bestobj;
}


static wgt_t __partition_mlevel_rb(
    ctrl_t * const ctrl,
    graph_t * const graph,
    pid_t const offset,
    pid_t ** const gwhere) 
{
  vtx_t v, g, mynvtxs, lvtx;
  tid_t hmyid, mygroup, lid;
  dlthread_comm_t lcomm;
  pid_t hoff, hnparts;
  wgt_t cut;
  ctrl_t * myctrl;

  wgt_t * hcut;
  graph_t ** hgraphs;
  pid_t *** hgwhere;

  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);
  tid_t const myid = dlthread_get_id(ctrl->comm);

  /* handle the serial case */
  if (nthreads == 1) {
    return __ser_partition_metis(ctrl,graph,gwhere);
  }

  /* initial bisection */
  par_partition_edgeseparator(ctrl,graph,gwhere);

  /* handle the case where we've made our final bisection */
  if (ctrl->nparts <= 2) {
    return graph->mincut;
  }

  if (myid == 0) {
    dl_start_timer(&(ctrl->timers.recursion));
  }

  hgraphs = dlthread_get_shmem((sizeof(graph_t*)*2) + (sizeof(pid_t**)*2) + \
      (sizeof(vtx_t)*(nthreads+1))+(sizeof(wgt_t)*2),ctrl->comm);

  hgwhere = (pid_t***)(hgraphs+2);
  hcut = (wgt_t*)(hgwhere+2);

  /* extract subgraphs and structure based on number of calling threads */
  mygroup = par_graph_extract_halves(graph,(pid_t const **)gwhere,hgraphs);

  /* still need to do something to handle non-power of two partitions */

  if (mygroup == 0) {
    hoff = offset;
    hnparts = ctrl->nparts/2;
  } else {
    hoff = (ctrl->nparts/2) + offset;
    hnparts = ctrl->nparts - (ctrl->nparts/2);
  }
  dlthread_barrier(ctrl->comm);

  lcomm = hgraphs[mygroup]->comm;

  hmyid = dlthread_get_id(lcomm);

  myctrl = par_ctrl_split(ctrl,hgraphs[mygroup]->nvtxs,hnparts,lcomm);

  DL_ASSERT_EQUALS((size_t)myctrl->comm,(size_t)hgraphs[mygroup]->comm,"%zu");

  hgwhere[mygroup] = dlthread_get_shmem(sizeof(pid_t*)*nthreads,lcomm);
  hgwhere[mygroup][hmyid] = pid_alloc(hgraphs[mygroup]->mynvtxs[hmyid]);

  if (myid == 0) {
    dl_stop_timer(&(ctrl->timers.recursion));
  }

  cut = __partition_mlevel_rb(myctrl,hgraphs[mygroup],hoff,hgwhere[mygroup]);

  if (myid == 0) {
    ctrl_combine_timers(ctrl,myctrl);
  }

  if (hmyid == 0) {
    hcut[mygroup] = cut;
  }

  par_ctrl_free(myctrl);

  /* project my newly partitioned vertices */
  mynvtxs = hgraphs[mygroup]->mynvtxs[hmyid];
  for (v=0;v<mynvtxs;++v) {
    g = hgraphs[mygroup]->label[hmyid][v];
    lid = gvtx_to_tid(g,graph->dist);
    lvtx = gvtx_to_lvtx(g,graph->dist);
    gwhere[lid][lvtx] = hgwhere[mygroup][hmyid][v];
  }

  if (myid == 0) {
    graph->mincut += hcut[0] + hcut[1];
  }

  dl_free(hgwhere[mygroup][hmyid]);
  dlthread_free_shmem(hgwhere[mygroup],lcomm);

  par_graph_free(hgraphs[mygroup]);

  dlthread_comm_finalize(lcomm);
  dlthread_free_shmem(hgraphs,ctrl->comm);

  return graph->mincut;
}


/**
 * @brief Find a vertex separator using the multilevel paradigm.
 *
 * @param ctrl The control structure to use.
 * @param graph The graph to find the separator of.
 * @param where The partition each vertex gets assigned to (output).
 *
 * @return The weight of the vertex separator. 
 */
static wgt_t __partition_mlevel_vsep(
    ctrl_t * const ctrl,
    graph_t * const graph,
    pid_t * const * const where)
{
  vtx_t i, k;
  wgt_t curobj, bestobj;
  pid_t me;
  double curbal, bestbal;
  graph_t * cgraph;
  idx_t options[METIS_NOPTIONS];

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  if (myid == 0) {
    dl_start_timer(&ctrl->timers.partitioning);
  }

  if (nthreads == 1 && ctrl->metis_serial) {
    METIS_SetDefaultOptions(options);

    options[METIS_OPTION_NITER] = 10;
    if (ctrl->verbosity == MTMETIS_VERBOSITY_MAXIMUM) {
      options[METIS_OPTION_DBGLVL] = 15;
    } else {
      options[METIS_OPTION_DBGLVL] = 0;
    }
    options[METIS_OPTION_NSEPS] = 1;
    options[METIS_OPTION_NCUTS] = 1;
    options[METIS_OPTION_NITER] = ctrl->nrefpass;
    options[METIS_OPTION_UFACTOR] = 1000*(ctrl->ubfactor - 1.0);
    options[METIS_OPTION_OBJTYPE] = METIS_OBJTYPE_NODE;
  }

  curobj = 0;
  bestobj = graph->tvwgt;
  bestbal = ctrl->nparts;

  for (i=0;i<ctrl->ncuts;++i) {
    if (nthreads == 1 && ctrl->metis_serial) {
      options[METIS_OPTION_SEED] = ctrl->seed;

      graph->pwgts = wgt_init_alloc(0,3);
      graph->where = r_pid_alloc(1);
      graph->where[0] = pid_alloc(graph->mynvtxs[0]);

      METIS_ComputeVertexSeparator((idx_t*)graph->mynvtxs, \
          (idx_t*)graph->xadj[0],(idx_t*)graph->adjncy[0], \
          (idx_t*)graph->vwgt[0],options,&curobj,(idx_t*)graph->where[0]);

      for (k=0;k<graph->mynvtxs[0];++k) {
        me = graph->where[0][k];
        graph->pwgts[me] += graph->vwgt[0][k];
      }
    } else {
      cgraph = par_coarsen_graph(ctrl,graph);

      par_initpart_vsep(ctrl,cgraph);

      par_uncoarsen_vsep(ctrl, graph, cgraph);

      DL_ASSERT(check_separator(graph,(pid_t const **)graph->where), \
          "Bad separator generated");
      #ifdef USE_ASSERTS
      dlthread_barrier(ctrl->comm);
      #endif

      curobj = graph->minsep;
    }

    curbal = dl_max(graph->pwgts[0],graph->pwgts[1]) * \
          2.0/(graph->pwgts[0]+graph->pwgts[1]);

    if (i == 0 || bestobj > curobj) {
      pid_copy(where[myid],graph->where[myid],graph->mynvtxs[myid]);
      bestobj = curobj;
      bestbal = curbal;
    }

    par_graph_free_rdata(graph);

    ++ctrl->seed;

    if (ctrl->cutstats) {
      ctrl->cuts[i] = curobj;
    }

    if (bestobj == 0 && bestbal <= ctrl->ubfactor) {
      break;
    }
  }

  if (myid == 0) {
    dl_stop_timer(&ctrl->timers.partitioning);
  }

  return bestobj;
}


/**
 * @brief Find an edge separator using the multilevel paradigm.
 *
 * @param ctrl The control structure to use.
 * @param graph The graph to find the separator of.
 * @param where The partition each vertex gets assigned to (output).
 *
 * @return The weight of the edge separator. 
 */
static wgt_t __partition_mlevel_esep(
    ctrl_t * const ctrl,
    graph_t * const graph,
    pid_t * const * const where)
{
  vtx_t i, k;
  wgt_t curobj, bestobj;
  pid_t me;
  double curbal, bestbal;
  graph_t * cgraph;
  idx_t ncon = 1, nparts = 2;
  real_t ubf = 1.0;
  idx_t options[METIS_NOPTIONS];

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  if (myid == 0) {
    dl_start_timer(&ctrl->timers.partitioning);
  }

  if (nthreads == 1 && ctrl->metis_serial) {
    METIS_SetDefaultOptions(options);

    options[METIS_OPTION_NITER] = 10;
    if (ctrl->verbosity == MTMETIS_VERBOSITY_MAXIMUM) {
      options[METIS_OPTION_DBGLVL] = 15;
    } else {
      options[METIS_OPTION_DBGLVL] = 0;
    }
    options[METIS_OPTION_NSEPS] = 1;
    options[METIS_OPTION_NCUTS] = 1;
    options[METIS_OPTION_NITER] = ctrl->nrefpass;
    options[METIS_OPTION_UFACTOR] = 1000*(ctrl->ubfactor - 1.0);
    options[METIS_OPTION_OBJTYPE] = METIS_OBJTYPE_CUT;

    ubf = ctrl->ubfactor;
  }

  curobj = 0;
  bestobj = graph->tvwgt;
  bestbal = ctrl->nparts;

  for (i=0;i<ctrl->ncuts;++i) {
    if (nthreads == 1 && ctrl->metis_serial) {
      options[METIS_OPTION_SEED] = ctrl->seed;

      graph->pwgts = wgt_init_alloc(0,2);
      graph->where = r_pid_alloc(1);
      graph->where[0] = pid_alloc(graph->mynvtxs[0]);

      METIS_PartGraphRecursive((idx_t*)graph->mynvtxs,&ncon, \
          (idx_t*)graph->xadj[0],(idx_t*)graph->adjncy[0], \
          (idx_t*)graph->vwgt[0],NULL,(idx_t*)graph->adjwgt[0],&nparts,NULL, \
          &ubf,options,&curobj,(idx_t*)graph->where[0]);

      for (k=0;k<graph->mynvtxs[0];++k) {
        me = graph->where[0][k];
        graph->pwgts[me] += graph->vwgt[0][k];
      }
    } else {
      cgraph = par_coarsen_graph(ctrl,graph);

      par_initpart_esep(ctrl,cgraph);

      par_uncoarsen_esep(ctrl, graph, cgraph);

      #ifdef USE_ASSERTS
      dlthread_barrier(ctrl->comm);
      #endif

      curobj = graph->mincut;
    }

    curbal = dl_max(graph->pwgts[0],graph->pwgts[1]) * \
          2.0/(graph->pwgts[0]+graph->pwgts[1]);

    if (i == 0 || bestobj > curobj) {
      pid_copy(where[myid],graph->where[myid],graph->mynvtxs[myid]);
      bestobj = curobj;
      bestbal = curbal;
    }

    par_graph_free_rdata(graph);

    ++ctrl->seed;

    if (ctrl->cutstats) {
      ctrl->cuts[i] = curobj;
    }

    if (bestobj == 0 && bestbal <= ctrl->ubfactor) {
      break;
    }
  }

  if (myid == 0) {
    dl_stop_timer(&ctrl->timers.partitioning);
  }

  return bestobj;
}



/******************************************************************************
* PUBLIC SERIAL FUNCTIONS *****************************************************
******************************************************************************/


void partition_print_info(
    ctrl_t const * ctrl,
    graph_t const * graph,
    pid_t const * const * where)
{
  vtx_t i, k, mynvtxs;
  pid_t nparts;
  tid_t myid;
  wgt_t tvwgt, mvwgt;
  wgt_t * kpwgts;
  real_t * tpwgts;
  double unbalance;
  const wgt_t *vwgt; 
  const pid_t *mywhere;

  nparts = ctrl->nparts;
  tpwgts = ctrl->tpwgts;

  dl_print_footer('*');
  printf(" size of vtx_t: %zu, adj_t: %zu, wgt_t: %zu, pid_t: %zu, tid_t: " \
      "%zu, real_t: %zu\n",8*sizeof(vtx_t), 8*sizeof(adj_t), 8*sizeof(wgt_t), \
      8*sizeof(pid_t), 8*sizeof(tid_t), 8*sizeof(real_t));
  printf("\n");
  dl_print_header("Graph Information",'-');
  printf("#Vertices: %"PF_VTX_T", #Edges: %"PF_ADJ_T", #Parts: %"PF_PID_T"\n", 
    graph->nvtxs, graph->nedges/2, ctrl->nparts);

  printf("\n");
  printf("\n");
  if (ctrl->ptype == MTMETIS_PTYPE_KWAY || ctrl->ptype == MTMETIS_PTYPE_ESEP \
      || ctrl->ptype == MTMETIS_PTYPE_RB) {

    switch (ctrl->ptype) {
      case MTMETIS_PTYPE_KWAY:
        dl_print_header("Direct k-way Partitioning",'-');
        break;
      case MTMETIS_PTYPE_RB:
        dl_print_header("Recursive Bisection Partitioning",'-');
        break;
      case MTMETIS_PTYPE_ESEP:
        dl_print_header("Direct Bisection Partitioning",'-');
        break;
    }

    /* Compute objective-related infomration */
    printf(" - Edgecut: %"PF_WGT_T", communication volume: %"PF_VTX_T".\n\n", \
      __partition_calc_cut(graph,where),__partition_calc_comvol(graph,where, \
        nparts));


    /* Compute constraint-related information */
    kpwgts = wgt_init_alloc(0,nparts);

    for (myid=0;myid<graph->dist.nthreads;++myid) {
      mynvtxs = graph->mynvtxs[myid];
      vwgt = graph->vwgt[myid];
      mywhere = where[myid];
      for (i=0; i<mynvtxs; ++i) {
        kpwgts[mywhere[i]] += vwgt[i];
      }
    }

    /* Report on balance */
    printf(" - Balance:\n");
    tvwgt = wgt_sum(kpwgts,nparts);
    k = 0;
    unbalance = 1.0*kpwgts[k]/(tpwgts[k]*tvwgt);
    for (i=1;i<nparts;++i) {
      if (unbalance < 1.0*kpwgts[i]/(tpwgts[i]*tvwgt)) {
        unbalance = 1.0*kpwgts[i]/(tpwgts[i]*tvwgt);
        k = i;
      }
    }
    mvwgt = 0;
    for (myid=0;myid<graph->dist.nthreads;++myid) {
      if ((mynvtxs = graph->mynvtxs[myid]) > 0) {
        vwgt = graph->vwgt[myid];
        k = wgt_max_index(vwgt,mynvtxs);
        if (vwgt[k] > mvwgt) {
          mvwgt = vwgt[k];
        }
      }
    }

    printf("     constraint #0:  %5.3lf out of %5.3lf\n", \
        unbalance, 1.0*nparts*mvwgt/ (1.0*tvwgt));
    printf("\n");

    for (k=0, unbalance=kpwgts[k]/(tpwgts[k]*tvwgt), i=1; i<nparts; i++) {
      if (unbalance < kpwgts[i]/(tpwgts[i]*tvwgt)) {
        unbalance = kpwgts[i]/(tpwgts[i]*tvwgt);
        k = i;
      }
    }

    printf(" - Most overweight partition:\n");
    printf("     pid: %"PF_PID_T", actual: %"PF_WGT_T", desired: %"PF_WGT_T \
           ", ratio: %.2lf\n",k,kpwgts[k],(wgt_t)(tvwgt*tpwgts[k]),unbalance);
    printf("\n");

  } else if (ctrl->ptype == MTMETIS_PTYPE_VSEP) {
    dl_print_header("Vertex Separator",'-');

    printf(" - Separator Size: %"PF_WGT_T".\n\n", \
        __partition_calc_vsep(graph,where));

    kpwgts = wgt_init_alloc(0,3);

    for (myid=0;myid<graph->dist.nthreads;++myid) {
      mynvtxs = graph->mynvtxs[myid];
      vwgt = graph->vwgt[myid];
      mywhere = where[myid];
      for (i=0; i<mynvtxs; ++i) {
        kpwgts[mywhere[i]] += vwgt[i];
      }
    }

    printf(" - Balance:\n");

    tvwgt = wgt_sum(kpwgts,2);
    if (kpwgts[0] > kpwgts[1]) {
      k = 0;
    } else {
      k = 1;
    }
    unbalance = 2.0*kpwgts[k]/tvwgt;
    
    printf(" - Most overweight partition:\n");
    printf("     pid: %"PF_PID_T", actual: %"PF_WGT_T", desired: %"PF_WGT_T \
           ", ratio: %.2lf\n",k,kpwgts[k],(wgt_t)(tvwgt*0.5),unbalance);
    printf("\n");
  } else {
    dl_error("Unknown partition type '%d'\n",ctrl->ptype);
  }

  dl_free(kpwgts);

  dl_print_footer('*');
}            




/******************************************************************************
* PUBLIC PARALLEL FUNCTIONS ***************************************************
******************************************************************************/


void par_partition_kway(
    ctrl_t * const ctrl, 
    graph_t * const graph, 
    pid_t ** const where)
{
  pid_t i;
  wgt_t cut;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  /* set up multipliers for making balance computations easier */
  if (myid == 0) {
    if (!ctrl->pijbm) {
      ctrl->pijbm = real_alloc(ctrl->nparts);
    }
    for (i=0;i<ctrl->nparts;++i) {
      ctrl->pijbm[i] = graph->invtvwgt / ctrl->tpwgts[i];
    }
  }
  dlthread_barrier(ctrl->comm);

  cut = __partition_mlevel_kway(ctrl,graph,where); 

  if (myid == 0) {
    graph->mincut = cut;
  }

  dlthread_barrier(ctrl->comm);
}


void par_partition_rb(
    ctrl_t * const ctrl,
    graph_t * const graph,
    pid_t ** const where)
{
  pid_t i;
  wgt_t cut;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  /* set up multipliers for making balance computations easier */
  if (myid == 0) {
    if (!ctrl->pijbm) {
      ctrl->pijbm = real_alloc(ctrl->nparts);
    }
    for (i=0;i<ctrl->nparts;++i) {
      ctrl->pijbm[i] = graph->invtvwgt / ctrl->tpwgts[i];
    }
  }
  dlthread_barrier(ctrl->comm);

  cut = __partition_mlevel_rb(ctrl,graph,0,where);

  if (myid == 0) {
    graph->mincut = cut;
  }

  dlthread_barrier(ctrl->comm);
}


void par_partition_vertexseparator(
    ctrl_t * const ctrl, 
    graph_t * const graph, 
    pid_t ** const where)
{
  __partition_mlevel_vsep(ctrl,graph,where);
}


void par_partition_edgeseparator(
    ctrl_t * const ctrl, 
    graph_t * const graph, 
    pid_t ** const where)
{
  wgt_t cut;
  pid_t i;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  /* set up multipliers for making balance computations easier */
  if (myid == 0) {
    if (!ctrl->pijbm) {
      ctrl->pijbm = real_alloc(ctrl->nparts);
    }
    DL_ASSERT_EQUALS(ctrl->nparts,(pid_t)2,"%"PF_PID_T);
    for (i=0;i<ctrl->nparts;++i) {
      ctrl->pijbm[i] = graph->invtvwgt / ctrl->tpwgts[i];
    }
  }
  dlthread_barrier(ctrl->comm);

  cut = __partition_mlevel_esep(ctrl,graph,where);
  if (myid == 0) {
    graph->mincut = cut;
  }

  dlthread_barrier(ctrl->comm);
}


void par_partition_pre(
    ctrl_t * const ctrl,
    graph_t * const graph)
{
  vtx_t i;
  double options[MTMETIS_NOPTIONS];
  ctrl_t * sctrl;
  pid_t ** dperm;

  tid_t const myid = dlthread_get_id(graph->comm);
  tid_t const nthreads = dlthread_get_nthreads(graph->comm);

  if (myid == 0) {
    dl_start_timer(&ctrl->timers.preprocess);

    graph->ngroup = nthreads*ctrl->partfactor;
    graph->group = r_pid_alloc(nthreads);

    double_set(options,MTMETIS_VAL_OFF,MTMETIS_NOPTIONS);
    options[MTMETIS_OPTION_NTHREADS] = ctrl->nthreads;
    options[MTMETIS_OPTION_NPARTS] = graph->ngroup; 
    options[MTMETIS_OPTION_NITER] = 3;
  }
  dperm = dlthread_get_shmem(sizeof(pid_t*)*nthreads,ctrl->comm);

  graph->group[myid] = pid_alloc(graph->mynvtxs[myid]);

  par_ctrl_parse(options,&sctrl,ctrl->comm);
  par_ctrl_setup(sctrl,graph->nvtxs);
  par_partition_kway(sctrl,graph,graph->group);
  par_ctrl_free(sctrl);

  dperm[myid] = pid_alloc(graph->mynvtxs[myid]);
  for (i=0;i<graph->mynvtxs[myid];++i) {
    dperm[myid][i] = graph->group[myid][i] % nthreads;
  }

  par_graph_shuffle(ctrl,graph,(pid_t const **)dperm,0);

  dl_free(dperm[myid]);

  if (myid == 0) {
    dl_stop_timer(&ctrl->timers.preprocess);
  }
  dlthread_free_shmem(dperm,ctrl->comm);
}





#endif

