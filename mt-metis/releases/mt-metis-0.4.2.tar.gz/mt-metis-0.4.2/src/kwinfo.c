/**
 * @file kwinfo.c
 * @brief Functions for allocating an manipulating kwinfos. 
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2014-09-19
 */





#ifndef MTMETIS_KWINFO_C
#define MTMETIS_KWINFO_C




#include "kwinfo.h"




/******************************************************************************
* DOMLIB MACROS ***************************************************************
******************************************************************************/


#define DLMEM_PREFIX kwnbrinfo
#define DLMEM_TYPE_T kwnbrinfo_t
#include <dlmem_funcs.h>
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX


#define DLMEM_PREFIX adjinfo
#define DLMEM_TYPE_T adjinfo_t
#include <dlmem_funcs.h>
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static size_t const MIN_NNBRPOOL = 1024;



/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


kwinfo_t * kwinfo_create(
    ctrl_t const * const ctrl,
    graph_t const * const graph)
{
  kwinfo_t * kwinfo;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  kwinfo = (kwinfo_t*)malloc(sizeof(kwinfo_t));

  kwinfo->nparts = ctrl->nparts;
  kwinfo->bnd = vtx_iset_create(0,graph->mynvtxs[myid]);
  kwinfo->nbrinfo = kwnbrinfo_alloc(graph->mynvtxs[myid]);
  kwinfo->nnbrpool = 0;
  kwinfo->maxnnbrpool = dl_max(graph->mynedges[myid]*4,MIN_NNBRPOOL);
  kwinfo->nbrpool = adjinfo_alloc(kwinfo->maxnnbrpool);

  return kwinfo;
}


void kwinfo_free(
    kwinfo_t * kwinfo)
{
  if (kwinfo->bnd) {
    vtx_iset_free(kwinfo->bnd);
  }
  if (kwinfo->nbrinfo) {
    dl_free(kwinfo->nbrinfo);
  }
  if (kwinfo->nbrpool) {
    dl_free(kwinfo->nbrpool);
  }
  dl_free(kwinfo);
}




#endif
