/**
 * @file esinfo.c
 * @brief Functions for manipulating esinfo structures.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2015, Regents of the University of Minnesota
 * @version 1
 * @date 2015-02-26
 */




#ifndef MTMETIS_ESINFO_C
#define MTMETIS_ESINFO_C




#include "esinfo.h"





/******************************************************************************
* DOMLIB MACROS ***************************************************************
******************************************************************************/


#define DLMEM_PREFIX esnbrinfo
#define DLMEM_TYPE_T esnbrinfo_t
#include <dlmem_funcs.h>
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


esinfo_t * esinfo_create(
    ctrl_t const * const ctrl,
    graph_t const * const graph)
{
  esinfo_t * esinfo;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  esinfo = (esinfo_t*)malloc(sizeof(esinfo_t));

  esinfo->bnd = vtx_iset_create(0,graph->mynvtxs[myid]);
  esinfo->nbrinfo = esnbrinfo_alloc(graph->mynvtxs[myid]);

  return esinfo;
}


void esinfo_free(
    esinfo_t * esinfo)
{
  if (esinfo->bnd) {
    vtx_iset_free(esinfo->bnd);
  }
  if (esinfo->nbrinfo) {
    dl_free(esinfo->nbrinfo);
  }
  dl_free(esinfo);
}




#endif


