/**
 * @file eseprefine.c
 * @brief Functions for performing refinement of two way edge separators.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2015, Regents of the University of Minnesota
 * @version 1
 * @date 2015-02-26
 */





#ifndef MTMETIS_ESEPREFINE_C
#define MTMETIS_ESEPREFINE_C




#include "eseprefine.h"
#include "check.h"




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef struct update_t {
  vtx_t v; 
  wgt_t w;
} update_t;




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLPQ_PREFIX vw
#define DLPQ_KEY_T wgt_t
#define DLPQ_VAL_T vtx_t
#define DLPQ_STATIC
#include "dlpq_headers.h"
#undef DLPQ_STATIC
#undef DLPQ_VAL_T
#undef DLPQ_KEY_T
#undef DLPQ_PREFIX


#define DLPQ_PREFIX vt
#define DLPQ_KEY_T wgt_t
#define DLPQ_VAL_T vtx_t
#define DLPQ_USE_HT
#define DLPQ_STATIC
#include "dlpq_headers.h"
#undef DLPQ_STATIC
#undef DLPQ_USE_HT
#undef DLPQ_VAL_T
#undef DLPQ_KEY_T
#undef DLPQ_PREFIX


#define DLLCB_PREFIX update
#define DLLCB_TYPE_T update_t
#define DLLCB_STATIC 1
#include "dllcb_headers.h"
#undef DLLCB_STATIC
#undef DLLCB_TYPE_T
#undef DLLCB_PREFIX


#define DLLCB_PREFIX vtx
#define DLLCB_TYPE_T vtx_t
#define DLLCB_STATIC 1
#include "dllcb_headers.h"
#undef DLLCB_STATIC
#undef DLLCB_TYPE_T
#undef DLLCB_PREFIX






/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static size_t const SERIAL_FM_FACTOR = 32768; /* 2^16 */
static size_t const MAX_HILL_SEARCH = 1024;
static vtx_t MAX_HILLS = 32;




/******************************************************************************
* PRIVATE SERIAL FUNCTIONS ****************************************************
******************************************************************************/


static inline pid_t __pick_side(
    graph_t const * const graph,
    wgt_t const maxpwgt,
    vw_pq_t * const * const q)
{
  vtx_t p, v, g;
  tid_t myid;
  pid_t side;

  wgt_t const * const pwgts = graph->pwgts;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;

  /* part next move properties */
  vtx_t vtx[2];
  wgt_t wgt[2], pri[2];

  /* determine stats for each side */
  for (p=0;p<MTMETIS_ESEP_NPARTS;++p) {
    if (q[p]->size > 0) {
      g = vtx[p] = vw_pq_peek(q[p]);
      v = gvtx_to_lvtx(g,graph->dist);
      myid = gvtx_to_tid(g,graph->dist);
      pri[p] = vw_pq_top(q[p]);
      wgt[p] = pwgts[p] + gvwgt[myid][v];
    } else {
      pri[p] = -maxpwgt; /* below what is possible for a valid priority */
      vtx[p] = NULL_VTX;
      wgt[p] = NULL_WGT;
    }
  }

  /* figure out which side we'll use -- this seems like I could do it 
   * better */
  if (vtx[MTMETIS_ESEP_PARTA] == NULL_VTX && \
      vtx[MTMETIS_ESEP_PARTB] == NULL_VTX) {
    /* exit loop -- both queues are empty */
    return NULL_PID;
  } else if (pri[MTMETIS_ESEP_PARTA] > pri[MTMETIS_ESEP_PARTB]) {
    side = MTMETIS_ESEP_PARTA;
  } else if (pri[MTMETIS_ESEP_PARTA] < pri[MTMETIS_ESEP_PARTB]) {
    side = MTMETIS_ESEP_PARTB;
  } else {
    if (wgt[MTMETIS_ESEP_PARTA] < wgt[MTMETIS_ESEP_PARTB]) {
      side = MTMETIS_ESEP_PARTA;
    } else if (wgt[MTMETIS_ESEP_PARTA] > wgt[MTMETIS_ESEP_PARTB]) {
      side = MTMETIS_ESEP_PARTB;
    } else {
      /* alternate sides */
      side = (q[MTMETIS_ESEP_PARTA]->size + q[MTMETIS_ESEP_PARTB]->size) % 2;
    } 
  }

  /* make sure it will be balanced */
  if (wgt[side] > maxpwgt) {
    side = side ^ 0x01;
    if (vtx[side] == NULL_VTX) {
      /* the other side is empty */
      return NULL_PID;
    }
  }

  DL_ASSERT(q[side]->size > 0,"Choosing side with empty queue");

  return side;
}


static void __move_vertex_1S(
    tid_t const myid,
    vtx_t const v,
    pid_t const side,
    graph_t * const graph,
    esnbrinfo_t * const * const gnbrinfo,
    vtx_iset_t * const * const gbnd,
    vw_pq_t * const q)
{
  vtx_t k, lvtx;
  adj_t j;
  tid_t nbrid;
  wgt_t gain;

  vtx_t const * const gmynvtxs = graph->mynvtxs;
  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;
  wgt_t const * const * const gadjwgt = (wgt_t const **)graph->adjwgt;

  wgt_t * const pwgts = graph->pwgts;
  pid_t * const * const gwhere = graph->where;

  pid_t const other = side ^ 0x01;

  gwhere[myid][v] = side;

  pwgts[side] += gvwgt[myid][v];
  pwgts[other] -= gvwgt[myid][v];

  /* process edges */
  for (j=gxadj[myid][v];j<gxadj[myid][v+1];++j) {
    k = gadjncy[myid][j];
    if (k < gmynvtxs[myid]) {
      lvtx = k;
      nbrid = myid;
      k = lvtx_to_gvtx(k,myid,graph->dist);
    } else {
      lvtx = gvtx_to_lvtx(k,graph->dist);
      nbrid = gvtx_to_tid(k,graph->dist);
    }

    /* update connectivity */
    gnbrinfo[nbrid][lvtx].con[side] += gadjwgt[myid][j];
    gnbrinfo[nbrid][lvtx].con[other] -= gadjwgt[myid][j];

    /* remove or add to boundary */
    if (gwhere[nbrid][lvtx] == side) {
      if (gnbrinfo[nbrid][lvtx].con[other] == 0) {
        vtx_iset_remove(lvtx,gbnd[nbrid]);
      }
    } else {
      if (!vtx_iset_contains(lvtx,gbnd[nbrid])) {
        vtx_iset_add(lvtx,gbnd[nbrid]);
        /* add to queue */
        if (q) {
          gain = gnbrinfo[nbrid][lvtx].con[side] - \
              gnbrinfo[nbrid][lvtx].con[other];
          vw_pq_push(gain,k,q);
        }
      } else {
        if (q && vw_pq_contains(k,q)) {
          gain = gnbrinfo[nbrid][lvtx].con[side] - \
              gnbrinfo[nbrid][lvtx].con[other];
          vw_pq_update(gain,k,q);
        }
      }
    }
  }

  /* see if I need to be added to or removed from the boundary */
  if (gnbrinfo[myid][v].con[other] > 0) {
    if (!vtx_iset_contains(v,gbnd[myid])) {
      vtx_iset_add(v,gbnd[myid]);
    }
  } else if (gnbrinfo[myid][v].con[side] > 0) {
    /* Only non-island vertices get removed from the boundary */
    if (vtx_iset_contains(v,gbnd[myid])) {
      vtx_iset_remove(v,gbnd[myid]);
    }
  }
}


static void __move_vertex_2S(
    tid_t const myid,
    vtx_t const v,
    pid_t const side,
    int * const * const lock,
    graph_t * const graph,
    esnbrinfo_t * const * const gnbrinfo,
    vtx_iset_t * const * const gbnd,
    vw_pq_t * const * const q)
{
  vtx_t k, lvtx;
  adj_t j;
  tid_t nbrid;
  wgt_t gain;

  vtx_t const * const gmynvtxs = graph->mynvtxs;
  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;
  wgt_t const * const * const gadjwgt = (wgt_t const **)graph->adjwgt;

  wgt_t * const pwgts = graph->pwgts;
  pid_t * const * const gwhere = graph->where;

  pid_t const other = side ^ 0x01;

  lock[myid][v] = 1;
  gwhere[myid][v] = side;

  pwgts[side] += gvwgt[myid][v];
  pwgts[other] -= gvwgt[myid][v];

  /* process edges */
  for (j=gxadj[myid][v];j<gxadj[myid][v+1];++j) {
    k = gadjncy[myid][j];
    if (k < gmynvtxs[myid]) {
      lvtx = k;
      nbrid = myid;
      k = lvtx_to_gvtx(k,myid,graph->dist);
    } else {
      lvtx = gvtx_to_lvtx(k,graph->dist);
      nbrid = gvtx_to_tid(k,graph->dist);
    }

    /* update connectivity */
    gnbrinfo[nbrid][lvtx].con[side] += gadjwgt[myid][j];
    gnbrinfo[nbrid][lvtx].con[other] -= gadjwgt[myid][j];

    /* remove or add to boundary */
    if (gwhere[nbrid][lvtx] == side) {
      if (gnbrinfo[nbrid][lvtx].con[other] == 0) {
        vtx_iset_remove(lvtx,gbnd[nbrid]);
      } else {
        if (q && !lock[nbrid][lvtx]) {
          gain = gnbrinfo[nbrid][lvtx].con[other] - \
              gnbrinfo[nbrid][lvtx].con[side];
          if (vw_pq_contains(k,q[other])) {
            vw_pq_update(gain,k,q[other]);
          } else {
            vw_pq_push(gain,k,q[other]);
          }
        }
      }
    } else {
      if (!vtx_iset_contains(lvtx,gbnd[nbrid])) {
        vtx_iset_add(lvtx,gbnd[nbrid]);
        /* add to queue */
        if (q && !lock[nbrid][lvtx]) {
          gain = gnbrinfo[nbrid][lvtx].con[side] - \
              gnbrinfo[nbrid][lvtx].con[other];
          vw_pq_push(gain,k,q[side]);
        }
      } else {
        if (q && !lock[nbrid][lvtx] && vw_pq_contains(k,q[side])) {
          gain = gnbrinfo[nbrid][lvtx].con[side] - \
              gnbrinfo[nbrid][lvtx].con[other];
          vw_pq_update(gain,k,q[side]);
        }
      }
    }
  }

  /* see if I need to be added to or removed from the boundary */
  if (gnbrinfo[myid][v].con[other] > 0) {
    if (!vtx_iset_contains(v,gbnd[myid])) {
      vtx_iset_add(v,gbnd[myid]);
    }
  } else if (gnbrinfo[myid][v].con[side] > 0) {
    /* Only non-island vertices get removed from the boundary */
    if (vtx_iset_contains(v,gbnd[myid])) {
      vtx_iset_remove(v,gbnd[myid]);
    }
  }
}


static vtx_t __pass_GREEDY(
    pid_t const side,
    graph_t * const graph,
    wgt_t const maxpwgt,
    esnbrinfo_t * const * const gnbrinfo,
    vtx_iset_t * const * const gbnd,
    vw_pq_t * const q)
{
  vtx_t g, v, i, nmoves;
  pid_t other;
  tid_t myid;
  wgt_t mincut, curcut, minbal, curbal, gain;
  esnbrinfo_t * myrinfo;

  wgt_t * const pwgts = graph->pwgts;
  pid_t * const * const gwhere = graph->where;
  vtx_t const nvtxs = graph->nvtxs;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;
  tid_t const nthreads = graph->dist.nthreads;

  other = side ^ 0x01;

  /* move vertices to 'side' from 'other' */

  nmoves = 0;
  minbal = wgt_abs_diff(pwgts[0],pwgts[1]);

  vw_pq_clear(q);
  for (myid=0;myid<nthreads;++myid) {
    for (i=0;i<gbnd[myid]->size;++i) {
      v = vtx_iset_get(i,gbnd[myid]); 
      /* only add vertices in other partition */
      if (gwhere[myid][v] == other) {
        myrinfo = gnbrinfo[myid] + v;
        g = lvtx_to_gvtx(v,myid,graph->dist);
        gain = myrinfo->con[side] - myrinfo->con[other];
        vw_pq_push(gain,g,q);
      }
    }
  }

  curcut = mincut = graph->mincut;

  /* make possible moves */
  while (nmoves < nvtxs && (q->size > 0 && vw_pq_top(q) >= 0)) {
    g = vw_pq_pop(q);
    v = gvtx_to_lvtx(g,graph->dist);
    myid = gvtx_to_tid(g,graph->dist);

    DL_ASSERT_EQUALS(other,gwhere[myid][v],"%"PF_PID_T);

    if (pwgts[side] >= maxpwgt) {
      break;
    }

    if (pwgts[side]+gvwgt[myid][v] > maxpwgt && \
        pwgts[side]+gvwgt[myid][v] > pwgts[other]) {
      /* search for another vertex to move */
      continue;
    }

    myrinfo = gnbrinfo[myid] + v;

    curcut = curcut - (myrinfo->con[side] - myrinfo->con[other]);
    curbal = wgt_abs_diff(pwgts[side]+gvwgt[myid][v], \
        pwgts[other]-gnbrinfo[myid][v].con[other]);

    if (curcut < mincut || \
        (curcut == mincut && curbal < minbal)) {
      mincut = curcut;
      minbal = curbal;
    } else {
      break; 
    }
    
    ++nmoves;
    __move_vertex_1S(myid,v,side,graph,gnbrinfo,gbnd,q);
  }

  graph->mincut = mincut;

  return nmoves;
}


static vtx_t __eseprefine_HM1S(
    ctrl_t * const ctrl,
    graph_t * const graph,
    size_t const niter,
    esinfo_t * const esinfo,
    wgt_t const maxpwgt)
{
  vtx_t v, g, i, k, l, nmoves, totalmoves, ntotalmoves, hs, lvtx;
  adj_t j;
  wgt_t gain, hgain, cwgt;
  pid_t side, other, o, d;
  tid_t myid, nbrid;
  esnbrinfo_t * myrinfo;
  size_t pass;
  int ** hill;
  vtx_t * hlist;
  vw_pq_t * q, * qh;
  esnbrinfo_t ** gnbrinfo;
  vtx_iset_t ** gbnd;

  tid_t const nthreads = graph->dist.nthreads;

  vtx_t const * const gmynvtxs = graph->mynvtxs;
  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;
  wgt_t const * const * const gadjwgt = (wgt_t const **)graph->adjwgt;
  wgt_t * const pwgts = graph->pwgts;
  pid_t * const * const gwhere = graph->where;

  vtx_t const limit = ctrl->hillsize;

  myid = dlthread_get_id(ctrl->comm);

  gnbrinfo = dlthread_get_shmem((sizeof(esnbrinfo_t*)*nthreads) + \
      (sizeof(vtx_iset_t*)*nthreads),ctrl->comm);
  gbnd = (vtx_iset_t**)(gnbrinfo+nthreads);

  gnbrinfo[myid] = esinfo->nbrinfo;
  gbnd[myid] = esinfo->bnd;

  /* allocate stuff only needed by master thread */

  ntotalmoves = 0;

  /* make sure gbnd and gnbrinfo is set up */
  dlthread_barrier(ctrl->comm);

  if (myid == 0) {
    q = vw_pq_create(0,graph->gnvtxs);
    qh = vw_pq_create(0,graph->gnvtxs);

    hlist = vtx_alloc(limit);
    hill = r_int_alloc(nthreads);
    for (myid=0;myid<nthreads;++myid) {
      hill[myid] = int_init_alloc(0,gmynvtxs[myid]);
    }

    for (pass=0;pass<niter;++pass) {
      totalmoves = 0;

      if (pwgts[0] > pwgts[1]) {
        o = 1;
      } else if (pwgts[0] < pwgts[1]) {
        o = 0;
      } else {
        o = graph->level % 2;
      }

      for (d=0;d<2;++d) {
        side = (d+o) % 2;
        other = side ^ 0x01;

        /* move vertices to 'side' from 'other' */

        nmoves = 0;

        vw_pq_clear(q);
        for (myid=0;myid<nthreads;++myid) {
          for (i=0;i<gbnd[myid]->size;++i) {
            v = vtx_iset_get(i,gbnd[myid]); 
            /* only add vertices in other partition */
            if (gwhere[myid][v] == other) {
              myrinfo = gnbrinfo[myid] + v;
              g = lvtx_to_gvtx(v,myid,graph->dist);
              gain = myrinfo->con[side] - myrinfo->con[other];
              vw_pq_push(gain,g,q);
            }
          }
        }

        /* make possible moves */
        l = 0;
        while (l < MAX_HILLS && q->size > 0 && pwgts[side] < maxpwgt) {
          g = vw_pq_pop(q);
          v = gvtx_to_lvtx(g,graph->dist);
          myid = gvtx_to_tid(g,graph->dist);

          ++l;

          DL_ASSERT_EQUALS(other,gwhere[myid][v],"%"PF_PID_T);

          myrinfo = gnbrinfo[myid] + v;

          gain = myrinfo->con[side] - myrinfo->con[other];

          if (gain > 0) {
            if (gvwgt[myid][v] + pwgts[side] > maxpwgt) {
              continue;
            }
            hlist[0] = g;
            hs = 1;
            hgain = gain;
          } else {
            vw_pq_push(gain,g,qh);

            hs = 0;
            cwgt = 0;
            hgain = 0;
            while (qh->size > 0) {
              if (q->size > 0 && vw_pq_top(qh) < vw_pq_top(q)) {
                break;
              }

              gain = vw_pq_top(qh);
              g = vw_pq_pop(qh);
              i = gvtx_to_lvtx(g,graph->dist);
              myid = gvtx_to_tid(g,graph->dist);

              DL_ASSERT_EQUALS(hill[myid][i],0,"%d");

              cwgt += gvwgt[myid][i];
              if (cwgt + pwgts[side] > maxpwgt && \
                  cwgt + pwgts[side] > pwgts[other]) {
                /* don't bother build too heavy hills */
                break;
              }

              hgain += gain;

              myrinfo = gnbrinfo[myid] + i;

              hill[myid][i] = 1;
              hlist[hs++] = g;

              if (hgain > 0 || hs >= limit) {
                break;
              }

              for (j=gxadj[myid][i];j<gxadj[myid][i+1];++j) {
                k = gadjncy[myid][j];
                if (k < gmynvtxs[myid]) {
                  lvtx = k;
                  nbrid = myid;
                  k = lvtx_to_gvtx(lvtx,nbrid,graph->dist);
                } else {
                  lvtx = gvtx_to_lvtx(k,graph->dist);
                  nbrid = gvtx_to_tid(k,graph->dist);
                }
                if (!hill[nbrid][lvtx]) {
                  /* only consider unassigned vertices */
                  if (gwhere[nbrid][lvtx] == other) {
                    /* count edge weight twice as it detracts from current 
                     * vertex connectivity and neighbor vertex connectivity */
                    if (vw_pq_contains(k,qh)) {
                      vw_pq_updateadd(2*gadjwgt[myid][j],k,qh);
                    } else {
                      myrinfo = gnbrinfo[nbrid] + lvtx;
                      gain = myrinfo->con[side] - myrinfo->con[other] + \
                          2*gadjwgt[myid][j];
                      vw_pq_push(gain,k,qh);
                    }
                  }
                }
              }
            }
            vw_pq_clear(qh);

            if (hs == 0 || hgain < 0 || \
                (hgain == 0 && pwgts[side]+cwgt >= pwgts[other]-cwgt)) {
              /* get rid of hill */
              for (i=0;i<hs;++i) {
                g = hlist[i];
                v = gvtx_to_lvtx(g,graph->dist);
                myid = gvtx_to_tid(g,graph->dist);
                hill[myid][v] = 0;
              }
              continue;
            }
          }

          l = 0;
          
          /* move hill */
          for (i=0;i<hs;++i) {
            g = hlist[i];
            v = gvtx_to_lvtx(g,graph->dist);
            myid = gvtx_to_tid(g,graph->dist);

            if (vw_pq_contains(g,q)) {
              vw_pq_remove(g,q);
            }

            __move_vertex_1S(myid,v,side,graph,gnbrinfo,gbnd,q);
            ++nmoves;
            /* clear hill status */
            hill[myid][v] = 0;
          }

          graph->mincut -= hgain;
        }

        totalmoves += nmoves;
      }

      if (totalmoves == 0) {
        break;
      }
      ntotalmoves += totalmoves;
    }

    vw_pq_free(q);
    vw_pq_free(qh);
    dl_free(hlist);
    for (myid=0;myid<nthreads;++myid) {
      dl_free(hill[myid]);
    }
    dl_free(hill);
  }

  ntotalmoves = vtx_dlthread_broadcast(ntotalmoves,0,ctrl->comm);

  DL_ASSERT(check_esinfo(esinfo,graph,(pid_t const **)gwhere), \
      "Bad esinfo after refinement");

  dlthread_free_shmem(gnbrinfo,ctrl->comm);

  return ntotalmoves;
}


static vtx_t __eseprefine_FM1S(
    ctrl_t * const ctrl,
    graph_t * const graph,
    size_t const niter,
    esinfo_t * const esinfo,
    wgt_t const maxpwgt)
{
  vtx_t v, g, i, nmoves, totalmoves, minmove, ntotalmoves;
  wgt_t mincut, curcut, minbal, curbal, gain;
  pid_t side, other, o, d;
  tid_t myid;
  vtx_t * moves;
  esnbrinfo_t * myrinfo;
  size_t pass;
  vw_pq_t * q;
  esnbrinfo_t ** gnbrinfo;
  vtx_iset_t ** gbnd;

  tid_t const nthreads = graph->dist.nthreads;

  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;

  wgt_t * const pwgts = graph->pwgts;
  pid_t * const * const gwhere = graph->where;

  vtx_t const limit = ctrl->hillsize;

  myid = dlthread_get_id(ctrl->comm);

  gnbrinfo = dlthread_get_shmem((sizeof(esnbrinfo_t*)*nthreads) + \
      (sizeof(vtx_iset_t*)*nthreads),ctrl->comm);
  gbnd = (vtx_iset_t**)(gnbrinfo+nthreads);

  gnbrinfo[myid] = esinfo->nbrinfo;
  gbnd[myid] = esinfo->bnd;

  /* allocate stuff only needed by master thread */

  ntotalmoves = 0;

  /* make sure gbnd and gnbrinfo is set up */
  dlthread_barrier(ctrl->comm);

  if (myid == 0) {
    moves = vtx_alloc(graph->nvtxs);
    q = vw_pq_create(0,graph->gnvtxs);

    for (pass=0;pass<niter;++pass) {
      totalmoves = 0;

      if (pwgts[0] > pwgts[1]) {
        o = 1;
      } else if (pwgts[0] < pwgts[1]) {
        o = 0;
      } else {
        o = graph->level % 2;
      }

      for (d=0;d<2;++d) {
        side = (d+o) % 2;
        other = side ^ 0x01;

        /* move vertices to 'side' from 'other' */

        nmoves = 0;
        minmove = 0;
        minbal = wgt_abs_diff(pwgts[0],pwgts[1]);

        vw_pq_clear(q);
        for (myid=0;myid<nthreads;++myid) {
          for (i=0;i<gbnd[myid]->size;++i) {
            v = vtx_iset_get(i,gbnd[myid]); 
            /* only add vertices in other partition */
            if (gwhere[myid][v] == other) {
              myrinfo = gnbrinfo[myid] + v;
              g = lvtx_to_gvtx(v,myid,graph->dist);
              gain = myrinfo->con[side] - myrinfo->con[other];
              vw_pq_push(gain,g,q);
            }
          }
        }

        curcut = mincut = graph->mincut;

        /* make possible moves */
        while (q->size > 0) {
          g = vw_pq_pop(q);
          v = gvtx_to_lvtx(g,graph->dist);
          myid = gvtx_to_tid(g,graph->dist);

          DL_ASSERT_EQUALS(other,gwhere[myid][v],"%"PF_PID_T);

          if (pwgts[side] >= maxpwgt) {
            break;
          }

          if (pwgts[side]+gvwgt[myid][v] > maxpwgt && \
              pwgts[side]+gvwgt[myid][v] > pwgts[other]) {
            /* search for another vertex to move */
            continue;
          }

          myrinfo = gnbrinfo[myid] + v;

          curcut = curcut - (myrinfo->con[side] - myrinfo->con[other]);
          curbal = wgt_abs_diff(pwgts[side]+gvwgt[myid][v], \
              pwgts[other]-gvwgt[myid][v]);

          if (curcut < mincut || \
              (curcut == mincut && curbal < minbal)) {
            mincut = curcut;
            minmove = nmoves+1;
            /* we only need to abs this here, as if its negative, it means the
             * move increases the balance */
            minbal = curbal;
          } else {
            if (nmoves-minmove+1 > limit) {
              /* revert back to best cut */
              break; 
            }
          }
          
          /* move the vertex */
          moves[++nmoves] = g;

          __move_vertex_1S(myid,v,side,graph,gnbrinfo,gbnd,q);
        }

        /* undo bad moves */
        while (nmoves > minmove) {
          g = moves[nmoves];

          v = gvtx_to_lvtx(g,graph->dist);
          myid = gvtx_to_tid(g,graph->dist);

          __move_vertex_1S(myid,v,other,graph,gnbrinfo,gbnd,NULL);

          --nmoves;
        }
        graph->mincut = mincut;
        totalmoves += nmoves;
      }

      if (totalmoves == 0) {
        break;
      }
      ntotalmoves += totalmoves;
    }

    dl_free(moves);
    vw_pq_free(q);

    /* restore my id */
    myid = 0;
  }

  ntotalmoves = vtx_dlthread_broadcast(ntotalmoves,0,ctrl->comm);

  DL_ASSERT(check_esinfo(esinfo,graph,(pid_t const **)gwhere), \
      "Bad esinfo after refinement");
  DL_ASSERT(check_esbnd(gbnd[myid],graph),"Bad boundary after " \
      "refinement");

  dlthread_free_shmem(gnbrinfo,ctrl->comm);

  return ntotalmoves;
}


static vtx_t __eseprefine_FM2S(
    ctrl_t * const ctrl,
    graph_t * const graph,
    size_t const niter,
    esinfo_t * const esinfo,
    wgt_t const maxpwgt)
{
  vtx_t v, g, i, nmoves, minmove, ntotalmoves;
  wgt_t mincut, curcut, minbal, curbal, gain;
  pid_t side, other;
  tid_t myid;
  vtx_t * moves;
  int ** lock;
  esnbrinfo_t * myrinfo;
  size_t pass;
  vw_pq_t * q[2];
  esnbrinfo_t ** gnbrinfo;
  vtx_iset_t ** gbnd;

  tid_t const nthreads = graph->dist.nthreads;

  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;

  wgt_t * const pwgts = graph->pwgts;
  pid_t * const * const gwhere = graph->where;

  vtx_t const limit = ctrl->hillsize;

  myid = dlthread_get_id(ctrl->comm);

  gnbrinfo = dlthread_get_shmem((sizeof(esnbrinfo_t*)*nthreads) + \
      (sizeof(vtx_iset_t*)*nthreads)+(sizeof(int*)*nthreads),ctrl->comm);
  gbnd = (vtx_iset_t**)(gnbrinfo+nthreads);
  lock = (int**)(gbnd+nthreads);

  gnbrinfo[myid] = esinfo->nbrinfo;
  gbnd[myid] = esinfo->bnd;
  lock[myid] = int_init_alloc(0,graph->mynvtxs[myid]);

  /* allocate stuff only needed by master thread */

  ntotalmoves = 0;

  if (myid == 0) {
    moves = vtx_alloc(graph->nvtxs);
    q[0] = vw_pq_create(0,graph->gnvtxs);
    q[1] = vw_pq_create(0,graph->gnvtxs);

    for (pass=0;pass<niter;++pass) {
      /* move vertices to 'side' from 'other' */
      nmoves = 0;
      minmove = 0;
      minbal = wgt_abs_diff(pwgts[0],pwgts[1]);

      vw_pq_clear(q[0]);
      vw_pq_clear(q[1]);
      for (myid=0;myid<nthreads;++myid) {
        for (i=0;i<gbnd[myid]->size;++i) {
          v = vtx_iset_get(i,gbnd[myid]); 
          /* only add vertices in other partition */
          other = gwhere[myid][v];
          side = other ^ 0x01;
          myrinfo = gnbrinfo[myid] + v;
          g = lvtx_to_gvtx(v,myid,graph->dist);
          gain = myrinfo->con[side] - myrinfo->con[other];
          vw_pq_push(gain,g,q[side]);
        }
      }

      curcut = mincut = graph->mincut;

      /* make possible moves */
      while (q[0]->size + q[1]->size > 0) {
        side = __pick_side(graph,maxpwgt,q);
        other = side ^ 0x01;

        /* handles invalid moves */
        if (side == NULL_PID) {
          break;
        }

        g = vw_pq_pop(q[side]);

        v = gvtx_to_lvtx(g,graph->dist);
        myid = gvtx_to_tid(g,graph->dist);

        DL_ASSERT_EQUALS(other,gwhere[myid][v],"%"PF_PID_T);

        if (pwgts[side]+gvwgt[myid][v] > maxpwgt && \
            pwgts[side]+gvwgt[myid][v] > pwgts[other]) {
          /* search for another vertex to move */
          continue;
        }

        myrinfo = gnbrinfo[myid] + v;

        curcut = curcut - (myrinfo->con[side] - myrinfo->con[other]);
        curbal = wgt_abs_diff(pwgts[side]+gvwgt[myid][v], \
            pwgts[other]-gvwgt[myid][v]);

        if (curcut < mincut || \
            (curcut == mincut && curbal < minbal)) {
          mincut = curcut;
          minmove = nmoves+1;
          /* we only need to abs this here, as if its negative, it means the
           * move increases the balance */
          minbal = curbal;
        } else {
          if (nmoves-minmove+1 > limit) {
            /* revert back to best cut */
            break; 
          }
        }
        
        /* move the vertex */
        moves[++nmoves] = g;

        __move_vertex_2S(myid,v,side,lock,graph,gnbrinfo,gbnd,q);
      }

      /* undo bad moves */
      while (nmoves > minmove) {
        g = moves[nmoves];
        v = gvtx_to_lvtx(g,graph->dist);
        myid = gvtx_to_tid(g,graph->dist);

        other = gwhere[myid][v] ^ 0x01;

        __move_vertex_1S(myid,v,other,graph,gnbrinfo,gbnd,NULL);

        /* unlock vertex */
        lock[myid][v] = 0;

        --nmoves;
      }
      /* unlock remaining vertices */
      for (i=1;i<=nmoves;++i) {
        g = moves[i];
        v = gvtx_to_lvtx(g,graph->dist);
        myid = gvtx_to_tid(g,graph->dist);

        lock[myid][v] = 0;
      }
      graph->mincut = mincut;

      if (nmoves == 0) {
        break;
      }
      ntotalmoves += nmoves;
    }

    dl_free(moves);
    vw_pq_free(q[0]);
    vw_pq_free(q[1]);
  }

  ntotalmoves = vtx_dlthread_broadcast(ntotalmoves,0,ctrl->comm);

  DL_ASSERT(check_esinfo(esinfo,graph,(pid_t const **)gwhere), \
      "Bad esinfo after refinement");
  DL_ASSERT(check_esbnd(gbnd[myid],graph),"Bad boundary after " \
      "refinement");

  dl_free(lock[myid]);

  dlthread_free_shmem(gnbrinfo,ctrl->comm);

  return ntotalmoves;
}




/******************************************************************************
* PRIVATE PARALLEL FUNCTIONS **************************************************
******************************************************************************/


static inline void __par_sync_pwgts(
    tid_t const myid,
    wgt_t * const gpwgts,
    wgt_t * const lpwgts,
    dlthread_comm_t const comm)
{
  /* turn local pwgts into deltas */
  lpwgts[0] -= gpwgts[0];
  lpwgts[1] -= gpwgts[1];

  /* create global deltas */
  wgt_dlthread_sumareduce(lpwgts,3,comm);

  /* set local pwgts to be global pwgts */
  lpwgts[0] += gpwgts[0];
  lpwgts[1] += gpwgts[1];

  dlthread_barrier(comm);

  if (myid == 0) {
    /* re-sync global pwgts */
    gpwgts[0] = lpwgts[0];
    gpwgts[1] = lpwgts[1];
  }

  dlthread_barrier(comm);
}


static inline wgt_t __par_update_neighbor(
    pid_t const side,
    vtx_t const v,
    adj_t const ewgt,
    pid_t const * const where,
    esnbrinfo_t * const nbrinfo,
    vtx_iset_t * const bnd,
    vw_pq_t * const q)
{
  wgt_t cut, gain;

  pid_t const other = side ^ 0x01;

  /* update connectivity */
  nbrinfo[v].con[side] += ewgt;
  nbrinfo[v].con[other] -= ewgt;

  /* remove or add to boundary */
  if (where[v] == side) {
    cut = -ewgt;
    if (nbrinfo[v].con[other] == 0) {
      vtx_iset_remove(v,bnd);
    }
  } else {
    cut = ewgt;
    if (!vtx_iset_contains(v,bnd)) {
      vtx_iset_add(v,bnd);
      /* add to queue */
      if (q) {
        gain = nbrinfo[v].con[side] - \
            nbrinfo[v].con[other];
        vw_pq_push(gain,v,q);
      }
    } else {
      if (q) {
        gain = nbrinfo[v].con[side] - \
            nbrinfo[v].con[other];
        if (vw_pq_contains(v,q)) {
          gain = nbrinfo[v].con[side] - \
              nbrinfo[v].con[other];
          vw_pq_update(gain,v,q);
        } else {
          vw_pq_push(gain,v,q);
        }
      }
    }
  }

  DL_ASSERT(nbrinfo[v].con[other] >= 0,"Negative con %"PF_WGT_T":%"PF_WGT_T \
      " ewgt = %"PF_WGT_T" for %"PF_TID_T":%"PF_VTX_T"\n",nbrinfo[v].con[0], \
      nbrinfo[v].con[1],ewgt,(tid_t)dlthread_get_id(DLTHREAD_COMM_ROOT),v);

  return cut;
}


static wgt_t __par_move_vertex_1S(
    tid_t const myid,
    vtx_t const v,
    pid_t const side,
    graph_t * const graph,
    wgt_t * const pwgts,
    esnbrinfo_t * const nbrinfo,
    vtx_iset_t * const bnd,
    vw_pq_t * const q,
    update_combuffer_t * const combuffer)
{
  vtx_t k, lvtx;
  wgt_t cut;
  adj_t j;
  tid_t nbrid;
  update_t up;

  vtx_t const mynvtxs = graph->mynvtxs[myid];
  adj_t const * const xadj = graph->xadj[myid];
  vtx_t const * const adjncy = graph->adjncy[myid];
  wgt_t const * const vwgt = graph->vwgt[myid];
  wgt_t const * const adjwgt = graph->adjwgt[myid];

  pid_t * const where = graph->where[myid];

  pid_t const other = side ^ 0x01;

  cut = nbrinfo[v].con[other] - nbrinfo[v].con[side];

  where[v] = side;

  pwgts[side] += vwgt[v];
  pwgts[other] -= vwgt[v];

  /* process edges */
  for (j=xadj[v];j<xadj[v+1];++j) {
    k = adjncy[j];
    if (k < mynvtxs) {
      /* perform update myself */
      cut += __par_update_neighbor(side,k,adjwgt[j],where,nbrinfo,bnd,q);
    } else {
      lvtx = gvtx_to_lvtx(k,graph->dist);
      nbrid = gvtx_to_tid(k,graph->dist);

      /* buffer update for neighbor */
      up.v = lvtx;
      up.w = adjwgt[j];
      update_combuffer_add(nbrid,up,combuffer);
    }
  }

  /* see if I need to be added to or removed from the boundary */
  if (nbrinfo[v].con[other] > 0) {
    if (!vtx_iset_contains(v,bnd)) {
      vtx_iset_add(v,bnd);
    }
  } else if (nbrinfo[v].con[side] > 0) {
    /* Only non-island vertices get removed from the boundary */
    if (vtx_iset_contains(v,bnd)) {
      vtx_iset_remove(v,bnd);
    }
  }

  return cut;
}


static vtx_t __par_pass_GREEDY(
    pid_t const side,
    graph_t * const graph,
    wgt_t * const pwgts,
    wgt_t const maxpwgt,
    esnbrinfo_t * const nbrinfo,
    vtx_iset_t * const bnd,
    vw_pq_t * const q,
    update_combuffer_t * const combuffer,
    dlthread_comm_t const comm)
{
  vtx_t v, i, nmoves;
  pid_t other;
  wgt_t minbal, curbal, gain, cutdelta, mycut, ewgt;
  
  update_t up;
  esnbrinfo_t * myrinfo;

  tid_t const myid = dlthread_get_id(comm);

  pid_t * const where = graph->where[myid];
  wgt_t const * const vwgt = graph->vwgt[myid];

  other = side ^ 0x01;

  /* move vertices to 'side' from 'other' */

  mycut = 0;
  nmoves = 0;
  minbal = wgt_abs_diff(pwgts[0],pwgts[1]);

  vw_pq_clear(q);
  for (i=0;i<bnd->size;++i) {
    v = vtx_iset_get(i,bnd); 
    /* only add vertices in other partition */
    if (where[v] == other) {
      myrinfo = nbrinfo + v;
      gain = myrinfo->con[side] - myrinfo->con[other];
      vw_pq_push(gain,v,q);
    }
  }

  /* make possible moves */
  do {
    /* recieve updates from other threads */
    while (update_combuffer_next(&up,combuffer)) {
      v = up.v;
      ewgt = up.w;

      DL_ASSERT(v < graph->mynvtxs[myid],"Bad vertex attached to update: %" \
          PF_VTX_T"/%"PF_VTX_T,v,graph->mynvtxs[myid]);

      mycut += __par_update_neighbor(side,v,ewgt,where,nbrinfo,bnd,q);
    }

    if (pwgts[side] < maxpwgt && (q->size > 0 && vw_pq_top(q) >= 0)) {
      v = vw_pq_pop(q);

      DL_ASSERT_EQUALS(other,where[v],"%"PF_PID_T);

      if (pwgts[side]+vwgt[v] > maxpwgt && \
          pwgts[side]+vwgt[v] > pwgts[other]) {
        /* search for another vertex to move */
      } else {
        myrinfo = nbrinfo + v;

        cutdelta = (myrinfo->con[side] - myrinfo->con[other]);
        curbal = wgt_abs_diff(pwgts[side]+vwgt[v], \
            pwgts[other]-nbrinfo[v].con[other]);

        if (cutdelta > 0 || \
            (cutdelta == 0 && curbal < minbal)) {
          minbal = curbal;
          ++nmoves;

          mycut += __par_move_vertex_1S(myid,v,side,graph,pwgts,nbrinfo,bnd, \
              q,combuffer);
        }
      }
    }
  } while ((pwgts[side] < maxpwgt && (q->size > 0 && vw_pq_top(q) >= 0)) || \
      !update_combuffer_finish(combuffer));

  DL_ASSERT_EQUALS(update_combuffer_next(NULL,combuffer),0,"%d");

  update_combuffer_clear(combuffer);

  /* implicit barrier */
  mycut = wgt_dlthread_sumreduce(mycut,comm) / 2;

  if (myid == 0) {
    DL_ASSERT(mycut <= 0,"Greedy refinement increasing cutsize by %" \
        PF_WGT_T,mycut);
    graph->mincut += mycut;
  }

  return nmoves;
}


static vtx_t __par_eseprefine_GREEDY(
    ctrl_t * const ctrl,
    graph_t * const graph,
    size_t const niter,
    esinfo_t * const esinfo,
    wgt_t const maxpwgt)
{
  vtx_t totalmoves, ntotalmoves;
  pid_t side, o, d;
  size_t pass;
  wgt_t lpwgts[2];
  vw_pq_t * q;
  update_combuffer_t * combuffer;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  esnbrinfo_t * const nbrinfo = esinfo->nbrinfo;
  vtx_iset_t * const bnd = esinfo->bnd;
  wgt_t * const pwgts = graph->pwgts;

  combuffer = update_combuffer_create(graph->mynedges[myid],ctrl->comm);

  ntotalmoves = 0;
  q = vw_pq_create(0,graph->mynvtxs[myid]);

  for (pass=0;pass<niter;++pass) {
    totalmoves = 0;

    if (pwgts[0] > pwgts[1]) {
      o = 1;
    } else if (pwgts[0] < pwgts[1]) {
      o = 0;
    } else {
      o = graph->level % 2;
    }

    /* make sure all threads have selected the same 'o' */

    for (d=0;d<2;++d) {
      side = (d+o) % 2;

      wgt_copy(lpwgts,pwgts,2);

      dlthread_barrier(ctrl->comm);

      totalmoves += __par_pass_GREEDY(side,graph,lpwgts,maxpwgt,nbrinfo,bnd, \
          q,combuffer,ctrl->comm);

      __par_sync_pwgts(myid,pwgts,lpwgts,ctrl->comm);
    }

    totalmoves = vtx_dlthread_sumreduce(totalmoves,ctrl->comm);

    if (totalmoves == 0) {
      break;
    }
    ntotalmoves += totalmoves;
  }

  vw_pq_free(q);

  DL_ASSERT(check_esbnd(bnd,graph),"Bad boundary after refinement");
  DL_ASSERT(check_esinfo(esinfo,graph,(pid_t const **)graph->where), \
      "Bad esinfo after refinement");

  /* implicit barrier */
  update_combuffer_free(combuffer);

  return ntotalmoves;
}


static vtx_t __par_eseprefine_HM1S(
    ctrl_t * const ctrl,
    graph_t * const graph,
    size_t const niter,
    esinfo_t * const esinfo,
    wgt_t const maxpwgt)
{
  vtx_t v, g, i, k, l, nmoves, totalmoves, ntotalmoves, hs, lvtx;
  adj_t j;
  wgt_t gain, hgain, cwgt, mycut, ewgt;
  pid_t side, other, o, d;
  tid_t oid, nbrid;
  update_t up;
  esnbrinfo_t * myrinfo;
  size_t pass;
  wgt_t lpwgts[2];
  int ** hill;
  vtx_t * hlist;
  vw_pq_t * q;
  vt_pq_t * qh;
  esnbrinfo_t ** gnbrinfo;
  update_combuffer_t * ucb;
  vtx_combuffer_t * mcb;

  tid_t const myid = dlthread_get_id(ctrl->comm);
  tid_t const nthreads = dlthread_get_nthreads(ctrl->comm);

  vtx_t const * const gmynvtxs = graph->mynvtxs;
  adj_t const * const * const gxadj = (adj_t const **)graph->xadj;
  vtx_t const * const * const gadjncy = (vtx_t const **)graph->adjncy;
  wgt_t const * const * const gvwgt = (wgt_t const **)graph->vwgt;
  wgt_t const * const * const gadjwgt = (wgt_t const **)graph->adjwgt;
  wgt_t * const pwgts = graph->pwgts;
  pid_t * const * const gwhere = graph->where;
  vtx_t const limit = ctrl->hillsize;
  vtx_iset_t * const bnd = esinfo->bnd;
  vtx_t const maxnhills = MAX_HILLS / nthreads;

  gnbrinfo = dlthread_get_shmem((sizeof(esnbrinfo_t*)*nthreads) + \
      (sizeof(vtx_t*)*nthreads),ctrl->comm);
  hill = (int**)(gnbrinfo+nthreads);

  gnbrinfo[myid] = esinfo->nbrinfo;
  hill[myid] = int_init_alloc(0,gmynvtxs[myid]);

  ucb = update_combuffer_create(gxadj[myid][gmynvtxs[myid]],ctrl->comm);
  mcb = vtx_combuffer_create(gxadj[myid][gmynvtxs[myid]],ctrl->comm);

  /* allocate stuff only needed by master thread */

  ntotalmoves = 0;
  mycut = 0;

  q = vw_pq_create(0,gmynvtxs[myid]);
  qh = vt_pq_create(gmynvtxs[myid]);

  hlist = vtx_alloc(limit);

  for (pass=0;pass<niter;++pass) {
    totalmoves = 0;

    if (pwgts[0] > pwgts[1]) {
      o = 1;
    } else if (pwgts[0] < pwgts[1]) {
      o = 0;
    } else {
      o = graph->level % 2;
    }

    for (d=0;d<2;++d) {
      side = (d+o) % 2;
      other = side ^ 0x01;

      /* move vertices to 'side' from 'other' */

      nmoves = 0;

      vw_pq_clear(q);
      for (i=0;i<bnd->size;++i) {
        v = vtx_iset_get(i,bnd); 
        /* only add vertices in other partition */
        if (gwhere[myid][v] == other) {
          myrinfo = gnbrinfo[myid] + v;
          gain = myrinfo->con[side] - myrinfo->con[other];
          vw_pq_push(gain,v,q);
        }
      }

      /* get local copies of the partition weights */
      wgt_copy(lpwgts,pwgts,2);

      dlthread_barrier(ctrl->comm);

      /* make possible moves */
      l = 0;
      do {
        while (vtx_combuffer_next(&v,mcb)) {
          DL_ASSERT(v < graph->mynvtxs[myid],"Bad vertex attached to " \
              "move: %"PF_VTX_T"/%"PF_VTX_T"\n",v,graph->mynvtxs[myid]);

          if (gwhere[myid][v] != side) {
            if (vw_pq_contains(v,q)) {
              vw_pq_remove(v,q);
            }

            /* I have not moved this vertex yet */
            mycut += __par_move_vertex_1S(myid,v,side,graph,lpwgts, \
                gnbrinfo[myid],bnd,q,ucb);
          }
        }

        while (update_combuffer_next(&up,ucb)) {
          v = up.v;
          ewgt = up.w;

          DL_ASSERT(v < graph->mynvtxs[myid],"Bad vertex attached to " \
              "update: %"PF_VTX_T"/%"PF_VTX_T"\n",v,graph->mynvtxs[myid]);

          mycut += __par_update_neighbor(side,v,ewgt,gwhere[myid], \
              gnbrinfo[myid],bnd,q);
        }

        if (l < maxnhills && q->size > 0 && lpwgts[side] < maxpwgt) {
          v = vw_pq_pop(q);

          ++l;

          DL_ASSERT_EQUALS(other,gwhere[myid][v],"%"PF_PID_T);

          myrinfo = gnbrinfo[myid] + v;

          gain = myrinfo->con[side] - myrinfo->con[other];

          g = lvtx_to_gvtx(v,myid,graph->dist);

          if (gain > 0) {
            /* move single vertex */
            if (gvwgt[myid][v] + lpwgts[side] > maxpwgt) {
              continue;
            }
            hlist[0] = g;
            hs = 1;
            hgain = gain;
          } else {
            vt_pq_push(gain,g,qh);

            hs = 0;
            cwgt = 0;
            hgain = 0;
            while (qh->size > 0) {
              if (q->size > 0 && vt_pq_top(qh) < vw_pq_top(q)) {
                break;
              }

              gain = vt_pq_top(qh);

              g = vt_pq_pop(qh);
              i = gvtx_to_lvtx(g,graph->dist);
              oid = gvtx_to_tid(g,graph->dist);

              if (hill[oid][i]) {
                /* someone else scooped up this vertex */
                continue;
              }

              cwgt += gvwgt[oid][i];
              if (cwgt + lpwgts[side] > maxpwgt && \
                  cwgt + lpwgts[side] > pwgts[other]) {
                /* don't bother build too heavy hills */
                break;
              }

              hgain += gain;

              myrinfo = gnbrinfo[oid] + i;

              hill[oid][i] = 1;
              hlist[hs++] = g;

              if (hgain > 0 || hs >= limit) {
                break;
              }

              for (j=gxadj[oid][i];j<gxadj[oid][i+1];++j) {
                k = gadjncy[oid][j];
                if (k < gmynvtxs[oid]) {
                  lvtx = k;
                  nbrid = oid;
                  k = lvtx_to_gvtx(lvtx,nbrid,graph->dist);
                } else {
                  lvtx = gvtx_to_lvtx(k,graph->dist);
                  nbrid = gvtx_to_tid(k,graph->dist);
                }
                if (!hill[nbrid][lvtx]) {
                  /* only consider unassigned vertices */
                  if (gwhere[nbrid][lvtx] == other) {
                    /* count edge weight twice as it detracts from current 
                     * vertex connectivity and neighbor vertex connectivity */
                    if (vt_pq_contains(k,qh)) {
                      vt_pq_updateadd(2*gadjwgt[oid][j],k,qh);
                    } else {
                      myrinfo = gnbrinfo[nbrid] + lvtx;
                      gain = myrinfo->con[side] - myrinfo->con[other] + \
                          2*gadjwgt[oid][j];
                      vt_pq_push(gain,k,qh);
                    }
                  }
                }
              }
            }
            vt_pq_clear(qh);

            if (hs == 0 || hgain < 0 || \
                (hgain == 0 && lpwgts[side]+cwgt >= lpwgts[other]-cwgt)) {
              /* get rid of hill */
              for (i=0;i<hs;++i) {
                g = hlist[i];
                v = gvtx_to_lvtx(g,graph->dist);
                oid = gvtx_to_tid(g,graph->dist);
                hill[oid][v] = 0;
              }
              continue;
            }
          }

          l = 0;

          /* move hill */
          for (i=0;i<hs;++i) {
            g = hlist[i];
            v = gvtx_to_lvtx(g,graph->dist);
            oid = gvtx_to_tid(g,graph->dist);

            if (oid == myid) {
              if (vw_pq_contains(v,q)) {
                vw_pq_remove(v,q);
              }

              mycut += __par_move_vertex_1S(myid,v,side,graph,lpwgts, \
                  gnbrinfo[myid],bnd,q,ucb);
              ++nmoves;
              /* clear hill status */
              hill[myid][v] = 0;
            } else {
              /* queue for remote access */
              up.v = v;
              up.w = NULL_WGT; /* signal that this vertex is being moved */

              vtx_combuffer_add(oid,v,mcb);
            }
          }
        }

      } while ((l < maxnhills && q->size > 0 && lpwgts[side] < maxpwgt) || \
          !vtx_combuffer_finish(mcb) || !update_combuffer_finish(ucb));

      DL_ASSERT_EQUALS(vtx_combuffer_next(NULL,mcb),0,"%d");
      DL_ASSERT_EQUALS(update_combuffer_next(NULL,ucb),0,"%d");

      vtx_combuffer_clear(mcb);
      update_combuffer_clear(ucb);

      __par_sync_pwgts(myid,pwgts,lpwgts,ctrl->comm);

      totalmoves += nmoves;
    }

    totalmoves = vtx_dlthread_sumreduce(totalmoves,ctrl->comm);

    if (totalmoves == 0) {
      break;
    }
    ntotalmoves += totalmoves;
  }

  mycut = vtx_dlthread_sumreduce(mycut,ctrl->comm);
  if (myid == 0) {
    graph->mincut += mycut/2;
  }

  vw_pq_free(q);
  vt_pq_free(qh);
  dl_free(hlist);
  dl_free(hill[myid]);

  DL_ASSERT(check_esinfo(esinfo,graph,(pid_t const **)gwhere), \
      "Bad esinfo after refinement");

  dlthread_free_shmem(gnbrinfo,ctrl->comm);

  /* implicit barrier */
  update_combuffer_free(ucb);
  vtx_combuffer_free(mcb);

  return ntotalmoves;
}




/******************************************************************************
* PUBLIC PARALLEL FUNCTIONS ***************************************************
******************************************************************************/


vtx_t par_eseprefine(
    ctrl_t * const ctrl,
    graph_t * const graph,
    esinfo_t * const esinfo)
{
  vtx_t nmoves;

  tid_t const myid = dlthread_get_id(ctrl->comm);

  wgt_t * const pwgts = graph->pwgts;

  wgt_t const maxpwgt = ctrl->ubfactor*(pwgts[0]+pwgts[1])*0.5;

  if (myid == 0) {
    dl_start_timer(&(ctrl->timers.refinement));
  }

  DL_ASSERT(check_esinfo(esinfo,graph,(pid_t const **)graph->where), \
      "Bad esinfo before refinement");
  DL_ASSERT(check_esbnd(esinfo->bnd,graph),"Bad boundary before refinement");

  if (graph->nedges < SERIAL_FM_FACTOR*sqrt(graph->dist.nthreads)) {
    nmoves = __eseprefine_FM1S(ctrl,graph,ctrl->nrefpass,esinfo,maxpwgt);
  } else {
    switch (ctrl->rtype) {
      case MTMETIS_RTYPE_FM:
        nmoves = __eseprefine_FM1S(ctrl,graph,ctrl->nrefpass,esinfo,maxpwgt);
        break;
      case MTMETIS_RTYPE_GREEDY:
        nmoves = __par_eseprefine_GREEDY(ctrl,graph,ctrl->nrefpass,esinfo, \
            maxpwgt);
        break;
      case MTMETIS_RTYPE_HM:
        nmoves = __par_eseprefine_HM1S(ctrl,graph,ctrl->nrefpass,esinfo, \
            maxpwgt);
        break;
      default:
        dl_error("Unknown refinement type for edge separators '%d'\n", \
            ctrl->rtype);
    }
  }

  if (myid == 0) {
    dl_stop_timer(&(ctrl->timers.refinement));
  }

  DL_ASSERT_EQUALS(graph->mincut,par_graph_cut(graph, \
        (pid_t const **)graph->where),"%"PF_WGT_T);
  DL_ASSERT_EQUALS(wgt_sum(graph->pwgts,2),graph->tvwgt,"%"PF_WGT_T);
  DL_ASSERT(check_esbnd(esinfo->bnd,graph),"Bad boundary before refinement");

  par_vprintf(ctrl->verbosity,MTMETIS_VERBOSITY_HIGH,"%zu) [%"PF_VTX_T" %" \
      PF_ADJ_T"] {%"PF_WGT_T" %"PF_WGT_T" %"PF_WGT_T" # %"PF_WGT_T" %" \
      PF_VTX_T"}\n",graph->level,graph->nvtxs,graph->nedges,pwgts[0], \
      pwgts[1],graph->mincut,maxpwgt,nmoves);

  return nmoves;
}



#endif
