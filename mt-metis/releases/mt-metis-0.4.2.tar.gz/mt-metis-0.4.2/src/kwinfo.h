/**
 * @file kwinfo.h
 * @brief Types and function for uncoarsening information.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014, Regents of the University of Minnesota
 * @version 1
 * @date 2014-09-19
 */




#ifndef MTMETIS_KWINFO_H
#define MTMETIS_KWINFO_H




#include "base.h"
#include "graph.h"
#include "ctrl.h"




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef struct adjinfo_t {
  wgt_t ed;
  pid_t pid;
} adjinfo_t;


typedef struct kwnbrinfo_t {
  wgt_t id;
  wgt_t ed;
  pid_t nnbrs;
  adj_t nbrstart;
} kwnbrinfo_t;


typedef struct kwinfo_t {
  pid_t nparts;
  vtx_iset_t * bnd;
  kwnbrinfo_t * nbrinfo;
  vtx_t nnbrpool;
  vtx_t maxnnbrpool;
  adjinfo_t * nbrpool;
} kwinfo_t;



/******************************************************************************
* DOMLIB MACROS ***************************************************************
******************************************************************************/


#define DLMEM_PREFIX kwnbrinfo
#define DLMEM_TYPE_T kwnbrinfo_t
#include <dlmem_headers.h>
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX


#define DLMEM_PREFIX adjinfo
#define DLMEM_TYPE_T adjinfo_t
#include <dlmem_headers.h>
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


#define kwinfo_create __mtmetis_kwinfo_create
/**
 * @brief Allocate the memory arrays for refinement. 
 *
 * @param ctrl The control structure.
 * @param graph The graph.
 *
 * @return The thread's newly allocated kwinfo
 */
kwinfo_t * kwinfo_create(
    ctrl_t const * ctrl,
    graph_t const * graph);


#define kwinfo_free __mtmetis_kwinfo_free
/**
 * @brief Free a kwinfo and its associate memory.
 *
 * @param kwinfo The kwinfo to free.
 */
void kwinfo_free(
    kwinfo_t * kwinfo);




#endif
