To build mt-metis, use the traditional *nix style steps:

$ ./configure
$ make
$ make install

This should create and install the 'mt-metis' executable. For usage, type:

$ ./mt-metis -h

