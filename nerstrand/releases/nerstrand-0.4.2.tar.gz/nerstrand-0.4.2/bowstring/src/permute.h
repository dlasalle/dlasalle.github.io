/**
 * @file permute.h
 * @brief Graph re-ording utilities
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-07-18
 */




#ifndef PERMUTE_H
#define PERMUTE_H




#include "base.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


int permute_graph(
    vtx_t nvtxs, 
    adj_t * xadj, 
    vtx_t * adjncy, 
    wgt_t * vwgt, 
    wgt_t * adjwgt);


int reorder_graph(
    vtx_t nvtxs, 
    adj_t * xadj, 
    vtx_t * adjncy, 
    wgt_t * vwgt, 
    wgt_t * adjwgt, 
    const vtx_t * perm);




#endif
