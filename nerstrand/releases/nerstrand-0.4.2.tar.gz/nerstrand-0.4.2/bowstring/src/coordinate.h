/**
 * @file coordinate.h
 * @brief Function prototytes and types for embedding vertices in
 * coordinate-space
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-11-20
 */




#ifndef BOWSTRING_COORDINATE_H
#define BOWSTRING_COORDINATE_H




#include "base.h"




/******************************************************************************
* EMBEDDING FUNCTIONS *********************************************************
******************************************************************************/


int embed_BFS(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy,
    const wgt_t * adjwgt, 
    coord_t * coords, 
    size_t ncoords);




#endif
