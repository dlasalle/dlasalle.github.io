/**
 * @file dlmath_headers.h
 * @brief Mathematical function prototypes
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-06
 */




#ifndef DLMATH_STATIC



/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


/* prefixing ugliness */
#define DLMATH_PRE2(prefix,suffix) prefix ## _ ## suffix
#define DLMATH_PRE1(prefix,suffix) DLMATH_PRE2(prefix,suffix)
#define DLMATH_PUB(name) DLMATH_PRE1(DLMATH_PREFIX,name)
#define DLMATH_PRI(name) DLMATH_PRE1(_,DLMATH_PRE1(DLMATH_PREFIX,name))


DLMATH_TYPE_T DLMATH_PUB(sum)(const DLMATH_TYPE_T * ptr, size_t n);


DLMATH_TYPE_T DLMATH_PUB(product)(const DLMATH_TYPE_T * ptr, size_t n);


DLMATH_TYPE_T * DLMATH_PUB(differentiate)(DLMATH_TYPE_T * ptr, size_t n);


DLMATH_TYPE_T * DLMATH_PUB(prefixsum_inc)(DLMATH_TYPE_T * ptr, size_t n);


DLMATH_TYPE_T * DLMATH_PUB(prefixsum_exc)(DLMATH_TYPE_T * ptr, size_t n);


size_t DLMATH_PUB(find_max_index)(const DLMATH_TYPE_T * ptr, size_t n);


DLMATH_TYPE_T DLMATH_PUB(find_max_value)(const DLMATH_TYPE_T * ptr, size_t n);


DLMATH_TYPE_T * DLMATH_PUB(set_max)(DLMATH_TYPE_T * ptr, DLMATH_TYPE_T max, 
    size_t n);


size_t DLMATH_PUB(find_min_index)(const DLMATH_TYPE_T * ptr, size_t n);


DLMATH_TYPE_T DLMATH_PUB(find_min_value)(const DLMATH_TYPE_T * ptr, size_t n);


DLMATH_TYPE_T * DLMATH_PUB(set_min)(DLMATH_TYPE_T * ptr, DLMATH_TYPE_T min, 
    size_t n);


DLMATH_TYPE_T * DLMATH_PUB(incset)(DLMATH_TYPE_T * ptr, DLMATH_TYPE_T start, 
    DLMATH_TYPE_T inc, size_t n);


DLMATH_TYPE_T * DLMATH_PUB(cyclicperm)(DLMATH_TYPE_T * ptr, size_t cyclesize, 
    size_t n);


DLMATH_TYPE_T * DLMATH_PUB(blockcyclicperm)(DLMATH_TYPE_T * ptr, 
    size_t cyclesize, size_t blocksize, size_t n);


DLMATH_TYPE_T * DLMATH_PUB(max_merge)(DLMATH_TYPE_T * dst, 
    const DLMATH_TYPE_T * src, size_t n, DLMATH_TYPE_T empty_value);


DLMATH_TYPE_T * DLMATH_PUB(min_merge)(DLMATH_TYPE_T * dst, 
    const DLMATH_TYPE_T * src, size_t n, DLMATH_TYPE_T empty_value);


DLMATH_TYPE_T * DLMATH_PUB(avg_merge)(DLMATH_TYPE_T * dst, 
    const DLMATH_TYPE_T * src, size_t n, DLMATH_TYPE_T empty_value);


size_t DLMATH_PUB(intersection_size)(const DLMATH_TYPE_T * a, size_t n,
    const DLMATH_TYPE_T * b, size_t m);


#if defined(DLMATH_DLTYPE) && DLMATH_DLTYPE == DLTYPE_FLOAT


DLMATH_TYPE_T DLMATH_PUB(stable_sum)(const DLMATH_TYPE_T * ptr, size_t n);


long double DLMATH_PUB(fa_sum)(const DLMATH_TYPE_T * ptr, size_t n);


#endif


#if defined(DLMATH_DLTYPE) && DLMATH_DLTYPE == DLTYPE_INTEGRAL


DLMATH_TYPE_T DLMATH_PUB(uplog2)(DLMATH_TYPE_T n); 


DLMATH_TYPE_T DLMATH_PUB(downlog2)(DLMATH_TYPE_T n);


DLMATH_TYPE_T DLMATH_PUB(uppow2)(DLMATH_TYPE_T n);


DLMATH_TYPE_T DLMATH_PUB(downpow2)(DLMATH_TYPE_T n);


DLMATH_TYPE_T DLMATH_PUB(updiv)(DLMATH_TYPE_T a, DLMATH_TYPE_T b);


DLMATH_TYPE_T DLMATH_PUB(chunksize)(DLMATH_TYPE_T i, DLMATH_TYPE_T n, 
    DLMATH_TYPE_T m);


DLMATH_TYPE_T DLMATH_PUB(chunkstart)(DLMATH_TYPE_T i, DLMATH_TYPE_T n, 
    DLMATH_TYPE_T m);

DLMATH_TYPE_T DLMATH_PUB(reversebits)(DLMATH_TYPE_T n);


#endif




#undef DLMATH_PRE2
#undef DLMATH_PRE1
#undef DLMATH_PUB
#undef DLMATH_PRI


#else


#define DLMATH_VISIBILITY static
#include "dlmath_funcs.h"
#undef DLMATH_VISIBILITY


#endif
