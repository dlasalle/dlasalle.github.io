/**
 * @file tree.h
 * @brief Functions for generating trees in a graph
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-08-06
 */


#ifndef TREE_H
#define TREE_H

#include "base.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


int build_dfs_tree(vtx_t nvtxs, const adj_t * xadj, const vtx_t * adjncy, 
    vtx_t start, vtx_t * label, vtx_t * rank, adj_t * parent, int * adjmap);


int build_bfs_tree(vtx_t nvtxs, const adj_t * xadj, const vtx_t * adjncy, 
    vtx_t start, vtx_t * label, vtx_t * rank, adj_t * parent, int * adjmap);


int build_mst_tree(vtx_t nvtxs, const adj_t * xadj, const vtx_t * adjncy, 
    const wgt_t * adjwgt, int * adjmap);


int build_rst_tree(vtx_t nvtxs, const adj_t * xadj, const vtx_t * adjncy, 
    int * adjmap);


#endif
