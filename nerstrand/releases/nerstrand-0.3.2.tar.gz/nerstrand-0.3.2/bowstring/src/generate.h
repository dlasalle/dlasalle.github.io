/**
 * @file generate.h
 * @brief Function prototypes for generating graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-19
 */




#ifndef BOWSTRING_GENERATE_H
#define BOWSTRING_GENERATE_H




#include "base.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


int generate_complete_graph(vtx_t nvtxs, adj_t ** r_xadj, vtx_t ** r_adjncy,
    wgt_t ** r_vwgt, wgt_t ** r_adjwgt);


int generate_caveman_graph(vtx_t nvtxs, adj_t ** r_xadj, vtx_t ** r_adjncy, 
    wgt_t ** r_vwgt, wgt_t ** r_adjwgt, vtx_t ncaves, adj_t nlinks, 
    wgt_t intwgt, wgt_t extwgt);


int generate_grid_graph(vtx_t nvx, vtx_t nvy, vtx_t nvz, adj_t ** r_xadj, 
    vtx_t ** r_adjncy, wgt_t ** r_vwgt, wgt_t ** r_adjwgt);




#endif

