/**
 * @file dlutil.h
 * @brief Utility functions (moslty timing)
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-09-11
 */


#ifndef DL_UTIL_H
#define DL_UTIL_H

#include "domlib.h"




/******************************************************************************
* Enums and Structs ***********************************************************
******************************************************************************/


typedef enum dl_timer_state_t {
  DL_TIMER_RUNNING = 1,
  DL_TIMER_STOPPED = 2
} dl_timer_state_t;


typedef struct dl_timer_t {
    double duration;
    double start;
    dl_timer_state_t state;
} dl_timer_t;




/******************************************************************************
* Function Prototypes *********************************************************
******************************************************************************/


int dl_to_bytes(void * dst, const void * src, size_t width);
int dl_from_bytes(void * dst, const void * src, size_t width);
double dl_wctime(void);
void dl_init_timer(dl_timer_t * timer);
double dl_start_timer(dl_timer_t * timer);
double dl_stop_timer(dl_timer_t * timer);
double dl_reset_timer(dl_timer_t * timer);
double dl_poll_timer(const dl_timer_t * timer);
double dl_diff_timer(const dl_timer_t * timer1, const dl_timer_t * timer2);
void dl_init_rand(void); 
void dl_set_rand(unsigned int seed);
unsigned int * dl_get_rand(void);




#endif
