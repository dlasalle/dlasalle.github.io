/**
 * @file dlblas_headers.h
 * @brief Basic linear algebra prototypes
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-09-29
 */




/* prefixing ugliness */
#define DLBLAS_PRE2(prefix,suffix) prefix ## _ ## suffix
#define DLBLAS_PRE1(prefix,suffix) DLBLAS_PRE2(prefix,suffix)
#define DLBLAS_PUB(name) DLBLAS_PRE1(DLBLAS_PREFIX,name)




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


/* Sparse Matrix */
typedef struct DLBLAS_PUB(sparse_matrix_t) {
    size_t n,m;
    ssize_t nnz,nner,nnec;
    size_t *ptr, *ind;
    DLBLAS_TYPE_T * val;
} DLBLAS_PUB(sparse_matrix_t);


/* Sparse Vector */
typedef struct DLBLAS_PUB(sparse_vector_t) {
    size_t n;
    ssize_t nnz;
    size_t * ind;
    DLBLAS_TYPE_T * val;
} DLBLAS_PUB(sparse_vector_t);


/* Dense Matrix */
typedef struct DLBLAS_PUB(dense_matrix_t) {
    size_t n,m;
    DLBLAS_TYPE_T ** val;
} DLBLAS_PUB(dense_matrix_t);


/* Dense Vector */
typedef struct DLBLAS_PUB(dense_vector_t) {
    size_t n;
    DLBLAS_TYPE_T * val;
} DLBLAS_PUB(dense_vector_t);



/******************************************************************************
* MEMORY FUNCTIONS ************************************************************
******************************************************************************/


#define DLMEM_PREFIX DLBLAS_PUB(sparse_matrix)
#define DLMEM_TYPE_T DLBLAS_PUB(sparse_matrix_t)
#include "dlmem_headers.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


#define DLMEM_PREFIX DLBLAS_PUB(dense_matrix)
#define DLMEM_TYPE_T DLBLAS_PUB(dense_matrix_t)
#include "dlmem_headers.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


#define DLMEM_PREFIX DLBLAS_PUB(sparse_vector)
#define DLMEM_TYPE_T DLBLAS_PUB(sparse_vector_t)
#include "dlmem_headers.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


#define DLMEM_PREFIX DLBLAS_PUB(dense_vector)
#define DLMEM_TYPE_T DLBLAS_PUB(dense_vector_t)
#include "dlmem_headers.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


/* Initialization */

DLBLAS_PUB(sparse_matrix_t) * DLBLAS_PUB(sm_init)(size_t n, size_t m, 
    ssize_t nnz);


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sv_init)(size_t n, ssize_t nnz);


DLBLAS_PUB(dense_matrix_t) * DLBLAS_PUB(dm_init)(size_t n, size_t m);


DLBLAS_PUB(dense_vector_t) * DLBLAS_PUB(dv_init)(size_t n);


ssize_t DLBLAS_PUB(sm_update_nner)(DLBLAS_PUB(sparse_matrix_t) * mat);


ssize_t DLBLAS_PUB(sm_update_nnec)(DLBLAS_PUB(sparse_matrix_t) * mat);


/* Zeroing */

DLBLAS_PUB(dense_matrix_t) * DLBLAS_PUB(dm_zero)(
    DLBLAS_PUB(dense_matrix_t) * mat);


DLBLAS_PUB(dense_vector_t) * DLBLAS_PUB(dv_zero)(
    DLBLAS_PUB(dense_vector_t) * vec);


/* Transformation */

DLBLAS_PUB(sparse_matrix_t) * DLBLAS_PUB(dm_sparsify)(
    DLBLAS_PUB(dense_matrix_t) * mat);


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(dv_sparsify)(
    DLBLAS_PUB(dense_vector_t) * vec);


DLBLAS_PUB(dense_matrix_t) * DLBLAS_PUB(sm_densify)(
    DLBLAS_PUB(sparse_matrix_t) * mat);


DLBLAS_PUB(dense_vector_t) * DLBLAS_PUB(sv_densify)(
    DLBLAS_PUB(sparse_vector_t) * vec);


DLBLAS_PUB(sparse_matrix_t) * DLBLAS_PUB(sm_transpose)(
    DLBLAS_PUB(sparse_matrix_t) * mat);


DLBLAS_PUB(dense_matrix_t) * DLBLAS_PUB(dm_transpose)(
    DLBLAS_PUB(dense_matrix_t) * mat);


DLBLAS_PUB(sparse_matrix_t) * DLBLAS_PUB(sm_transpose_inplace)(
    DLBLAS_PUB(sparse_matrix_t) * mat);


DLBLAS_PUB(dense_matrix_t) * DLBLAS_PUB(dm_transpose_inplace)(
    DLBLAS_PUB(dense_matrix_t) * mat);


/* Subdivision */

DLBLAS_PUB(sparse_matrix_t) * DLBLAS_PUB(sm_submatrix)(
    DLBLAS_PUB(sparse_matrix_t) * mat, size_t si, size_t sj, size_t n, 
    size_t m);


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sv_subvector)(
    DLBLAS_PUB(sparse_vector_t) * vec, size_t si, size_t n);


/* Multiplication */

DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sm_multiply_sv)(
    DLBLAS_PUB(sparse_matrix_t) * mat, DLBLAS_PUB(sparse_vector_t) * vec);


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sm_multiply_dv)(
    DLBLAS_PUB(sparse_matrix_t) * mat, DLBLAS_PUB(dense_vector_t) * vec);


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sv_multiply_sm)(
    DLBLAS_PUB(sparse_vector_t) * vec, DLBLAS_PUB(sparse_matrix_t) * mat);


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sm_transmult_sv)(
    DLBLAS_PUB(sparse_matrix_t) * mat, DLBLAS_PUB(sparse_vector_t) * vec);


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sv_transmult_sm)(
    DLBLAS_PUB(sparse_vector_t) * vec, DLBLAS_PUB(sparse_matrix_t) * mat);


/* Freeing */

void DLBLAS_PUB(sm_free)(DLBLAS_PUB(sparse_matrix_t) * mat);


void DLBLAS_PUB(sv_free)(DLBLAS_PUB(sparse_vector_t) * vec);


void DLBLAS_PUB(dm_free)(DLBLAS_PUB(dense_matrix_t) * mat);


void DLBLAS_PUB(dv_free)(DLBLAS_PUB(dense_vector_t) * vec);




#undef DLBLAS_PRE1
#undef DLBLAS_PRE2
#undef DLBLAS_PUB

