#ifndef NERSTRAND_IO_H
#define NERSTRAND_IO_H

#include "base.h"
#include "objective.h"
#include "graph.h"
#include "cluster.h"


/******************************************************************************
* DEFINES *********************************************************************
******************************************************************************/
#define NERSTRAND_BINARY_CLUSTER_HEADER 0x646f6d63
#define NERSTRAND_BINARY_CLUSTER_VERSION 1

/******************************************************************************
* FORMATS *********************************************************************
******************************************************************************/
/*
   text clustering file ( based on metis .part file )
   1
    
   2
   2
*/
/*
   binary cluster file
   [ bytes | description ]
   [ 0-3   | magic number (646f6d3) ]
   [ 4-7   | file version ]
   [ 8     | cid_t width ]
   [ 9-12  | nvtxs ]
   [ 13-20 | nclusters ]
   [ 21-*  | cids ]
*/


/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/
/**
 * @brief Read in a clustering from the filesystem
 *
 * @param clusterfile The file to read the clustering data from
 * @param where A reference to the where pointer
 * @param nvtxs A reference to the number of vertices in the clustering
 * @param binary 1 if the clustering is stored in binary format, 0 if the
 * clustering is stored in text format
 *
 * @return !0 on success 
 */
int read_clustering(const char * clusterfile, cid_t ** where, vtx_t * nvtxs,
    int binary);


/**
 * @brief Write a clustering to the file specified by 'clusterfile', using
 * either binary or text format as indicated by 'binary'.
 *
 * @param clusterfile The file to which to write.
 * @param where The vector containing the cluster id for each vertex.
 * @param nvtxs The length of the where vector
 * @param binary 1 to write in binary fomrat, and 0 to write in text format.
 *
 * @return !0 on success 
 */
int write_clustering(const char * clusterfile, const cid_t * where, 
    vtx_t nvtxs, int binary);


/**
 * @brief Prints the clustering information for the graph
 *
 * @param clustering The clustering to print
 * @param graph The graph that has been clustered (maybe NULL if update = 0)
 * @param update Whether or not to update the clustering based on the graph
 * @param verbosity How verbose the print out should be
 *
 * @return !0 on success
 */
int print_clustering(clustering_t * clustering, const graph_t * graph,
    int update, int verbosity);


/**
 * @brief Prints out the timers
 *
 * @param timers duh.
 *
 * @return !0 on success
 */
int print_timers(const objective_t * objective);


/**
 * @brief Prints out the the different paramters of the objective  struct
 *
 * @param objective
 *
 * @return !0 on success
 */
int print_objective(const objective_t * objective);


/**
 * @brief Print a header row for information
 *
 * @param out The stream to print to
 * @param title The header title to print
 * @param marker The character to mark the row with
 * @param width The width of the row
 *
 * @return !0 on success
 */
int fprint_header(FILE * out, const char * title, char marker, int width);


/**
 * @brief Print a row of chars
 *
 * @param out The stream to print to
 * @param marker The char to print
 * @param width The width of the row
 *
 * @return !0 on success
 */
int fprint_footer(FILE * out, char marker, int width);


void print_loadbalance_stats(loadbalance_stat_list_t * stat);
void print_aggregation_stats(aggregation_stat_list_t * stat);
void print_refinement_stats(refinement_stat_list_t * stat);
void print_modularity_stats(const mod_t * mods, size_t nmods);
void print_initialclustering_stats(
    const initialclustering_stats_t * stats);



#endif
