/**
 * @file merge.h
 * @brief For reducing the number of clusters in a clustering
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-04-11
 */


#ifndef NERSTRAND_MERGE_H
#define NERSTRAND_MERGE_H


#include "objective.h"
#include "mgraph.h"
#include "cluster.h"



/******************************************************************************
* SERIAL FUNCTION PROTOTYPES **************************************************
******************************************************************************/



/******************************************************************************
* PARALLEL FUNCTION PROTOTYPES ************************************************
******************************************************************************/


/**
 * @brief Find clusters whose degree is less than objective->mergeclusterdegree
 * and merge them with the cluster that maximizes their modularity
 *
 * @param objective The objective specifying merging parameters
 * @param mgraph The clustered mgraph
 * @param clustering The clustering to modify
 *
 * @return The modified cluster if successful, or NULL if an error is
 * encountered
 */
clustering_t * par_clustering_merge(objective_t * objective, 
    const mgraph_t * mgraph, clustering_t * clustering);

#endif
