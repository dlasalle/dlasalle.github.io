/**
 * @file merge.c
 * @brief For reducing the number of clusters in a clustering
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-04-15
 */

#ifndef NERSTRAND_MERGE_C
#define NERSTRAND_MERGE_C

#include "merge.h"

#ifdef XXX

/******************************************************************************
* PUBLIC PARALLEL FUNCTIONS ***************************************************
******************************************************************************/
cid_t __pcm_ndeleted;
cid_t * __pcm_deleted;
clustering_t * par_clustering_merge(objective_t * objective, 
    const mgraph_t * mgraph, clustering_t * clustering)
{
  vtx_t i,k,b;
  adj_t j;
  cid_t c, me, maxidx, nnbrs;
  tid_t o;
  mod_t maxmod, curmod;
  wgt_t dam;

  const tid_t myid = omp_get_thread_num();
  const tid_t nthreads = omp_get_num_threads();

  /* graph parts */
  const graph_t * const graph = mgraph->graph;
  const vtx_t mynvtxs = graph->mynvtxs[myid];
  const adj_t * const xadj = graph->xadj[myid];
  const vtx_t * const adjncy = graph->adjncy[myid];
  const wgt_t * const adjwgt = graph->adjwgt[myid];
  const wgt_t * const eadjwgt = graph->eadjwgt[myid];

  /* cluster parts */
  const cid_t nclsuters = clustering->nclusters;
  const cid_t * const * const where = (const cid_t * const *)clustering->where;
  const cluster_t * const clusters = clustering->clusters;
  const ucinfo_t * const * const ucinfo = mgraph->ucinfo;

  const wgt_t invm = 1.0/graph->gadjwgt;

  const nbrinfo->

  #pragma omp master
  {
    __pcm_ndeleted = 0;
    __pcm_deleted = cid_alloc(nclusters);
  }
  #pragma omp barrier

  /* find one-vertex clusters for merging */
  for (b=0;b<(vtx_t)mybnd->size;++b) {
    i = vtx_iset_get(b,mybnd);
    me = where[myid][i];
    dam = (clusters[me].eadjwgt+clusters[me].viadjwgt)*invm;
    if (clusters[me].nvtxs == 1) {
      /* find a cluster to merge with */
      nnbrs = 0;
      maxidx = me;
      maxmod = 0;
      for (c=0;c<ucinfo[myid]->nnbrs;++c) {
        curmod = hwgt[c] - (
            (clusters[c].eadjwgt+clusters[c].iadjwgt+clusters[c].viadjwgt)
            *dam); 
        if (maxmod < curmod) {
          maxidx = c;
          maxmod = curmod;
        }
      }
      if (maxidx != me) {
        #pragma omp critical
        {
          curmod = hwgt[maxidx] - ((clusters[maxidx].eadjwgt +
                                    clusters[maxidx].iadjwgt +
                                    clusters[maxidx].viadjwgt)*dam); 
          if (clusters[maxidx].nvtxs > 0 && curmod > 0) {
            where[myid][i] = maxidx;
            /* udpate my cluster */
            clusters[me].nvtxs = 0;
            __pcm_deleted[ndeleted++] = me;
            /* update foreign cluster */
            ++clusters[maxidx].nvtxs;
            clusters[maxidx].iadjwgt += 2*hwgt[maxidx];
            /* update neighbors */
            /* update my ucinfo */
          }
        }
      }
      for (c=0;c<nnbrs;++c) {
        hwgt[c] = 0.0;
      }
    }
  }

  return NULL;
}

#endif

#endif
