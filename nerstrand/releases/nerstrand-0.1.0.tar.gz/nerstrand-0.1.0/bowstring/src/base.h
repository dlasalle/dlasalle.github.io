/**
 * @file base.h
 * @brief Library external header file
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2012
 * @version 1
 * @date 2013-04-09
 */

#ifndef BOWSTRING_BASE_H
#define BOWSTRING_BASE_H

#include <domlib.h>
#include <stdlib.h> 
#include <stdio.h>
#include <stdint.h>

/**
 * @brief Flags specifying what weights are in a file
 */
typedef enum bowstring_wgt_flag_t {
  ADJWGT_FLAG = 1,
  VWGT_FLAG = 1 << 1,
  IADJWGT_FLAG = 1 << 2
} bowstring_wgt_flag_t;


#ifdef BOWSTRING_TYPES_DEFINED
/* Define the types for internal use if they are externally defined.
 * Otherwise bowstring.h will provide definitions for us. */
#ifdef BOWSTRING_SIGNED_TYPES
typedef int64_t bowstring_int64_t;
#define PF_BSINT64_T "%"PRIi64
typedef int32_t bowstring_int32_t;
#define PF_BSINT32_T "%"PRIi32
#else
typedef uint64_t bowstring_int64_t;
#define PF_BSINT64_T "%"PRIu64
typedef uint32_t bowstring_int32_t;
#define PF_BSINT32_T "%"PRIu32
#endif /* BOWSTRING_SIGNED_TYPES */
#ifdef BOWSTRING_64BIT_VERTICES
typedef bowstring_int64_t vtx_t;
#define PF_VTX_T PF_BSINT64_T
#else
typedef bowstring_int32_t vtx_t;
#define PF_VTX_T PF_BSINT32_T
#endif /* BOWSTRING_64BIT_VERTICES */
#ifdef BOWSTRING_64BIT_EDGES
typedef bowstring_int64_t adj_t;
#define PF_ADJ_T PF_BSINT64_T
#else
typedef bowstring_int32_t adj_t;
#define PF_ADJ_T PF_BSINT32_T
#endif /* BOWSTRING_64BIT_EDGES */
#ifdef BOWSTRING_DOUBLE_WEIGHTS
#ifdef BOWSTRING_INT_WEIGHTS
typedef bowstring_int64_t wgt_t;
#define PF_WGT_T PF_BSINT64_T
#else
typedef double wgt_t;
#define PF_WGT_T "%lf"
#endif /* BOWSTRING_INT_WEIGHTS */
#else
#ifdef BOWSTRING_INT_WEIGHTS
typedef bowstring_int32_t wgt_t;
#define PF_WGT_T PF_BSINT32_T
#else
typedef float wgt_t;
#define PF_WGT_T "%f"
#endif /* BOWSTRING_INT_WEIGHTS */
#endif /* BOWSTIRNG_DOUBLE_WEIGHTS */
#endif /* BOWSTRING_TYPES_DEFINED */


/* Define the label types for internal use if they are externally defined.
 * Otherwise bowstring.h will provide definitions for us. */
#ifdef BOWSTRING_LABELS_DEFINED
#ifdef BOWSTRING_64BIT_VLABELS
typedef int64_t vlbl_t;
#define PF_VLBL_T "%"PRIi64
#else
typedef int32_t vlbl_t;
#define PF_VLBL_T "%"PRIi32
#endif /* BOWSTRING_64BIT_VLABELS */
#ifdef BOWSTRING_64BIT_ELABELS
typedef int64_t elbl_t;
#define PF_ELBL_T "%"PRIi64
#else
typedef int32_t elbl_t;
#define PF_ELBL_T "%"PRIi32
#endif /* BOWSTRING_64BIT_ELABELS */
#endif /* BOWSTRING_LABELS_DEFINED */


#include <bowstring.h>


/* wgt_t */
#define DLMEM_PREFIX wgt
#define DLMEM_TYPE_T wgt_t
#include "dlmem_headers.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T

#define DLRAND_PREFIX wgt
#define DLRAND_TYPE_T wgt_t
#include "dlrand_headers.h"
#undef DLRAND_PREFIX
#undef DLRAND_TYPE_T


/* vtx_t */
#define DLMEM_PREFIX vtx
#define DLMEM_TYPE_T vtx_t
#include "dlmem_headers.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T

#define DLRAND_PREFIX vtx
#define DLRAND_TYPE_T vtx_t
#include "dlrand_headers.h"
#undef DLRAND_PREFIX
#undef DLRAND_TYPE_T

#define DLMATH_PREFIX vtx
#define DLMATH_TYPE_T vtx_t
#define DLMATH_DLTYPE DLTYPE_INTEGRAL
#include "dlmath_headers.h"
#undef DLMATH_DLTYPE
#undef DLMATH_PREFIX
#undef DLMATH_TYPE_T


/* adj_t */
#define DLMEM_PREFIX adj
#define DLMEM_TYPE_T adj_t
#include "dlmem_headers.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T

#define DLRAND_PREFIX adj
#define DLRAND_TYPE_T adj_t
#include "dlrand_headers.h"
#undef DLRAND_PREFIX
#undef DLRAND_TYPE_T

#define DLMATH_PREFIX adj
#define DLMATH_TYPE_T adj_t
#define DLMATH_DLTYPE DLTYPE_INTEGRAL
#include "dlmath_headers.h"
#undef DLMATH_DLTYPE
#undef DLMATH_PREFIX
#undef DLMATH_TYPE_T


/* vlbl_t */
#define DLMEM_PREFIX vlbl
#define DLMEM_TYPE_T vlbl_t
#include "dlmem_headers.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


/* elbl_t */
#define DLMEM_PREFIX elbl
#define DLMEM_TYPE_T elbl_t
#include "dlmem_headers.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


static const vtx_t NULL_VTX = -1;


#endif
