/**
 * @file io.c
 * @brief IO file operations for graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2012
 * @version 1
 * @date 2013-04-09
 */

#ifndef BOWSTRING_IO_C
#define BOWSTRING_IO_C

#include "io.h"
#include <math.h>


#define DLTREE_STATIC
#define DLTREE_PREFIX cv
#define DLTREE_KEY_T char *
#define DLTREE_VAL_T vtx_t 
#include "dltree_headers.h"
#undef DLTREE_PREFIX
#undef DLTREE_KEY_T
#undef DLTREE_VAL_T
#undef DLTREE_STATIC


#define DLSORT_PREFIX vtx
#define DLSORT_TYPE_T vtx_t
#define DLSORT_DLTYPE DLTYPE_INTEGRAL
#define DLSORT_STATIC
#include "dlsort_headers.h"
#undef DLSORT_STATIC
#undef DLSORT_DLTYPE
#undef DLSORT_PREFIX
#undef DLSORT_TYPE_T




/******************************************************************************
* MACROS **********************************************************************
******************************************************************************/
#define __READ_INT64(var,buffer,file,msg,fn) \
  do { \
    if (fread((buffer),8,1,(file)) != 1) { \
      dl_error("Failed reading "msg" from '%s'\n",(fn)); \
    } \
    dl_from_bytes(&(var),buffer,8); \
  } while (0)

#define __READ_INT(var,buffer,file,msg,fn) \
  do { \
    if (fread((buffer),4,1,(file)) != 1) { \
      dl_error("Failed reading "msg" from '%s'\n",(fn)); \
    } \
    dl_from_bytes(&(var),buffer,4); \
  } while (0)

#define __READ_BYTE(var,buffer,file,msg,fn) \
  do { \
    if (fread((buffer),1,1,(file)) != 1) { \
      dl_error("Failed reading "msg" from '%s'\n",(fn)); \
    } \
    dl_from_bytes(&(var),buffer,1); \
  } while (0)

#define __WRITE_INT64(var,buffer,file,msg,fn) \
  do { \
    dl_to_bytes((buffer),&(var),8); \
    if (fwrite((buffer),8,1,(file)) != 1) { \
      dl_error("Failed writing "msg" to '%s'\n",(fn)); \
    } \
  } while (0)

#define __WRITE_INT(var,buffer,file,msg,fn) \
  do { \
    dl_to_bytes((buffer),&(var),4); \
    if (fwrite((buffer),4,1,(file)) != 1) { \
      dl_error("Failed writing "msg" to '%s'\n",(fn)); \
    } \
  } while (0)

#define __WRITE_BYTE(var,buffer,file,msg,fn) \
  do { \
    dl_to_bytes((buffer),&(var),1); \
    if (fwrite((buffer),1,1,(file)) != 1) { \
      dl_error("Failed writing "msg" to '%s'\n",(fn)); \
    } \
  } while (0)

#define __CONVERT_ARRAY(var,buffer,bsize,width,arr,i,type) \
  do { \
    size_t j; \
    for ((j)=0;(j)<(bsize);++(j),++(i)) { \
      dl_from_bytes(&(var),(buffer)+((j)*(width)),width); \
      (arr)[i] = (type)(var); \
    } \
  } while (0)

#define __SETSTATS(stat,stat_max,stat_avg,level,level_max) \
  do { \
    if ((stat) > (stat_max)) { \
      (stat_max) = (stat); \
      (level_max) = (level); \
    } \
    (stat_avg) += (stat); \
  } while (0)




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const size_t BUFFERSIZE = 0x1000;
static const char COMMENT_CHARS[256] = {
  ['#']=1,
  ['%']=1,
  ['\'']=1,
  ['"']=1,
  ['/']=1
};
static const char DIMACS_COMMENT = 'c';
static const char DIMACS_PROBLEM = 'p';
static const char DIMACS_ARC = 'a';
static const char DIMACS_NODE_DESCRIPTOR = 'n';
static const char DIMACS_EDGE = 'e';


/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static void __quicksort_edges(vtx_t * const keys,
    wgt_t * const vals, const size_t n)
{
  vtx_t mid;
  size_t i,j,k;
  i = 1;
  j = n-1;
  k = n >> 1;
  mid = keys[k];
  keys[k] = keys[0];
  while (i < j) {
    if (keys[i] > mid) { /* keys[i] is on the wrong side */
      if (keys[j] <= mid) {
        dl_swap(keys[i],keys[j]);
        dl_swap(vals[i],vals[j]);
        ++i;
      }
      --j;
    } else {
      if (keys[j] > mid) { /* keys[j] is on the right side */
        --j;
      }
      ++i;
    }
  }
  if (keys[i] > mid) {
    --i;
  }
  keys[0] = keys[i];
  keys[i] = mid;
  if (i > 1) {
    __quicksort_edges(keys,vals,i);
  }
  ++i; /* skip the pivot element */
  if (n-i > 1) {
    __quicksort_edges(keys+i,vals+i,n-i);
  }
} 



/**
 * @brief Convert bitwise weight flags to base 10 format:
 *    1 = 1, 2 = 10, 4 = 100, etc.
 *
 * @param flags The bitwised flags
 *
 * @return The base 10 representation suitable for printing
 */
static int __flag_to_int(int flags) 
{
  int iflags = 0;

  int p10 = 1;
  int p2 = 1;
  while (flags > 0) {
    if (flags & p2) {
      iflags += p10;
      flags ^= p2;
    }
    /* obnoxious way to multiply by 10 */
    p10 = (p10 << 3) + (p10 << 1);
    p2 <<= 1;
  }
  
  return iflags;
}


/**
 * @brief Wrapper around the dl_file routines to handle error codes
 *
 * @param filename The file to open
 * @param mode The mode to open the file in
 * @param r_file The reference to the file pointer
 *
 * @return BOWSTRING_SUCCESS, or an error code
 */
static int __open_file(const char * const filename, const char * const mode,
    file_t ** const r_file)
{
  int rv;
  if ((rv = dl_open_file(filename,mode,r_file)) != DL_FILE_SUCCESS) {
    switch (rv) {
      case DL_FILE_BAD_PARAMETERS:
      case DL_FILE_PATH_PARSE_FAILURE:
        eprintf("Bad filename '%s'\n",filename);
        rv = BOWSTRING_INVALIDINPUT;
        break;
      case DL_FILE_PATH_BAD:
        eprintf("File not found '%s'\n",filename);
        rv = BOWSTRING_FILENOTFOUND;
        break;
      case DL_FILE_PATH_ACCESS_DENIED:
      case DL_FILE_READ_ACCESS_DENIED:
      case DL_FILE_WRITE_ACCESS_DENIED:
        eprintf("Permission denied '%s'\n",filename);
        rv = BOWSTRING_FILEPERMISSIONDENIED;
        break;
      default:
        eprintf("Unknown failure: %d opening '%s'\n",rv,filename);
        rv = BOWSTRING_UNKNOWN;
        break;
    }
  } else {
    rv = BOWSTRING_SUCCESS;
  }
  return rv;
}




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


/* META FILES ****************************************************************/

int read_vertex_labels(const char * const filename, vtx_t * const r_nvtxs, 
    vlbl_t ** const r_labels)
{
  file_t * file;
  vtx_t nl;
  vlbl_t l;
  int rv;
  ssize_t ll;
  size_t bufsize;
  char * line;

  vlbl_t * labels = NULL;

  bufsize = BUFFERSIZE;

  if ((rv = __open_file(filename,"r",&file)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }
  line = char_alloc(bufsize);
  ll = dl_get_next_line(file,&line,&bufsize);
  /* skip comments */
  while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
    ll = dl_get_next_line(file,&line,&bufsize);
  }
  if (!r_nvtxs || *r_nvtxs == 0) {
    /* determine the size of the file */
    nl = 0;
    while (ll > 0 && sscanf(line,PF_VLBL_T,&l) == 1) {
      ++nl; 
      ll = dl_get_next_line(file,&line,&bufsize);
    }
    dl_reset_file(file);
    ll = dl_get_next_line(file,&line,&bufsize);
    /* skip comments */
    while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
      ll = dl_get_next_line(file,&line,&bufsize);
    }
  } else {
    /* the size of the file was specified */
    nl = *r_nvtxs;
  }
  labels = vlbl_alloc(nl);
  nl = 0;
  /* read in the file */
  while (ll > 0 && sscanf(line,PF_VLBL_T,&l) == 1) {
    labels[nl++] = l;
    ll = dl_get_next_line(file,&line,&bufsize);
  }
  if (r_nvtxs) {
    *r_nvtxs = nl;
  }

  dl_free(line);

  if (r_labels) {
    *r_labels = labels;
  } else {
    dl_free(labels);
  }

  return BOWSTRING_SUCCESS; 

  ERROR:

  if (line) {
    dl_free(line);
  } 
  if (labels) {
    dl_free(labels);
  }

  return rv;
}


int write_vertex_labels(const char * const filename, const vtx_t nvtxs, 
    const vlbl_t * const labels)
{
  int rv;
  vtx_t i;
  file_t * file = NULL;

  if ((rv = __open_file(filename,"w",&file)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  for (i=0;i<nvtxs;++i) {
    fprintf(file,PF_VLBL_T"\n",labels[i]);
  }

  dl_close_file(file);
  file = NULL;

  return BOWSTRING_SUCCESS;

  ERROR:

  if (file) {
    dl_close_file(file);
  }

  return rv;
}


int read_edge_labels(const char * const filename, adj_t * const r_nedges, 
    elbl_t ** const r_labels)
{
  file_t * file;
  adj_t nl;
  elbl_t l;
  double d;
  int rv;
  ssize_t ll;
  size_t bufsize;
  char * line, * eptr, * sptr;

  elbl_t * labels = NULL;

  bufsize = BUFFERSIZE;

  if ((rv = __open_file(filename,"r",&file)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }
  line = char_alloc(bufsize);
  ll = dl_get_next_line(file,&line,&bufsize);
  /* skip comments */
  while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
    ll = dl_get_next_line(file,&line,&bufsize);
  }
  if (*r_nedges == 0) {
    /* determine the size of the file */
    nl = 0;
    while (ll > 0) {
      eptr = sptr = line;
      d = strtod(sptr,&eptr);
      if (isfinite(d)) {
        rv = BOWSTRING_INVALIDVALUE;
        goto ERROR;
      }
      while (eptr != sptr) {
        ++nl; 
        d = strtod(sptr,&eptr);
        if (isfinite(d)) {
          rv = BOWSTRING_INVALIDVALUE;
          goto ERROR;
        }
      }
      ll = dl_get_next_line(file,&line,&bufsize);
    }
    dl_reset_file(file);
    ll = dl_get_next_line(file,&line,&bufsize);
    /* skip comments */
    while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
      ll = dl_get_next_line(file,&line,&bufsize);
    }
  } else {
    /* the size of the file was specified */
    nl = *r_nedges;
  }
  labels = elbl_alloc(nl);
  nl = 0;
  /* read in the file */
  while (ll > 0) {
    eptr = sptr = line;
    l = (elbl_t)strtod(sptr,&eptr);
    while (eptr != sptr) {
      labels[nl++] = l;
      l = (elbl_t)strtod(sptr,&eptr);
    }
    ll = dl_get_next_line(file,&line,&bufsize);
  }

  *r_nedges = nl;

  dl_free(line);

  if (r_labels) {
    *r_labels = labels;
  } else {
    dl_free(labels);
  }

  return BOWSTRING_SUCCESS; 

  ERROR:

  if (line) {
    dl_free(line);
  } 
  if (labels) {
    dl_free(labels);
  }

  return rv;
}


int write_edge_labels(const char * const filename, const adj_t nedges, 
    const elbl_t * const labels)
{
  int rv;
  adj_t i;
  file_t * file = NULL;

  if ((rv = __open_file(filename,"w",&file)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  for (i=0;i<nedges;++i) {
    fprintf(file,PF_ELBL_T"\n",labels[i]);
  }

  dl_close_file(file);
  file = NULL;

  return BOWSTRING_SUCCESS;

  ERROR:

  if (file) {
    dl_close_file(file);
  }

  return rv;
}


/* NERSTAND ******************************************************************/


int write_nerstrand_graph(const char * const filename, const vtx_t nvtxs, 
    const adj_t * const xadj, const vtx_t * const adjncy, 
    const wgt_t * const vwgt, const wgt_t * const adjwgt)
{
  int rv;
  file_t * file;
  size_t i, j;

  int do_vwgt, do_adjwgt, iflags;

  int wgt_flags = 0;
  do_vwgt = do_adjwgt = 0;

  const adj_t nedges = xadj[nvtxs];

  /* check if we should write the weights */
  if (vwgt) {
    for (i=0;i<nvtxs;++i) {
      if (vwgt[i] != 1.0) {
        break;
      }
    }
    if (i < nvtxs) {
      wgt_flags |= VWGT_FLAG;
      do_vwgt = 1;
    }
  }
  if (adjwgt) {
    for (i=0;i<nvtxs;++i) {
      if (adjwgt[i] != 1.0) {
        break;
      }
    }
    if (i < nvtxs) {
      wgt_flags |= ADJWGT_FLAG;
      do_adjwgt = 1;
    }
  }

  if ((rv = __open_file(filename,"w",&file)) != BOWSTRING_SUCCESS) {
    return rv;
  }

  /* print the header line */
  fprintf(file,"%zu %zu",(size_t)nvtxs,(size_t)(nedges/2));
  iflags = __flag_to_int(wgt_flags);
  if (iflags) {
    fprintf(file," %d\n",iflags);
  } else {
    fprintf(file,"\n");
  }

  /* print out the graph */
  for (i=0;i<nvtxs;++i) {
    if (do_vwgt) {
      fprintf(file,"%lf ",(double)vwgt[i]);
    }
    for (j=(size_t)xadj[i];j<(size_t)xadj[i+1];++j) {
      fprintf(file,"%zu ",(size_t)(adjncy[j]+1));
      if (do_adjwgt) {
        fprintf(file,"%lf ",(double)adjwgt[j]);
      }
    }
    fprintf(file,"\n");
  }
  dl_close_file(file);

  return BOWSTRING_SUCCESS;
}


/* METIS *********************************************************************/

int read_metis_graph(const char * const filename, vtx_t * const r_nvtxs, 
    adj_t ** const r_xadj, vtx_t ** const r_adjncy, wgt_t ** const r_vwgt, 
    wgt_t ** const r_adjwgt)
{
  file_t * file;
  int w, rv;
  size_t n,m,i, j, ln, ne, num_header;
  ssize_t ll;
  size_t bufsize;
  char * line,*eptr, * sptr;
  wgt_t weight;

  adj_t * xadj = NULL;
  vtx_t * adjncy = NULL;
  wgt_t * vwgt = NULL;
  wgt_t * adjwgt = NULL;

  bufsize = BUFFERSIZE;

  if ((rv = __open_file(filename,"r",&file)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }
  line = char_alloc(bufsize);
  ll = dl_get_next_line(file,&line,&bufsize);
  /* skip comments */
  while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
    ll = dl_get_next_line(file,&line,&bufsize);
  }
  num_header = sscanf(line,"%zu %zu %d",&n,&m,&w);

  int do_vwgt, do_adjwgt;

  if (num_header == 3) {
    do_vwgt = ((w & VWGT_FLAG) ? 1 : 0);
    do_adjwgt = ((w & ADJWGT_FLAG) ? 1 : 0);
  } else if (num_header == 2) {
    do_vwgt = 0;
    do_adjwgt = 0;
  } else {
    eprintf("Invalid header line '%s'\n",line);
    dl_close_file(file);
    rv = BOWSTRING_INVALIDINPUT;
    goto ERROR;
  }

  /* make edges count twice */
  m *= 2;
  xadj = adj_alloc(n+1);
  adjncy = vtx_alloc(m);
  if (do_vwgt) {
    vwgt = wgt_alloc(n);
  }
  if (do_adjwgt) {
    adjwgt = wgt_alloc(m);
  }

  xadj[0] = 0;
  ln = j = 0;
  /* scan through the file */
  while((ll = dl_get_next_line(file,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      if (ln == n) {
        /* if we've read all vertices, ignore trailing blank lines */
        continue;
      }
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    ne = 0;
    /* vertex weight */
    if (do_vwgt) {
      weight = (wgt_t)strtod(sptr,&eptr);
      if (eptr == sptr) {
        eprintf("Missing vertex weight for vertex %zu\n",ln);
        dl_close_file(file);
        rv = BOWSTRING_INVALIDINPUT;
        goto ERROR;
      }
      sptr = eptr;
      vwgt[ln] = weight;
    }
    i = strtoull(sptr,&eptr,10)-1;
    while (eptr != sptr) {
      sptr = eptr;
      if (i >= n) {
        eprintf("Invalid vertex %zu at line %zu\n",i+1,ln);
        dl_close_file(file);
        rv = BOWSTRING_INVALIDINPUT;
        goto ERROR;
      }
      if (j >= m) {
        eprintf("Edge %zu found at vertex %zu is greater "
            "than specified number of edges (%zu)\n", j,ln,m);
        dl_close_file(file);
        rv = BOWSTRING_INVALIDINPUT;
        goto ERROR;
      }
      adjncy[j] = (vtx_t)i;
      /* edge weight */ 
      if (do_adjwgt) {
        weight = (wgt_t)strtod(sptr,&eptr);
        if (eptr == sptr) {
          eprintf("Missing edge weight for vertex %zu, edge %zu\n",ln,ne);
          dl_close_file(file);
          rv = BOWSTRING_INVALIDINPUT;
          goto ERROR;
        }
        sptr = eptr;
        adjwgt[j] = weight;
      }
      ++j;
      ++ne;
      i = strtoull(sptr,&eptr,10)-1;
    }
    xadj[++ln] = (adj_t)j;
  }
  dl_close_file(file);
  if (ln < n) {
    eprintf("Only found %zu out of %zu vertices in graph file\n",ln,n);
    rv = BOWSTRING_INVALIDINPUT;
    goto ERROR;
  } else if (j != m) {
    eprintf("Only found %zu out of %zu edges in graph file\n",j,m);
    rv = BOWSTRING_INVALIDINPUT;
    goto ERROR;
  }

  dl_free(line);

  if (r_nvtxs) {
    *r_nvtxs = n;
  }
  if (r_xadj) {
    *r_xadj = xadj;
  } else if (xadj) {
    dl_free(xadj);
  }
  if (r_adjncy) {
    *r_adjncy = adjncy;
  } else if (adjncy) {
    dl_free(adjncy);
  }
  if (r_vwgt) {
    *r_vwgt = vwgt;
  } else if (vwgt) {
    dl_free(vwgt);
  }
  if (r_adjwgt) {
    *r_adjwgt = adjwgt;
  } else if (adjwgt) {
    dl_free(adjwgt);
  }

  return BOWSTRING_SUCCESS;

  ERROR:

  dl_free(line);
  if (xadj) {
    dl_free(xadj);
  }
  if (adjncy) {
    dl_free(adjncy);
  }
  if (vwgt) {
    dl_free(vwgt);
  }
  if (adjwgt) {
    dl_free(adjwgt);
  }
  return rv;
}


int write_metis_graph(const char * const filename, const vtx_t nvtxs, 
    const adj_t * const xadj, const vtx_t * const adjncy, 
    const wgt_t * const vwgt, const wgt_t * const adjwgt)
{
  int rv;
  file_t * file;
  size_t i, j;

  int do_vwgt, do_adjwgt, iflags;

  int wgt_flags = 0;
  do_vwgt = do_adjwgt = 0;

  const adj_t nedges = xadj[nvtxs];

  /* check if we should write the weights */
  if (vwgt) {
    for (i=0;i<nvtxs;++i) {
      if (vwgt[i] != 1.0) {
        break;
      }
    }
    if (i < nvtxs) {
      wgt_flags |= VWGT_FLAG;
      do_vwgt = 1;
    }
  }
  if (adjwgt) {
    for (i=0;i<nvtxs;++i) {
      if (adjwgt[i] != 1.0) {
        break;
      }
    }
    if (i < nvtxs) {
      wgt_flags |= ADJWGT_FLAG;
      do_adjwgt = 1;
    }
  }

  if ((rv = __open_file(filename,"w",&file)) != BOWSTRING_SUCCESS) {
    return rv;
  }

  /* print the header line */
  fprintf(file,"%zu %zu",(size_t)nvtxs,(size_t)(nedges/2));
  iflags = __flag_to_int(wgt_flags);
  if (iflags) {
    fprintf(file," %d\n",iflags);
  } else {
    fprintf(file,"\n");
  }

  /* print out the graph */
  for (i=0;i<nvtxs;++i) {
    if (do_vwgt) {
      fprintf(file,"%zu ",(size_t)vwgt[i]);
    }
    for (j=(size_t)xadj[i];j<(size_t)xadj[i+1];++j) {
      fprintf(file,"%zu ",(size_t)(adjncy[j]+1));
      if (do_adjwgt) {
        fprintf(file,"%zu ",(size_t)adjwgt[j]);
      }
    }
    fprintf(file,"\n");
  }
  dl_close_file(file);

  return BOWSTRING_SUCCESS;
}


int translate_metis_to_snap(const char * const infile, 
    const char * const outfile)
{
  file_t * fin = NULL, *fout = NULL;
  int w, rv;
  size_t n,m,i, j, ln, ne, num_header;
  ssize_t ll;
  size_t bufsize;
  char * line,*eptr, * sptr;
  wgt_t weight;

  bufsize = BUFFERSIZE;

  /* prep input file */
  if ((rv = __open_file(infile,"r",&fin)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  line = char_alloc(bufsize);
  ll = dl_get_next_line(fin,&line,&bufsize);
  /* skip comments */
  while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
    ll = dl_get_next_line(fin,&line,&bufsize);
  }
  num_header = sscanf(line,"%zu %zu %d",&n,&m,&w);

  int do_vwgt, do_adjwgt;

  if (num_header == 3) {
    do_vwgt = ((w & VWGT_FLAG) ? 1 : 0);
    do_adjwgt = ((w & ADJWGT_FLAG) ? 1 : 0);
  } else if (num_header == 2) {
    do_vwgt = 0;
    do_adjwgt = 0;
  } else {
    eprintf("Invalid header line '%s'\n",line);
    rv = BOWSTRING_INVALIDINPUT;
    goto ERROR;
  }

  /* prep output file */
  if ((rv = __open_file(outfile,"w",&fout)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  /* make edges count twice */
  m *= 2;
  if (do_vwgt) {
    printf("Ignoring vertex weights when converting to SNAP\n");
  }

  ln = j = 0;
  /* scan through the file */
  while((ll = dl_get_next_line(fin,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      if (ln == n) {
        /* if we've read all vertices, ignore trailing blank lines */
        continue;
      }
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    ne = 0;
    i = strtoull(sptr,&eptr,10)-1;
    while (eptr != sptr) {
      sptr = eptr;
      if (i >= n) {
        eprintf("Invalid vertex %zu at line %zu\n",i+1,ln);
        rv = BOWSTRING_INVALIDINPUT;
        goto ERROR;
      }
      if (j >= m) {
        eprintf("Edge %zu found at vertex %zu is greater "
            "than specified number of edges (%zu)\n", j,ln,m);
        rv = BOWSTRING_INVALIDINPUT;
        goto ERROR;
      }
      fprintf(fout,"%zu %zu",ln,i);
      /* edge weight */ 
      if (do_adjwgt) {
        weight = (wgt_t)strtod(sptr,&eptr);
        if (eptr == sptr) {
          eprintf("Missing edge weight for vertex %zu, edge %zu\n",ln,ne);
          rv = BOWSTRING_INVALIDINPUT;
          goto ERROR;
        }
        sptr = eptr;
        fprintf(fout," "PF_WGT_T,weight);
      }
      fprintf(fout,"\n");
      ++j;
      ++ne;
      i = strtoull(sptr,&eptr,10)-1;
    }
    ++ln;
  }
  dl_close_file(fin);
  fin = NULL;
  dl_close_file(fout);
  fout = NULL;
  if (ln < n) {
    eprintf("Only found %zu out of %zu vertices in graph file\n",ln,n);
    rv = BOWSTRING_INVALIDINPUT;
    goto ERROR;
  } else if (j != m) {
    eprintf("Only found %zu out of %zu edges in graph file\n",j,m);
    rv = BOWSTRING_INVALIDINPUT;
    goto ERROR;
  }

  dl_free(line);

  return BOWSTRING_SUCCESS;

  ERROR:
  if (fin) {
    dl_close_file(fin);
    fin = NULL;
  }
  if (fout) {
    dl_close_file(fout);
    fout = NULL;
  }
  dl_free(line);
  return rv;
}


int translate_metis_to_cloud9(const char * infile, const char * outfile)
{ 
  file_t * fin = NULL, *fout = NULL;
  int w, rv;
  size_t n,m,i, j, ln, ne, num_header;
  ssize_t ll;
  size_t bufsize;
  char * line = NULL;
  char * eptr, * sptr;
  wgt_t weight;

  bufsize = BUFFERSIZE;

  /* prep input file */
  if ((rv = __open_file(infile,"r",&fin)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }
  line = char_alloc(bufsize);
  ll = dl_get_next_line(fin,&line,&bufsize);
  /* skip comments */
  while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
    ll = dl_get_next_line(fin,&line,&bufsize);
  }
  num_header = sscanf(line,"%zu %zu %d",&n,&m,&w);

  int do_vwgt, do_adjwgt;

  if (num_header == 3) {
    do_vwgt = ((w & VWGT_FLAG) ? 1 : 0);
    do_adjwgt = ((w & ADJWGT_FLAG) ? 1 : 0);
  } else if (num_header == 2) {
    do_vwgt = 0;
    do_adjwgt = 0;
  } else {
    eprintf("Invalid header line '%s'\n",line);
    dl_close_file(fin);
    rv = BOWSTRING_INVALIDINPUT;
    goto ERROR;
  }

  /* prep output file */
  if ((rv = __open_file(outfile,"w",&fout)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  /* make edges count twice */
  m *= 2;
  if (do_vwgt) {
    wprintf("Ignoring vertex weights when converting to Cloud9\n");
  }

  ln = j = 0;
  /* scan through the file */
  while((ll = dl_get_next_line(fin,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      if (ln == n) {
        /* if we've read all vertices, ignore trailing blank lines */
        continue;
      }
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    ne = 0;
    fprintf(fout,"%zu",ln);
    i = strtoull(sptr,&eptr,10)-1;
    while (eptr != sptr) {
      sptr = eptr;
      if (i >= n) {
        eprintf("Invalid vertex %zu at line %zu\n",i+1,ln);
        rv = BOWSTRING_INVALIDINPUT;
        goto ERROR;
      }
      if (j >= m) {
        eprintf("Edge %zu found at vertex %zu is greater "
            "than specified number of edges (%zu)\n", j,ln,m);
        rv = BOWSTRING_INVALIDINPUT;
        goto ERROR;
      }
      fprintf(fout," %zu",i);
      /* edge weight */ 
      if (do_adjwgt) {
        weight = (wgt_t)strtod(sptr,&eptr);
        if (eptr == sptr) {
          eprintf("Missing edge weight for vertex %zu, edge %zu\n",ln,ne);
          rv = BOWSTRING_INVALIDINPUT;
          goto ERROR;
        }
        sptr = eptr;
        fprintf(fout," "PF_WGT_T,weight);
      }
      ++j;
      ++ne;
      i = strtoull(sptr,&eptr,10)-1;
    }
    fprintf(fout,"\n");
    ++ln;
  }
  dl_close_file(fin);
  fin = NULL;
  dl_close_file(fout);
  fout = NULL;
  if (ln < n) {
    eprintf("Only found %zu out of %zu vertices in graph file\n",ln,n);
    rv = BOWSTRING_INVALIDINPUT;
    goto ERROR;
  } else if (j != m) {
    eprintf("Only found %zu out of %zu edges in graph file\n",j,m);
    rv = BOWSTRING_INVALIDINPUT;
    goto ERROR;
  }

  dl_free(line);

  return BOWSTRING_SUCCESS;

  ERROR:
  if (fin) {
    dl_close_file(fin);
    fin = NULL;
  }
  if (fout) {
    dl_close_file(fout);
    fout = NULL;
  }
  if (line) {
    dl_free(line);
  }
  return rv;
}


int translate_metis_to_dimacs(const char * infile, const char * outfile)
{
  return BOWSTRING_UNIMPLEMENTED;
}


/* CSR ***********************************************************************/

int read_csr_graph(const char * const filename, vtx_t * const r_nvtxs, 
    adj_t ** const xadj, vtx_t ** const adjncy, wgt_t ** const vwgt, 
    wgt_t ** const adjwgt)
{
  return BOWSTRING_UNIMPLEMENTED;
}


int write_csr_graph(const char * const filename, const vtx_t nvtxs, 
    const adj_t * const xadj, const vtx_t * const adjncy, 
    const wgt_t * const vwgt, const wgt_t * const adjwgt)
{
  return BOWSTRING_UNIMPLEMENTED;
}


int translate_csr_to_snap(const char * infile, const char * outfile)
{
  file_t * fin = NULL, *fout = NULL;
  int rv;
  size_t i, j, ln, ne;
  ssize_t ll;
  size_t bufsize;
  char * line,*eptr, * sptr;

  bufsize = BUFFERSIZE;
  line = char_alloc(bufsize);

  /* prep input file */
  if ((rv = __open_file(infile,"r",&fin)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  ll = dl_get_next_line(fin,&line,&bufsize);
  /* skip comments */
  while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
    ll = dl_get_next_line(fin,&line,&bufsize);
  }

  /* prep output file */
  if ((rv =__open_file(outfile,"w",&fout)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  /* make edges count twice */
  ln = j = 0;
  /* scan through the file */
  while((ll = dl_get_next_line(fin,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      /* no way to tell if its a trailing blank line or island vertice */
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    ne = 0;
    i = strtoull(sptr,&eptr,10);
    while (eptr != sptr) {
      sptr = eptr;
      fprintf(fout,"%zu %zu",ln,i);
      fprintf(fout,"\n");
      ++j;
      ++ne;
      i = strtoull(sptr,&eptr,10);
    }
    ++ln;
  }
  dl_close_file(fin);
  fin = NULL;
  dl_close_file(fout);
  fout = NULL;

  dl_free(line);

  return BOWSTRING_SUCCESS;

  ERROR:
  if (fin) {
    dl_close_file(fin);
    fin = NULL;
  }
  if (fout) {
    dl_close_file(fout);
    fout = NULL;
  }
  dl_free(line);
  return rv;
}


int translate_csr_to_cloud9(const char * infile, const char * outfile)
{ 
  file_t * fin = NULL, *fout = NULL;
  int rv;
  size_t i, j, ln, ne;
  ssize_t ll;
  size_t bufsize;
  char * line = NULL, *eptr, * sptr;

  bufsize = BUFFERSIZE;
  line = char_alloc(bufsize);

  /* prep input file */
  if ((rv = __open_file(infile,"r",&fin)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }
  ll = dl_get_next_line(fin,&line,&bufsize);

  /* prep output file */
  if ((rv = __open_file(outfile,"w",&fout)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  /* make edges count twice */
  ln = j = 0;
  /* scan through the file */
  while((ll = dl_get_next_line(fin,&line,&bufsize)) >= 0) {
    if (ll == 0) {
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    ne = 0;
    fprintf(fout,"%zu",ln);
    i = strtoull(sptr,&eptr,10);
    while (eptr != sptr) {
      sptr = eptr;
      fprintf(fout," %zu",i);
      ++j;
      ++ne;
      i = strtoull(sptr,&eptr,10);
    }
    fprintf(fout,"\n");
    ++ln;
  }
  dl_close_file(fin);
  fin = NULL;
  dl_close_file(fout);
  fout = NULL;

  dl_free(line);

  return BOWSTRING_SUCCESS;

  ERROR:
  if (fin) {
    dl_close_file(fin);
    fin = NULL;
  }
  if (fout) {
    dl_close_file(fout);
    fout = NULL;
  }
  dl_free(line);
  return rv;
}


int translate_csr_to_pegasus(const char * infile, const char * outfile)
{
  file_t * fin = NULL, *fout = NULL;
  int rv;
  size_t i, j, ln, ne;
  ssize_t ll;
  size_t bufsize;
  char * line,*eptr, * sptr;

  bufsize = BUFFERSIZE;
  line = char_alloc(bufsize);

  /* prep input file */
  if ((rv = __open_file(infile,"r",&fin)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  ll = dl_get_next_line(fin,&line,&bufsize);
  /* skip comments */
  while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
    ll = dl_get_next_line(fin,&line,&bufsize);
  }

  /* prep output file */
  if ((rv =__open_file(outfile,"w",&fout)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  /* make edges count twice */
  ln = j = 0;
  /* scan through the file */
  while((ll = dl_get_next_line(fin,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      /* no way to tell if its a trailing blank line or island vertice */
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    ne = 0;
    i = strtoull(sptr,&eptr,10);
    while (eptr != sptr) {
      sptr = eptr;
      fprintf(fout,"%zu\t%zu",ln,i);
      fprintf(fout,"\n");
      ++j;
      ++ne;
      i = strtoull(sptr,&eptr,10);
    }
    ++ln;
  }
  dl_close_file(fin);
  fin = NULL;
  dl_close_file(fout);
  fout = NULL;

  dl_free(line);

  return BOWSTRING_SUCCESS;

  ERROR:
  if (fin) {
    dl_close_file(fin);
    fin = NULL;
  }
  if (fout) {
    dl_close_file(fout);
    fout = NULL;
  }
  dl_free(line);
  return rv;

}


int translate_csr_to_matrixmarket(const char * infile, const char * outfile)
{
  file_t * fin = NULL, *fout = NULL;
  int rv;
  adj_t ne;
  vtx_t minidx,i,ln,lm;
  ssize_t ll;
  size_t bufsize;
  char * line,*eptr, * sptr;
  wgt_t w;

  bufsize = BUFFERSIZE;
  line = char_alloc(bufsize);

  /* prep input file */
  if ((rv = __open_file(infile,"r",&fin)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  /* make edges count twice */
  minidx = 1;
  lm = ln = 0;
  ne = 0;
  /* scan through the file */
  while((ll = dl_get_next_line(fin,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      /* no way to tell if its a trailing blank line or island vertice */
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    eptr = sptr = line;
    i = strtoull(sptr,&eptr,10);
    sptr = eptr;
    w = (wgt_t)strtod(sptr,&eptr);
    while (eptr != sptr) {
      if (i < minidx) {
        minidx = i;
      }
      if (i > lm) {
        lm = i;
      }
      ++ne;
      sptr = eptr;
      i = strtoull(sptr,&eptr,10);
      sptr = eptr;
      w = (wgt_t)strtod(sptr,&eptr);
    }
    ++ln;
  }
  if (minidx == 0) {
    ++lm;
  }
  dl_reset_file(fin);

  /* prep output file */
  if ((rv =__open_file(outfile,"w",&fout)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  fprintf(fout,"%%%%MatrixMarket matrix coordinate real general\n");
  fprintf(fout,PF_VTX_T" "PF_VTX_T" "PF_ADJ_T"\n",ln,lm,ne);

  /* make edges count twice */
  ln = 0;
  /* scan through the file */
  while((ll = dl_get_next_line(fin,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      /* no way to tell if its a trailing blank line or island vertice */
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    i = (vtx_t)(strtoull(sptr,&eptr,10)-minidx);
    sptr = eptr;
    w = (wgt_t)strtod(sptr,&eptr);
    while (eptr != sptr) {
      fprintf(fout,PF_VTX_T" "PF_VTX_T" "PF_WGT_T"\n",ln,i,w);
      sptr = eptr;
      i = (vtx_t)(strtoull(sptr,&eptr,10)-minidx);
      sptr = eptr;
      w = (wgt_t)strtod(sptr,&eptr);
    }
    ++ln;
  }
  dl_close_file(fin);
  fin = NULL;
  dl_close_file(fout);
  fout = NULL;

  dl_free(line);

  return BOWSTRING_SUCCESS;

  ERROR:
  if (fin) {
    dl_close_file(fin);
    fin = NULL;
  }
  if (fout) {
    dl_close_file(fout);
    fout = NULL;
  }
  dl_free(line);
  return rv;
}


int tile_csr(const char * infile, const char * outfile, const vtx_t nx, 
    const vtx_t ny)
{
  file_t * fin = NULL, *fout = NULL;
  vtx_t ncol, nrow, j, i, x, y;
  wgt_t w;
  adj_t nnz;
  int rv;
  ssize_t ll;
  size_t bufsize;
  char * line,*eptr, * sptr;

  bufsize = BUFFERSIZE;
  line = char_alloc(bufsize);

  /* prep input file */
  if ((rv = __open_file(infile,"r",&fin)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  /* prep output file */
  if ((rv =__open_file(outfile,"w",&fout)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  fprintf(fout,"%%%%MatrixMarket matrix coordinate real general\n");

  /* scan through the file to find ncol */
  ncol = 0;
  nrow = 0;
  nnz = 0;
  while((ll = dl_get_next_line(fin,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      /* no way to tell if its a trailing blank line or island vertice */
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    i = strtoull(sptr,&eptr,10);
    sptr = eptr;
    w = strtod(sptr,&eptr);
    while (eptr != sptr) {
      if (i > ncol) {
        ncol = i;
      }
      sptr = eptr;
      i = strtoull(sptr,&eptr,10);
      sptr = eptr;
      w = strtod(sptr,&eptr);
      ++nnz;
    }
    ++nrow;
  }

  ncol += 1;

  fprintf(fout,PF_VTX_T" "PF_VTX_T" "PF_ADJ_T"\n",nrow*ny,ncol*nx,nnz*nx*ny);

  j= 0;
  for (y=0;y<ny;++y) {
    dl_reset_file(fin);
    /* scan through the file */
    while((ll = dl_get_next_line(fin,&line,&bufsize)) >= 0) {
      if (ll == 0) {
        /* no way to tell if its a trailing blank line or island vertice */
      } else {
        if (COMMENT_CHARS[(unsigned int)line[0]]) {
          /* skip comments */
          continue;
        }
      }
      for (x=0;x<nx;++x) {
        sptr = line;
        i = strtoull(sptr,&eptr,10);
        sptr = eptr;
        w = strtod(sptr,&eptr);
        while (eptr != sptr) {
          fprintf(fout,PF_VTX_T" "PF_VTX_T" "PF_WGT_T"\n",j,i+(x*ncol),w);
          sptr = eptr;
          i = strtoull(sptr,&eptr,10);
          sptr = eptr;
          w = strtod(sptr,&eptr);
        }
      }
      ++j;
    }
  }
  dl_close_file(fin);
  fin = NULL;
  dl_close_file(fout);
  fout = NULL;

  dl_free(line);

  return BOWSTRING_SUCCESS;

  ERROR:
  if (fin) {
    dl_close_file(fin);
    fin = NULL;
  }
  if (fout) {
    dl_close_file(fout);
    fout = NULL;
  }
  dl_free(line);
  return rv;
}


/* CLOUD9 ********************************************************************/

int read_cloud9_graph(const char * const filename, vtx_t * const r_nvtxs, 
    adj_t ** const r_xadj, vtx_t ** const r_adjncy, wgt_t ** const r_vwgt, 
    wgt_t ** const r_adjwgt)
{
  return BOWSTRING_UNIMPLEMENTED;
}


int write_cloud9_graph(const char * const filename, const vtx_t nvtxs, 
    const adj_t * const xadj, const vtx_t * const adjncy, 
    const wgt_t * const vwgt, const wgt_t * const adjwgt)
{
  file_t * file;
  size_t i, j;
  int do_vwgt, do_adjwgt, rv;

  int wgt_flags = 0;
  do_vwgt = do_adjwgt = 0;

  /* check if we should write the weights */
  if (vwgt) {
    for (i=0;i<nvtxs;++i) {
      if (vwgt[i] != 1.0) {
        break;
      }
    }
    if (i < nvtxs) {
      wgt_flags |= VWGT_FLAG;
      do_vwgt = 1;
    }
  }
  if (adjwgt) {
    for (i=0;i<nvtxs;++i) {
      if (adjwgt[i] != 1.0) {
        break;
      }
    }
    if (i < nvtxs) {
      wgt_flags |= ADJWGT_FLAG;
      do_adjwgt = 1;
    }
  }

  if ((rv = __open_file(filename,"w",&file)) != BOWSTRING_SUCCESS) {
    return rv;
  }

  /* print out the graph */
  for (i=0;i<nvtxs;++i) {
    fprintf(file,"%zu ",i);
    if (do_vwgt) {
      fprintf(file,"%lf ",(double)vwgt[i]);
    }
    for (j=(size_t)xadj[i];j<(size_t)xadj[i+1];++j) {
      fprintf(file,"%zu ",(size_t)(adjncy[j]+1));
      if (do_adjwgt) {
        fprintf(file,"%lf ",(double)adjwgt[j]);
      }
    }
    fprintf(file,"\n");
  }
  dl_close_file(file);

  return BOWSTRING_SUCCESS;
}


/* SNAP **********************************************************************/

int read_snap_graph(const char * const filename, vtx_t * const r_nvtxs, 
    adj_t ** const r_xadj, vtx_t ** const r_adjncy, wgt_t ** const r_vwgt, 
    wgt_t ** const r_adjwgt)
{
  file_t * file;
  int rv;
  vtx_t nvtxs, i, j, u, v, maxv;
  adj_t nedges;
  ssize_t ll;
  size_t bufsize;
  char * line = NULL,*eptr, * sptr;
  wgt_t w;

  vtx_t * labels = NULL;
  adj_t * xadj = NULL;
  vtx_t * adjncy = NULL;
  wgt_t * adjwgt = NULL;

  bufsize = BUFFERSIZE;

  if ((rv = __open_file(filename,"r",&file)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }
  line = char_alloc(bufsize);

  int do_adjwgt = 0;

  nedges = 0;

  /* first pass to count edges and vertices */
  maxv = 0;
  while((ll = dl_get_next_line(file,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      /* ignore blank lines */
      continue;
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    i = (vtx_t)strtoull(sptr,&eptr,10);
    sptr = eptr;
    j = (vtx_t)strtoull(sptr,&eptr,10);
    sptr = eptr;
    w = (wgt_t)strtod(sptr,&eptr);
    if (eptr != sptr) {
      /* if anyone is missing weight, we'll assign 1 */
      printf("Parsing edge weight from SNAP graph\n");
      do_adjwgt = 1;
    }
    if (i > maxv) {
      maxv = i;
    }
    if (j > maxv) {
      maxv = j;
    }
    /* count edges in both directions */
    nedges+=2;
  }
  nvtxs = maxv+1;

  labels = vtx_init_alloc(NULL_VTX,nvtxs);
  xadj = adj_calloc(nvtxs+1);
  adjncy = vtx_alloc(nedges);
  if (do_adjwgt) {
    adjwgt = wgt_alloc(nedges);
  }
  dl_reset_file(file);

  /* second pass to populate xadj */
  nvtxs = 0;
  while((ll = dl_get_next_line(file,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      /* ignore blank lines */
      continue;
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    i = strtoull(sptr,&eptr,10);
    if (labels[i] == NULL_VTX) {
      u = labels[i] = nvtxs++;
    } else {
      u = labels[i];
    }
    sptr = eptr;
    j = strtoull(sptr,&eptr,10);
    if (labels[j] == NULL_VTX) {
      v = labels[j] = nvtxs++;
    } else {
      v = labels[j];
    }
    ++xadj[u+1];
    ++xadj[v+1];
  }
  xadj[0] = 0;
  adj_prefixsum_exc(xadj+1,nvtxs);
  dl_reset_file(file);

  DL_ASSERT(xadj[1] == 0,"Broken xadj for loading\n");

  /* final pass */
  w = 0; /* stops uninitialized complaints */
  while((ll = dl_get_next_line(file,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      /* ignore blank lines */
      continue;
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    sptr = line;
    u = labels[strtoull(sptr,&eptr,10)];
    sptr = eptr;
    v = labels[strtoull(sptr,&eptr,10)];
    sptr = eptr;
    if (do_adjwgt) {
      w = (wgt_t)strtod(sptr,&eptr);
      if (eptr == sptr) {
        /* if anyone is missing weight, we'll assign 1 */
        w = 1;
      }
    }
    adjncy[xadj[u+1]] = v;
    adjncy[xadj[v+1]] = u;
    if (do_adjwgt) {
      adjwgt[xadj[u+1]] = w;
      adjwgt[xadj[v+1]] = w;
    }
    ++xadj[u+1];
    ++xadj[v+1];
  }
  dl_free(labels);
  dl_free(line);
  dl_close_file(file);

  /* sort the edges */
  if (do_adjwgt) {
    for (i=0;i<nvtxs;++i) {
      __quicksort_edges(adjncy+xadj[i],adjwgt+xadj[i],xadj[i+1]-xadj[i]); 
    }
  } else {
    for (i=0;i<nvtxs;++i) {
      vtx_quicksort(adjncy+xadj[i],xadj[i+1]-xadj[i]); 
    }
  }

  /* remove duplicates */
  nedges = 0;
  for (i=0;i<nvtxs;++i) {
    j=xadj[i];
    xadj[i] = nedges;
    if (j<xadj[i+1]) {
      adjncy[nedges] = adjncy[j];
      if (do_adjwgt) {
        adjwgt[nedges] = adjwgt[j];
      }
      ++nedges;
      ++j;
    }
    for (;j<xadj[i+1];++j) {
      if (adjncy[j] != adjncy[j-1]) {
        adjncy[nedges] = adjncy[j];
        if (do_adjwgt) {
          adjwgt[nedges] = adjwgt[j];
        }
        ++nedges;
      }
    }
  }
  xadj[nvtxs] = nedges;

  if (r_nvtxs) {
    *r_nvtxs = nvtxs;
  }
  if (r_xadj) {
    *r_xadj = xadj;
  } else if (xadj) {
    dl_free(xadj);
  }
  if (r_adjncy) {
    *r_adjncy = adjncy;
  } else if (adjncy) {
    dl_free(adjncy);
  }
  /* doesn't support vwgt */
  if (r_vwgt) {
    *r_vwgt = NULL;
  }
  if (r_adjwgt) {
    *r_adjwgt = adjwgt;
  } else if (adjwgt) {
    dl_free(adjwgt);
  }

  return BOWSTRING_SUCCESS;

  ERROR:

  if (line) {
    dl_free(line);
  }
  if (labels) {
    dl_free(labels);
  }
  if (xadj) {
    dl_free(xadj);
  }
  if (adjncy) {
    dl_free(adjncy);
  }
  if (adjwgt) {
    dl_free(adjwgt);
  }
  return rv;

}


int write_snap_graph(const char * const filename, const vtx_t nvtxs, 
    const adj_t * const xadj, const vtx_t * const adjncy, 
    const wgt_t * const vwgt, const wgt_t * const adjwgt)
{
  return BOWSTRING_UNIMPLEMENTED;
}




/* DIMACS ********************************************************************/


int read_dimacs_graph(const char * const filename, vtx_t * const r_nvtxs, 
    adj_t ** const xadj, vtx_t ** const adjncy, wgt_t ** const vwgt, 
    wgt_t ** const adjwgt)
{
  return BOWSTRING_UNIMPLEMENTED;
}


int write_dimacs_graph(const char * const filename, const vtx_t nvtxs, 
    const adj_t * const xadj, const vtx_t * const adjncy, 
    const wgt_t * const vwgt, const wgt_t * const adjwgt)
{
  FILE * fout;
  vtx_t i, u,v;
  adj_t j, nedges;
  wgt_t w;
  int rv;

  nedges = (size_t)xadj[nvtxs];

  if ((rv = __open_file(filename,"w",&fout)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  } 

  fprintf(fout,"%c File generated by GraphUtils\n",DIMACS_COMMENT);
  fprintf(fout,"%c sp "PF_VTX_T" "PF_ADJ_T"\n",DIMACS_PROBLEM,nvtxs,nedges);

  for (i=0;i<nvtxs;++i) {
    v = i+1;
    for (j=(size_t)xadj[i];j<(size_t)xadj[i+1];++j) {
      u = ((size_t)adjncy[j])+1;
      if (adjwgt) {
        w = adjwgt[j];
      } else {
        w = 1;
      }
      fprintf(fout,"%c "PF_VTX_T" "PF_VTX_T" "PF_WGT_T"\n",DIMACS_ARC,v,u,w);
    }
  }

  dl_close_file(fout);

  return BOWSTRING_SUCCESS;

  ERROR:

  if (fout) {
    dl_close_file(fout);
    fout = NULL;
  }

  return rv;
}



/* EDGELIST ******************************************************************/

int translate_edgelist_to_snap(const char * const infile, 
    const char * const outfile)
{
  int rv;
  vtx_t i, j, nvtxs;
  ssize_t ll;
  char * line = NULL;
  char * v;
  char * key;
  size_t bufsize;
  file_t * ifile = NULL, * ofile = NULL;
  cv_tree_t * tree = NULL;

  bufsize = BUFFERSIZE;

  if ((rv = __open_file(infile,"r",&ifile)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }
  line = char_alloc(bufsize);

  tree = cv_tree_create(strcmp);

  nvtxs = 0;
  /* do a pass over the vertices to count nedges and O(nvtxs) */
  while((ll = dl_get_next_line(ifile,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      /* ignore blank lines */
      continue;
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    v = strtok(line,"\t ");
    key = (char*)malloc(strlen(v)+1);
    memcpy(key,v,strlen(v)+1);
    if (cv_tree_add(key,nvtxs,tree)) {
      ++nvtxs;
    } else {
      dl_free(key);
    }
    key = (char*)malloc(strlen(v)+1);
    memcpy(key,v,strlen(v)+1);
    v = strtok(NULL,"\t ");
    key = (char*)malloc(strlen(v)+1);
    memcpy(key,v,strlen(v)+1);
    if (cv_tree_add(key,nvtxs,tree)) {
      ++nvtxs;
    } else {
      dl_free(key);
    }
  }

  dl_reset_file(ifile);

  if ((rv = __open_file(outfile,"w",&ofile)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  while((ll = dl_get_next_line(ifile,&line,&bufsize)) >= 0) {
    if (ll == 0) {
      /* ignore blank lines */
      continue;
    } else {
      if (COMMENT_CHARS[(unsigned int)line[0]]) {
        /* skip comments */
        continue;
      }
    }
    v = strtok(line,"\t ");
    i = cv_tree_get(v,tree);
    v = strtok(NULL,"\t ");
    j = cv_tree_get(v,tree);
    fprintf(ofile,PF_VTX_T" "PF_VTX_T"\n",i,j);
  }

  dl_close_file(ifile);
  dl_close_file(ofile);

  dl_free(line);
  cv_tree_free(tree);

  return BOWSTRING_SUCCESS;

  ERROR:

  if (line) {
    dl_free(line);
  }

  if (ifile) {
    dl_close_file(ifile);
  }

  if (ofile) {
    dl_close_file(ofile);
  }

  if (tree) {
    cv_tree_free(tree);
  }

  return rv;
}


#endif
