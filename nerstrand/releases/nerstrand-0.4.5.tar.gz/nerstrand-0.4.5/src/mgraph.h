/**
 * @file mgraph.h
 * @brief Types and function prototypes for multi-level graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013, Regents of the University of Minnesota
 * @version 1
 * @date 2013-10-08
 */




#ifndef NERSTRAND_MGRAPH_H
#define NERSTRAND_MGRAPH_H




#include "base.h"
#include "graph.h"
#include "ucinfo.h"




/******************************************************************************
* TYPES ***********************************************************************
******************************************************************************/


typedef struct mgraph_t {
  size_t level;
  const graph_t * graph;
  vtx_t ** cmap;
  struct mgraph_t * coarser;
  struct mgraph_t * finer;
  ucinfo_t ** ucinfo;
  int free_cmap;
  int free_graph;
  int free_ucinfo;
} mgraph_t;




/******************************************************************************
* SERIAL FUNCTION PROTOTYPES **************************************************
******************************************************************************/


/**
 * @brief Initialize an mgraph structure
 *
 * @param mgraph The structure to initialize
 *
 * @return The initialized structure 
 */
mgraph_t * init_mgraph(
    mgraph_t * mgraph);


/**
 * @brief Setup an mgraph structure with the given parameters
 *
 * @param level The level of the mgraph (0 is finest)
 * @param graph The underlying graph structure
 * @param cmap The fine vertex to coarse vertex mapping
 * @param coarser The coarser mgraph
 * @param finer The finer mgraph
 *
 * @return A pointer to the setup mgraph structure
 */
mgraph_t * setup_mgraph(
    size_t level,
    graph_t const * graph,
    vtx_t ** cmap, 
    mgraph_t * coarser,
    mgraph_t * finer);


/**
 * @brief Free an mgraph structure and associated memory
 *
 * @param mgraph The mgraph to free
 *
 * @return !0 on success
 */
int free_mgraph(
    mgraph_t * mgraph);




/******************************************************************************
* PARALLEL FUNCTION PROTOTYPES ************************************************
******************************************************************************/


/**
 * @brief Setup an mgraph structure in parallel
 *
 * @param level The level of the new mgraph
 * @param graph The underlying graph
 * @param cmap The fine to coarse vertex mapping
 * @param coarser The coarser mgraph
 * @param finer The finer mgraph
 *
 * @return The setup mgraph
 */
mgraph_t * par_setup_mgraph(
    size_t level,
    graph_t const * graph,
    vtx_t * cmap, 
    mgraph_t * coarser,
    mgraph_t * finer);


/**
 * @brief Free the mgraph structure in parallel
 *
 * @param mgraph The mgraph to free
 *
 * @return !0 on success
 */
int par_free_mgraph(
    mgraph_t * mgraph);


/**
 * @brief Adjust a cmap generated with a the old offset to use the new offset 
 *
 * @param cmap The cmap to adjust
 * @param nvtxs The size of the cmap
 * @param olddist The graph distribution from which the cmap was created
 * @param newdist The graph distribution that the cmap will be used with
 *
 * @return !0 on success 
 */
int par_adjust_cmap(
    vtx_t * cmap, 
    vtx_t mynvtxs,
    graphdist_t olddist, 
    graphdist_t newdist);




#endif
