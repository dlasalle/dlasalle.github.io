/**
 * @file mgraph.c
 * @brief Functions for manipulating and allocating multi-level graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013, Regents of the University of Minnesota
 * @version 1
 * @date 2013-10-08
 */




#ifndef NERSTRAND_MGRAPH_C
#define NERSTRAND_MGRAPH_C




#include "mgraph.h"




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX mgraph
#define DLMEM_TYPE_T mgraph_t
#define DLMEM_STATIC
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T




/******************************************************************************
* PUBLIC SERIAL FUNCTIONS *****************************************************
******************************************************************************/
mgraph_t * init_mgraph(
    mgraph_t * const mgraph) 
{
  mgraph->level = 0;
  mgraph->graph = NULL;
  mgraph->cmap = NULL;
  mgraph->coarser = NULL;
  mgraph->finer = NULL;
  mgraph->free_cmap = 0;
  mgraph->free_graph = 0;
  mgraph->free_ucinfo = 0;
  return mgraph;
}


mgraph_t * setup_mgraph(
    size_t level, 
    const graph_t * const graph, 
    vtx_t ** cmap,
    mgraph_t * coarser,
    mgraph_t * finer)
{
  mgraph_t * mgraph = mgraph_calloc(1);
  mgraph->level = level;
  mgraph->graph = graph;
  mgraph->cmap = cmap;
  mgraph->coarser = coarser;
  mgraph->finer = finer;
  return mgraph;
}


int free_mgraph(
    mgraph_t * mgraph)
{
  const tid_t nthreads = mgraph->graph->npar;
  if (mgraph->free_graph) {
    free_graph((graph_t*)mgraph->graph);
  }
  if (mgraph->free_cmap) {
    r_vtx_free(mgraph->cmap,nthreads);
  }
  if (mgraph->free_ucinfo) {
    free_ucinfos(mgraph->ucinfo,nthreads);
  }
  dl_free(mgraph);
  return 1;
}


int adjust_cmap(
    vtx_t * const * const cmap,
    const vtx_t * const nvtxs, 
    const tid_t nthreads,
    const graphdist_t olddist,
    const graphdist_t newdist)
{
  tid_t myid;
  vtx_t i,k;
  tid_t o;
  for (myid=0;myid<nthreads;++myid) {
    for (i=0;i<nvtxs[myid];++i) {
      if (cmap[myid][i] >= olddist.offset) { /* remote vertex */
        k = gvtx_to_lvtx(cmap[myid][i],olddist);
        o = gvtx_to_tid(cmap[myid][i],olddist);
        cmap[myid][i] = lvtx_to_gvtx(k,o,newdist);
      }
    }
  }

  return 1;
}




/******************************************************************************
* PUBLIC PARALLEL FUNCTIONS ***************************************************
******************************************************************************/


mgraph_t * __psm_mgraph;
mgraph_t * par_setup_mgraph(
    size_t level, 
    const graph_t * const graph, 
    vtx_t * const cmap, 
    mgraph_t * const coarser, 
    mgraph_t * const finer)
{
  const tid_t myid = omp_get_thread_num();
  const tid_t nthreads = omp_get_num_threads();
  DL_ASSERT_EQUALS(nthreads,graph->npar,PF_TID_T);
  #pragma omp master
  {
    __psm_mgraph = mgraph_calloc(1);
    __psm_mgraph->level = level;
    __psm_mgraph->graph = graph;
    __psm_mgraph->coarser = coarser;
    __psm_mgraph->finer = finer;
    if (cmap) {
      __psm_mgraph->cmap = r_vtx_alloc(nthreads);
    } else {
      __psm_mgraph->cmap = NULL;
    }
  }
  #pragma omp barrier
  if (cmap) {
    __psm_mgraph->cmap[myid] = cmap;
    #pragma omp barrier
  }
  return __psm_mgraph;
}


int par_free_mgraph(
    mgraph_t * mgraph)
{
  const vtx_t myid = omp_get_thread_num();
  if (mgraph->free_graph) {
    par_free_graph((graph_t*)mgraph->graph);
  }
  if (mgraph->free_cmap) {
    dl_free(mgraph->cmap[myid]);
    #pragma omp barrier
    #pragma omp master
    {
      dl_free(mgraph->cmap);
    }
  }
  if (mgraph->free_ucinfo) {
    free_ucinfo(mgraph->ucinfo[myid]);
    #pragma omp barrier
    #pragma omp master
    {
      dl_free(mgraph->ucinfo);
    }
  }
  #pragma omp barrier
  #pragma omp master
  {
    dl_free(mgraph);
  }
  return 1;
}


int par_adjust_cmap(
    vtx_t * const cmap, 
    const vtx_t mynvtxs, 
    const graphdist_t olddist, 
    const graphdist_t newdist)
{
  vtx_t i,k;
  tid_t o;
  for (i=0;i<mynvtxs;++i) {
    if (cmap[i] >= olddist.offset) { /* remote vertex */
      k = gvtx_to_lvtx(cmap[i],olddist);
      o = gvtx_to_tid(cmap[i],olddist);
      cmap[i] = lvtx_to_gvtx(k,o,newdist);
    }
  }

  return 1;
}




#endif
