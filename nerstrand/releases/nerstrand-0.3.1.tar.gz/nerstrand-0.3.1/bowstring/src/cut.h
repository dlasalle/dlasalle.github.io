/**
 * @file cut.h
 * @brief Function prototypes for cutting graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2014-01-26
 */




#ifndef BOWSTRING_CUT_H
#define BOWSTRING_CUT_H




#include "base.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


int coordinate_bisection(vtx_t nvtxs, const wgt_t * vwgt, 
    const coord_t * x, wgt_t lwgt, vlbl_t * where);


int recursive_coordinate_bisection(vtx_t nvtxs, const adj_t * xadj,
    const vtx_t * adjncy, const wgt_t * vwgt, const wgt_t * adjwgt,
    const coord_t ** x, size_t ndim, const wgt_t * twgts, vlbl_t nparts, 
    vlbl_t * where);




#endif
