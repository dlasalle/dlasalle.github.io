/**
 * @file dlstring.c
 * @brief Functions for manipulating and processing strings
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-08
 */




#ifndef DL_STRING_C
#define DL_STRING_C




#include "dlstring.h"
#include "ctype.h"




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


size_t dl_string_split(const char * const string, const char * const delims, 
    char *** ptrs)
{
  size_t i,j,n,noc;
  char c;
  char * base, * ind;
  char ** oc;

  /* create a character map of all 0's */
  char map[128] = {0};
  n = strlen(delims);

  /* mark my delimiters */
  for (i=0;i<n;++i) {
    map[(int)delims[i]] = 1;
  }

  /* count occurences and allocate our split string */
  noc = 1;
  for (i=0,noc=0;(c = string[i]) != '\0';++i) {
    if (map[(int)c]) {
      ++noc;
    }
  }

  /* create our memory locations */
  base = (char*)malloc(i+(sizeof(char*)*noc));
  ind = base + (sizeof(char*)*noc);
  oc = (char**)base;

  /* copy over chunks my string */
  i=j=0;
  oc[0] = ind;
  while ((c = *ind) != '\0') {
    if (map[(int)c]) {
      ind[j] = string[i];
    } else {
      ind[j] = '\0';
      oc[j++] = ind;
    }
    ++ind;
  }

  /* set our output */
  *ptrs = (char**)base;

  return j;
}

size_t dl_string_occurances(const char * string, const char * substr)
{
  size_t noc,n;
  size_t i,j,k;
  char c;

  /* create a character map of all 0's */
  char map[128] = {0};
  if ((n = strlen(substr)) == 0) {
    /* if we have a length 0 substring, quit */
    return 0;
  }
  for (i=0;i<n;++i) {
    map[i] = 1;
  }

  noc = 0;
  /* this is stupid, I should start at 0 and count forward */
  i = n-1;
  while ((c = string[i]) != '\0') {
    /* see if we hit part of the substr */
    if (map[(int)c]) {
      for(k=n-1,j=i;k>0;--j,--k) {
        if (string[j] != substr[k]) {
          break;
        }
      }
      if (i-j == n) {
        ++noc;
      }
    }
    i += n;
  }

  return noc;
}


int dl_string_endswith(const char * const string, const char * const suffix)
{
  size_t nstr, nsuf;

  if (!string || !suffix) {
    return 0;
  } else {
    nstr = strlen(string);
    nsuf = strlen(suffix);
    if (nsuf > nstr) {
      return 0;
    } else {
      return strncmp(string+nstr-nsuf,suffix,nsuf) == 0;
    }
  }
}


int dl_string_lowerize(char * const string)
{
  size_t i = 0;
  while (string[i] != '\0') {
    string[i] = tolower(string[i]);
    ++i;
  }

  return 1;
}


int dl_string_nlowerize(char * const string, const size_t len)
{
  size_t i = 0;
  while (string[i] != '\0' && i < len) {
    string[i] = tolower(string[i]);
    ++i;
  }

  return 1;
}


int dl_string_upperize(char * const string)
{
  size_t i = 0;
  while (string[i] != '\0') {
    string[i] = toupper(string[i]);
    ++i;
  }

  return 1;
}


int dl_string_nupperize(char * const string, const size_t len)
{
  size_t i = 0;
  while (string[i] != '\0' && i < len) {
    string[i] = toupper(string[i]);
    ++i;
  }

  return 1;
}




#endif
