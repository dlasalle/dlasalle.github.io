/**
 * @file dynamic.c
 * @brief Functions for dynamic graph operations.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2014
 * @version 1
 * @date 2014-10-22
 */




#ifndef BOWSTRING_DYNAMIC_C
#define BOWSTRING_DYNAMIC_C




#include <bowstring_dynamic.h>
#include "base.h"




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static vtx_t const MIN_EDGES = sizeof(vtx_t)/64;




/******************************************************************************
* DOMLIB IMPORTS **************************************************************
******************************************************************************/


#define DLMEM_PREFIX dynnode
#define DLMEM_TYPE_T dynnode_t
#define DLMEM_STATIC 1
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


/**
 * @brief Determine the size of the current (or prospective) edge allocation.
 *
 * @param n The number of edges.
 */
static inline vtx_t __edge_size(
    vtx_t n)
{
  return dl_max(MIN_EDGES,vtx_uplog2(n));
}



/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


dyngraph_t * bowstring_dg_create(
    vtx_t const max_nvtxs)
{
  vtx_t i;
  dyngraph_t * graph;

  graph = (dyngraph_t*)malloc(sizeof(dyngraph_t));

  graph->nvtxs = 0;
  graph->max_nvtxs = max_nvtxs;

  /* initialize htable */
  graph->htable = vtx_init_alloc(NULL_VTX,max_nvtxs);

  /* initialize vertices */
  graph->nodes = dynnode_alloc(max_nvtxs); 
  for (i=0;i<max_nvtxs;++i) {
    graph->nodes[i].nadj = NULL_VTX;
  }

  return graph;
}


void bowstring_dg_addvtx(
    vtx_t const v,
    vtx_t const * const adjncy,
    wgt_t const * const adjwgt,
    vtx_t const nadj,
    dyngraph_t * const graph)
{
  vtx_t rnadj;

  ++graph->nvtxs;
  graph->nodes[v].nadj = nadj;

  if (nadj > 0) {
    rnadj = __edge_size(nadj);

    /* allocate my edge arrays */
    graph->nodes[v].adj = vtx_alloc(rnadj);
    graph->nodes[v].wgt = wgt_alloc(rnadj);

    /* populate my edge arrays */
    vtx_copy(graph->nodes[v].adj,adjncy,nadj);
    wgt_copy(graph->nodes[v].wgt,adjwgt,nadj);
  }
}


void bowstring_dg_addedge(
    vtx_t const v,
    vtx_t const u,
    wgt_t const w,
    dyngraph_t * const graph)
{
  vtx_t vnadj, unadj;

  vnadj = graph->nodes[v].nadj;
  unadj = graph->nodes[u].nadj;

  if (vnadj == __edge_size(vnadj)) {
    graph->nodes[v].adj = vtx_realloc(graph->nodes[v].adj,vnadj+1);
    graph->nodes[v].wgt = wgt_realloc(graph->nodes[v].wgt,vnadj+1);
  }
  if (unadj == __edge_size(unadj)) {
    graph->nodes[u].adj = vtx_realloc(graph->nodes[u].adj,unadj+1);
    graph->nodes[u].wgt = wgt_realloc(graph->nodes[u].wgt,unadj+1);
  }

  graph->nodes[v].adj[vnadj] = u;
  graph->nodes[v].wgt[vnadj] = w;
  ++graph->nodes[v].nadj;

  graph->nodes[u].adj[unadj] = v;
  graph->nodes[u].wgt[unadj] = w;
  ++graph->nodes[u].nadj;

  ++graph->nedges;
}


void bowstring_dg_delvtx(
    vtx_t const v,
    dyngraph_t * const graph)
{
  vtx_t i, j, k;
  vtx_t * adj;

  adj = graph->nodes[v].adj;

  dl_free(graph->nodes[v].wgt);

  /* remove edges */
  for (i=0;i<graph->nodes[v].nadj;++i) {
    k = adj[i];
    for (j=0;j<graph->nodes[k].nadj;++j) {
      if (graph->nodes[k].adj[j] == v) {
        graph->nodes[k].adj[j] = graph->nodes[k].adj[--graph->nodes[k].nadj];
        break;
      }
    }
  }

  graph->nedges -= graph->nodes[v].nadj;

  /* mark the vertex as not in the graph */
  graph->nodes[v].nadj = NULL_VTX;

  dl_free(adj); 
}


void bowstring_dg_deledge(
    vtx_t const v,
    vtx_t const u,
    dyngraph_t * const graph)
{
  vtx_t i, k;

  /* remove from v */
  for (i=0;i<graph->nodes[v].nadj;++i) {
    k = graph->nodes[v].adj[i];
    if (k == u) {
      graph->nodes[v].adj[i] = graph->nodes[v].adj[--graph->nodes[v].nadj]; 
      break;
    }
  }
  
  /* remove from u */
  for (i=0;i<graph->nodes[u].nadj;++i) {
    k = graph->nodes[u].adj[i];
    if (k == v) {
      graph->nodes[u].adj[i] = graph->nodes[u].adj[--graph->nodes[u].nadj]; 
      break;
    }
  }

  --graph->nedges;
}


void bowstring_dg_updateedge(
    vtx_t const v,
    vtx_t const u,
    vtx_t const w,
    dyngraph_t * const graph)
{
  vtx_t i, k;

  /* remove from v */
  for (i=0;i<graph->nodes[v].nadj;++i) {
    k = graph->nodes[v].adj[i];
    if (k == u) {
      graph->nodes[v].wgt[i] = w; 
      break;
    }
  }
  
  /* remove from u */
  for (i=0;i<graph->nodes[u].nadj;++i) {
    k = graph->nodes[u].adj[i];
    if (k == v) {
      graph->nodes[u].wgt[i] = w; 
      break;
    }
  }
}


vtx_t bowstring_dg_contract(
    int const method,
    vtx_t const * const vtxs,
    vtx_t const nvtxs,
    dyngraph_t * const graph)
{
  vtx_t i, j, k, m, v, nadj, min, l, lnadj;
  vtx_t * htable, * adj;
  wgt_t * wgt;
  dynnode_t node;

  /* we assume the htable is full of NULL_VTX */
  htable = graph->htable;

  /* decide how many edges I might have */
  nadj = 0;
  for (i=0;i<nvtxs;++i) {
    v = vtxs[i];
    nadj += graph->nodes[v].nadj; 
  }

  min = vtx_min_value(vtxs,nvtxs);

  /* the size of my new arrays */
  nadj = __edge_size(dl_min(graph->nvtxs-nvtxs,nadj));

  adj = vtx_alloc(nadj);
  wgt = wgt_alloc(nadj);

  nadj = 0;
  switch (method) {
    case BOWSTRING_CONTRACT_SUM:
      for (i=0;i<nvtxs;++i) {
        v = vtxs[i];
        node = graph->nodes[v];
        for (j=0;j<node.nadj;++j) {
          k = node.adj[j];
          if ((m = htable[k]) == NULL_VTX) {
            /* add edge */
            adj[nadj] = k;
            wgt[nadj] = node.wgt[j];
            htable[k] = nadj++;
          } else {
            /* update edge */
            wgt[m] += node.wgt[j];
          }
          /* delete the reverse edge */
          for (l=0;l<graph->nodes[k].nadj;++l) {
            if (v == graph->nodes[k].adj[l]) {
              graph->nodes[k].adj[l] = \
                  graph->nodes[k].adj[--graph->nodes[k].nadj];
              break;
            }
          }
        }
      }
      break;
    case BOWSTRING_CONTRACT_MAX:
      for (i=0;i<nvtxs;++i) {
        v = vtxs[i];
        node = graph->nodes[v];
        for (j=0;j<node.nadj;++j) {
          k = node.adj[j];
          if ((m = htable[k]) == NULL_VTX) {
            /* add edge */
            adj[nadj] = k;
            wgt[nadj] = node.wgt[j];
            htable[k] = nadj++;
          } else if (wgt[m] < node.wgt[j]) {
            /* update edge */
            wgt[m] = node.wgt[j];
          }
          /* delete the reverse edge */
          for (l=0;l<graph->nodes[k].nadj;++l) {
            if (v == graph->nodes[k].adj[l]) {
              graph->nodes[k].adj[l] = \
                  graph->nodes[k].adj[--graph->nodes[k].nadj];
              break;
            }
          }
        }
      }
      break;
    case BOWSTRING_CONTRACT_MIN:
      for (i=0;i<nvtxs;++i) {
        v = vtxs[i];
        node = graph->nodes[v];
        for (j=0;j<node.nadj;++j) {
          k = node.adj[j];
          if ((m = htable[k]) == NULL_VTX) {
            /* add edge */
            adj[nadj] = k;
            wgt[nadj] = node.wgt[j];
            htable[k] = nadj++;
          } else if (wgt[m] > node.wgt[j]) {
            /* update edge */
            wgt[m] = node.wgt[j];
          }
          /* delete the reverse edge */
          for (l=0;l<graph->nodes[k].nadj;++l) {
            if (v == graph->nodes[k].adj[l]) {
              graph->nodes[k].adj[l] = \
                  graph->nodes[k].adj[--graph->nodes[k].nadj];
              break;
            }
          }
        }
      }
      break;
    default:
      dl_error("Unknown contraction method '%d'\n",method);
  }

  for (i=0;i<nadj;++i) {
    k = adj[j];

    /* add edges to new node -- we know we have room because we deleted */
    lnadj = graph->nodes[k].nadj++;
    graph->nodes[k].adj[lnadj] = min;
    graph->nodes[k].wgt[lnadj] = wgt[j];

    /* clear htable */
    htable[k] = NULL_VTX;
  }

  /* delete contracted nodes */
  for (i=0;i<nvtxs;++i) {
    v = vtxs[i]; 
    graph->nodes[v].nadj = NULL_VTX;
    dl_free(graph->nodes[v].adj);
    dl_free(graph->nodes[v].wgt);
  }

  /* save new node */
  graph->nodes[min].nadj = nadj;
  graph->nodes[min].adj = adj; 
  graph->nodes[min].wgt = wgt; 

  graph->nvtxs -= nvtxs-1;

  return min;
}


void bowstring_dg_free(
    bowstring_dyngraph_t * graph)
{
  vtx_t i;

  for (i=0;i<graph->nvtxs;++i) {
    if (graph->nodes[i].nadj != NULL_VTX) {
      dl_free(graph->nodes[i].adj);
      dl_free(graph->nodes[i].wgt);
    }
  }

  dl_free(graph->nodes);
  dl_free(graph->htable);
  dl_free(graph);
}



#endif
