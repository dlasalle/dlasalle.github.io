#!/bin/bash

INPUTDIR="/scratch/glu22/graphs/big-power-law"
OUTPUTDIR="/scratch/glu22/graphs/nbg"

for f in "${INPUTDIR}"/*.graph; do
  g="${f##*/}" 
  OUT="${OUTPUTDIR}/${g%graph}nbg"
  if [[ ! -f "${OUT}" ]]; then
    echo "Converting '${f}'"
    ./build/Linux-x86_64/bin/bowstring convert -i"${f}" \
        -o"${OUT}"
    echo "Converted '${OUT}'"
  fi
done

