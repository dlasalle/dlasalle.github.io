/**
 * @file stp.c
 * @brief Functions for reading and writing STP files
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2014-02-13
 */




#ifndef BOWSTRING_STP_C
#define BOWSTRING_STP_C




#include "stp.h"


/******************************************************************************
* MACROS **********************************************************************
******************************************************************************/


#define __SECTION_STR "SECTION"
#define __STP_HEADER "33D32945 STP File, STP Format Version 1.0"




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const size_t BUFFERSIZE = 0x1000;




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static int __find_section(file_t * file, const char * const section, 
    size_t * const r_bufsize)
{
  int found = 0;
  ssize_t ll;
  char * line = NULL;
  size_t bufsize;
  char str[512];

  bufsize = *r_bufsize;

  while((ll = dl_get_next_line(file,&line,&bufsize)) >= 0) {
    dl_string_upperize(line);
    if (sscanf(line,__SECTION_STR" %512s",str) != 1) {
      continue;
    } else {
      if (strcmp(section,str) == 0) {
        /* found the section */
        found = 1;
        break;
      } else {
        /* some other section */
      }
    }
  }

  *r_bufsize = bufsize;

  return found;
}



/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int read_stp_graph(const char * const filename, vtx_t * const r_nvtxs, 
    adj_t ** const r_xadj, vtx_t ** const r_adjncy, wgt_t ** const r_vwgt, 
    wgt_t ** const r_adjwgt)
{
  int rv;
  vtx_t i, k, nvtxs;
  adj_t nedges, j, l;
  wgt_t w;
  ssize_t ll;
  char * line = NULL;
  size_t bufsize;
  file_t * ifile;

  vtx_t * x = NULL;
  vtx_t * y = NULL;
  wgt_t * z = NULL;

  adj_t * xadj = NULL;
  vtx_t * adjncy = NULL;
  wgt_t * adjwgt = NULL;


  if ((rv = __open_file(filename,"r",&ifile)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }
  line = char_alloc(bufsize);

  /* find the graph section */
  if (!__find_section(ifile,"GRAPH",&bufsize)) {
    eprintf("Could not find graph section\n");
    rv = BOWSTRING_INVALIDINPUT; 
    goto ERROR;
  }

  /* read the number of vertices/nodes */
  if ((ll = dl_get_next_line(ifile,&line,&bufsize)) < 0 || 
      sscanf(line,"Nodes "PF_VTX_T,&nvtxs) != 1) {
    eprintf("Could not read number of nodes from graph section\n");
    rv = BOWSTRING_INVALIDINPUT; 
    goto ERROR;
  }

  /* read the number of edges */
  if ((ll = dl_get_next_line(ifile,&line,&bufsize)) < 0 || 
      sscanf(line,"Edges "PF_ADJ_T,&nedges) != 1) {
    eprintf("Could not read number of edges from graph section\n");
    rv = BOWSTRING_INVALIDINPUT; 
    goto ERROR;
  }
  nedges *=2;

  /* allocate graph */
  xadj = adj_calloc(nvtxs+1);
  adjncy = vtx_alloc(nedges);
  adjwgt = wgt_alloc(nedges);


  /* allocate graph buffers */
  x = vtx_alloc(nedges/2);
  y = vtx_alloc(nedges/2);
  z = wgt_alloc(nedges/2);

  /* read in edges */
  for (j=0;j<nedges/2;++j) {
    if ((ll = dl_get_next_line(ifile,&line,&bufsize)) < 0 || 
        sscanf(line,"E "PF_VTX_T" "PF_VTX_T" "PF_WGT_T,&i,&k,&w) != 3) {
      eprintf("Could not read edge #"PF_ADJ_T": '%s'\n",j,line);
      rv = BOWSTRING_INVALIDINPUT; 
      goto ERROR;
    } else {
      ++xadj[i];
      ++xadj[k];
      --i;
      --k;
      x[j] = i;
      y[j] = k;
      z[j] = w;
    }
  }

  /* check the end of the edge list */
  if ((ll = dl_get_next_line(ifile,&line,&bufsize)) < 0 ||
      strncmp(line,"END",3) != 0) {
    eprintf("Invalid line at end of section: '%s'\n",line);
    rv = BOWSTRING_INVALIDINPUT; 
    goto ERROR;
  }

  /* close the file */
  dl_close_file(ifile);
  ifile = NULL;

  /* build edges */
  adj_prefixsum_exc(xadj+1,nvtxs);
  for (j=0;j<nedges/2;++j) {
    i = x[j];
    k = y[j];
    w = z[j];
    /* vertex a */
    l = xadj[i+1]++;
    adjncy[l] = k;
    adjwgt[l] = w;
    /* vertex b */
    l = xadj[k+1]++;
    adjncy[l] = i;
    adjwgt[l] = w;
  }

  /* free buffers */
  dl_free(x);
  dl_free(y);
  dl_free(z);

  *r_nvtxs = nvtxs;
  *r_xadj = xadj;
  *r_adjncy = adjncy;
  *r_adjwgt = adjwgt;
  *r_vwgt = NULL;


  return BOWSTRING_SUCCESS;

  ERROR:

  if (line) {
    dl_free(line);
  }

  if (ifile) {
    dl_close_file(ifile);
  }

  if (xadj) {
    dl_free(xadj);
  }

  if (adjncy) {
    dl_free(adjncy);
  }

  if (adjwgt) {
    dl_free(adjwgt);
  }

  if (x) {
    dl_free(x);
  }

  if (y) {
    dl_free(y);
  }

  if (z) {
    dl_free(z);
  }

  return rv;
}


int write_stp_graph(const char * const filename, const vtx_t nvtxs, 
    const adj_t * const xadj, const vtx_t * const adjncy, 
    const wgt_t * const vwgt, const wgt_t * const adjwgt)
{
  return BOWSTRING_UNIMPLEMENTED;
}




#endif
