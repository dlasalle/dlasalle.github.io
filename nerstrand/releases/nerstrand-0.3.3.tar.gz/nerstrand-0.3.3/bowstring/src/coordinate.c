/**
 * @file coordinate.c
 * @brief Function prototypes for embedding vertices in coordinate-space
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-11-20
 */




#ifndef BOWSTRING_COORDINATE_C
#define BOWSTRING_COORDINATE_C




#include "coordinate.h"




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const size_t NBFS_RANK_BINS = 16;




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int embed_BFS(
    const vtx_t nvtxs, 
    const adj_t * const xadj, 
    const vtx_t * const adjncy, 
    const wgt_t * const adjwgt, 
    coord_t * const coords, 
    const size_t ncoords)
{
  #ifdef XXX
  vtx_t i, k, sq, eq;
  coord_t maxval;
  vtx_t * q;
  vtx_t vhist[NBFS_RANK_BINS] = {0};
  #endif

  return BOWSTRING_SUCCESS;
}




#endif
