#ifndef NERSTRAND_UNCOARSEN_H
#define NERSTRAND_UNCOARSEN_H

#include "base.h"
#include "cluster.h"
#include "ucinfo.h"
#include "mgraph.h"
#include "objective.h"


/******************************************************************************
* SERIAL FUNCTION PROTOYPES ***************************************************
******************************************************************************/
/**
 * @brief Create and return the ucinfo for the supplied graph and clustering 
 *
 * @param clustering The clustering to use while deriving the ucinfo
 * @param mgraph The mgraph to use while deriving the ucinfo
 *
 * @return The derived ucinfo
 */
ucinfo_t ** derive_ucinfo(const clustering_t * clustering, 
    const mgraph_t * mgraph);



/**
 * @brief Project and refine a clustering from the coarser graph cmgraph to the
 * finer graph fmgraph
 *
 * @param objective The objective to use for projection and refinement
 * @param clustering The clustering to project and refine
 * @param fmgraph The fine graph
 * @param cmgraph The coarse graph
 *
 * @return The updated clustering 
 */
clustering_t * uncoarsen_graph(objective_t * objective, 
    clustering_t * clustering, mgraph_t * fmgraph, 
    const mgraph_t * cmgraph);


/**
 * @brief Verify the sanity of the boundary
 *
 * @param mgraph The mgraph with the boundary info
 * @param where The where vector describing the clustering
 *
 * @return 1 on success, 0 for invalid boundary info
 */
int check_bnd(const mgraph_t * mgraph, const cid_t * const * where);


/******************************************************************************
* PARALLEL FUNCTION PROTOYPES *************************************************
******************************************************************************/
/**
 * @brief Allocate and calculate a new ucinfo based on the graph and clustering
 * -- to be called by each thread in a parallel region
 *
 * @param clustering The clustering to calculate the ucinfo from
 * @param mgraph The graph to which the ucinfo belongs
 *
 * @return The newly created ucinfo 
 */
ucinfo_t * par_derive_ucinfo(const clustering_t * clustering, 
    const mgraph_t * mgraph);


/**
 * @brief Project and refine a clustering from the coarser graph cmgraph to the
 * finer graph fmgraph -- to be called by each thread in a parallel region
 *
 * @param objective The objective to use for projection and refinement
 * @param clustering The clustering to project and refine
 * @param fmgraph The fine graph
 * @param cmgraph The coarse graph
 *
 * @return The updated clustering 
 */
clustering_t * par_uncoarsen_graph(objective_t * objective, 
    clustering_t * clustering, mgraph_t * fmgraph, 
    const mgraph_t * cmgraph);


#endif
