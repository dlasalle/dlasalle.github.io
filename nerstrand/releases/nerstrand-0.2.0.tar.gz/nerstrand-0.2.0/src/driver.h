/**
 * @file driver.h
 * @brief Driver header for the nerstrand clustering algorithm
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013, Regents of the University of Minnesota
 * @version 1
 * @date 2013-07-23
 */

#ifndef NERSTRAND_DRIVER_H
#define NERSTRAND_DRIVER_H

#include "base.h"
#include "graph.h"
#include "objective.h"
#include "multilevel.h"
#include "io.h"

clustering_t * nerstrand_cluster(objective_t * objective, 
    const graph_t * graph);

#endif
