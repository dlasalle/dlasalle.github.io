#ifndef NERSTRAND_CONTRACT_H
#define NERSTRAND_CONTRACT_H

#include "base.h"
#include "aggregate.h"


/******************************************************************************
* SERIAL FUNCTION PROTOTYPES **************************************************
******************************************************************************/
/**
 * @brief Contract a graph given an aggregation 
 *
 * @param objective The objective specifying how to contract the graph
 * @param mgraph The graph to contract
 * @param aggregate The aggeregation to contract based on
 *
 */
graph_t * contract_graph(objective_t * objective, mgraph_t * mgraph, 
    const aggregate_t * aggregate);




/******************************************************************************
* PARALLEL FUNCTION PROTOTYPES ************************************************
******************************************************************************/


/**
 * @brief Contract a graph given an aggregation -- to be called by each thread
 * from within a parallel region
 *
 * @param objective The objective specifying how to contract the graph 
 * @param mgraph The graph to contract
 * @param aggregate The aggregation to contract based on
 *
 * @return The contracted (coarser) graph
 */
graph_t * par_contract_graph(objective_t * objective, mgraph_t * mgraph, 
    const aggregate_t * aggregate);


#endif
