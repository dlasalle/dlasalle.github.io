/**
 * @file dlstring.h
 * @brief Functions for manipulating strings
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-08
 */




#ifndef DL_STRING_H
#define DL_STRING_H




#include "domlib.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


size_t dl_string_split(const char * string, const char * delims, 
    char *** ptrs);


size_t dl_string_occurances(const char * string, const char * substr);


int dl_string_endswith(const char * string, const char * suffix);


#endif
