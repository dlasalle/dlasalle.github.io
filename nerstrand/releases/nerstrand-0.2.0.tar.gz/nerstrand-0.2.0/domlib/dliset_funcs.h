/**
 * @file dliset_funcs.h
 * @brief ISet functions
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-05
 */




/* prefixing ugliness */
#define DLISET_PRE2(prefix,suffix) prefix ## _ ## suffix
#define DLISET_PRE1(prefix,suffix) DLISET_PRE2(prefix,suffix)
#define DLISET_PUB(name) DLISET_PRE1(DLISET_PREFIX,name)
#define DLISET_PRI(name) DLISET_PRE1(_,DLISET_PRE1(DLISET_PREFIX,name))



/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/

#ifdef DLISET_NULL_VALUE
static const DLISET_TYPE_T DLISET_PRI(iset_null_value) =
    (DLISET_TYPE_T)DLISET_NULL_VALUE;
#else
static const DLISET_TYPE_T DLISET_PRI(iset_null_value) = (DLISET_TYPE_T)-1;
#endif


/******************************************************************************
* MEMORY FUNCTIONS ************************************************************
******************************************************************************/


#define DLMEM_PREFIX DLISET_PUB(iset)
#define DLMEM_TYPE_T DLISET_PUB(iset_t)
#define DLMEM_STATIC
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX


#define DLMEM_PREFIX DLISET_PRI(element)
#define DLMEM_TYPE_T DLISET_TYPE_T
#define DLMEM_STATIC
#include "dlmem_headers.h"
#undef DLMEM_STATIC
#undef DLMEM_TYPE_T
#undef DLMEM_PREFIX


/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


#ifndef DLISET_VISIBILITY
  #define DLISET_DEFVIS
  #define DLISET_VISIBILITY
#endif


DLISET_VISIBILITY DLISET_PUB(iset_t) * DLISET_PUB(iset_create)(
    const DLISET_TYPE_T min, const DLISET_TYPE_T max)
{
  DL_ASSERT(min <= max, "Attempt to create a iset where min is greater "
      "than max\n");
  DL_ASSERT(((DLISET_PRI(iset_null_value) < min) ||
        (DLISET_PRI(iset_null_value) > max)), "Attempt to create"
      "a iset where NULL_VALUE is in  between min and max\n");
  DLISET_PUB(iset_t) * set = DLISET_PUB(iset_alloc)(1);
  set->min = min;
  set->max = max;
  set->maxsize = (size_t)(set->max - set->min);
  set->size = 0;
  set->ind = DLISET_PRI(element_alloc)(set->maxsize);
  set->ptr = DLISET_PRI(element_init_alloc)(DLISET_PRI(iset_null_value),
      set->maxsize);
  return set;
}


DLISET_VISIBILITY DLISET_TYPE_T DLISET_PUB(iset_get)(const size_t i,
    const DLISET_PUB(iset_t) * const set)
{
  DL_ASSERT(i < set->size,"Attempting to get item from beyond set end\n");
  return set->ind[i];
}


DLISET_VISIBILITY int DLISET_PUB(iset_contains)(const DLISET_TYPE_T item, 
    const DLISET_PUB(iset_t) * const set)
{
  DL_ASSERT(item >= set->min, "Search for item less tham minimum in "
      "iset\n");
  DL_ASSERT(item < set->max, "Search for item greater tham maximum in "
      "iset\n");
  size_t idx = (size_t)(item - set->min);
  return set->ptr[idx] != DLISET_PRI(iset_null_value);
}


DLISET_VISIBILITY int DLISET_PUB(iset_add)(const DLISET_TYPE_T item, 
    DLISET_PUB(iset_t) * const set)
{
  DL_ASSERT(item >= set->min, "Trying to add item less tham minimum in "
      "iset\n");
  DL_ASSERT(item < set->max, "Trying to add  item greater tham maximum in "
      "iset\n");
  size_t idx = (size_t)(item - set->min);
  if (set->ptr[idx] == DLISET_PRI(iset_null_value)) {
    set->ptr[idx] = set->size;
    set->ind[(size_t)set->size++] = item;
    return 1;
  } else {
    return 0;
  }
}


DLISET_VISIBILITY int DLISET_PUB(iset_remove)(const DLISET_TYPE_T item,
    DLISET_PUB(iset_t) * const set)
{
  DL_ASSERT(item >= set->min, "Trying to delete item less tham minimum in "
      "iset\n");
  DL_ASSERT(item < set->max, "Trying to delete item greater tham maximum "
      "in iset\n");
  size_t idx = (size_t)(item - set->min);
  size_t odx;
  if (set->ptr[idx] == DLISET_PRI(iset_null_value)) {
    return 0;
  } else {
    odx = set->ind[set->ptr[idx]] = set->ind[--set->size];
    set->ptr[odx-set->min] = set->ptr[idx];
    set->ptr[idx] = DLISET_PRI(iset_null_value);
    return 1;
  }
}


DLISET_VISIBILITY int DLISET_PUB(iset_populate)(DLISET_PUB(iset_t) * const set)
{
  size_t i;
  const size_t n = set->maxsize;
  for (i=0;i<n;++i) {
    set->ptr[i] = i;
    set->ind[i] = i+set->min;
  }
  set->size = n;
  return 1;
}


DLISET_VISIBILITY size_t DLISET_PUB(iset_clear)(DLISET_PUB(iset_t) * const set)
{
  const size_t n = set->size;
  size_t i;
  DLISET_TYPE_T j;
  for (i=0;i<n;++i) {
    j = set->ind[i];
    set->ptr[j] = DLISET_PRI(iset_null_value);
  }
  set->size = 0;
  return n;
}


DLISET_VISIBILITY DLISET_TYPE_T DLISET_PUB(iset_indexof)(
    const DLISET_TYPE_T item, const DLISET_PUB(iset_t) * const set)
{
  DL_ASSERT(item >= set->min, "Trying to find item less tham minimum in "
      "iset\n");
  DL_ASSERT(item < set->max, "Trying to find item greater tham maximum in "
      "iset\n");
  size_t idx = (size_t)(item - set->min);
  return set->ptr[idx];
}


DLISET_VISIBILITY void DLISET_PUB(iset_free)(DLISET_PUB(iset_t) * ptr)
{
  dl_free(ptr->ptr);
  dl_free(ptr->ind);
  dl_free(ptr);
}




#ifdef DLISET_VISIBILITY
  #undef DLISET_DEFVIS
  #undef DLISET_VISIBILITY
#endif


#undef DLISET_PRE2
#undef DLISET_PRE1
#undef DLISET_PRI
#undef DLISET_PUB


