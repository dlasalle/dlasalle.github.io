/**
 * @file cut.h
 * @brief Function prototypes for cutting graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2014-01-26
 */




#ifndef BOWSTRING_CUT_H
#define BOWSTRING_CUT_H




#include "base.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


int bisect_coordinates(vtx_t nvtxs, const adj_t * xadj, const wgt_t * vwgt, 
    const coord_t * x, vlbl_t * where);





#endif
