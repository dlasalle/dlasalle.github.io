/**
 * @file io.h
 * @brief IO File operations for graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2012
 * @version 1
 * @date 2013-04-09
 */

#ifndef BOWSTRING_IO_H
#define BOWSTRING_IO_H

#include "base.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/

/* labels */
int read_vertex_labels(const char * filename, vtx_t * nvtxs, vlbl_t ** labels);


int write_vertex_labels(const char * filename, vtx_t nvtxs, 
    const vlbl_t * labels);


int read_edge_labels(const char * filename, adj_t * nedges, elbl_t ** labels);


int write_edge_labels(const char * filename, adj_t nedges, 
    const elbl_t * labels);


/* matrices */
int write_matrix(const char * filename, const coord_t * const * coords, 
    vtx_t n, size_t m);


/* nerstrand */
int write_nerstrand_graph(const char * filename, vtx_t nvtxs, 
    const adj_t * xadj, const vtx_t * adjncy, const wgt_t * vwgt, 
    const wgt_t * adjwgt);


/* metis */
int read_metis_graph(const char * filename, vtx_t * nvtxs, adj_t ** xadj, 
    vtx_t ** adjncy, wgt_t ** vwgt, wgt_t ** adjwgt);


int write_metis_graph(const char * filename, vtx_t nvtxs, const adj_t * xadj,
    const vtx_t * adjncy, const wgt_t * vwgt, const wgt_t * adjwgt);


int translate_metis_to_snap(const char * infile, const char * outfile);


int translate_metis_to_cloud9(const char * infile, const char * outfile);


int translate_metis_to_dimacs(const char * infile, const char * outfile);


/* csr */
int read_csr_graph(const char * filename, vtx_t * nvtxs, adj_t ** xadj, 
    vtx_t ** adjncy, wgt_t ** vwgt, wgt_t ** adjwgt);


int write_csr_graph(const char * filename, vtx_t nvtxs, const adj_t * xadj,
    const vtx_t * adjncy, const wgt_t * vwgt, const wgt_t * adjwgt);


int translate_csr_to_snap(const char * infile, const char * outfile);


int translate_csr_to_cloud9(const char * infile, const char * outfile);


int translate_csr_to_pegasus(const char * infile, const char * outfile);


int translate_csr_to_matrixmarket(const char * infile, const char * outfile);


int tile_csr(const char * infile, const char * outfile, vtx_t nx, vtx_t ny);


/* cloud9 */
int read_cloud9_graph(const char * filename, vtx_t * nvtxs, adj_t ** xadj, 
    vtx_t ** adjncy, wgt_t ** vwgt, wgt_t ** adjwgt);


int write_cloud9_graph(const char * filename, vtx_t nvtxs, const adj_t * xadj,
    const vtx_t * adjncy, const wgt_t * vwgt, const wgt_t * adjwgt);


/* snap */
int read_snap_graph(const char * filename, vtx_t * nvtxs, adj_t ** xadj, 
    vtx_t ** adjncy, wgt_t ** vwgt, wgt_t ** adjwgt);


int write_snap_graph(const char * filename, vtx_t nvtxs, const adj_t * xadj,
    const vtx_t * adjncy, const wgt_t * vwgt, const wgt_t * adjwgt);


/* dimacs */
int read_dimacs_graph(const char * filename, vtx_t * nvtxs, adj_t ** xadj, 
    vtx_t ** adjncy, wgt_t ** vwgt, wgt_t ** adjwgt);


int write_dimacs_graph(const char * filename, vtx_t nvtxs, const adj_t * xadj,
    const vtx_t * adjncy, const wgt_t * vwgt, const wgt_t * adjwgt);


/* edgelist */
int translate_edgelist_to_snap(const char * infile, const char * outfile);

#endif
