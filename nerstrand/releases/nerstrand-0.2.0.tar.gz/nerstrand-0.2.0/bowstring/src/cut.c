/**
 * @file cut.c
 * @brief Functions for cutting graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2014-01-26
 */




#ifndef BOWSTRING_CUT_C
#define BOWSTRING_CUT_C




#include "cut.h"




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static int _split_graph(const vtx_t nvtxs, const wgt_t * const vwgt, 
    const vlbl_t * const where, coord_t ** const x, vtx_t * snvtxs, 
    wgt_t ** const svwgt, coord_t *** const coords, vtx_t ** const lbl)
{
  vtx_t i;
  vlbl_t w;
  
  snvtxs[0] = snvtxs[1] = 0;
  for (i=0;i<nvtxs;++i) {
    w = where[i];
    coords[w][snvtxs[w]] = x[i];
    if (lbl) {
      lbl[w][snvtxs[w]] = i;
    }
    if (svwgt) {
      svwgt[w][snvtxs[w]] = vwgt[i];
    }
    ++snvtxs[w];
  }

  return BOWSTRING_SUCCESS;
}


/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int bisect_coordinates(const vtx_t nvtxs, const adj_t * const xadj, 
    const wgt_t * const vwgt, const coord_t * const x, vlbl_t * where)
{
  vtx_t pivot,n,s,i,j;
  coord_t pv;
  coord_t * mx;

  const vtx_t center = nvtxs/2;

  mx = coord_duplicate(x,nvtxs);
  n = nvtxs;
  s = 0;

  while (1) {
    j = s; 
    pivot = vtx_rand(s,n);
    
    pv = mx[pivot];
    mx[pivot] = mx[n-1];
    for (i=s;i<n-1;++i) {
      if (mx[i] <= pv) {
        dl_swap(mx[j],mx[i]);
        ++j;
      }
    }
    mx[n-1] = mx[j];
    mx[j] = pv;
    if (j == center) {
      break;
    } else if (j < center) {
      s = j;
    } else {
      n = j;
    }
  }
  /* j is the median */
  pv = mx[j];

  dl_free(mx);

  for (i=0;i<nvtxs;++i) {
    if (x[i] > pv) {
      where[i] = 1;
    } else {
      where[i] = 0;
    }
  }

  return BOWSTRING_SUCCESS;
}





#endif
