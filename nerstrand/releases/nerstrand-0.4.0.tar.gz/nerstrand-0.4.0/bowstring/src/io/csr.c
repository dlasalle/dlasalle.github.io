/**
 * @file csr.c
 * @brief Functions for reading and writing graphs stored in CSR format
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2014-02-13
 */




#ifndef BOWSTRING_IO_CSR_C
#define BOWSTRING_IO_CSR_C




#include "csr.h"




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const size_t BUFFERSIZE = 0x1000;
static const char COMMENT_CHARS[256] = {
  ['#']=1,
  ['%']=1,
  ['\'']=1,
  ['"']=1,
  ['/']=1
};




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int read_csr_graph(const char * const filename, vtx_t * const r_nvtxs, 
    adj_t ** const xadj, vtx_t ** const adjncy, wgt_t ** const vwgt, 
    wgt_t ** const adjwgt)
{
  return BOWSTRING_ERROR_UNIMPLEMENTED;
}


int write_csr_graph(const char * const filename, const vtx_t nvtxs, 
    const adj_t * const xadj, const vtx_t * const adjncy, 
    const wgt_t * const vwgt, const wgt_t * const adjwgt)
{
  return BOWSTRING_ERROR_UNIMPLEMENTED;
}




#endif
