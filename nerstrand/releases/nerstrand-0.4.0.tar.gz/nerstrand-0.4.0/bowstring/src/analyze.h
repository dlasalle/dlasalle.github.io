/**
 * @file analytics.h
 * @brief Functions for measuring and estimating characteristics of graphs
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-09
 */




#ifndef BOWSTRING_ANALYZE_H
#define BOWSTRING_ANALYZE_H




#include "base.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


int degree_distribution(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    vtx_t ** degrees, 
    vtx_t * maxdegree);


int nhop_degree_distribution(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    vtx_t nhops, 
    vtx_t ** degrees, 
    vtx_t * maxdegree);


size_t count_triangles(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy,
    adj_t * radj);


int count_atomic_cycles(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy,
    adj_t * radj, 
    size_t ** r_cycles, 
    vtx_t * r_maxcycle);


int count_stars(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy,
    vtx_t ** r_stars, 
    vtx_t * r_maxstar);


int calc_domaindegree(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const wgt_t * adjwgt, 
    vlbl_t nparts, 
    const vlbl_t * where, 
    wgt_t * dd);


int calc_domaincomvol(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const wgt_t * vwgt, 
    vlbl_t nparts, 
    const vlbl_t * where, 
    wgt_t * dcvo,
    wgt_t * dcvi);


wgt_t calc_edgecut(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const wgt_t * adjwgt, 
    const vlbl_t * where);


wgt_t calc_communicationvolume(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const wgt_t * vwgt, 
    vlbl_t nparts,
    const vlbl_t * where);


wgt_t calc_max_domaincomvol(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const wgt_t * vwgt, 
    vlbl_t nparts,
    const vlbl_t * where);


wgt_t calc_max_domaindegree(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const wgt_t * adjwgt, 
    vlbl_t nparts,
    const vlbl_t * where);


double calc_vertex_balance(
    vtx_t nvtxs,
    const adj_t * xadj,
    const vtx_t * adjncy,
    const wgt_t * vwgt,
    vlbl_t nparts,
    const vlbl_t * where);


double calc_edge_balance(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const wgt_t * adjwgt, 
    vlbl_t nparts,
    const vlbl_t * where);


double calc_degree_balance(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const wgt_t * adjwgt, 
    vlbl_t nparts,
    const vlbl_t * where);


double calc_comvol_balance(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const wgt_t * adjwgt, 
    vlbl_t nparts,
    const vlbl_t * where);




#endif
