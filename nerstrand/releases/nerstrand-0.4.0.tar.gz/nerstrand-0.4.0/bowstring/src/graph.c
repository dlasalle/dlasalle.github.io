/**
 * @file graph.c
 * @brief Functions for performing misc graph operations
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-08-07
 */


#ifndef GRAPH_C
#define GRAPH_C


#include "graph.h"




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const vtx_t UNASSIGNED = (vtx_t)-1;
static const vtx_t QUEUED = (vtx_t)-2;




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static int __check_radj(
    const vtx_t nvtxs,
    const vtx_t * const adjncy,
    const adj_t nedges, 
    const adj_t * const radj)
{
  adj_t j;

  for (j=0;j<nedges;++j) {
    if (adjncy[j] < nvtxs) {
      if (radj[radj[j]] != j) {
        eprintf("Bad reverse adjacency list j = "PF_ADJ_T", radj[j] = "
            PF_ADJ_T", radj[radj[j]] = "PF_ADJ_T"\n",j,radj[j],radj[radj[j]]);
        return 0;
      }
    } else {
      if (radj[j] != NULL_ADJ) {
        eprintf("Bad reverse adjacency list j = "PF_ADJ_T", adjncy[j] = "
            PF_VTX_T", radj[j] = "PF_ADJ_T"\n",j,adjncy[j],radj[j]);
        return 0;
      }
    }
  }

  return 1;
}




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int apply_edge_mask(
    const vtx_t nvtxs, 
    const adj_t * const gxadj, 
    const vtx_t * const gadjncy, 
    const wgt_t * const gadjwgt, 
    const int * const adjmask, 
    adj_t ** const r_xadj, 
    vtx_t ** const r_adjncy, 
    wgt_t ** const r_adjwgt) 
{
  vtx_t i;
  adj_t j, tnedges;
  adj_t * xadj = NULL;
  vtx_t * adjncy = NULL;
  wgt_t * adjwgt = NULL;

  const adj_t nedges = int_sum(adjmask,gxadj[nvtxs]);

  xadj = adj_alloc(nvtxs+1);
  if (gadjncy) {
    adjncy = vtx_alloc(nedges);
  }
  if (gadjwgt) {
    adjwgt = wgt_alloc(nedges); 
  }
  tnedges = xadj[0] = 0;
  if (adjwgt) {
    if (adjncy) {
      for (i=0;i<nvtxs;++i) {
        for (j=gxadj[i];j<gxadj[i+1];++j) {
          if (adjmask[j]) {
            adjncy[tnedges] = gadjncy[j];
            adjwgt[tnedges] = gadjwgt[j];
            ++tnedges;
          }
        }
        xadj[i+1] = tnedges;
      }
    } else {
      for (i=0;i<nvtxs;++i) {
        for (j=gxadj[i];j<gxadj[i+1];++j) {
          if (adjmask[j]) {
            adjwgt[tnedges++] = gadjwgt[j];
          }
        }
        xadj[i+1] = tnedges;
      }
    }
  } else {
    if (adjncy) {
      for (i=0;i<nvtxs;++i) {
        for (j=gxadj[i];j<gxadj[i+1];++j) {
          if (adjmask[j]) {
            adjncy[tnedges++] = gadjncy[j];
          }
        }
        xadj[i+1] = tnedges;
      }
    } else {
      for (i=0;i<nvtxs;++i) {
        for (j=gxadj[i];j<gxadj[i+1];++j) {
          if (adjmask[j]) {
            ++tnedges;
          }
        }
        xadj[i+1] = tnedges;
      }
    }
  }

  if (r_xadj) {
    *r_xadj = xadj;
  } else if (xadj) {
    dl_free(xadj);
  }
  if (r_adjncy) {
    *r_adjncy = adjncy;
  } else if (adjncy) {
    dl_free(adjncy);
  }
  if (r_adjwgt) {
    *r_adjwgt = adjwgt;
  } else if (adjwgt) {
    dl_free(adjwgt);
  }
  
  return BOWSTRING_SUCCESS;
}


vtx_t mark_boundary_vertices(
    const vtx_t nvtxs, 
    const adj_t * const xadj, 
    const vtx_t * const adjncy, 
    const vlbl_t * const where, 
    int * const bnd)
{
  vtx_t i, k, nbnd;
  adj_t j;
  vlbl_t w;

  nbnd = 0;
  for (i=0;i<nvtxs;++i) {
    w = where[i];
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (w != where[k]) {
        if (bnd) {
          bnd[i] = 1;
        }         
        ++nbnd;
      } else {
        if (bnd) {
          bnd[i] = 0;
        }
      }
    }
  }

  return nbnd;
}


vtx_t find_boundary_vertices(
    const vtx_t nvtxs, 
    const adj_t * const xadj, 
    const vtx_t * const adjncy, 
    const vlbl_t * const where, 
    vtx_t ** const r_bnd)
{
  vtx_t i, k, nbnd;
  adj_t j;
  vlbl_t w;

  vtx_t * bnd = NULL;

  if (r_bnd) {
    bnd = vtx_alloc(nvtxs);
  }

  nbnd = 0;
  for (i=0;i<nvtxs;++i) {
    w = where[i];
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (w != where[k]) {
        if (r_bnd) {
          bnd[nbnd++] = i;
        } else {
          ++nbnd;
        }
      }
    }
  }

  if (r_bnd) {
    *r_bnd = vtx_realloc(bnd,nbnd);
  }

  return nbnd;
}


int build_adjncy_index(
    const vtx_t nvtxs, 
    const adj_t * const xadj,
    const vtx_t * const adjncy, 
    adj_t * const radj)
{
  vtx_t i, k;
  adj_t j;
  vtx_t * tadj;
  adj_t * txadj, * padj, * tradj, * trans; 

  const adj_t nedges = xadj[nvtxs];

  /* In this loop the lower number vertex on each edge inserts the edge and its
   * reverse index into the radj array. The txadj array is used to track where
   * into that array it should be inserted. The radj array stores a permuted
   * adjncy list for each vertex, and the tradj array stores the reverse index
   * for the tadj array. */ 
  txadj = adj_duplicate(xadj,nvtxs+1);
  tadj = vtx_alloc(nedges); 
  tradj = adj_alloc(nedges);
  for (i=0;i<nvtxs;++i) {
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (i < k) {
        tadj[txadj[i]] = k;
        tradj[txadj[i]] = txadj[k];
        tadj[txadj[k]] = i;
        tradj[txadj[k]] = txadj[i];
        ++txadj[k];
        ++txadj[i];
      }
    }
  }
  dl_free(txadj);

  /* In this loop the padj array is populated such that it serves as a
   * permutation array from tadj to adjncy. */
  trans = adj_alloc(nvtxs);
  padj = adj_alloc(nedges);
  for (i=0;i<nvtxs;++i) {
    /* write the location of edges in the original graph to trans */
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      trans[k] = j;
    }
    /* using the new ordering of the edges, read in the location of the edges
     * from the original graph. */
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = tadj[j];
      padj[j] = trans[k];
    }
  }
  dl_free(trans);
  dl_free(tadj);

  /* correct radj -- save it to tadj */
  for (i=0;i<nvtxs;++i) {
    for (j=xadj[i];j<xadj[i+1];++j) {
      radj[padj[j]] = padj[tradj[j]];
    }
  }

  dl_free(padj);
  dl_free(tradj);

  DL_ASSERT(__check_radj(nvtxs,adjncy,nedges,radj) == 1,
      "Bad radj generated\n");

  return BOWSTRING_SUCCESS;
}


int build_adjncy_index_rem(
    const vtx_t nvtxs, 
    const adj_t * const xadj,
    const vtx_t * const adjncy, 
    adj_t * const radj)
{
  vtx_t i, k, nr;
  adj_t j, l;
  vtx_t * tadj;
  adj_t * txadj, * padj, * tradj, * trans; 

  const adj_t nedges = xadj[nvtxs];

  /* In this loop the lower number vertex on each edge inserts the edge and its
   * reverse index into the radj array. The txadj array is used to track where
   * into that array it should be inserted. The radj array stores a permuted
   * adjncy list for each vertex, and the tradj array stores the reverse index
   * for the tadj array. */ 
  txadj = adj_duplicate(xadj,nvtxs+1);
  tadj = vtx_alloc(nedges); 
  tradj = adj_alloc(nedges);
  for (i=0;i<nvtxs;++i) {
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (i < k) {
        if (k < nvtxs) {
          /* handle local edges normally */
          tadj[txadj[i]] = k;
          tradj[txadj[i]] = txadj[k];
          tadj[txadj[k]] = i;
          tradj[txadj[k]] = txadj[i];
          ++txadj[k];
          ++txadj[i];
        } else {
          /* for incomplete graphs */
          tadj[txadj[i]] = k;
          tradj[txadj[i]] = NULL_ADJ;
          ++txadj[i];
        }
      }
    }
  }
  dl_free(txadj);

  /* In this loop the padj array is populated such that it serves as a
   * permutation array from tadj to adjncy. Remote edges have their ordering
   * preserved. */
  trans = adj_alloc(nvtxs+nedges);
  padj = adj_alloc(nedges);
  for (i=0;i<nvtxs;++i) {
    /* write the location of edges in the original graph to trans */
    nr = nvtxs;
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (k < nvtxs) {
        trans[k] = j;
      } else {
        trans[nr++] = j;
      }
    }
    /* using the new ordering of the edges, read in the location of the edges
     * from the original graph. */
    nr = nvtxs;
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = tadj[j];
      if (k < nvtxs) {
        padj[j] = trans[k];
      } else {
        padj[j] = trans[nr++];
      }
    }
  }
  dl_free(tadj);
  dl_free(trans);

  /* correct radj -- save it to tadj */
  for (i=0;i<nvtxs;++i) {
    for (j=xadj[i];j<xadj[i+1];++j) {
      l = tradj[j];
      if (l != NULL_ADJ) {
        radj[padj[j]] = padj[l];
      } else {
        radj[padj[j]] = NULL_ADJ;
      }
    }
  }

  dl_free(padj);
  dl_free(tradj);

  DL_ASSERT(__check_radj(nvtxs,adjncy,nedges,radj) == 1,
      "Bad radj generated\n");

  return BOWSTRING_SUCCESS;
}


vtx_t neighborhoodify(
    const vtx_t nvtxs, 
    const adj_t * const xadj, 
    const vtx_t * const adjncy, 
    vtx_t * const nbrhd, 
    const vtx_t nbrsize)
{
  vtx_t i, p, k, nnbrhd, nnbr, nbr, nq; 
  adj_t j;
  vtx_t * perm, * q;
  
  vtx_set(nbrhd,UNASSIGNED,nvtxs);
  q = vtx_alloc(nvtxs);
  perm = vtx_alloc(nvtxs);
  vtx_incset(perm,0,1,nvtxs);
  vtx_pseudo_shuffle(perm,nvtxs/16,nvtxs);

  nnbrhd = 0;
  for (p=0;p<nvtxs;++p) {
    i = perm[p];
    if (nbrhd[i] == UNASSIGNED) {
      nnbr = nq = 0;
      nbr = nnbrhd++;
      q[nq++] = i;
      while (nnbr < nq && nnbr < nbrsize) {
        i = q[nnbr++];
        nbrhd[i] = nbr;
        for (j=xadj[i];j<xadj[i+1];++j) {
          k = adjncy[j];
          if (nbrhd[k] == UNASSIGNED) {
            q[nq++] = k;
            nbrhd[k] = QUEUED;
          }
          if (nq >= nbrsize) {
            break;
          }
        }
      }
      /* clear nodes left in queue */
      while (nnbr < nq) {
        nbrhd[q[nnbr++]] = UNASSIGNED;
      }
    }
  }

  dl_free(perm);

  return nnbrhd;
}



#endif
