/**
 * @file graph.h
 * @brief Misc function prototypes for graph operations 
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-08-07
 */




#ifndef GRAPH_H
#define GRAPH_H




#include "base.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


int apply_edge_mask(
    vtx_t nvtxs, 
    const adj_t * gxadj, 
    const vtx_t * gadjncy, 
    const wgt_t * gadjwgt, 
    const int * adjmask, 
    adj_t ** r_xadj, 
    vtx_t ** r_adjncy, 
    wgt_t ** r_adjwgt); 


vtx_t mark_boundary_vertices(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const vlbl_t * where, 
    int * bnd);


vtx_t find_boundary_vertices(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy, 
    const vlbl_t * where, 
    vtx_t ** bnd);


/**
 * @brief Build a reverse adjacency index, such that:
 *
 * radj[radj[j]] = j
 *
 * and:
 *
 * for (j=xadj[i];j<xadj[i+1];++j) {
 *   adjncy[radj[j]] == i
 * }
 *
 * @param nvtxs Number of vertices in the graph
 * @param xadj The array pointing to the start of each vertices adjacency list
 * @param adjncy The adjacency list of each vertex
 * @param radj The reverse adjacency list -- output array of length 
 *   xadj[nvtxs].
 *
 * @return BOWSTRING_SUCCESS on success. 
 */
int build_adjncy_index(
    vtx_t nvtxs, 
    const adj_t * xadj,
    const vtx_t * adjncy, 
    adj_t * radj);


/**
 * @brief Build a reverse adjacency index supporting remote edges, such that:
 *
 * radj[radj[j]] = j
 *
 * and:
 *
 * for (j=xadj[i];j<xadj[i+1];++j) {
 *   adjncy[radj[j]] == i
 * }
 *
 * except for edges where adjncy[j] > nvtxs, in which case radj[j] = NULL_ADJ.
 *
 * @param nvtxs Number of vertices in the graph
 * @param xadj The array pointing to the start of each vertices adjacency list
 * @param adjncy The adjacency list of each vertex
 * @param radj The reverse adjacency list -- output array of length 
 *   xadj[nvtxs].
 *
 * @return BOWSTRING_SUCCESS on success. 
 */
int build_adjncy_index_rem(
    vtx_t nvtxs, 
    const adj_t * xadj,
    const vtx_t * adjncy, 
    adj_t * radj);


vtx_t neighborhoodify(
    vtx_t nvtxs, 
    const adj_t * xadj, 
    const vtx_t * adjncy,
    vtx_t * nbrhd, 
    vtx_t nbrsize);




#endif
