/**
 * @file newman.h
 * @brief Function prototypes for agglormerative clustering
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013, Regents of the University of Minnesota
 * @version 1
 * @date 2013-10-24
 */




#ifndef NERSTRAND_NEWMAN_H
#define NERSTRAND_NEWMAN_H




#include "cluster.h"
#include "graph.h"




/******************************************************************************
* FUNCTION PROTOTYPES *********************************************************
******************************************************************************/


clustering_t * generate_newman_clustering(
    const graph_t * graph);




#endif
