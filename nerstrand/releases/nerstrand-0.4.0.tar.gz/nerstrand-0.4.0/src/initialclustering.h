/**
 * @file initialclustering.h
 * @brief Function prototypes for initial clustering
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013, Regents of the University of Minnesota
 * @version 1
 * @date 2013-10-08
 */




#ifndef NERSTRAND_INITIALCLUSTERING_H
#define NERSTRAND_INITIALCLUSTERING_H




#include "base.h"
#include "cluster.h"
#include "mgraph.h"
#include "objective.h"




/******************************************************************************
* SERIAL FUNCTION PROTOTYPES **************************************************
******************************************************************************/


clustering_t * generate_kclustering(
    objective_t * objective,
    mgraph_t * mgraph);


clustering_t * generate_aclustering(
    objective_t * objective,
    mgraph_t * mgraph);




/******************************************************************************
* PARALLEL FUNCTION PROTOTYPES ************************************************
******************************************************************************/


clustering_t * par_generate_kclustering(
    objective_t * objective,
    mgraph_t * mgraph);


clustering_t * par_generate_aclustering(
    objective_t * objective,
    mgraph_t * mgraph);



#endif
