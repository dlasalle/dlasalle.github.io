/**
 * @file dlblas_headers.h
 * @brief Basic linear algebra functions
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-09-29
 */




/* prefixing ugliness */
#define __DLBLAS_PRE2(prefix,suffix) prefix ## _ ## suffix
#define __DLBLAS_PRE1(prefix,suffix) __DLBLAS_PRE2(prefix,suffix)
#define DLBLAS_PUB(name) __DLBLAS_PRE1(DLBLAS_PREFIX,name)



/******************************************************************************
* MEMORY FUNCTIONS ************************************************************
******************************************************************************/


#define DLMEM_PREFIX DLBLAS_PUB(sparse_matrix)
#define DLMEM_TYPE_T DLBLAS_PUB(sparse_matrix_t)
#include "dlmem_funcs.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


#define DLMEM_PREFIX DLBLAS_PUB(dense_matrix)
#define DLMEM_TYPE_T DLBLAS_PUB(dense_matrix_t)
#include "dlmem_funcs.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


#define DLMEM_PREFIX DLBLAS_PUB(sparse_vector)
#define DLMEM_TYPE_T DLBLAS_PUB(sparse_vector_t)
#include "dlmem_funcs.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T


#define DLMEM_PREFIX DLBLAS_PUB(dense_vector)
#define DLMEM_TYPE_T DLBLAS_PUB(dense_vector_t)
#include "dlmem_funcs.h"
#undef DLMEM_PREFIX
#undef DLMEM_TYPE_T




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/



/* Initialization */
DLBLAS_PUB(sparse_matrix_t) * DLBLAS_PUB(sm_init)(const size_t nrows,
  const size_t ncols, const ssize_t nnz)
{
  DLBLAS_PUB(sparse_matrix_t) * mat = DLBLAS_PUB(sparse_matrix_alloc)(1);
  mat->n = nrows;
  mat->m = ncols;
  mat->nnz = nnz;
  mat->nner = mat->nnec = -1;
  mat->ptr = size_alloc(mat->n+1);
  mat->ptr[0] = 0;
  if (mat->nnz < 0) {
    /* Don't allocate ind or val */
    mat->ind = NULL;
    mat->val = NULL;
  } else {
    mat->ind = size_alloc(mat->nnz);
    mat->val = DLBLAS_PUB(alloc)(mat->nnz);
  }
  return mat;
}


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sv_init)(const size_t n,
    const ssize_t nnz)
{
  DLBLAS_PUB(sparse_vector_t) * vec = DLBLAS_PUB(sparse_vector_alloc)(1);
  vec->n = n;
  vec->nnz = nnz;
  if (vec->nnz < 0) {
    vec->ind = NULL;
    vec->val = NULL;
  } else {
    vec->ind = size_alloc(vec->nnz);
    vec->val = DLBLAS_PUB(alloc)(vec->nnz);
  }
  return vec;
}


DLBLAS_PUB(dense_matrix_t) * DLBLAS_PUB(dm_init)(const size_t n,
    const size_t m)
{
  DLBLAS_PUB(dense_matrix_t) * mat = DLBLAS_PUB(dense_matrix_alloc)(1);
  size_t i;
  mat->n = n;
  mat->m = m;
  mat->val = (DLBLAS_TYPE_T**)malloc(sizeof(DLBLAS_TYPE_T*)*n);
  mat->val[0] = DLBLAS_PUB(alloc)(m*n);
  for (i=1;i<n;++i) {
    mat->val[i] = mat->val[i-1]+m;
  }
  return mat;
}


DLBLAS_PUB(dense_vector_t) * DLBLAS_PUB(dv_init)(const size_t n)
{
  DLBLAS_PUB(dense_vector_t) * vec = DLBLAS_PUB(dense_vector_alloc)(1);
  vec->n = n;
  vec->val = DLBLAS_PUB(alloc)(n);
  return vec;
}


ssize_t DLBLAS_PUB(sm_update_nner)(DLBLAS_PUB(sparse_matrix_t) * mat)
{
  size_t i,nner;
  for (nner=mat->n,i=0;i<mat->n;++i) {
    if (mat->ptr[i+1] - mat->ptr[i] == 0) {
      --nner;
    }
  }
  return mat->nner = nner;
}


ssize_t DLBLAS_PUB(sm_update_nnec)(DLBLAS_PUB(sparse_matrix_t) * mat)
{
  size_t i,j;
  ssize_t nnec;
  ssize_t * cs;
  cs = ssize_init_alloc(0,mat->m);
  for (nnec=mat->n,i=0;i<mat->n;++i) {
    for (j=mat->ptr[i];j<mat->ptr[j+1];++j) {
      if (cs[mat->ind[j]]++ == 0) {
        ++nnec;
      }
    }
  }
  dl_free(cs);
  return mat->nnec = nnec;
}


/* Zero out */
DLBLAS_PUB(dense_matrix_t) * DLBLAS_PUB(dm_zero)(
    DLBLAS_PUB(dense_matrix_t) * mat) {
  size_t i;
  for (i=0;i<mat->n*mat->m;++i) {
    mat->val[0][i] = 0;
  }
  return mat;
}


DLBLAS_PUB(dense_vector_t) * DLBLAS_PUB(dv_zero)(
    DLBLAS_PUB(dense_vector_t) * vec)
{
  size_t i;
  for (i=0;i<vec->n;++i) {
    vec->val[i] = 0;
  }
  return vec;
}


/* Transformation */
DLBLAS_PUB(sparse_matrix_t) * DLBLAS_PUB(dm_sparsify)(
    DLBLAS_PUB(dense_matrix_t) * mat)
{
  size_t nnz,i,j,ind,ptr;
  size_t * colcount;
  for (nnz=i=0;i<mat->n*mat->m;++i) {
    if (mat->val[0][i] != 0) {
      ++nnz;
    }
  }
  colcount = size_init_alloc(0,mat->m);
  DLBLAS_PUB(sparse_matrix_t) * sm =
    DLBLAS_PUB(sm_init)(mat->n,mat->m,nnz);
  sm->nner = mat->n;
  sm->nnec = 0;
  for (ptr=ind=i=0;i<mat->n;++i) {
    for (j=0;j<mat->m;++j) {
      if (mat->val[i][j] != 0) {
        sm->val[ind] = mat->val[i][j];
        sm->ind[ind++] = j;
        if (colcount[j]++ == 0) {
          ++sm->nnec;
        }
      }
    }
    sm->ptr[++ptr] = ind;
    if (sm->ptr[ptr] == sm->ptr[ptr-1]) {
      --sm->nner;
    }
  }
  dl_free(colcount);
  return sm;
}


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(dv_sparsify)(
    DLBLAS_PUB(dense_vector_t) * vec)
{
  size_t nnz,i;
  for (nnz=i=0;i<vec->n;++i) {
    if (vec->val[i] != 0.0) {
      ++nnz;
    }
  }
  DLBLAS_PUB(sparse_vector_t) * sv = DLBLAS_PUB(sv_init)(vec->n,nnz);
  for (nnz=i=0;i<vec->n;++i) {
    if (vec->val[i] != 0.0) {
      sv->val[nnz] = vec->val[i];
      sv->ind[nnz++] = i;
    }
  }
  return sv;
}


DLBLAS_PUB(dense_matrix_t) * DLBLAS_PUB(sm_densify)(
    DLBLAS_PUB(sparse_matrix_t) * mat)
{
  size_t i,j;
  DLBLAS_PUB(dense_matrix_t) * dm = DLBLAS_PUB(dm_init)(mat->n,mat->m);
  for (i=0;i<mat->n;++i) {
    for (j=mat->ptr[i];j<mat->ptr[i+1];++j) {
      dm->val[i][mat->ind[j]] = mat->val[j];
    }
  }
  return dm;
}


DLBLAS_PUB(dense_vector_t) * DLBLAS_PUB(sv_densify)(
    DLBLAS_PUB(sparse_vector_t) * vec) {
  DL_ASSERT(vec->nnz >= 0,"Cannot densify a vector with < 0 nnz\n");
  size_t i;
  DLBLAS_PUB(dense_vector_t) * dv = DLBLAS_PUB(dv_init)(vec->n);
  for (i=0;i<(size_t)vec->nnz;++i) {
    dv->val[vec->ind[i]] = vec->val[i];
  }
  return dv;
}


DLBLAS_PUB(sparse_matrix_t) * DLBLAS_PUB(sm_transpose)(
    DLBLAS_PUB(sparse_matrix_t) * mat)
{
  size_t i,j,k;
  size_t * indptr;
  DLBLAS_PUB(sparse_matrix_t) * tmat =
    DLBLAS_PUB(sm_init)(mat->m,mat->n,mat->nnz);
  tmat->nnec = 0;
  size_set(tmat->ptr,0,tmat->n+1);
  for (i=0;i<mat->n;++i) {
    if (mat->ptr[i+1] > mat->ptr[i]) {
      ++tmat->nnec;
      for (j=mat->ptr[i];j<mat->ptr[i+1];++j) {
        ++(tmat->ptr[mat->ind[j]+1]);
      }
    }
  }
  tmat->nner = tmat->n;
  for (i=0;i<tmat->n;++i) {
    if (tmat->ptr[i+1] == 0) {
      --tmat->nner;
      tmat->ptr[i+1] = tmat->ptr[i];
    } else {
      tmat->ptr[i+1] += tmat->ptr[i];
    }
  }
  indptr = size_duplicate(tmat->ptr,tmat->n+1);
  for (i=0;i<mat->n;++i) {
    for (j=mat->ptr[i];j<mat->ptr[i+1];++j) {
      k = indptr[mat->ind[j]]++;
      tmat->val[k] = mat->val[j];
      tmat->ind[k] = i;
    }
  }
  dl_free(indptr);
  return tmat;
}


DLBLAS_PUB(dense_matrix_t) * DLBLAS_PUB(dm_transpose)(
    DLBLAS_PUB(dense_matrix_t) * mat)
{
  size_t i,j;
  DLBLAS_PUB(dense_matrix_t) * tmat = DLBLAS_PUB(dm_init)(mat->m,mat->n);
  for (i=0;i<mat->n;++i) {
    for (j=0;j<mat->m;++j) {
      tmat->val[j][i] = mat->val[i][j];
    }
  }
  return tmat;
}


DLBLAS_PUB(dense_matrix_t) * DLBLAS_PUB(dm_transpose_inplace)(
    DLBLAS_PUB(dense_matrix_t) * mat) {
  size_t i,j;
  for (i=0;i<mat->n;++i) {
    for (j=0;j<i;++j) {
      dl_swap(mat->val[j][i],mat->val[i][j]);
    }
  }
  return mat;
}


/* Sub-divsion */
DLBLAS_PUB(sparse_matrix_t) * DLBLAS_PUB(sm_submatrix)(
    DLBLAS_PUB(sparse_matrix_t) * mat, size_t si, size_t sj, size_t n,
    size_t m)
{
  size_t i,j,nnz,ptr;
  for (nnz=0,i=si;i<si+n;++i) {
    for (j=mat->ptr[i];j<mat->ptr[i+1];++j) {
      if (mat->ind[j] >= sj) {
        if (mat->ind[j] >= sj + m) {
          break;
        } else {
          ++nnz;
        }
      }
    }
  }
  DLBLAS_PUB(sparse_matrix_t) * sm = DLBLAS_PUB(sm_init)(n,m,nnz);
  size_set(sm->ptr,0,si+1);
  for (nnz=0,ptr=i=si;i<si+n;++i) {
    for (j=mat->ptr[i];j<mat->ptr[i+1];++j) {
      if (mat->ind[j] >= sj) {
        if (mat->ind[j] >= sj + m) {
          break;
        } else {
          sm->val[nnz] = mat->val[j];
          sm->ind[nnz++] = mat->ind[j];
        }
      }
    }
    sm->ptr[++ptr] = nnz;
  }
  size_set(sm->ptr+ptr+1,sm->ptr[ptr],mat->n-ptr);
  return sm;
}


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sv_subvector)(
    DLBLAS_PUB(sparse_vector_t) * vec, size_t si, size_t n)
{
  size_t i,nnz;
  ssize_t sidx;
  for (sidx=(-1),nnz=i=0;i<(size_t)vec->nnz;++i) {
    if (vec->ind[i] >= si) {
      if (vec->ind[i] >= si+n) {
        break;
      } else if (nnz == 0) {
        nnz = 1;
        sidx = i;
      } else {
        ++nnz;
      }
    }
  }
  DLBLAS_PUB(sparse_vector_t) * sv = DLBLAS_PUB(sv_init)(n,nnz);
  size_copy(sv->ind,vec->ind+sidx,nnz);
  DLBLAS_PUB(copy)(sv->val,vec->val+sidx,nnz);
  return sv;
}


/* Multiplication */
DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sm_multiply_sv)(
    DLBLAS_PUB(sparse_matrix_t) * mat, DLBLAS_PUB(sparse_vector_t) * vec)
{
  return NULL;
}


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sm_multiply_dv)(
    DLBLAS_PUB(sparse_matrix_t) * mat, DLBLAS_PUB(dense_vector_t) * vec)
{
  size_t i,j,k;
  if (mat->nner < 0) {
    DLBLAS_PUB(sm_update_nner)(mat);
  }
  DLBLAS_PUB(sparse_vector_t) * res =
    DLBLAS_PUB(sv_init)(mat->n,mat->nner);
  for (k=i=0;i<mat->n;++i) {
    if (mat->ptr[i+1] > mat->ptr[i]) {
      res->val[k] = 0;
      for(j=mat->ptr[i];j<mat->ptr[i+1];++j) {
        res->val[k] += mat->val[j]*vec->val[mat->ind[j]];
      }
      res->ind[k++] = i;
    }
  }
  return res;
}


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sv_multiply_sm)(
    DLBLAS_PUB(sparse_vector_t) * vec, DLBLAS_PUB(sparse_matrix_t) * mat)
{
  return DLBLAS_PUB(sm_transmult_sv)(mat,vec);
}


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sm_transmult_sv)(
    DLBLAS_PUB(sparse_matrix_t) * mat, DLBLAS_PUB(sparse_vector_t) * vec)
{
  DL_ASSERT(vec->nnz >= 0,"Cannot multiply a vector with < 0 nnz\n");
  size_t i,j,k;
  DLBLAS_PUB(sparse_vector_t) * res;
  DLBLAS_TYPE_T * hashvec = DLBLAS_PUB(init_alloc)(0.0,mat->m);
  for(i=0;i<(size_t)vec->nnz;++i) {
    k = vec->ind[i];
    for (j=mat->ptr[k];j<mat->ptr[k+1];++j) {
      hashvec[mat->ind[j]] += vec->val[i]*mat->val[j];
    }
  }
  res = DLBLAS_PUB(sv_init)(mat->m,mat->nnec);
  for (k=i=0;i<mat->m;++i) {
    if (hashvec[i] != 0) {
      res->val[k] = hashvec[i];
      res->ind[k++] = i;
    }
  }
  dl_free(hashvec);
  return res;
}


DLBLAS_PUB(sparse_vector_t) * DLBLAS_PUB(sv_transmult_sm)(
    DLBLAS_PUB(sparse_vector_t) * vec, DLBLAS_PUB(sparse_matrix_t) * mat)
{
  return NULL;
}


/* Free */
void DLBLAS_PUB(sm_free)(DLBLAS_PUB(sparse_matrix_t) * mat)
{
  dl_free(mat->ind);
  dl_free(mat->val);
  dl_free(mat->ptr);
  dl_free(mat);
}


void DLBLAS_PUB(sv_free)(DLBLAS_PUB(sparse_vector_t) * vec)
{
  dl_free(vec->ind);
  dl_free(vec->val);
  dl_free(vec);
}


void DLBLAS_PUB(dm_free)(DLBLAS_PUB(dense_matrix_t) * mat)
{
  if (mat->val != NULL) {
    dl_free(mat->val[0]);
    dl_free(mat->val);
  }
  dl_free(mat);
}


void DLBLAS_PUB(dv_free)(DLBLAS_PUB(dense_vector_t) * vec)
{
  dl_free(vec->val);
  dl_free(vec);
}




#undef __DLBLAS_PRE1
#undef __DLBLAS_PRE2
#undef DLBLAS_PUB

