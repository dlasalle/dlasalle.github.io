/**
 * @file dlbuffer_headers.h
 * @brief Buffer function prototypes
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-10-04
 */


/* prefixing ugliness */
#define DLBUFFER_PRE2(prefix,suffix) prefix ## _ ## suffix
#define DLBUFFER_PRE1(prefix,suffix) DLBUFFER_PRE2(prefix,suffix)
#define DLBUFFER_PUB(name) DLBUFFER_PRE1(DLBUFFER_PREFIX,name)
#define DLBUFFER_PRI(name) DLBUFFER_PRE1(_,DLBUFFER_PRE1(DLBUFFER_PREFIX,name))


typedef struct DLBUFFER_PUB(buffer_t) {
  size_t size;
  size_t maxsize;
  size_t defsize;
  DLBUFFER_TYPE_T * elements;
} DLBUFFER_PUB(buffer_t);


#ifndef DLBUFFER_STATIC



DLBUFFER_PUB(buffer_t) * DLBUFFER_PUB(buffer_init)(size_t size,
    DLBUFFER_PUB(buffer_t) * b);


DLBUFFER_PUB(buffer_t) * DLBUFFER_PUB(buffer_create)(size_t size);


size_t DLBUFFER_PUB(buffer_add)(DLBUFFER_TYPE_T val, 
    DLBUFFER_PUB(buffer_t) * b);


size_t DLBUFFER_PUB(buffer_clear)(DLBUFFER_PUB(buffer_t) * b);


size_t DLBUFFER_PUB(buffer_reset)(DLBUFFER_PUB(buffer_t) * b);


void DLBUFFER_PUB(buffer_free)(DLBUFFER_PUB(buffer_t) * b);


#undef DLBUFFER_PRE2
#undef DLBUFFER_PRE1
#undef DLBUFFER_PUB
#undef DLBUFFER_PRI


#else


#define DLBUFFER_VISIBILITY static
#include "dlbuffer_funcs.h"
#undef DLBUFFER_VISIBILITY


#undef DLBUFFER_PRE2
#undef DLBUFFER_PRE1
#undef DLBUFFER_PUB
#undef DLBUFFER_PRI

#endif


