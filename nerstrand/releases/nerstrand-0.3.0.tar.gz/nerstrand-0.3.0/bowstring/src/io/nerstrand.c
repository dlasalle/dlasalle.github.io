/**
 * @file nerstrand.c
 * @brief Functions for reading and writing graphs in the Nerstrand graph
 * format.
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2014-02-13
 */




#ifndef BOWSTRING_IO_NERSTRAND_C
#define BOWSTRING_IO_NERSTRAND_C




#include "nerstrand.h"




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const size_t BUFFERSIZE = 0x1000;
static const char COMMENT_CHARS[256] = {
  ['#']=1,
  ['%']=1,
  ['\'']=1,
  ['"']=1,
  ['/']=1
};




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int write_nerstrand_graph(const char * const filename, const vtx_t nvtxs, 
    const adj_t * const xadj, const vtx_t * const adjncy, 
    const wgt_t * const vwgt, const wgt_t * const adjwgt)
{
  int rv;
  file_t * file;
  size_t i, j;

  int do_vwgt, do_adjwgt, iflags;

  int wgt_flags = 0;
  do_vwgt = do_adjwgt = 0;

  const adj_t nedges = xadj[nvtxs];

  /* check if we should write the weights */
  if (vwgt) {
    for (i=0;i<nvtxs;++i) {
      if (vwgt[i] != 1.0) {
        break;
      }
    }
    if (i < nvtxs) {
      wgt_flags |= VWGT_FLAG;
      do_vwgt = 1;
    }
  }
  if (adjwgt) {
    for (i=0;i<nvtxs;++i) {
      if (adjwgt[i] != 1.0) {
        break;
      }
    }
    if (i < nvtxs) {
      wgt_flags |= ADJWGT_FLAG;
      do_adjwgt = 1;
    }
  }

  if ((rv = __open_file(filename,"w",&file)) != BOWSTRING_SUCCESS) {
    return rv;
  }

  /* print the header line */
  fprintf(file,"%zu %zu",(size_t)nvtxs,(size_t)(nedges/2));
  iflags = __flag_to_int(wgt_flags);
  if (iflags) {
    fprintf(file," %d\n",iflags);
  } else {
    fprintf(file,"\n");
  }

  /* print out the graph */
  for (i=0;i<nvtxs;++i) {
    if (do_vwgt) {
      fprintf(file,"%lf ",(double)vwgt[i]);
    }
    for (j=(size_t)xadj[i];j<(size_t)xadj[i+1];++j) {
      fprintf(file,"%zu ",(size_t)(adjncy[j]+1));
      if (do_adjwgt) {
        fprintf(file,"%lf ",(double)adjwgt[j]);
      }
    }
    fprintf(file,"\n");
  }
  dl_close_file(file);

  return BOWSTRING_SUCCESS;
}


int read_nerstrand_clustering(const char * const filename, vtx_t * const r_nvtxs, 
    vlbl_t ** const r_labels)
{
  file_t * file;
  vtx_t nl;
  vlbl_t l;
  int rv;
  ssize_t ll;
  size_t bufsize;
  char * line;

  vlbl_t * labels = NULL;

  bufsize = BUFFERSIZE;

  if ((rv = __open_file(filename,"r",&file)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }
  line = char_alloc(bufsize);
  ll = dl_get_next_line(file,&line,&bufsize);
  /* skip comments */
  while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
    ll = dl_get_next_line(file,&line,&bufsize);
  }
  if (!r_nvtxs || *r_nvtxs == 0) {
    /* determine the size of the file */
    nl = 0;
    while (ll > 0 && sscanf(line,PF_VLBL_T,&l) == 1) {
      ++nl; 
      ll = dl_get_next_line(file,&line,&bufsize);
    }
    dl_reset_file(file);
    ll = dl_get_next_line(file,&line,&bufsize);
    /* skip comments */
    while (ll > 0 && COMMENT_CHARS[(unsigned int)line[0]]) {
      ll = dl_get_next_line(file,&line,&bufsize);
    }
  } else {
    /* the size of the file was specified */
    nl = *r_nvtxs;
  }
  labels = vlbl_alloc(nl);
  nl = 0;
  /* read in the file */
  while (ll > 0 && sscanf(line,PF_VLBL_T,&l) == 1) {
    labels[nl++] = l;
    ll = dl_get_next_line(file,&line,&bufsize);
  }
  if (r_nvtxs) {
    *r_nvtxs = nl;
  }

  dl_free(line);

  if (r_labels) {
    *r_labels = labels;
  } else {
    dl_free(labels);
  }

  return BOWSTRING_SUCCESS; 

  ERROR:

  if (line) {
    dl_free(line);
  } 
  if (labels) {
    dl_free(labels);
  }

  return rv;
}


int write_nerstrand_clustering(const char * const filename, const vtx_t nvtxs, 
    const vlbl_t * const labels)
{
  int rv;
  vtx_t i;
  file_t * file = NULL;

  if ((rv = __open_file(filename,"w",&file)) != BOWSTRING_SUCCESS) {
    goto ERROR;
  }

  for (i=0;i<nvtxs;++i) {
    fprintf(file,PF_VLBL_T"\n",labels[i]);
  }

  dl_close_file(file);
  file = NULL;

  return BOWSTRING_SUCCESS;

  ERROR:

  if (file) {
    dl_close_file(file);
  }

  return rv;
}





#endif
