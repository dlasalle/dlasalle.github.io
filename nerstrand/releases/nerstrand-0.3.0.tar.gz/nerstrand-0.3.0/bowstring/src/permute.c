/**
 * @file permute.c
 * @brief Permutation functions
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-07-18
 */


#ifndef PERMUTE_C
#define PERMUTE_C

#include "permute.h"


int permute_graph(const size_t nvtxs, adj_t * const xadj, vtx_t * const adjncy,
    wgt_t * const vwgt, wgt_t * const adjwgt)
{
  /* generate my permutation array */
  vtx_t * perm = vtx_alloc(nvtxs);

  vtx_incset(perm,0,1,nvtxs);
  dl_init_rand();
  perm = vtx_shuffle(perm,nvtxs);

  reorder_graph(nvtxs,xadj,adjncy,vwgt,adjwgt,perm);
  dl_free(perm);

  return BOWSTRING_SUCCESS;
}

#ifdef XXX
int order_graph(graph_t * const graph)
{
  const sint_t nvtxs = graph->nvtxs;
  const sint_t nedges = graph->nedges;

  const sint_t * const xadj = graph->xadj;
  const sint_t * const vwgt = graph->vwgt;
  const sint_t * const adjncy = graph->adjncy;
  const sint_t * const adjwgt = graph->adjwgt;

  sint_t pid, aid, eid, i,j,k,l;
  sint_t * perm = sint_alloc(nvtxs);
  sint_t * in = sint_init_alloc(0,nvtxs);

  l = 0;
  aid = pid = 0;
  while (aid < nvtxs) { /* loop through each connected component */
    for (i=l;in[i];++i); /* find the first un-added vertex */
    l = i;
    in[i] = 1;
    perm[aid++] = i;
    while (pid < aid) {
      /* go through each vertex on this level */
      for (eid=aid;pid<eid;++pid) {
        i = perm[pid];
        for (j=xadj[i];j<xadj[i+1];++j) {
          k = adjncy[j];
          if (!in[k]) {
            perm[aid++] = k;
            in[k] = 1;
          }
        }
      }
    }
  }

  graph_t * rgraph = reorder_graph(graph,perm);
  dl_free(perm);
  dl_free(in);
  return rgraph; 
}
#endif


int reorder_graph(const size_t nvtxs, adj_t * const xadj, vtx_t * const adjncy,
    wgt_t * const vwgt, wgt_t * const adjwgt, const vtx_t * const perm) 
{
  size_t i, j, k, pi;
  const size_t nedges = xadj[nvtxs];

  /* allocate my permuted junk */
  adj_t * rxadj = adj_alloc(nvtxs+1);
  vtx_t * radjncy = vtx_alloc(nedges);

  wgt_t * rvwgt = NULL, * radjwgt = NULL; 
  if (vwgt) {
    rvwgt = wgt_alloc(nvtxs);
  }
  if (adjwgt) {
    radjwgt = wgt_alloc(nedges);
  }

  vtx_t * rename = vtx_alloc(nvtxs);
  
  /* permute the xadj and the vwgt */
  rxadj[0] = 0;
  for (i=0;i<nvtxs;++i) {
    pi = perm[i];
    rename[pi] = i;
    rxadj[i+1] = (xadj[pi+1]-xadj[pi]) + rxadj[i];
    if (vwgt) {
      rvwgt[i] = vwgt[pi];
    }
  }

  /* permute the adjncy and adjwgt */
  k = 0;
  for (i=0;i<nvtxs;++i) {
    pi = perm[i];
    for (j=(size_t)xadj[pi];j<(size_t)xadj[pi+1];++j) {
      radjncy[k] = rename[adjncy[j]];
      if (adjwgt) {
        radjwgt[k] = adjwgt[j];
      }
      ++k;
    }
  }

  dl_free(rename);

  adj_copy(xadj,rxadj,nvtxs+1);
  vtx_copy(adjncy,radjncy,nedges);
  dl_free(rxadj);
  dl_free(radjncy);
  
  if (vwgt) {
    wgt_copy(vwgt,rvwgt,nvtxs);
    dl_free(rvwgt);
  }

  if (adjwgt) {
    wgt_copy(adjwgt,radjwgt,nedges);
    dl_free(radjwgt);
  }

  return BOWSTRING_SUCCESS;
}

#endif

