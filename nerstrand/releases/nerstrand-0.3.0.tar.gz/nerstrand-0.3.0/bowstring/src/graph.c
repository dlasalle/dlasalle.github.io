/**
 * @file graph.c
 * @brief Functions for performing misc graph operations
 * @author Dominique LaSalle <lasalle@cs.umn.edu>
 * Copyright 2013
 * @version 1
 * @date 2013-08-07
 */


#ifndef GRAPH_C
#define GRAPH_C


#include "graph.h"




/******************************************************************************
* CONSTANTS *******************************************************************
******************************************************************************/


static const vtx_t UNASSIGNED = (vtx_t)-1;
static const vtx_t QUEUED = (vtx_t)-2;




/******************************************************************************
* PRIVATE FUNCTIONS ***********************************************************
******************************************************************************/


static int __check_radj(const adj_t nedges, const adj_t * const radj)
{
  adj_t j;

  for (j=0;j<nedges;++j) {
    if (radj[radj[j]] != j) {
      eprintf("Bad reverse adjacency list j = "PF_ADJ_T", radj[j] = "PF_ADJ_T
          ", radj[radj[j]] = "PF_ADJ_T"\n",j,radj[j],radj[radj[j]]);
      return 0;
    }
  }

  return 1;
}




/******************************************************************************
* PUBLIC FUNCTIONS ************************************************************
******************************************************************************/


int apply_edge_mask(const vtx_t nvtxs, const adj_t * const gxadj, 
    const vtx_t * const gadjncy, const wgt_t * const gadjwgt, 
    const int * const adjmask, adj_t ** const r_xadj, vtx_t ** const r_adjncy, 
    wgt_t ** const r_adjwgt) 
{
  vtx_t i;
  adj_t j, tnedges;
  adj_t * xadj = NULL;
  vtx_t * adjncy = NULL;
  wgt_t * adjwgt = NULL;

  const adj_t nedges = int_sum(adjmask,gxadj[nvtxs]);

  xadj = adj_alloc(nvtxs+1);
  if (gadjncy) {
    adjncy = vtx_alloc(nedges);
  }
  if (gadjwgt) {
    adjwgt = wgt_alloc(nedges); 
  }
  tnedges = xadj[0] = 0;
  if (adjwgt) {
    if (adjncy) {
      for (i=0;i<nvtxs;++i) {
        for (j=gxadj[i];j<gxadj[i+1];++j) {
          if (adjmask[j]) {
            adjncy[tnedges] = gadjncy[j];
            adjwgt[tnedges] = gadjwgt[j];
            ++tnedges;
          }
        }
        xadj[i+1] = tnedges;
      }
    } else {
      for (i=0;i<nvtxs;++i) {
        for (j=gxadj[i];j<gxadj[i+1];++j) {
          if (adjmask[j]) {
            adjwgt[tnedges++] = gadjwgt[j];
          }
        }
        xadj[i+1] = tnedges;
      }
    }
  } else {
    if (adjncy) {
      for (i=0;i<nvtxs;++i) {
        for (j=gxadj[i];j<gxadj[i+1];++j) {
          if (adjmask[j]) {
            adjncy[tnedges++] = gadjncy[j];
          }
        }
        xadj[i+1] = tnedges;
      }
    } else {
      for (i=0;i<nvtxs;++i) {
        for (j=gxadj[i];j<gxadj[i+1];++j) {
          if (adjmask[j]) {
            ++tnedges;
          }
        }
        xadj[i+1] = tnedges;
      }
    }
  }

  if (r_xadj) {
    *r_xadj = xadj;
  } else if (xadj) {
    dl_free(xadj);
  }
  if (r_adjncy) {
    *r_adjncy = adjncy;
  } else if (adjncy) {
    dl_free(adjncy);
  }
  if (r_adjwgt) {
    *r_adjwgt = adjwgt;
  } else if (adjwgt) {
    dl_free(adjwgt);
  }
  
  return BOWSTRING_SUCCESS;
}


wgt_t calc_edge_cut(const vtx_t nvtxs, const adj_t * const xadj, 
    const vtx_t * const adjncy, const wgt_t * const adjwgt, 
    const vlbl_t * const where)
{
  vtx_t i,k;
  adj_t j;
  wgt_t cut, partcut;

  cut = 0.0;

  for (i=0;i<nvtxs;++i) {
    partcut = 0.0;
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (where[i] != where[k]) {
        if (adjwgt) {
          partcut += adjwgt[j];
        } else {
          partcut += 1.0;
        }
      }
    }
    cut += (partcut/2.0);
  }

  return cut;
}


vtx_t mark_boundary_vertices(const vtx_t nvtxs, const adj_t * const xadj, 
    const vtx_t * const adjncy, const vlbl_t * const where, int * const bnd)
{
  vtx_t i, k, nbnd;
  adj_t j;
  vlbl_t w;

  nbnd = 0;
  for (i=0;i<nvtxs;++i) {
    w = where[i];
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (w != where[k]) {
        if (bnd) {
          bnd[i] = 1;
        }         
        ++nbnd;
      } else {
        if (bnd) {
          bnd[i] = 0;
        }
      }
    }
  }

  return nbnd;
}


vtx_t find_boundary_vertices(const vtx_t nvtxs, const adj_t * const xadj, 
    const vtx_t * const adjncy, const vlbl_t * const where, 
    vtx_t ** const r_bnd)
{
  vtx_t i, k, nbnd;
  adj_t j;
  vlbl_t w;

  vtx_t * bnd = NULL;

  if (r_bnd) {
    bnd = vtx_alloc(nvtxs);
  }

  nbnd = 0;
  for (i=0;i<nvtxs;++i) {
    w = where[i];
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (w != where[k]) {
        if (r_bnd) {
          bnd[nbnd++] = i;
        } else {
          ++nbnd;
        }
      }
    }
  }

  if (r_bnd) {
    *r_bnd = vtx_realloc(bnd,nbnd);
  }

  return nbnd;
}


int build_adjacency_index(const vtx_t nvtxs, const adj_t * const xadj,
    const vtx_t * const adjncy, adj_t * const radj)
{
  vtx_t i, k;
  adj_t j;
  vtx_t * trans;
  adj_t * txadj, * tadj, * padj;

  const adj_t nedges = xadj[nvtxs];

  /* build the radj array */
  txadj = adj_duplicate(xadj,nvtxs+1);
  tadj = adj_alloc(nedges); 
  /* initial pass for tadj and radj */
  for (i=0;i<nvtxs;++i) {
    /* for each vertex */
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      if (i < k) {
        radj[txadj[i]] = k;
        tadj[txadj[i]] = txadj[k];
        radj[txadj[k]] = i;
        tadj[txadj[k]] = txadj[i];
        ++txadj[k];
        ++txadj[i];
      }
    }
  }
  dl_free(txadj);

  trans = vtx_alloc(nvtxs);
  padj = adj_alloc(nedges);
  /* turn tadj into a translate array */
  for (i=0;i<nvtxs;++i) {
    /* write new indices */
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = adjncy[j];
      trans[k] = j;
    }
    /* read new indices from old indices */
    for (j=xadj[i];j<xadj[i+1];++j) {
      k = radj[j];
      padj[j] = trans[k];
    }
  }
  dl_free(trans);
  /* correct radj -- save it to tadj */
  for (i=0;i<nvtxs;++i) {
    for (j=xadj[i];j<xadj[i+1];++j) {
      radj[padj[j]] = padj[tadj[j]];
    }
  }

  dl_free(padj);
  dl_free(tadj);

  DL_ASSERT(__check_radj(nedges,radj) == 1,"Bad radj generated\n");

  return BOWSTRING_SUCCESS;
}


vtx_t neighborhoodify(const vtx_t nvtxs, const adj_t * const xadj, 
    const vtx_t * const adjncy, vtx_t * const nbrhd, const vtx_t nbrsize)
{
  vtx_t i, p, k, nnbrhd, nnbr, nbr, nq; 
  adj_t j;
  vtx_t * perm, * q;
  
  vtx_set(nbrhd,UNASSIGNED,nvtxs);
  q = vtx_alloc(nvtxs);
  perm = vtx_alloc(nvtxs);
  vtx_incset(perm,0,1,nvtxs);
  vtx_pseudo_shuffle(perm,nvtxs/16,nvtxs);

  nnbrhd = 0;
  for (p=0;p<nvtxs;++p) {
    i = perm[p];
    if (nbrhd[i] == UNASSIGNED) {
      nnbr = nq = 0;
      nbr = nnbrhd++;
      q[nq++] = i;
      while (nnbr < nq && nnbr < nbrsize) {
        i = q[nnbr++];
        nbrhd[i] = nbr;
        for (j=xadj[i];j<xadj[i+1];++j) {
          k = adjncy[j];
          if (nbrhd[k] == UNASSIGNED) {
            q[nq++] = k;
            nbrhd[k] = QUEUED;
          }
          if (nq >= nbrsize) {
            break;
          }
        }
      }
      /* clear nodes left in queue */
      while (nnbr < nq) {
        nbrhd[q[nnbr++]] = UNASSIGNED;
      }
    }
  }

  dl_free(perm);

  return nnbrhd;
}



#endif
